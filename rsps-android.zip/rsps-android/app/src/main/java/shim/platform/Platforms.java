package shim.platform;

public final class Platforms {
    private Platforms() {}
    public static volatile Platform current = new NullPlatform();

    /** Receives client-reported errors and exit requests (for diagnostics on devices). */
    public interface Sink { void log(String text); }
    public static volatile Sink sink;

    public static void error(String message, Throwable t) {
        Sink s = sink;
        if (s == null) return;
        StringBuilder b = new StringBuilder();
        if (message != null) b.append(message).append('\n');
        if (t != null) {
            java.io.StringWriter sw = new java.io.StringWriter();
            t.printStackTrace(new java.io.PrintWriter(sw));
            b.append(sw);
        }
        s.log(b.toString());
    }

    /** Replacement for System.exit in the client: logs who asked, then exits. */
    public static void exit(int code) {
        error("client requested exit(" + code + ") from:", new Throwable("exit"));
        try { Thread.sleep(300); } catch (InterruptedException e) { }
        System.exit(code);
    }
}
