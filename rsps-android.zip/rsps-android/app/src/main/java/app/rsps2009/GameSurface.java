package app.rsps2009;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

import rt4.Camera;

/** The game's drawing surface. Also turns touches into mouse/camera input and hosts the soft keyboard. */
public class GameSurface extends SurfaceView {

    private static final long LONG_PRESS_MS = 420;

    private enum State { IDLE, PENDING, DRAGGING, LONG, CAMERA, IGNORE }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final float touchSlop;
    private final float density;
    private float scale = 1f;

    private State state = State.IDLE;
    private float downX, downY, lastX, lastY;
    // two-finger camera gesture
    private float camCx, camCy, camDist;
    private float wheelAccum;

    private final Runnable longPress = new Runnable() {
        @Override public void run() {
            if (state == State.PENDING) {
                state = State.LONG;
                GameEvents.move(downX, downY);
                GameEvents.press(downX, downY, shim.awt.event.MouseEvent.BUTTON3);
                GameEvents.release(downX, downY, shim.awt.event.MouseEvent.BUTTON3);
                performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
            }
        }
    };

    public GameSurface(Context context) {
        super(context);
        density = context.getResources().getDisplayMetrics().density;
        touchSlop = 10 * density;
        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    public void setRenderScale(float s) { scale = s; GameEvents.setScale(s); }

    // ----------------------------------------------------------------- touch

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = e.getX();
                downY = lastY = e.getY();
                state = State.PENDING;
                GameEvents.move(downX, downY);
                handler.postDelayed(longPress, LONG_PRESS_MS);
                return true;

            case MotionEvent.ACTION_POINTER_DOWN:
                if (e.getPointerCount() == 2) {
                    handler.removeCallbacks(longPress);
                    if (state == State.DRAGGING) {
                        GameEvents.release(lastX, lastY, shim.awt.event.MouseEvent.BUTTON1);
                    }
                    state = State.CAMERA;
                    camCx = (e.getX(0) + e.getX(1)) / 2f;
                    camCy = (e.getY(0) + e.getY(1)) / 2f;
                    camDist = dist(e);
                    wheelAccum = 0;
                } else {
                    state = State.IGNORE;
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                if (state == State.CAMERA && e.getPointerCount() >= 2) {
                    float cx = (e.getX(0) + e.getX(1)) / 2f;
                    float cy = (e.getY(0) + e.getY(1)) / 2f;
                    float dx = (cx - camCx) / scale;
                    float dy = (cy - camCy) / scale;
                    camCx = cx;
                    camCy = cy;
                    Camera.yawTarget -= dx * 1.6;
                    Camera.pitchTarget += dy * 1.0;
                    Camera.clampCameraAngle();
                    float d = dist(e);
                    wheelAccum += (camDist - d) / (40f * density);
                    camDist = d;
                    int steps = (int) wheelAccum;
                    if (steps != 0) {
                        wheelAccum -= steps;
                        GameEvents.wheel(cx, cy, steps);
                    }
                    return true;
                }
                if (e.getPointerCount() == 1) {
                    float x = e.getX(), y = e.getY();
                    if (state == State.PENDING) {
                        float ddx = x - downX, ddy = y - downY;
                        if (ddx * ddx + ddy * ddy > touchSlop * touchSlop) {
                            handler.removeCallbacks(longPress);
                            GameEvents.press(downX, downY, shim.awt.event.MouseEvent.BUTTON1);
                            state = State.DRAGGING;
                            GameEvents.drag(x, y);
                        }
                    } else if (state == State.DRAGGING) {
                        GameEvents.drag(x, y);
                    }
                    lastX = x;
                    lastY = y;
                }
                return true;

            case MotionEvent.ACTION_POINTER_UP:
                if (state == State.CAMERA) {
                    state = State.IGNORE; // wait until all fingers lift
                }
                return true;

            case MotionEvent.ACTION_UP:
                handler.removeCallbacks(longPress);
                if (state == State.PENDING) {
                    GameEvents.move(downX, downY);
                    GameEvents.press(downX, downY, shim.awt.event.MouseEvent.BUTTON1);
                    GameEvents.release(downX, downY, shim.awt.event.MouseEvent.BUTTON1);
                } else if (state == State.DRAGGING) {
                    GameEvents.release(e.getX(), e.getY(), shim.awt.event.MouseEvent.BUTTON1);
                }
                state = State.IDLE;
                return true;

            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(longPress);
                if (state == State.DRAGGING) {
                    GameEvents.release(lastX, lastY, shim.awt.event.MouseEvent.BUTTON1);
                }
                state = State.IDLE;
                return true;

            default:
                return true;
        }
    }

    private static float dist(MotionEvent e) {
        float dx = e.getX(0) - e.getX(1), dy = e.getY(0) - e.getY(1);
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    // -------------------------------------------------------------- keyboard

    @Override
    public boolean onCheckIsTextEditor() { return true; }

    @Override
    public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
        outAttrs.inputType = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
        outAttrs.imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI | EditorInfo.IME_FLAG_NO_FULLSCREEN | EditorInfo.IME_ACTION_NONE;
        return new BaseInputConnection(this, false) {
            @Override public boolean commitText(CharSequence text, int newCursorPosition) {
                GameEvents.typeText(text);
                return true;
            }
            @Override public boolean setComposingText(CharSequence text, int newCursorPosition) {
                return true; // composing is flushed through commitText
            }
            @Override public boolean deleteSurroundingText(int beforeLength, int afterLength) {
                for (int i = 0; i < Math.max(1, beforeLength); i++) GameEvents.controlKey(shim.awt.event.KeyEvent.VK_BACK_SPACE, '\b');
                return true;
            }
            @Override public boolean sendKeyEvent(KeyEvent event) {
                return GameEvents.androidKey(event.getKeyCode(), event.getUnicodeChar(), event.getAction() == KeyEvent.ACTION_DOWN);
            }
            @Override public boolean performEditorAction(int actionCode) {
                GameEvents.typeChar('\n');
                return true;
            }
        };
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (GameEvents.androidKey(keyCode, event.getUnicodeChar(), true)) return true;
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (GameEvents.androidKey(keyCode, event.getUnicodeChar(), false)) return true;
        return super.onKeyUp(keyCode, event);
    }
}
