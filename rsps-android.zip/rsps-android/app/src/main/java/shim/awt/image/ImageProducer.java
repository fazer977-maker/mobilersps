package shim.awt.image;

public interface ImageProducer {
}
