package rt4;

import com.jogamp.opengl.GL2;

/**
 * Shared safety for the Rainbow Scape screen effects (sky, day/night, glow, weather, lamps).
 * - Every effect starts on texture unit 0, so it never binds or copies into the game's second unit
 *   (where fonts and sprites keep their clip masks).
 * - Effect textures are rebuilt whenever the game restarts its renderer (generation changes), so old
 *   texture numbers are never used for something that now belongs to the game (fonts, icons).
 * - If an effect fails half way, the GL state it changed is put back before the interface is drawn.
 */
final class FxGl {
    private FxGl() {}

    /** switch to unit 0 for an effect drawn in the middle of the scene; returns what to put back */
    static int enter(GL2 gl) {
        int saved = GL2.activeUnit() | (GL2.clientUnit() << 4);
        unit0(gl);
        return saved;
    }

    static void leave(GL2 gl, int saved) {
        if (saved < 0) return;
        if ((saved & 15) != 0) gl.glActiveTexture(GL2.GL_TEXTURE0 + (saved & 15));
        if ((saved >> 4) != 0) gl.glClientActiveTexture(GL2.GL_TEXTURE0 + (saved >> 4));
    }

    static void unit0(GL2 gl) {
        gl.glActiveTexture(GL2.GL_TEXTURE0);
        gl.glClientActiveTexture(GL2.GL_TEXTURE0);
    }

    /** puts back the usual state after an effect threw part way through */
    static void recover(GL2 gl) {
        try {
            unit0(gl);
            int vw = (int) (GlRenderer.canvasWidth * GameShell.canvasScale + GameShell.subpixelX);
            int vh = (int) (GlRenderer.canvasHeight * GameShell.canvasScale + GameShell.subpixelY);
            if (vw > 0 && vh > 0) gl.glViewport(0, 0, vw, vh);
            gl.glDisableClientState(GL2.GL_COLOR_ARRAY);
            gl.glDisableClientState(GL2.GL_TEXTURE_COORD_ARRAY);
            gl.glEnable(GL2.GL_CULL_FACE);
            gl.glEnable(GL2.GL_BLEND);
            gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
            gl.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            GlRenderer.setTextureId(-1);
            GlRenderer.enableDepthMask();
            GL2.resetStateCache();
        } catch (Throwable ignored) {
        }
    }
}
