package shim.sound.sampled;

public interface Mixer extends Line {
    class Info {
        private final String name;
        public Info(String name) { this.name = name; }
        public String getName() { return name; }
    }
}
