package app.rsps2009;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import rt4.Mastery;

/**
 * The Mastery window (levels 100 to 1000 after 99): every skill in the stats-tab order on the left with its
 * Mastery level and a thin progress bar, the chosen skill's details on the right (level, progress, perk),
 * a Skill guide button and Close. Opens when the server says so (tapping a 99 skill in the stats tab, or ::mastery).
 * A gold banner flashes on every Mastery level-up. Touches pass through to the game unless the window is open.
 */
final class MasteryView extends View {
    private static final int[] RAINBOW = {0xFFFF3B3B, 0xFFFF9A1E, 0xFFFFE62E, 0xFF4CFF6A, 0xFF2EE6FF, 0xFF4C7DFF, 0xFFC04CFF};
    private static final String[] NAME = {"Attack", "Defence", "Strength", "Hitpoints", "Ranged", "Prayer", "Magic", "Cooking",
            "Woodcutting", "Fletching", "Fishing", "Firemaking", "Crafting", "Smithing", "Mining", "Herblore", "Agility", "Thieving",
            "Slayer", "Farming", "Runecrafting", "Hunter", "Construction", "Summoning"};
    /** stats tab order, 3 columns */
    private static final int[] ORDER = {0, 3, 14, 2, 16, 13, 1, 15, 10, 4, 17, 7, 5, 12, 11, 6, 9, 8, 20, 18, 19, 22, 21, 23};

    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Typeface bold = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD);
    private Typeface pixel;
    private final RectF card = new RectF(), guideBtn = new RectF(), closeBtn = new RectF();
    private final RectF[] cells = new RectF[24];
    private boolean open, allowed, pressedGuide, pressedClose;
    private int sel = -1, seenOpen, seenUp;
    private long upAt, openedAt;
    private int upSkill, upLevel;

    MasteryView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        try { pixel = Typeface.createFromAsset(c.getAssets(), "silkscreen.ttf"); } catch (Throwable t) { pixel = bold; }
        for (int i = 0; i < 24; i++) cells[i] = new RectF();
        seenOpen = Mastery.openVersion; seenUp = Mastery.upVersion;
        setVisibility(GONE);
    }

    /** UI poller (every 50 ms) */
    void sync(boolean ok) {
        allowed = ok;
        long now = System.currentTimeMillis();
        if (Mastery.openVersion != seenOpen) {
            seenOpen = Mastery.openVersion;
            if (ok) { open = true; openedAt = now; int s = Mastery.openSkill; sel = s >= 0 && s < 24 ? s : firstMastered(); }
        }
        if (Mastery.upVersion != seenUp) { seenUp = Mastery.upVersion; upAt = now; upSkill = Mastery.upSkill; upLevel = Mastery.upLevel; }
        if (!ok) open = false;
        boolean banner = ok && upAt > 0 && now - upAt < 3800;
        boolean vis = open || banner;
        if ((getVisibility() == VISIBLE) != vis) setVisibility(vis ? VISIBLE : GONE);
        if (vis) invalidate();
    }

    private static int firstMastered() {
        int best = -1, bl = 0;
        for (int i = 0; i < 24; i++) if (Mastery.level[i] > bl) { bl = Mastery.level[i]; best = i; }
        return best;
    }

    private static String perk(int s, int over) {
        String f02 = String.format("%.1f", over * 0.02), f03 = String.format("%.1f", over * 0.03);
        switch (s) {
            case 0: return "+" + f02 + "% accuracy";
            case 2: return "+" + f02 + "% max hit";
            case 1: return "+" + f02 + "% defence";
            case 4: return "+" + f02 + "% ranged accuracy and damage";
            case 6: return "+" + f02 + "% magic accuracy";
            case 3: return "+" + f02 + "% healing";
            case 5: return "-" + f03 + "% prayer drain";
            case 14: case 8: case 10: return f03 + "% chance of double resources";
            default: return "Perk arrives with this skill's first Mastery tier";
        }
    }

    private void text(Canvas c, String s, float x, float y, int color) {
        int a = p.getAlpha();
        p.setColor(0xFF000000); p.setAlpha(a); c.drawText(s, x + d, y + d, p);
        p.setColor(color); p.setAlpha(a); c.drawText(s, x, y, p);
    }

    @Override protected void onDraw(Canvas c) {
        long now = System.currentTimeMillis();
        float W = getWidth(), H = getHeight();
        if (open) drawWindow(c, W, H, now);
        if (upAt > 0 && now - upAt < 3800) drawBanner(c, W, H, now);
    }

    private void drawBanner(Canvas c, float W, float H, long now) {
        long t = now - upAt;
        float a = t < 250 ? t / 250f : t > 3000 ? (3800 - t) / 800f : 1f;
        String s = "★ " + (upSkill >= 0 && upSkill < 24 ? NAME[upSkill].toUpperCase() : "") + " MASTERY " + upLevel + " ★";
        p.setShader(null); p.setTypeface(pixel); p.setTextAlign(Paint.Align.CENTER);
        float size = (upLevel % 100 == 0 ? 24 : 18) * d * (t < 250 ? 0.7f + 0.3f * a : 1f);
        p.setTextSize(size);
        float y = H * 0.30f;
        float tw = p.measureText(s);
        RectF r = new RectF(W / 2 - tw / 2 - 14 * d, y - size - 6 * d, W / 2 + tw / 2 + 14 * d, y + 10 * d);
        p.setStyle(Paint.Style.FILL); p.setColor(0xD0140A00); p.setAlpha((int) (210 * a));
        c.drawRoundRect(r, 10 * d, 10 * d, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2 * d); p.setColor(0xFFFFB000); p.setAlpha((int) (255 * a));
        c.drawRoundRect(r, 10 * d, 10 * d, p);
        p.setStyle(Paint.Style.FILL);
        p.setAlpha((int) (255 * a)); p.setColor(0xFF000000); p.setAlpha((int) (255 * a));
        c.drawText(s, W / 2 + 2 * d, y + 2 * d, p);
        float o = (now % 1600) / 1600f * tw;
        p.setShader(new LinearGradient(W / 2 - tw / 2 - o, 0, W / 2 - tw / 2 - o + tw, 0,
                new int[]{0xFFFFE9A0, 0xFFFFB000, 0xFFFFF6D0, 0xFFFFB000}, null, Shader.TileMode.MIRROR));
        p.setAlpha((int) (255 * a));
        c.drawText(s, W / 2, y, p);
        p.setShader(null); p.setAlpha(255); p.setTextAlign(Paint.Align.LEFT);
    }

    private void drawWindow(Canvas c, float W, float H, long now) {
        float pop = Math.min(1f, (now - openedAt) / 160f);
        p.setShader(null); p.setStyle(Paint.Style.FILL);
        p.setColor(0x99000000); p.setAlpha((int) (153 * pop)); c.drawRect(0, 0, W, H, p); p.setAlpha(255);
        float cw = Math.min(W * 0.92f, 640 * d), ch = Math.min(H * 0.90f, 330 * d);
        float x0 = (W - cw) / 2, y0 = (H - ch) / 2;
        card.set(x0, y0, x0 + cw, y0 + ch);
        p.setColor(0xF0120A1C); c.drawRoundRect(card, 14 * d, 14 * d, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2 * d);
        float off = (now % 4000) / 4000f * cw * 2;
        p.setShader(new LinearGradient(x0 - off, 0, x0 - off + cw, 0, RAINBOW, null, Shader.TileMode.MIRROR));
        c.drawRoundRect(card, 14 * d, 14 * d, p);
        p.setShader(null); p.setStyle(Paint.Style.FILL);

        // header
        p.setTypeface(pixel); p.setTextSize(15 * d);
        float hy = y0 + 24 * d;
        p.setShader(new LinearGradient(x0 + 16 * d - off / 3, 0, x0 + 200 * d - off / 3, 0,
                new int[]{0xFFFFE9A0, 0xFFFFB000, 0xFFFFF6D0}, null, Shader.TileMode.MIRROR));
        c.drawText("MASTERY", x0 + 16 * d, hy, p);
        p.setShader(null);
        int total = 0, maxed = 0;
        for (int i = 0; i < 24; i++) { if (Mastery.level[i] > 99) total += Mastery.level[i] - 99; if (Mastery.level[i] >= 99) maxed++; }
        p.setTypeface(bold); p.setTextSize(10.5f * d);
        String sub = "levels 100 - 1000 after 99     total Mastery " + total + "     skills at 99: " + maxed + "/24";
        text(c, sub, x0 + 16 * d + 118 * d, hy - 1 * d, 0xFFBFB2D6);

        // grid (left)
        float gx = x0 + 12 * d, gy = y0 + 36 * d, gw = cw * 0.56f, gh = ch - 36 * d - 12 * d;
        float colW = gw / 3, rowH = gh / 8;
        for (int k = 0; k < 24; k++) {
            int s = ORDER[k], col = k % 3, row = k / 3;
            RectF r = cells[s];
            r.set(gx + col * colW + 2 * d, gy + row * rowH + 2 * d, gx + (col + 1) * colW - 2 * d, gy + (row + 1) * rowH - 2 * d);
            int m = Mastery.level[s];
            boolean on = s == sel;
            p.setColor(on ? 0xFF3A2350 : m >= 100 ? 0xFF231733 : 0xFF1A1424);
            c.drawRoundRect(r, 6 * d, 6 * d, p);
            if (on) { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f * d); p.setColor(0xFFFFB000); c.drawRoundRect(r, 6 * d, 6 * d, p); p.setStyle(Paint.Style.FILL); }
            float ts = Math.min(10.5f * d, rowH * 0.36f);
            p.setTextSize(ts); p.setTypeface(bold);
            float ty = r.top + (r.height() - 4 * d) / 2 + ts * 0.38f;
            text(c, NAME[s], r.left + 6 * d, ty, m >= 99 ? 0xFFEDE6F7 : 0xFF7D7390);
            p.setTextAlign(Paint.Align.RIGHT);
            String lv = m >= 100 ? "★" + m : m == 99 ? "99" : "-";
            text(c, lv, r.right - 6 * d, ty, m >= 100 ? 0xFFFFB000 : m == 99 ? 0xFFFFFFFF : 0xFF5E566E);
            p.setTextAlign(Paint.Align.LEFT);
            if (m >= 99) {
                float bx0 = r.left + 6 * d, bx1 = r.right - 6 * d, by = r.bottom - 5 * d;
                p.setColor(0xFF0C0812); c.drawRect(bx0, by, bx1, by + 2.5f * d, p);
                float f = m >= 1000 ? 1f : Mastery.progress[s] / 1000f;
                p.setColor(0xFFFFB000); c.drawRect(bx0, by, bx0 + (bx1 - bx0) * f, by + 2.5f * d, p);
            }
        }

        // detail (right)
        float dx = gx + gw + 14 * d, dw = x0 + cw - 14 * d - dx, dy = gy + 4 * d;
        RectF pane = new RectF(dx - 4 * d, gy + 2 * d, dx + dw, y0 + ch - 12 * d);
        p.setColor(0xFF1A1226); c.drawRoundRect(pane, 10 * d, 10 * d, p);
        float lx = dx + 8 * d;
        if (sel < 0) {
            p.setTypeface(bold); p.setTextSize(11.5f * d);
            text(c, "Reach 99 in any skill", lx, dy + 26 * d, 0xFFFFFFFF);
            text(c, "to start its Mastery.", lx, dy + 42 * d, 0xFFFFFFFF);
            p.setTextSize(10 * d);
            text(c, "Every XP you earn after 99 counts.", lx, dy + 66 * d, 0xFFBFB2D6);
            text(c, "Each level gives a small perk,", lx, dy + 81 * d, 0xFFBFB2D6);
            text(c, "and new tiers unlock as you climb.", lx, dy + 96 * d, 0xFFBFB2D6);
        } else {
            int m = Mastery.level[sel];
            p.setTypeface(pixel); p.setTextSize(13 * d);
            text(c, NAME[sel].toUpperCase(), lx, dy + 20 * d, 0xFFFFFFFF);
            p.setTypeface(bold); p.setTextSize(11 * d);
            String l1 = m >= 100 ? "Mastery " + m + " / 1000" : m == 99 ? "Level 99 - Mastery starts now" : "Mastery starts at level 99";
            text(c, l1, lx, dy + 38 * d, m >= 100 ? 0xFFFFB000 : 0xFFBFB2D6);
            if (m >= 99) {
                float bx0 = lx, bx1 = dx + dw - 10 * d, by = dy + 48 * d;
                RectF b = new RectF(bx0, by, bx1, by + 10 * d);
                p.setColor(0xFF0C0812); c.drawRoundRect(b, 4 * d, 4 * d, p);
                float f = m >= 1000 ? 1f : Mastery.progress[sel] / 1000f;
                if (f > 0) {
                    float o2 = (now % 2000) / 2000f * (bx1 - bx0);
                    p.setShader(new LinearGradient(bx0 - o2, 0, bx0 - o2 + (bx1 - bx0), 0,
                            new int[]{0xFFFFB000, 0xFFFFE9A0, 0xFFFFB000}, null, Shader.TileMode.MIRROR));
                    c.drawRoundRect(new RectF(bx0, by, bx0 + (bx1 - bx0) * f, by + 10 * d), 4 * d, 4 * d, p);
                    p.setShader(null);
                }
                p.setTextSize(9.5f * d);
                String pr = m >= 1000 ? "MAXED" : (Mastery.progress[sel] / 10) + "." + (Mastery.progress[sel] % 10) + "% to " + (m + 1);
                text(c, pr, lx, by + 23 * d, 0xFFEDE6F7);
                p.setTextSize(10.5f * d);
                text(c, "Perk now:", lx, by + 42 * d, 0xFFBFB2D6);
                text(c, perk(sel, Math.max(0, m - 99)), lx, by + 57 * d, 0xFFFFFFFF);
                text(c, "At 1000:", lx, by + 76 * d, 0xFFBFB2D6);
                text(c, perk(sel, 901), lx, by + 91 * d, 0xFFFFE9A0);
            }
            // buttons
            float bh = 28 * d, by2 = y0 + ch - 12 * d - bh - 8 * d;
            float half = (dw - 24 * d) / 2;
            guideBtn.set(lx, by2, lx + half, by2 + bh);
            closeBtn.set(lx + half + 8 * d, by2, lx + half * 2 + 8 * d, by2 + bh);
            button(c, guideBtn, "Skill guide", pressedGuide);
        }
        if (sel < 0) {
            float bh = 28 * d, by2 = y0 + ch - 12 * d - bh - 8 * d;
            closeBtn.set(lx, by2, dx + dw - 10 * d, by2 + bh);
            guideBtn.setEmpty();
        }
        button(c, closeBtn, "Close", pressedClose);
    }

    private void button(Canvas c, RectF r, String label, boolean pressed) {
        p.setShader(null); p.setStyle(Paint.Style.FILL);
        p.setColor(pressed ? 0xFF5A3A12 : 0xFF3A2410); c.drawRoundRect(r, 7 * d, 7 * d, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.4f * d); p.setColor(0xFFFFB000); c.drawRoundRect(r, 7 * d, 7 * d, p);
        p.setStyle(Paint.Style.FILL); p.setTypeface(bold); p.setTextSize(11 * d); p.setTextAlign(Paint.Align.CENTER);
        text(c, label, r.centerX(), r.centerY() + 4 * d, 0xFFFFE9A0);
        p.setTextAlign(Paint.Align.LEFT);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (!open) return false;
        float x = e.getX(), y = e.getY();
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            pressedGuide = guideBtn.contains(x, y); pressedClose = closeBtn.contains(x, y);
            invalidate();
        } else if (a == MotionEvent.ACTION_UP) {
            boolean g = pressedGuide && guideBtn.contains(x, y), cl = pressedClose && closeBtn.contains(x, y);
            pressedGuide = pressedClose = false;
            if (g && sel >= 0) { Mastery.want("msguide " + sel); open = false; }
            else if (cl || !card.contains(x, y)) open = false;
            else for (int s = 0; s < 24; s++) if (cells[s].contains(x, y)) { sel = s; break; }
            invalidate();
        } else if (a == MotionEvent.ACTION_CANCEL) { pressedGuide = pressedClose = false; invalidate(); }
        return true;
    }
}
