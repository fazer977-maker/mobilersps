package rt4;

import com.jogamp.opengl.GL2;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

/**
 * Screen effects for the GPU renderer, done with plain fixed-function GL: copy the finished 3D picture into textures,
 * shrink it twice (bilinear) to get a blur, then draw that blur back as bloom (bright parts only) and as a tilt-shift
 * focus blur at the top and bottom of the screen. Also a vignette. Any GL trouble switches everything off.
 */
public final class PostFx {
	private static boolean done, broken;
	private static int[] tex = new int[4]; // 0 full copy, 1 quarter size, 2 small blur (plain), 3 small blur (bright pass)
	private static int fw, fh;
	private static final FloatBuffer vtx = ByteBuffer.allocateDirect(64 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
	private static final FloatBuffer tc = ByteBuffer.allocateDirect(64 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
	private static final FloatBuffer col = ByteBuffer.allocateDirect(64 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
	private static final ByteBuffer idx = ByteBuffer.allocateDirect(64 * 4).order(ByteOrder.nativeOrder());

	public static void frameDone() {
		done = false;
	}

	public static boolean active() {
		return !broken && (FxConfig.bloom || FxConfig.dof || FxConfig.vignette);
	}

	private static void makeTex(GL2 gl, int slot, int w, int h) {
		int[] t = new int[1];
		gl.glGenTextures(1, t, 0);
		tex[slot] = t[0];
		GlRenderer.setTextureId(t[0]);
		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_MIN_FILTER, GL2.GL_LINEAR);
		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_MAG_FILTER, GL2.GL_LINEAR);
		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_WRAP_S, GL2.GL_CLAMP_TO_EDGE);
		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_WRAP_T, GL2.GL_CLAMP_TO_EDGE);
		ByteBuffer empty = ByteBuffer.allocateDirect(w * h * 3).order(ByteOrder.nativeOrder());
		gl.glTexImage2D(GL2.GL_TEXTURE_2D, 0, 6407, w, h, 0, 6407, GL2.GL_UNSIGNED_BYTE, empty);
	}

	private static void ensureTextures(GL2 gl, int w, int h) {
		if (tex[0] != 0 && fw == w && fh == h) {
			return;
		}
		if (tex[0] != 0) {
			gl.glDeleteTextures(4, tex, 0);
		}
		fw = w;
		fh = h;
		makeTex(gl, 0, w, h);
		makeTex(gl, 1, Math.max(1, w / 4), Math.max(1, h / 4));
		makeTex(gl, 2, Math.max(1, w / 16), Math.max(1, h / 16));
		makeTex(gl, 3, Math.max(1, w / 16), Math.max(1, h / 16));
	}

	/** Full-canvas textured quad. */
	private static void drawQuad(GL2 gl, float w, float h) {
		vtx.clear();
		vtx.put(0).put(0).put(0).put(w).put(0).put(0).put(w).put(h).put(0).put(0).put(h).put(0);
		vtx.flip();
		tc.clear();
		tc.put(0).put(0).put(1).put(0).put(1).put(1).put(0).put(1);
		tc.flip();
		idx.clear();
		int[] i = {0, 1, 2, 0, 2, 3};
		for (int v : i) {
			idx.putInt(v);
		}
		idx.flip();
		gl.glVertexPointer(3, GL2.GL_FLOAT, 0, vtx);
		gl.glTexCoordPointer(2, GL2.GL_FLOAT, 0, tc);
		gl.glDrawElements(GL2.GL_TRIANGLES, 6, GL2.GL_UNSIGNED_INT, idx);
	}

	/** Shrinks the copy 4x then 4x again (using the screen corner as scratch space) and stores the result in the given small texture. */
	private static void blurChain(GL2 gl, float w, float h, int vw, int vh, boolean bright, int smallSlot) {
		int w4 = Math.max(1, vw / 4), h4 = Math.max(1, vh / 4), w16 = Math.max(1, vw / 16), h16 = Math.max(1, vh / 16);
		gl.glViewport(0, 0, w4, h4);
		gl.glDisable(GL2.GL_BLEND);
		GlRenderer.setTextureId(tex[0]);
		drawQuad(gl, w, h);
		if (bright) {
			// squaring the picture keeps bright areas and drops dark ones
			gl.glEnable(GL2.GL_BLEND);
			gl.glBlendFunc(GL2.GL_DST_COLOR, 0);
			drawQuad(gl, w, h);
			drawQuad(gl, w, h);
		}
		GlRenderer.setTextureId(tex[1]);
		gl.glCopyTexSubImage2D(GL2.GL_TEXTURE_2D, 0, 0, 0, 0, 0, w4, h4);
		gl.glViewport(0, 0, w16, h16);
		gl.glDisable(GL2.GL_BLEND);
		drawQuad(gl, w, h);
		GlRenderer.setTextureId(tex[smallSlot]);
		gl.glCopyTexSubImage2D(GL2.GL_TEXTURE_2D, 0, 0, 0, 0, 0, w16, h16);
	}

	/** Colored (no texture) mesh helper: x,y,alpha triples drawn black with the given alpha. */
	private static void drawShade(GL2 gl, float[] xya, int[] tris, boolean textured, float w, float h, float r, float g, float b) {
		int n = xya.length / 3;
		vtx.clear();
		col.clear();
		tc.clear();
		for (int k = 0; k < n; k++) {
			vtx.put(xya[k * 3]).put(xya[k * 3 + 1]).put(0);
			col.put(r).put(g).put(b).put(xya[k * 3 + 2]);
			tc.put(xya[k * 3] / w).put(xya[k * 3 + 1] / h);
		}
		vtx.flip();
		col.flip();
		tc.flip();
		idx.clear();
		for (int v : tris) {
			idx.putInt(v);
		}
		idx.flip();
		gl.glVertexPointer(3, GL2.GL_FLOAT, 0, vtx);
		gl.glColorPointer(4, GL2.GL_FLOAT, 0, col);
		if (textured) {
			gl.glTexCoordPointer(2, GL2.GL_FLOAT, 0, tc);
		}
		gl.glDrawElements(GL2.GL_TRIANGLES, tris.length, GL2.GL_UNSIGNED_INT, idx);
	}

	public static void apply(GL2 gl) {
		if (!FxConfig.armPost) {
			return;
		}
		FxConfig.armPost = false;
		if (!active()) {
			return;
		}
		try {
			run(gl);
		} catch (Throwable t) {
			broken = true;
		}
	}

	private static void run(GL2 gl) {
		float w = GlRenderer.canvasWidth, h = GlRenderer.canvasHeight;
		int vw = (int) (w * GameShell.canvasScale + GameShell.subpixelX), vh = (int) (h * GameShell.canvasScale + GameShell.subpixelY);
		if (vw < 64 || vh < 64) {
			return;
		}
		gl.glClientActiveTexture(GL2.GL_TEXTURE0);
		boolean pColor = GL2.clientOn(GL2.GL_COLOR_ARRAY), pTex = GL2.clientOn(GL2.GL_TEXTURE_COORD_ARRAY), pNormal = GL2.clientOn(GL2.GL_NORMAL_ARRAY);
		int[] sc = new int[1];
		gl.glGetIntegerv(0x0C11, sc, 0);
		gl.glDisable(0x0C11);
		MaterialManager.setMaterial(0, 0);
		GlRenderer.setLightingEnabled(false);
		GlRenderer.setDepthTestEnabled(false);
		GlRenderer.setFogEnabled(false);
		GlRenderer.disableDepthMask();
		GlRenderer.setTextureCombineRgbMode(0);
		GlRenderer.setTextureCombineAlphaMode(0);
		gl.glDisableClientState(GL2.GL_NORMAL_ARRAY);
		GlRenderer.normalArrayEnabled = false;
		gl.glEnableClientState(GL2.GL_VERTEX_ARRAY);
		if (GlRenderer.arbVboSupported) {
			gl.glBindBuffer(GL2.GL_ARRAY_BUFFER, 0);
			gl.glBindBuffer(GL2.GL_ELEMENT_ARRAY_BUFFER, 0);
		}
		boolean blur = FxConfig.bloom || FxConfig.dof;
		if (blur) {
			ensureTextures(gl, vw, vh);
			gl.glDisableClientState(GL2.GL_COLOR_ARRAY);
			gl.glEnableClientState(GL2.GL_TEXTURE_COORD_ARRAY);
			gl.glColor4f(1, 1, 1, 1);
			GlRenderer.setTextureId(tex[0]);
			gl.glCopyTexSubImage2D(GL2.GL_TEXTURE_2D, 0, 0, 0, 0, 0, vw, vh);
			if (FxConfig.dof) {
				blurChain(gl, w, h, vw, vh, false, 2);
			}
			if (FxConfig.bloom) {
				blurChain(gl, w, h, vw, vh, true, 3);
			}
			// put the original picture back over the scratch corner
			gl.glViewport(0, 0, vw, vh);
			gl.glDisable(GL2.GL_BLEND);
			GlRenderer.setTextureId(tex[0]);
			drawQuad(gl, w, h);
			gl.glEnable(GL2.GL_BLEND);
			if (FxConfig.dof) {
				// tilt-shift: blurred copy fades in toward the top and bottom of the screen
				gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
				gl.glEnableClientState(GL2.GL_COLOR_ARRAY);
				GlRenderer.setTextureId(tex[2]);
				float[] m = {0, 0, 0.85F, w, 0, 0.85F, 0, h * 0.22F, 0, w, h * 0.22F, 0, 0, h * 0.78F, 0, w, h * 0.78F, 0, 0, h, 0.95F, w, h, 0.95F};
				drawShade(gl, m, new int[]{0, 1, 3, 0, 3, 2, 2, 3, 5, 2, 5, 4, 4, 5, 7, 4, 7, 6}, true, w, h, 1, 1, 1);
			}
			if (FxConfig.bloom) {
				gl.glBlendFunc(GL2.GL_ONE, GL2.GL_ONE);
				gl.glDisableClientState(GL2.GL_COLOR_ARRAY);
				gl.glColor4f(1, 1, 1, 1);
				GlRenderer.setTextureId(tex[3]);
				drawQuad(gl, w, h);
			}
		}
		if (FxConfig.vignette) {
			GlRenderer.setTextureId(-1);
			gl.glEnable(GL2.GL_BLEND);
			gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
			gl.glDisableClientState(GL2.GL_TEXTURE_COORD_ARRAY);
			gl.glEnableClientState(GL2.GL_COLOR_ARRAY);
			float cx = w / 2, cy = h / 2;
			float[] v = {0, 0, 0.6F, cx, 0, 0.3F, w, 0, 0.6F, 0, cy, 0.3F, cx, cy, 0.0F, w, cy, 0.3F, 0, h, 0.6F, cx, h, 0.3F, w, h, 0.6F};
			drawShade(gl, v, new int[]{0, 1, 4, 0, 4, 3, 1, 2, 5, 1, 5, 4, 3, 4, 7, 3, 7, 6, 4, 5, 8, 4, 8, 7}, false, w, h, 0, 0, 0);
		}
		gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
		gl.glColor4f(1, 1, 1, 1);
		if (pColor) { gl.glEnableClientState(GL2.GL_COLOR_ARRAY); } else { gl.glDisableClientState(GL2.GL_COLOR_ARRAY); }
		if (pTex) { gl.glEnableClientState(GL2.GL_TEXTURE_COORD_ARRAY); } else { gl.glDisableClientState(GL2.GL_TEXTURE_COORD_ARRAY); }
		if (pNormal) { gl.glEnableClientState(GL2.GL_NORMAL_ARRAY); } else { gl.glDisableClientState(GL2.GL_NORMAL_ARRAY); }
		GlRenderer.normalArrayEnabled = pNormal;
		GlRenderer.setTextureId(-1);
		GlRenderer.enableDepthMask();
		if (sc[0] != 0) {
			gl.glEnable(0x0C11);
		}
	}

	private PostFx() {
	}
}
