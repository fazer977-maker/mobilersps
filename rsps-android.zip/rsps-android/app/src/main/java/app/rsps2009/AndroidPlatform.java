package app.rsps2009;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.view.SurfaceHolder;

import shim.platform.Platform;

/** Android implementation of the platform layer the client's AWT replacement talks to. */
public final class AndroidPlatform implements Platform {

    private final SurfaceHolder holder;
    private final String dataDir;
    private final float renderScale;
    private volatile int surfaceW, surfaceH;
    private volatile boolean surfaceValid;

    private Bitmap bitmap;
    private int bitmapW, bitmapH;
    private int[] scratch = new int[0];
    private final Paint blitPaint = new Paint();
    private final Rect dst = new Rect();

    public AndroidPlatform(SurfaceHolder holder, int surfaceW, int surfaceH, float renderScale, String dataDir) {
        this.holder = holder;
        this.surfaceW = surfaceW;
        this.surfaceH = surfaceH;
        this.renderScale = renderScale;
        this.dataDir = dataDir;
        this.surfaceValid = true;
        // Non-integer scales look better with filtering; integer scales stay crisp.
        blitPaint.setFilterBitmap(Math.abs(renderScale - Math.round(renderScale)) > 0.01f);
    }

    public void onSurfaceChanged(int w, int h) { surfaceW = w; surfaceH = h; }
    public void onSurfaceDestroyed() { surfaceValid = false; }
    public void onSurfaceCreated() { surfaceValid = true; }
    public float scale() { return renderScale; }

    // ------------------------------------------------------------------ display

    @Override
    public int viewWidth() { return Math.max(1, (int) (surfaceW / renderScale)); }

    @Override
    public int viewHeight() { return Math.max(1, (int) (surfaceH / renderScale)); }

    @Override
    public float renderScale() { return renderScale; }

    @Override
    public void setTitle(String title) { }

    // frame timing, reported to the on-screen log every few seconds
    private long perfWindowStart, perfLastEnd;
    private int perfFrames;
    private long perfPresentNs, perfClientNs;

    @Override
    public synchronized void present(int[] pixels, int w, int h, int cx, int cy, int cw, int ch) {
        if (!surfaceValid || w <= 0 || h <= 0) {
            return;
        }
        final long t0 = System.nanoTime();
        if (bitmap == null || bitmapW != w || bitmapH != h) {
            bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            bitmapW = w;
            bitmapH = h;
            cx = 0; cy = 0; cw = w; ch = h;
        }
        // clamp the dirty rectangle
        if (cx < 0) { cw += cx; cx = 0; }
        if (cy < 0) { ch += cy; cy = 0; }
        if (cx + cw > w) { cw = w - cx; }
        if (cy + ch > h) { ch = h - cy; }
        if (cw > 0 && ch > 0) {
            int needed = cw * ch;
            if (scratch.length < needed) {
                scratch = new int[needed];
            }
            for (int row = 0; row < ch; row++) {
                int src = (cy + row) * w + cx;
                int out = row * cw;
                for (int col = 0; col < cw; col++) {
                    scratch[out + col] = pixels[src + col] | 0xFF000000;
                }
            }
            bitmap.setPixels(scratch, 0, cw, cx, cy, cw, ch);
        }
        Canvas canvas = null;
        try {
            // GPU canvas: scaling the frame up to the screen is done by the GPU instead of the CPU
            try {
                canvas = holder.getSurface().lockHardwareCanvas();
            } catch (Throwable t) {
                canvas = null;
            }
            if (canvas == null) {
                canvas = holder.lockCanvas();
            }
            if (canvas != null) {
                dst.set(0, 0, canvas.getWidth(), canvas.getHeight());
                canvas.drawBitmap(bitmap, null, dst, blitPaint);
            }
        } catch (Throwable ignored) {
        } finally {
            if (canvas != null) {
                try { holder.getSurface().unlockCanvasAndPost(canvas); } catch (Throwable ignored) { }
            }
        }
        final long t1 = System.nanoTime();
        if (perfWindowStart == 0) {
            perfWindowStart = t1;
        } else {
            perfFrames++;
            perfPresentNs += t1 - t0;
            perfClientNs += t0 - perfLastEnd;
            if (t1 - perfWindowStart > 8_000_000_000L) {
                double secs = (t1 - perfWindowStart) / 1e9;
                shim.platform.Platforms.error(String.format(java.util.Locale.US,
                        "perf: %.1f fps, client work %.1f ms/frame, present %.1f ms/frame (%dx%d)",
                        perfFrames / secs, perfClientNs / 1e6 / Math.max(1, perfFrames),
                        perfPresentNs / 1e6 / Math.max(1, perfFrames), w, h), null);
                perfWindowStart = t1;
                perfFrames = 0;
                perfPresentNs = 0;
                perfClientNs = 0;
            }
        }
        perfLastEnd = t1;
    }

    // --------------------------------------------------------------------- text

    private static Paint paintFor(String font, int style, int size) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int tfStyle = (style & 1) != 0 ? ((style & 2) != 0 ? Typeface.BOLD_ITALIC : Typeface.BOLD)
                : ((style & 2) != 0 ? Typeface.ITALIC : Typeface.NORMAL);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, tfStyle));
        p.setTextSize(Math.max(1, size));
        return p;
    }

    @Override
    public int[] textMetrics(String font, int style, int size) {
        Paint.FontMetricsInt fm = paintFor(font, style, size).getFontMetricsInt();
        return new int[] { -fm.ascent, fm.descent, Math.max(0, fm.leading) };
    }

    @Override
    public int textWidth(String text, String font, int style, int size) {
        return (int) Math.ceil(paintFor(font, style, size).measureText(text));
    }

    @Override
    public void drawText(int[] dstPixels, int dw, int dh, String text, int x, int y, String font, int style, int size, int argb) {
        Paint p = paintFor(font, style, size);
        Paint.FontMetricsInt fm = p.getFontMetricsInt();
        int tw = (int) Math.ceil(p.measureText(text)) + 2;
        int th = fm.descent - fm.ascent + 2;
        if (tw <= 0 || th <= 0 || tw > 4096) {
            return;
        }
        Bitmap bm = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        p.setColor(argb | 0xFF000000);
        c.drawText(text, 1, 1 - fm.ascent, p);
        int[] px = new int[tw * th];
        bm.getPixels(px, 0, tw, 0, 0, tw, th);
        bm.recycle();
        int left = x - 1;
        int top = y + fm.ascent - 1;
        int r = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
        for (int row = 0; row < th; row++) {
            int dy = top + row;
            if (dy < 0 || dy >= dh) continue;
            for (int col = 0; col < tw; col++) {
                int dx = left + col;
                if (dx < 0 || dx >= dw) continue;
                int a = px[row * tw + col] >>> 24;
                if (a == 0) continue;
                int di = dy * dw + dx;
                if (a == 255) {
                    dstPixels[di] = 0xFF000000 | (r << 16) | (g << 8) | b;
                } else {
                    int d = dstPixels[di];
                    int rr = (r * a + ((d >> 16) & 255) * (255 - a)) / 255;
                    int gg = (g * a + ((d >> 8) & 255) * (255 - a)) / 255;
                    int bb = (b * a + (d & 255) * (255 - a)) / 255;
                    dstPixels[di] = 0xFF000000 | (rr << 16) | (gg << 8) | bb;
                }
            }
        }
    }

    // -------------------------------------------------------------------- audio

    @Override
    public AudioOut openAudio(int sampleRate, int channels, int bufferBytes) {
        try {
            int mask = channels >= 2 ? AudioFormat.CHANNEL_OUT_STEREO : AudioFormat.CHANNEL_OUT_MONO;
            int minBuf = AudioTrack.getMinBufferSize(sampleRate, mask, AudioFormat.ENCODING_PCM_16BIT);
            int trackBytes = Math.max(minBuf * 2, 4096);
            AudioTrack track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(mask)
                            .build())
                    .setBufferSizeInBytes(trackBytes)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
            track.play();
            shim.platform.Platforms.error("audio: opened " + sampleRate + "Hz ch=" + channels + " ring=" + bufferBytes + " track=" + trackBytes + " state=" + track.getState(), null);
            return new TrackOut(track, Math.max(bufferBytes, 2048), sampleRate);
        } catch (Throwable t) {
            shim.platform.Platforms.error("audio: open FAILED " + sampleRate + "Hz ch=" + channels, t);
            return null;
        }
    }

    /**
     * The client writes into a ring buffer and measures how fast it drains; a worker thread feeds
     * the AudioTrack with blocking writes, so drain speed equals real playback speed.
     */
    private static final class TrackOut implements AudioOut, Runnable {
        private final AudioTrack track;
        private final byte[] ring;
        private int head, fill; // guarded by lock
        private final Object lock = new Object();
        private volatile boolean closed;
        private final int rate;
        private long totalToTrack;
        private final long openedAt = System.currentTimeMillis();
        private boolean reported;

        TrackOut(AudioTrack track, int ringBytes, int rate) {
            this.track = track;
            this.ring = new byte[ringBytes];
            this.rate = rate;
            Thread t = new Thread(this, "audio-out");
            t.setDaemon(true);
            t.start();
        }

        @Override
        public int write(byte[] data, int off, int len) {
            synchronized (lock) {
                int n = Math.min(len, ring.length - fill);
                int tail = (head + fill) % ring.length;
                int first = Math.min(n, ring.length - tail);
                System.arraycopy(data, off, ring, tail, first);
                if (n > first) System.arraycopy(data, off + first, ring, 0, n - first);
                fill += n;
                lock.notifyAll();
                return n;
            }
        }

        @Override
        public int available() {
            synchronized (lock) { return ring.length - fill; }
        }

        @Override
        public void flush() {
            synchronized (lock) { head = 0; fill = 0; }
            try { track.pause(); track.flush(); track.play(); } catch (Throwable ignored) { }
        }

        @Override
        public void close() {
            closed = true;
            synchronized (lock) { lock.notifyAll(); }
        }

        @Override
        public void run() {
            byte[] chunk = new byte[2048];
            try {
                while (!closed) {
                    int n;
                    synchronized (lock) {
                        while (fill == 0 && !closed) {
                            lock.wait(100);
                        }
                        if (closed) break;
                        n = Math.min(fill, chunk.length);
                        int first = Math.min(n, ring.length - head);
                        System.arraycopy(ring, head, chunk, 0, first);
                        if (n > first) System.arraycopy(ring, 0, chunk, first, n - first);
                    }
                    int w = track.write(chunk, 0, n, AudioTrack.WRITE_BLOCKING);
                    if (w < 0) {
                        shim.platform.Platforms.error("audio: track.write error " + w, null);
                        Thread.sleep(100);
                        continue;
                    }
                    totalToTrack += w;
                    synchronized (lock) {
                        head = (head + w) % ring.length;
                        fill -= w;
                    }
                    if (!reported && System.currentTimeMillis() - openedAt > 3000) {
                        reported = true;
                        shim.platform.Platforms.error("audio check " + rate + "Hz: toTrack=" + totalToTrack + "B head=" + track.getPlaybackHeadPosition()
                                + " playState=" + track.getPlayState(), null);
                    }
                }
            } catch (Throwable t) {
                shim.platform.Platforms.error("audio: writer died", t);
            } finally {
                try { track.stop(); } catch (Throwable ignored) { }
                try { track.release(); } catch (Throwable ignored) { }
            }
        }
    }

    @Override
    public String dataDir() { return dataDir; }
}
