package app.rsps2009;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.FrameLayout;

import shim.platform.Platforms;

public class GameActivity extends Activity implements SurfaceHolder.Callback {

    private static boolean started = false;

    private GameSurface surface;
    private Settings settings;
    private AndroidPlatform platform;
    private boolean kbVisible;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        CrashLog.install(this);
        CrashLog.write(CrashLog.file(this), "");
        CrashLog.crumb(this, "GameActivity.onCreate");
        settings = Settings.load(this);
        setRequestedOrientation(settings.portrait
                ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                : ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        surface = new GameSurface(this);
        surface.setRenderScale(settings.renderScale);
        surface.getHolder().addCallback(this);
        root.addView(surface, new FrameLayout.LayoutParams(-1, -1));

        Button kb = new Button(this);
        kb.setText("⌨");
        kb.setAlpha(0.5f);
        kb.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleKeyboard(); }
        });
        float d = getResources().getDisplayMetrics().density;
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) (48 * d), (int) (40 * d));
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.topMargin = (int) (4 * d);
        lp.rightMargin = (int) (4 * d);
        root.addView(kb, lp);

        final View out = new View(this) {
            private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            private android.graphics.Bitmap door, stoneBmp;
            private int[] stoneSrc;
            @Override protected void onDraw(android.graphics.Canvas c) {
                if (door == null) {
                    android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                    o.inScaled = false;
                    door = android.graphics.BitmapFactory.decodeResource(getResources(), R.drawable.logout_door, o);
                }
                float w = getWidth(), h = getHeight(), u = Math.min(w, h);
                int[] sp = rt4.MobileLayout.stonePx;
                if (sp != null) {
                    if (stoneBmp == null || stoneSrc != sp) {
                        stoneSrc = sp;
                        stoneBmp = android.graphics.Bitmap.createBitmap(sp, rt4.MobileLayout.stoneWpx, rt4.MobileLayout.stoneHpx, android.graphics.Bitmap.Config.ARGB_8888);
                    }
                    p.setFilterBitmap(false);
                    c.drawBitmap(stoneBmp, null, new android.graphics.RectF(0, 0, w, h), p);
                    if (door != null) {
                        c.drawBitmap(door, null, new android.graphics.RectF(0, 0, w, h), p);
                    }
                    return;
                }
                // fallback: drawn stone tab background
                p.setStyle(android.graphics.Paint.Style.FILL);
                p.setShader(null);
                p.setColor(Color.rgb(26, 22, 18));
                c.drawRoundRect(new android.graphics.RectF(0, 0, w, h), u * 0.2f, u * 0.2f, p);
                p.setShader(new android.graphics.LinearGradient(0, 0, w, h, Color.rgb(120, 112, 100), Color.rgb(66, 60, 52), android.graphics.Shader.TileMode.CLAMP));
                c.drawRoundRect(new android.graphics.RectF(u * 0.06f, u * 0.06f, w - u * 0.06f, h - u * 0.06f), u * 0.17f, u * 0.17f, p);
                p.setShader(null);
                p.setStyle(android.graphics.Paint.Style.STROKE);
                p.setStrokeWidth(Math.max(1f, u * 0.04f));
                p.setColor(Color.argb(110, 255, 255, 255));
                c.drawRoundRect(new android.graphics.RectF(u * 0.09f, u * 0.09f, w - u * 0.09f, h - u * 0.09f), u * 0.15f, u * 0.15f, p);
                p.setStyle(android.graphics.Paint.Style.FILL);
                if (door != null) {
                    p.setFilterBitmap(false);
                    c.drawBitmap(door, null, new android.graphics.RectF(0, 0, w, h), p);
                }
            }
        };
        out.setVisibility(View.GONE);
        out.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                new android.app.AlertDialog.Builder(GameActivity.this)
                        .setMessage("Log out?")
                        .setPositiveButton("Log out", new android.content.DialogInterface.OnClickListener() {
                            @Override public void onClick(android.content.DialogInterface dd, int w) {
                                rt4.SavedAccount.requestLogout();
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        });
        final FrameLayout.LayoutParams lp2 = new FrameLayout.LayoutParams(10, 10);
        lp2.gravity = Gravity.TOP | Gravity.START;
        root.addView(out, lp2);
        final android.os.Handler hh = new android.os.Handler(android.os.Looper.getMainLooper());
        hh.post(new Runnable() {
            @Override public void run() {
                try {
                    boolean in = rt4.client.gameState == 30 && rt4.MobileLayout.logoutW > 0 && rt4.MobileLayout.canvasW > 0 && surface.getWidth() > 0;
                    if (in) {
                        float sc = surface.getWidth() / (float) rt4.MobileLayout.canvasW;
                        int x = Math.round(rt4.MobileLayout.logoutX * sc), y = Math.round(rt4.MobileLayout.logoutY * sc);
                        int w2 = Math.round(rt4.MobileLayout.logoutW * sc), h2 = Math.round(rt4.MobileLayout.logoutH * sc);
                        if (lp2.leftMargin != x || lp2.topMargin != y || lp2.width != w2 || lp2.height != h2) {
                            lp2.leftMargin = x; lp2.topMargin = y; lp2.width = w2; lp2.height = h2;
                            out.setLayoutParams(lp2);
                        }
                    }
                    out.setVisibility(in && !rt4.MobileLayout.logoutHidden() ? View.VISIBLE : View.GONE);
                } catch (Throwable ignored) { }
                hh.postDelayed(this, 250);
            }
        });
        final LoginOverlay overlay = new LoginOverlay(this, getFilesDir());
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        setContentView(root);
        goImmersive();
        GameEvents.onChatTap = new Runnable() {
            @Override public void run() {
                if (!kbVisible) toggleKeyboard();
            }
        };
        GameEvents.onEnter = new Runnable() {
            @Override public void run() {
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(surface.getWindowToken(), 0);
                kbVisible = false;
            }
        };
    }

    private void goImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) goImmersive();
        if (started) GameEvents.focus(hasFocus);
    }

    private void toggleKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        surface.requestFocus();
        if (kbVisible) imm.hideSoftInputFromWindow(surface.getWindowToken(), 0);
        else imm.showSoftInput(surface, InputMethodManager.SHOW_FORCED);
        kbVisible = !kbVisible;
    }

    @Override
    public void onBackPressed() {
        if (started) GameEvents.controlKey(shim.awt.event.KeyEvent.VK_ESCAPE, (char) 27);
    }

    // ---------------------------------------------------------------- surface

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        if (platform != null) platform.onSurfaceCreated();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
        CrashLog.crumb(this, "surfaceChanged " + w + "x" + h);
        if (platform != null) {
            platform.onSurfaceChanged(w, h);
            return;
        }
        platform = new AndroidPlatform(holder, w, h, settings.renderScale, getFilesDir().getAbsolutePath() + "/");
        Platforms.current = platform;
        if (started) return; // process survived an activity recreation; client keeps running
        started = true;
        try {
            final String cfg = settings.writeClientConfig(this).getAbsolutePath();
            System.setProperty("clientHomeOverride", getFilesDir().getAbsolutePath() + "/");
            rt4.DisplayMode.resizableSD = true;
            final java.io.File crashFile = CrashLog.file(this);
            final java.io.File dumpFile = new java.io.File(getFilesDir(), "layout.txt");
            dumpFile.delete();
            Platforms.dumpSink = new Platforms.Sink() {
                @Override public void log(String text) {
                    try (java.io.FileOutputStream o = new java.io.FileOutputStream(dumpFile, false)) {
                        o.write(text.getBytes("UTF-8"));
                    } catch (Throwable ignored) { }
                }
            };
            Platforms.sink = new Platforms.Sink() {
                @Override public void log(String text) {
                    synchronized (crashFile) {
                        try (java.io.FileOutputStream o = new java.io.FileOutputStream(crashFile, true)) {
                            String t = text.length() > 3000 ? text.substring(0, 3000) : text;
                            o.write((t + "\n---\n").getBytes("UTF-8"));
                        } catch (Throwable ignored) { }
                    }
                }
            };
            Thread t = new Thread(null, new Runnable() {
                @Override public void run() {
                    try {
                        CrashLog.crumb(GameActivity.this, "client.main begin");
                        rt4.client.main(new String[] {"--config", cfg});
                        CrashLog.crumb(GameActivity.this, "client.main returned");
                    } catch (Throwable e) {
                        android.util.Log.e("rsps2009", "client crashed", e);
                        CrashLog.write(CrashLog.file(GameActivity.this), "client main failed:\n" + CrashLog.trace(e));
                    }
                }
            }, "rs-main", 64L * 1024 * 1024);
            CrashLog.crumb(this, "starting client thread");
            t.start();
        } catch (Exception e) {
            android.util.Log.e("rsps2009", "start failed", e);
            CrashLog.write(CrashLog.file(this), "start failed:\n" + CrashLog.trace(e));
        }
    }

    @Override
    protected void onDestroy() {
        CrashLog.crumb(this, "onDestroy finishing=" + isFinishing());
        super.onDestroy();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        if (platform != null) platform.onSurfaceDestroyed();
    }
}
