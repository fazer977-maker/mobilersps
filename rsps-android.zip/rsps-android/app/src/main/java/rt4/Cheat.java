package rt4;

import org.openrs2.deob.annotation.OriginalArg;
import org.openrs2.deob.annotation.OriginalMember;
import org.openrs2.deob.annotation.Pc;
import plugin.PluginRepository;

public class Cheat {
	@OriginalMember(owner = "client!p", name = "f", descriptor = "Lclient!na;")
	public static final JagString JS5DROP = JagString.parse("::serverjs5drop");
	@OriginalMember(owner = "client!v", name = "d", descriptor = "Lclient!na;")
	public static final JagString CLIENTDROP = JagString.parse("::clientdrop");
	@OriginalMember(owner = "client!dg", name = "b", descriptor = "Lclient!na;")
	public static final JagString MSG_SHIFTCLICK_ENABLED = JagString.parse("Shift)2click ENABLED(Q");
	@OriginalMember(owner = "client!nh", name = "hb", descriptor = "Lclient!na;")
	public static final JagString COMMAND_FPS = JagString.parse("::fps ");
	@OriginalMember(owner = "client!nb", name = "e", descriptor = "Lclient!na;")
	public static final JagString BREAKCON = JagString.parse("::breakcon");
	@OriginalMember(owner = "client!wf", name = "s", descriptor = "Lclient!na;")
	public static final JagString MSG_TWEENING_DISABLED = JagString.parse("Forced tweening disabled)3");
	@OriginalMember(owner = "client!wd", name = "f", descriptor = "Lclient!na;")
	public static final JagString ERROR_TEST = JagString.parse("::errortest");
	@OriginalMember(owner = "client!wb", name = "j", descriptor = "Lclient!na;")
	public static final JagString MSG_MEMORY_AFTER_CLEANUP = JagString.parse("Memory after cleanup=");
	@OriginalMember(owner = "client!th", name = "h", descriptor = "Lclient!na;")
	public static final JagString PARTICLES = JagString.parse("::setparticles");
	@OriginalMember(owner = "client!rc", name = "K", descriptor = "Lclient!na;")
	public static final JagString RECT_DEBUG = JagString.parse("::rect_debug");
	@OriginalMember(owner = "client!hh", name = "b", descriptor = "Lclient!na;")
	public static final JagString TELE = JagString.parse("::tele ");
	@OriginalMember(owner = "client!hh", name = "k", descriptor = "Lclient!na;")
	public static final JagString WM0 = JagString.parse("::wm0");
	@OriginalMember(owner = "client!tg", name = "i", descriptor = "Lclient!na;")
	public static final JagString PCACHESIZE = JagString.parse("::pcachesize");
	@OriginalMember(owner = "client!fh", name = "ab", descriptor = "Lclient!na;")
	public static final JagString NOCLIP = JagString.parse("::noclip");
	@OriginalMember(owner = "client!en", name = "e", descriptor = "Lclient!na;")
	public static final JagString FPSOFF = JagString.parse("::fpsoff");
	@OriginalMember(owner = "client!ja", name = "k", descriptor = "Lclient!na;")
	public static final JagString DEBUG_FPS = JagString.parse("FPS: ");
	@OriginalMember(owner = "client!qh", name = "i", descriptor = "Lclient!na;")
	public static final JagString DEBUG_MEMORY = JagString.parse("RAM: ");
	@OriginalMember(owner = "client!bi", name = "W", descriptor = "Lclient!na;")
	public static final JagString DEBUG_MEMORY_UNIT = JagString.parse(" MB");
	@OriginalMember(owner = "client!dg", name = "d", descriptor = "Lclient!na;")
	public static final JagString DEBUG_CAHE = JagString.parse("Cache: ");
	@OriginalMember(owner = "client!hm", name = "Y", descriptor = "Lclient!na;")
	public static final JagString DEBUG_FPS2 = JagString.parse("FPS: ");
	@OriginalMember(owner = "client!c", name = "Y", descriptor = "Lclient!na;")
	public static final JagString DEBUG_MEM = JagString.parse("RAM: ");
	@OriginalMember(owner = "client!bg", name = "z", descriptor = "Lclient!na;")
	public static final JagString DEBUG_MEM_UNIT = JagString.parse(" MB");
	@OriginalMember(owner = "client!q", name = "h", descriptor = "Lclient!na;")
	public static final JagString DEBUG_CARD = JagString.parse("GPU: ");
	@OriginalMember(owner = "client!oi", name = "b", descriptor = "Lclient!na;")
	public static final JagString QA_OP_TEST = JagString.parse("::qa_op_test");
	@OriginalMember(owner = "client!jk", name = "F", descriptor = "Lclient!na;")
	public static final JagString TWEENING = JagString.parse("::tween");
	@OriginalMember(owner = "client!j", name = "z", descriptor = "Lclient!na;")
	public static final JagString SHIFTCLICK = JagString.parse("::shiftclick");
	@OriginalMember(owner = "client!qf", name = "N", descriptor = "Lclient!na;")
	public static final JagString CARDMEM = JagString.parse("::cardmem");
	@OriginalMember(owner = "client!e", name = "Ac", descriptor = "Lclient!na;")
	public static final JagString MSG_TWEENING_ENABLED = JagString.parse("Forced tweening ENABLED(Q");
	@OriginalMember(owner = "client!md", name = "T", descriptor = "Lclient!na;")
	public static final JagString MSG_SHIFTCLICK_DISABLED = JagString.parse("Shift)2click disabled)3");
	@OriginalMember(owner = "client!wh", name = "o", descriptor = "Lclient!na;")
	public static final JagString RECT_DEBUG_EQUALS = JagString.parse("rect_debug=");
	@OriginalMember(owner = "client!dh", name = "e", descriptor = "Lclient!na;")
	public static final JagString MSG_MODEL_CACHE_SIZE = JagString.parse("Number of player models in cache:");
	@OriginalMember(owner = "client!qh", name = "c", descriptor = "Lclient!na;")
	public static final JagString MSG_MEMORY_BEFORE_CLEANUP = JagString.parse("Memory before cleanup=");
	@OriginalMember(owner = "client!qg", name = "Z", descriptor = "Lclient!na;")
	public static final JagString MSG_MEMORY = JagString.parse("mem=");
	@OriginalMember(owner = "client!gg", name = "Y", descriptor = "Lclient!na;")
	public static final JagString GC = JagString.parse("::gc");
	@OriginalMember(owner = "client!wk", name = "u", descriptor = "Lclient!na;")
	public static final JagString CLIENTJS5DROP = JagString.parse("::clientjs5drop");
	@OriginalMember(owner = "client!id", name = "c", descriptor = "Lclient!na;")
	public static final JagString FPSON = JagString.parse("::fpson");
	@OriginalMember(owner = "client!md", name = "Q", descriptor = "Lclient!na;")
	public static final JagString MM = JagString.parse("::mm");
	@OriginalMember(owner = "client!j", name = "M", descriptor = "Lclient!na;")
	public static final JagString REPLACECANVAS = JagString.parse("::replacecanvas");
	@OriginalMember(owner = "client!li", name = "p", descriptor = "Lclient!na;")
	public static final JagString REBUILD = JagString.parse("::rebuild");
	@OriginalMember(owner = "client!oi", name = "j", descriptor = "Lclient!na;")
	public static final JagString WM1 = JagString.parse("::wm1");
	@OriginalMember(owner = "client!ql", name = "i", descriptor = "Lclient!na;")
	public static final JagString WM2 = JagString.parse("::wm2");
	@OriginalMember(owner = "client!hk", name = "db", descriptor = "Lclient!na;")
	public static final JagString WM3 = JagString.parse("::wm3");
	@OriginalMember(owner = "client!dg", name = "f", descriptor = "Z")
	public static boolean displayFps = false;
	@OriginalMember(owner = "client!nj", name = "a", descriptor = "Z")
	public static boolean shiftClick = GlobalConfig.USE_SHIFT_CLICK;
	@OriginalMember(owner = "client!qc", name = "U", descriptor = "I")
	public static int rectDebug = 0;
	@OriginalMember(owner = "client!jg", name = "e", descriptor = "Z")
	public static boolean qaOpTest = false;
	public static final JagString RELOADPLUGINS = JagString.parse("::reloadplugins");

	@OriginalMember(owner = "client!en", name = "a", descriptor = "(IIIB)V")
	public static void teleport(@OriginalArg(0) int tileX, @OriginalArg(1) int tileY, @OriginalArg(2) int plane) {
		@Pc(66) JagString command = JagString.concatenate(new JagString[]{TELE, JagString.parseInt(plane), JagString.COMMA, JagString.parseInt(tileX >> 6), JagString.COMMA, JagString.parseInt(tileY >> 6), JagString.COMMA, JagString.parseInt(tileX & 0x3F), JagString.COMMA, JagString.parseInt(tileY & 0x3F)});
		command.print();
		execute(command);
	}

	@OriginalMember(owner = "client!k", name = "a", descriptor = "(Lclient!na;Z)V")
	public static void execute(@OriginalArg(0) JagString command) {
		PluginRepository.ProcessCommand(command);
		// if (LoginManager.staffModLevel >= 2) {
			@Pc(18) int i;
			@Pc(38) int memory;
			@Pc(29) Runtime runtime;
			if (command.equalsIgnoreCase(GC)) {
				client.unloadSoft();
				for (i = 0; i < 10; i++) {
					System.gc();
				}
				runtime = Runtime.getRuntime();
				memory = (int) ((runtime.totalMemory() - runtime.freeMemory()) / 1024L);
				Chat.add(null, 0, JagString.concatenate(new JagString[]{MSG_MEMORY, JagString.parseInt(memory), DEBUG_MEM_UNIT}));
			}
			@Pc(117) int j;
			if (command.equalsIgnoreCase(MM)) {
				client.unloadSoft();
				for (i = 0; i < 10; i++) {
					System.gc();
				}
				runtime = Runtime.getRuntime();
				memory = (int) ((runtime.totalMemory() - runtime.freeMemory()) / 1024L);
				Chat.add(null, 0, JagString.concatenate(new JagString[]{MSG_MEMORY_BEFORE_CLEANUP, JagString.parseInt(memory), DEBUG_MEM_UNIT}));
				Player.invalidateGlModels();
				client.unloadSoft();
				for (j = 0; j < 10; j++) {
					System.gc();
				}
				memory = (int) ((runtime.totalMemory() - runtime.freeMemory()) / 1024L);
				Chat.add(null, 0, JagString.concatenate(new JagString[]{MSG_MEMORY_AFTER_CLEANUP, JagString.parseInt(memory), DEBUG_MEM_UNIT}));
			}
			if (command.equalsIgnoreCase(PCACHESIZE)) {
				Chat.add(null, 0, JagString.concatenate(new JagString[]{MSG_MODEL_CACHE_SIZE, JagString.parseInt(PlayerAppearance.getModelCacheSize())}));
			}
			if (GlRenderer.enabled && command.equalsIgnoreCase(CARDMEM)) {
				System.out.println("oncard_geometry:" + GlCleaner.onCardGeometry);
				System.out.println("oncard_2d:" + GlCleaner.onCard2d);
				System.out.println("oncard_texture:" + GlCleaner.onCardTexture);
			}
			if (command.equalsIgnoreCase(CLIENTDROP)) {
				Protocol.handleConnectionLost();
			}
			if (command.equalsIgnoreCase(CLIENTJS5DROP)) {
				client.js5NetQueue.quit();
			}
			if (command.equalsIgnoreCase(JS5DROP)) {
				client.js5NetQueue.drop();
			}
			if (command.equalsIgnoreCase(BREAKCON)) {
				GameShell.signLink.breakConnection();
				Protocol.socket.breakConnection();
				client.js5NetQueue.breakConnection();
			}
			if (command.equalsIgnoreCase(REPLACECANVAS)) {
				GameShell.replaceCanvas = true;
			}
			if (command.equalsIgnoreCase(REBUILD)) {
				client.setGameState(25);
			}
			if (command.equalsIgnoreCase(FPSON)) {
				displayFps = true;
			}
			if (command.equalsIgnoreCase(FPSOFF)) {
				displayFps = false;
			}
			if (command.equalsIgnoreCase(WM0)) {
				DisplayMode.setWindowMode(false, 0, -1, -1);
			}
			if (command.equalsIgnoreCase(WM1)) {
				DisplayMode.setWindowMode(false, 1, -1, -1);
			}
			if (command.equalsIgnoreCase(WM2)) {
				DisplayMode.setWindowMode(false, 2, -1, -1);
			}
			if (command.equalsIgnoreCase(WM3)) {
				DisplayMode.setWindowMode(false, 3, 1024, 768);
			}
			if (command.equalsIgnoreCase(NOCLIP)) {
				for (i = 0; i < 4; i++) {
					for (memory = 1; memory < 103; memory++) {
						for (j = 1; j < 103; j++) {
							PathFinder.collisionMaps[i].flags[memory][j] = 0;
						}
					}
				}
			}
			if (command.startsWith(PARTICLES)) {
				Preferences.setParticles(command.substring(15).parseInt());
				Preferences.write(GameShell.signLink);
				Preferences.sentToServer = false;
			}
			if (command.equalsIgnoreCase(JagString.parse("::time morning"))) { FxConfig.tod = 1; }
			if (command.equalsIgnoreCase(JagString.parse("::time day")) || command.equalsIgnoreCase(JagString.parse("::time midday"))) { FxConfig.tod = 2; }
			if (command.equalsIgnoreCase(JagString.parse("::time evening"))) { FxConfig.tod = 3; }
			if (command.equalsIgnoreCase(JagString.parse("::time night"))) { FxConfig.tod = 4; }
			if (command.equalsIgnoreCase(JagString.parse("::time auto"))) { FxConfig.tod = 5; }
			if (command.equalsIgnoreCase(JagString.parse("::time off"))) { FxConfig.tod = 0; }
			if (command.equalsIgnoreCase(JagString.parse("::weather clear"))) { FxConfig.weather = 0; }
			if (command.equalsIgnoreCase(JagString.parse("::weather rain"))) { FxConfig.weather = 1; }
			if (command.equalsIgnoreCase(JagString.parse("::weather snow"))) { FxConfig.weather = 2; }
			if (command.equalsIgnoreCase(JagString.parse("::weather mist"))) { FxConfig.weather = 3; }
			if (command.equalsIgnoreCase(JagString.parse("::weather auto"))) { FxConfig.weather = 4; }
			if (command.equalsIgnoreCase(JagString.parse("::fpson"))) { app.rsps2009.Settings.showFps = true; }
			if (command.equalsIgnoreCase(JagString.parse("::fpsoff"))) { app.rsps2009.Settings.showFps = false; }
			if (command.startsWith(COMMAND_FPS) && client.modeWhere != 0) {
				GameShell.setFpsTarget(command.substring(6).parseInt());
			}
			if (command.equalsIgnoreCase(ERROR_TEST)) {
				throw new RuntimeException();
			}
			if (command.startsWith(RECT_DEBUG)) {
				rectDebug = command.substring(12).trim().parseInt();
				Chat.add(null, 0, JagString.concatenate(new JagString[]{RECT_DEBUG_EQUALS, JagString.parseInt(rectDebug)}));
			}
			if (command.equalsIgnoreCase(QA_OP_TEST)) {
				qaOpTest = true;
			}
			if (command.equalsIgnoreCase(TWEENING)) {
				if (SeqType.applyTweening) {
					SeqType.applyTweening = false;
					Chat.add(null, 0, MSG_TWEENING_DISABLED);
				} else {
					SeqType.applyTweening = true;
					Chat.add(null, 0, MSG_TWEENING_ENABLED);
				}
			}
			if (command.equalsIgnoreCase(SHIFTCLICK)) {
				if (shiftClick) {
					MSG_SHIFTCLICK_DISABLED.print();
					shiftClick = false;
				} else {
					MSG_SHIFTCLICK_ENABLED.print();
					shiftClick = true;
				}
			}

		if (command.equalsIgnoreCase(RELOADPLUGINS)) {
			PluginRepository.reloadPlugins();
		}
		//}
		sendCheatPacket(command);
	}

	public static void sendCheatPacket(JagString commandLine) {
		Protocol.outboundBuffer.p1isaac(ClientProt.CLIENT_CHEAT);
		Protocol.outboundBuffer.p1(commandLine.length() - 1);
		Protocol.outboundBuffer.pjstr(commandLine.substring(2));
	}

}
