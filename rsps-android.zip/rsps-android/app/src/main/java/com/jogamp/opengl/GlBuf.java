package com.jogamp.opengl;

import java.nio.*;

/** Turns Java buffers into raw pointers for gl4es. Heap buffers are copied into reusable direct scratch memory. */
final class GlBuf {
    private static final ByteBuffer[] SLOTS = new ByteBuffer[16];
    private static final int[] READ_SLOT_LEN = new int[1];

    static int elem(Buffer b) {
        if (b instanceof ByteBuffer) return 1;
        if (b instanceof ShortBuffer || b instanceof CharBuffer) return 2;
        if (b instanceof IntBuffer || b instanceof FloatBuffer) return 4;
        return 8;
    }

    private static ByteBuffer slot(int i, int bytes) {
        ByteBuffer s = SLOTS[i];
        if (s == null || s.capacity() < bytes) {
            s = ByteBuffer.allocateDirect(Math.max(bytes, 4096)).order(ByteOrder.nativeOrder());
            SLOTS[i] = s;
        }
        s.clear();
        return s;
    }

    static long ptr(Buffer b, int slotIndex) {
        if (b == null) return 0;
        int es = elem(b);
        if (b.isDirect()) {
            return GlNative.address(b) + (long) b.position() * es;
        }
        ByteBuffer d = slot(slotIndex, b.remaining() * es);
        if (b instanceof ByteBuffer) d.put(((ByteBuffer) b).duplicate());
        else if (b instanceof IntBuffer) d.asIntBuffer().put(((IntBuffer) b).duplicate());
        else if (b instanceof FloatBuffer) d.asFloatBuffer().put(((FloatBuffer) b).duplicate());
        else if (b instanceof ShortBuffer) d.asShortBuffer().put(((ShortBuffer) b).duplicate());
        else throw new IllegalArgumentException("buffer type");
        d.clear();
        return GlNative.address(d);
    }

    static long readPtr(Buffer b) {
        if (b == null) return 0;
        if (b.isDirect()) return ptr(b, 10);
        ByteBuffer d = slot(10, b.remaining() * elem(b));
        return GlNative.address(d);
    }

    static void readDone(Buffer b) {
        if (b == null || b.isDirect()) return;
        ByteBuffer d = SLOTS[10];
        int n = b.remaining();
        d.clear();
        if (b instanceof ByteBuffer) { ByteBuffer t = (ByteBuffer) b; int p = t.position(); for (int i = 0; i < n; i++) t.put(p + i, d.get(i)); }
        else if (b instanceof IntBuffer) { IntBuffer t = (IntBuffer) b; int p = t.position(); IntBuffer s = d.asIntBuffer(); for (int i = 0; i < n; i++) t.put(p + i, s.get(i)); }
        else if (b instanceof FloatBuffer) { FloatBuffer t = (FloatBuffer) b; int p = t.position(); FloatBuffer s = d.asFloatBuffer(); for (int i = 0; i < n; i++) t.put(p + i, s.get(i)); }
    }
}
