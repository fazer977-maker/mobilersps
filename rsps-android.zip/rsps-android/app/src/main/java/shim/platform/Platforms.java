package shim.platform;

public final class Platforms {
    private Platforms() {}
    public static volatile Platform current = new NullPlatform();
}
