package com.jogamp.opengl;

/** OpenGL calls used by the game, forwarded to gl4es through JNI. Generated. */
public class GL2 extends GL {
    public static final int GL_EXTENSIONS = 0x1F03;
    public static final int GL_ADD = 260;
    public static final int GL_ADD_SIGNED = 34164;
    public static final int GL_ALPHA = 6406;
    public static final int GL_ALPHA_TEST = 3008;
    public static final int GL_AMBIENT = 4608;
    public static final int GL_AMBIENT_AND_DIFFUSE = 5634;
    public static final int GL_ARRAY_BUFFER = 34962;
    public static final int GL_BACK = 1029;
    public static final int GL_BACK_LEFT = 1026;
    public static final int GL_BGRA = 32993;
    public static final int GL_BLEND = 3042;
    public static final int GL_C4UB_V3F = 10787;
    public static final int GL_CLAMP_TO_EDGE = 33071;
    public static final int GL_COLOR = 6144;
    public static final int GL_COLOR_ARRAY = 32886;
    public static final int GL_COLOR_BUFFER_BIT = 16384;
    public static final int GL_COLOR_MATERIAL = 2903;
    public static final int GL_COMBINE = 34160;
    public static final int GL_COMBINE_ALPHA = 34162;
    public static final int GL_COMBINE_RGB = 34161;
    public static final int GL_COMPILE = 4864;
    public static final int GL_CONSTANT = 34166;
    public static final int GL_CONSTANT_ATTENUATION = 4615;
    public static final int GL_CULL_FACE = 2884;
    public static final int GL_DEPTH_BUFFER_BIT = 256;
    public static final int GL_DEPTH_TEST = 2929;
    public static final int GL_DIFFUSE = 4609;
    public static final int GL_DRAW_BUFFER = 3073;
    public static final int GL_DST_COLOR = 774;
    public static final int GL_ELEMENT_ARRAY_BUFFER = 34963;
    public static final int GL_ENABLE_BIT = 8192;
    public static final int GL_EYE_LINEAR = 9216;
    public static final int GL_EYE_PLANE = 9474;
    public static final int GL_FASTEST = 4353;
    public static final int GL_FILL = 6914;
    public static final int GL_FLOAT = 5126;
    public static final int GL_FOG = 2912;
    public static final int GL_FOG_BIT = 128;
    public static final int GL_FOG_COLOR = 2918;
    public static final int GL_FOG_DENSITY = 2914;
    public static final int GL_FOG_END = 2916;
    public static final int GL_FOG_HINT = 3156;
    public static final int GL_FOG_MODE = 2917;
    public static final int GL_FOG_START = 2915;
    public static final int GL_FRAGMENT_PROGRAM_ARB = 34820;
    public static final int GL_FRONT = 1028;
    public static final int GL_FRONT_LEFT = 1024;
    public static final int GL_GREATER = 516;
    public static final int GL_INTERPOLATE = 34165;
    public static final int GL_LEQUAL = 515;
    public static final int GL_LIGHT0 = 16384;
    public static final int GL_LIGHT1 = 16385;
    public static final int GL_LIGHTING = 2896;
    public static final int GL_LIGHT_MODEL_AMBIENT = 2899;
    public static final int GL_LINEAR = 9729;
    public static final int GL_LINEAR_ATTENUATION = 4616;
    public static final int GL_LINEAR_MIPMAP_LINEAR = 9987;
    public static final int GL_LINES = 1;
    public static final int GL_LINE_LOOP = 2;
    public static final int GL_LUMINANCE_ALPHA = 6410;
    public static final int GL_MAX_TEXTURE_COORDS = 34929;
    public static final int GL_MAX_TEXTURE_IMAGE_UNITS = 34930;
    public static final int GL_MAX_TEXTURE_UNITS = 34018;
    public static final int GL_MODELVIEW = 5888;
    public static final int GL_MODULATE = 8448;
    public static final int GL_NEAREST = 9728;
    public static final int GL_NORMAL_ARRAY = 32885;
    public static final int GL_NORMAL_MAP = 34065;
    public static final int GL_OBJECT_LINEAR = 9217;
    public static final int GL_OBJECT_PLANE = 9473;
    public static final int GL_ONE = 1;
    public static final int GL_ONE_MINUS_SRC_ALPHA = 771;
    public static final int GL_OPERAND0_RGB = 34192;
    public static final int GL_OPERAND1_RGB = 34193;
    public static final int GL_POINT_DISTANCE_ATTENUATION = 33065;
    public static final int GL_POINT_SIZE_MAX = 33063;
    public static final int GL_POINT_SIZE_MIN = 33062;
    public static final int GL_POSITION = 4611;
    public static final int GL_PREVIOUS = 34168;
    public static final int GL_PRIMARY_COLOR = 34167;
    public static final int GL_PROGRAM_ERROR_POSITION_ARB = 34379;
    public static final int GL_PROGRAM_FORMAT_ASCII_ARB = 34933;
    public static final int GL_PROJECTION = 5889;
    public static final int GL_Q = 8195;
    public static final int GL_QUADRATIC_ATTENUATION = 4617;
    public static final int GL_R = 8194;
    public static final int GL_READ_BUFFER = 3074;
    public static final int GL_RENDERER = 7937;
    public static final int GL_REPEAT = 10497;
    public static final int GL_REPLACE = 7681;
    public static final int GL_RGBA = 6408;
    public static final int GL_RGBA8 = 32856;
    public static final int GL_RGB_SCALE = 34163;
    public static final int GL_S = 8192;
    public static final int GL_SCISSOR_TEST = 3089;
    public static final int GL_SMOOTH = 7425;
    public static final int GL_SRC0_ALPHA = 34184;
    public static final int GL_SRC0_RGB = 34176;
    public static final int GL_SRC1_RGB = 34177;
    public static final int GL_SRC2_ALPHA = 34186;
    public static final int GL_SRC2_RGB = 34178;
    public static final int GL_SRC_ALPHA = 770;
    public static final int GL_SRC_COLOR = 768;
    public static final int GL_STATIC_DRAW = 35044;
    public static final int GL_STREAM_DRAW = 35040;
    public static final int GL_SUBTRACT = 34023;
    public static final int GL_T = 8193;
    public static final int GL_T2F_V3F = 10791;
    public static final int GL_TEXTURE = 5890;
    public static final int GL_TEXTURE0 = 33984;
    public static final int GL_TEXTURE1 = 33985;
    public static final int GL_TEXTURE2 = 33986;
    public static final int GL_TEXTURE_1D = 3552;
    public static final int GL_TEXTURE_2D = 3553;
    public static final int GL_TEXTURE_3D = 32879;
    public static final int GL_TEXTURE_COORD_ARRAY = 32888;
    public static final int GL_TEXTURE_CUBE_MAP = 34067;
    public static final int GL_TEXTURE_CUBE_MAP_POSITIVE_X = 34069;
    public static final int GL_TEXTURE_ENV = 8960;
    public static final int GL_TEXTURE_ENV_COLOR = 8705;
    public static final int GL_TEXTURE_ENV_MODE = 8704;
    public static final int GL_TEXTURE_GEN_MODE = 9472;
    public static final int GL_TEXTURE_GEN_Q = 3171;
    public static final int GL_TEXTURE_GEN_R = 3170;
    public static final int GL_TEXTURE_GEN_S = 3168;
    public static final int GL_TEXTURE_GEN_T = 3169;
    public static final int GL_TEXTURE_MAG_FILTER = 10240;
    public static final int GL_TEXTURE_MIN_FILTER = 10241;
    public static final int GL_TEXTURE_WRAP_R = 32882;
    public static final int GL_TEXTURE_WRAP_S = 10242;
    public static final int GL_TEXTURE_WRAP_T = 10243;
    public static final int GL_TRIANGLES = 4;
    public static final int GL_TRIANGLE_FAN = 6;
    public static final int GL_UNSIGNED_BYTE = 5121;
    public static final int GL_UNSIGNED_INT = 5125;
    public static final int GL_UNSIGNED_INT_8_8_8_8_REV = 33639;
    public static final int GL_VENDOR = 7936;
    public static final int GL_VERSION = 7938;
    public static final int GL_VERTEX_ARRAY = 32884;
    public static final int GL_VERTEX_PROGRAM_ARB = 34336;
    // ---- redundant-call filter: skip JNI calls that would set a state the driver already has. Cleared every frame as a safety net. ----
    private static final int[] bindCache = new int[4];
    private static int curUnit = 0;
    private static final byte[] capCache = new byte[65536]; // 0 unknown, 1 off, 2 on
    private static final byte[] texCap = new byte[4];
    private static final boolean[] csKnown = new boolean[4 * 8];
    private static final boolean[] csVal = new boolean[4 * 8];
    private static int depthMaskState = -1, blendS = -1, blendD = -1;
    private static float cr = -1, cg = -1, cb = -1, ca = -1;
    private static final int[][] envCache = new int[4][65536]; // value+1, 0 unknown
    public static void resetStateCache() {
        java.util.Arrays.fill(bindCache, -1);
        java.util.Arrays.fill(capCache, (byte) 0);
        java.util.Arrays.fill(texCap, (byte) 0);
        java.util.Arrays.fill(csKnown, false);
        depthMaskState = -1; blendS = -1; blendD = -1; cr = -1;
        for (int[] e : envCache) java.util.Arrays.fill(e, 0);
        curUnit = 0;
    }
    static { resetStateCache(); }
    public void glActiveTexture(int a0) {
        curUnit = Math.max(0, a0 - GL_TEXTURE0) & 3;
        GlNative.calls++; GlNative.glActiveTexture_0(a0);
        if (GlNative.dbg) GlNative.chk("glActiveTexture");
    }
    public void glAlphaFunc(int a0, float a1) {
        GlNative.calls++; GlNative.glAlphaFunc_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glAlphaFunc");
    }
    public void glBegin(int a0) {
        GlNative.calls++; GlNative.glBegin_0(a0);
    }
    public void glBindBuffer(int a0, int a1) {
        GlNative.calls++; GlNative.glBindBuffer_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glBindBuffer");
    }
    public void glBindProgramARB(int a0, int a1) {
        GlNative.calls++; GlNative.glBindProgramARB_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glBindProgramARB");
    }
    public void glBindTexture(int a0, int a1) {
        GlNative.calls++; GlNative.glBindTexture_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glBindTexture(" + (a0) + "," + (a1) + ")");
    }
    public void glBlendFunc(int a0, int a1) {
        if (a0 == blendS && a1 == blendD) return; blendS = a0; blendD = a1;
        GlNative.calls++; GlNative.glBlendFunc_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glBlendFunc");
    }
    public void glBufferData(int a0, long a1, java.nio.Buffer a2, int a3) {
        GlNative.calls++; GlNative.glBufferData_0(a0, a1, GlBuf.ptr(a2, 8), a3);
        if (GlNative.dbg) GlNative.chk("glBufferData");
    }
    public void glBufferSubData(int a0, long a1, long a2, java.nio.Buffer a3) {
        GlNative.calls++; GlNative.glBufferSubData_0(a0, a1, a2, GlBuf.ptr(a3, 8));
        if (GlNative.dbg) GlNative.chk("glBufferSubData");
    }
    public void glCallList(int a0) {
        GlNative.calls++; GlNative.glCallList_0(a0);
        if (GlNative.dbg) GlNative.chk("glCallList");
    }
    public void glClearColor(float a0, float a1, float a2, float a3) {
        GlNative.calls++; GlNative.glClearColor_0(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glClearColor");
    }
    public void glClearDepth(double a0) {
        GlNative.calls++; GlNative.glClearDepth_0(a0);
        if (GlNative.dbg) GlNative.chk("glClearDepth");
    }
    public void glClear(int a0) {
        GlNative.calls++; GlNative.glClear_0(a0);
        if (GlNative.dbg) GlNative.chk("glClear");
    }
    public void glColor3ub(byte a0, byte a1, byte a2) {
        cr = -1;
        GlNative.calls++; GlNative.glColor3ub_0(a0, a1, a2);
    }
    public void glColor4fv(float[] a0, int a1) {
        cr = -1;
        GlNative.calls++; GlNative.glColor4fv_0(a0, a1);
    }
    public void glColor4f(float a0, float a1, float a2, float a3) {
        if (a0 == cr && a1 == cg && a2 == cb && a3 == ca) return; cr = a0; cg = a1; cb = a2; ca = a3;
        GlNative.calls++; GlNative.glColor4f_0(a0, a1, a2, a3);
    }
    public void glColor4ub(byte a0, byte a1, byte a2, byte a3) {
        cr = -1;
        GlNative.calls++; GlNative.glColor4ub_0(a0, a1, a2, a3);
    }
    public void glColorMaterial(int a0, int a1) {
        GlNative.calls++; GlNative.glColorMaterial_0(a0, a1);
    }
    public void glColorPointer(int a0, int a1, int a2, java.nio.Buffer a3) {
        GlNative.calls++; GlNative.glColorPointer_0(a0, a1, a2, GlBuf.ptr(a3, 1));
    }
    public void glColorPointer(int a0, int a1, int a2, long a3) {
        GlNative.calls++; GlNative.glColorPointer_1(a0, a1, a2, a3);
    }
    public void glCopyPixels(int a0, int a1, int a2, int a3, int a4) {
        GlNative.calls++; GlNative.glCopyPixels_0(a0, a1, a2, a3, a4);
        if (GlNative.dbg) GlNative.chk("glCopyPixels");
    }
    public void glCullFace(int a0) {
        GlNative.calls++; GlNative.glCullFace_0(a0);
        if (GlNative.dbg) GlNative.chk("glCullFace");
    }
    public void glDeleteBuffers(int a0, int[] a1, int a2) {
        GlNative.calls++; GlNative.glDeleteBuffers_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glDeleteBuffers");
    }
    public void glDeleteLists(int a0, int a1) {
        GlNative.calls++; GlNative.glDeleteLists_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glDeleteLists");
    }
    public void glDeleteTextures(int a0, int[] a1, int a2) {
        java.util.Arrays.fill(bindCache, -1);
        GlNative.calls++; GlNative.glDeleteTextures_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glDeleteTextures");
    }
    public void glDepthFunc(int a0) {
        GlNative.calls++; GlNative.glDepthFunc_0(a0);
        if (GlNative.dbg) GlNative.chk("glDepthFunc");
    }
    public void glDepthMask(boolean a0) {
        int dm = a0 ? 1 : 0; if (dm == depthMaskState) return; depthMaskState = dm;
        GlNative.calls++; GlNative.glDepthMask_0(a0);
        if (GlNative.dbg) GlNative.chk("glDepthMask");
    }
    public void glDisableClientState(int a0) {
        int ci = csIndex(a0); if (ci >= 0) { if (csKnown[ci] && !csVal[ci]) return; csKnown[ci] = true; csVal[ci] = false; }
        GlNative.calls++; GlNative.glDisableClientState_0(a0);
        if (GlNative.dbg) GlNative.chk("glDisableClientState");
    }
    public void glDisable(int a0) {
        if (a0 == 3553) { if (texCap[curUnit] == 1) return; texCap[curUnit] = 1; }
        else if (a0 >= 0 && a0 < 65536) { if (capCache[a0] == 1) return; capCache[a0] = 1; }
        GlNative.calls++; GlNative.glDisable_0(a0);
        if (GlNative.dbg) GlNative.chk("glDisable(" + (a0) + ")");
    }
    public void glDrawBuffer(int a0) {
        GlNative.calls++; GlNative.glDrawBuffer_0(a0);
        if (GlNative.dbg) GlNative.chk("glDrawBuffer");
    }
    public void glDrawElements(int a0, int a1, int a2, java.nio.Buffer a3) {
        GlNative.calls++; GlNative.glDrawElements_0(a0, a1, a2, GlBuf.ptr(a3, 9));
        if (GlNative.dbg) GlNative.chk("glDrawElements");
    }
    public void glDrawElements(int a0, int a1, int a2, long a3) {
        GlNative.calls++; GlNative.glDrawElements_1(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glDrawElements");
    }
    public void glDrawPixels(int a0, int a1, int a2, int a3, java.nio.Buffer a4) {
        GlNative.calls++; GlNative.glDrawPixels_0(a0, a1, a2, a3, GlBuf.ptr(a4, 8));
        if (GlNative.dbg) GlNative.chk("glDrawPixels");
    }
    public void glEnableClientState(int a0) {
        int ci = csIndex(a0); if (ci >= 0) { if (csKnown[ci] && csVal[ci]) return; csKnown[ci] = true; csVal[ci] = true; }
        GlNative.calls++; GlNative.glEnableClientState_0(a0);
        if (GlNative.dbg) GlNative.chk("glEnableClientState(" + (a0) + ")");
    }
    public void glEnable(int a0) {
        if (a0 == 3553) { if (texCap[curUnit] == 2) return; texCap[curUnit] = 2; }
        else if (a0 >= 0 && a0 < 65536) { if (capCache[a0] == 2) return; capCache[a0] = 2; }
        GlNative.calls++; GlNative.glEnable_0(a0);
        if (GlNative.dbg) GlNative.chk("glEnable(" + (a0) + ")");
    }
    public void glEndList() {
        GlNative.calls++; GlNative.glEndList_0();
        if (GlNative.dbg) GlNative.chk("glEndList");
    }
    public void glEnd() {
        GlNative.calls++; GlNative.glEnd_0();
        if (GlNative.dbg) GlNative.chk("glEnd");
    }
    public void glFogfv(int a0, float[] a1, int a2) {
        GlNative.calls++; GlNative.glFogfv_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glFogfv");
    }
    public void glFogf(int a0, float a1) {
        GlNative.calls++; GlNative.glFogf_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glFogf");
    }
    public void glFogi(int a0, int a1) {
        GlNative.calls++; GlNative.glFogi_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glFogi");
    }
    public void glGenBuffers(int a0, int[] a1, int a2) {
        GlNative.calls++; GlNative.glGenBuffers_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glGenBuffers");
    }
    public int glGenLists(int a0) {
        GlNative.calls++; return GlNative.glGenLists_0(a0);
    }
    public void glGenProgramsARB(int a0, int[] a1, int a2) {
        GlNative.calls++; GlNative.glGenProgramsARB_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glGenProgramsARB");
    }
    public void glGenTextures(int a0, int[] a1, int a2) {
        GlNative.calls++; GlNative.glGenTextures_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glGenTextures");
    }
    public void glGenerateMipmap(int a0) {
        GlNative.calls++; GlNative.glGenerateMipmap_0(a0);
        if (GlNative.dbg) GlNative.chk("glGenerateMipmap");
    }
    public void glGetFloatv(int a0, float[] a1, int a2) {
        GlNative.calls++; GlNative.glGetFloatv_1(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glGetFloatv");
    }
    public void glGetIntegerv(int a0, int[] a1, int a2) {
        GlNative.calls++; GlNative.glGetIntegerv_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glGetIntegerv");
    }
    public void glHint(int a0, int a1) {
        GlNative.calls++; GlNative.glHint_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glHint");
    }
    public void glInterleavedArrays(int a0, int a1, java.nio.Buffer a2) {
        GlNative.calls++; GlNative.glInterleavedArrays_0(a0, a1, GlBuf.ptr(a2, 7));
        if (GlNative.dbg) GlNative.chk("glInterleavedArrays");
    }
    public void glInterleavedArrays(int a0, int a1, long a2) {
        GlNative.calls++; GlNative.glInterleavedArrays_1(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glInterleavedArrays");
    }
    public void glLightModelfv(int a0, float[] a1, int a2) {
        GlNative.calls++; GlNative.glLightModelfv_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glLightModelfv");
    }
    public void glLightfv(int a0, int a1, float[] a2, int a3) {
        GlNative.calls++; GlNative.glLightfv_0(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glLightfv");
    }
    public void glLightf(int a0, int a1, float a2) {
        GlNative.calls++; GlNative.glLightf_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glLightf");
    }
    public void glLineWidth(float a0) {
        GlNative.calls++; GlNative.glLineWidth_0(a0);
        if (GlNative.dbg) GlNative.chk("glLineWidth");
    }
    public void glLoadIdentity() {
        GlNative.calls++; GlNative.glLoadIdentity_0();
        if (GlNative.dbg) GlNative.chk("glLoadIdentity");
    }
    public void glLoadMatrixf(float[] a0, int a1) {
        GlNative.calls++; GlNative.glLoadMatrixf_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glLoadMatrixf");
    }
    public void glMatrixMode(int a0) {
        GlNative.calls++; GlNative.glMatrixMode_0(a0);
        if (GlNative.dbg) GlNative.chk("glMatrixMode(" + (a0) + ")");
    }
    public void glMultiTexCoord2f(int a0, float a1, float a2) {
        GlNative.calls++; GlNative.glMultiTexCoord2f_0(a0, a1, a2);
    }
    public void glNewList(int a0, int a1) {
        GlNative.calls++; GlNative.glNewList_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glNewList");
    }
    public void glNormalPointer(int a0, int a1, java.nio.Buffer a2) {
        GlNative.calls++; GlNative.glNormalPointer_0(a0, a1, GlBuf.ptr(a2, 2));
    }
    public void glNormalPointer(int a0, int a1, long a2) {
        GlNative.calls++; GlNative.glNormalPointer_1(a0, a1, a2);
    }
    public void glOrtho(double a0, double a1, double a2, double a3, double a4, double a5) {
        GlNative.calls++; GlNative.glOrtho_0(a0, a1, a2, a3, a4, a5);
        if (GlNative.dbg) GlNative.chk("glOrtho(" + (a0) + "," + (a1) + "," + (a2) + "," + (a3) + "," + (a4) + "," + (a5) + ")");
    }
    public void glPixelZoom(float a0, float a1) {
        GlNative.calls++; GlNative.glPixelZoom_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glPixelZoom(" + (a0) + "," + (a1) + ")");
    }
    public void glPointParameterfv(int a0, float[] a1, int a2) {
        GlNative.calls++; GlNative.glPointParameterfv_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glPointParameterfv");
    }
    public void glPointParameterf(int a0, float a1) {
        GlNative.calls++; GlNative.glPointParameterf_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glPointParameterf");
    }
    public void glPolygonMode(int a0, int a1) {
        GlNative.calls++; GlNative.glPolygonMode_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glPolygonMode");
    }
    public void glPopAttrib() {
        resetStateCache();
        GlNative.calls++; GlNative.glPopAttrib_0();
        if (GlNative.dbg) GlNative.chk("glPopAttrib");
    }
    public void glPopMatrix() {
        GlNative.calls++; GlNative.glPopMatrix_0();
        if (GlNative.dbg) GlNative.chk("glPopMatrix");
    }
    public void glProgramLocalParameter4fARB(int a0, int a1, float a2, float a3, float a4, float a5) {
        GlNative.calls++; GlNative.glProgramLocalParameter4fARB_0(a0, a1, a2, a3, a4, a5);
        if (GlNative.dbg) GlNative.chk("glProgramLocalParameter4fARB");
    }
    public void glProgramLocalParameter4fvARB(int a0, int a1, float[] a2, int a3) {
        GlNative.calls++; GlNative.glProgramLocalParameter4fvARB_1(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glProgramLocalParameter4fvARB");
    }
    public void glProgramStringARB(int a0, int a1, int a2, String a3) {
        GlNative.calls++; GlNative.glProgramStringARB_0(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glProgramStringARB");
    }
    public void glPushAttrib(int a0) {
        resetStateCache();
        GlNative.calls++; GlNative.glPushAttrib_0(a0);
        if (GlNative.dbg) GlNative.chk("glPushAttrib");
    }
    public void glPushMatrix() {
        GlNative.calls++; GlNative.glPushMatrix_0();
        if (GlNative.dbg) GlNative.chk("glPushMatrix");
    }
    public void glRasterPos2i(int a0, int a1) {
        GlNative.calls++; GlNative.glRasterPos2i_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glRasterPos2i(" + (a0) + "," + (a1) + ")");
    }
    public void glReadBuffer(int a0) {
        GlNative.calls++; GlNative.glReadBuffer_0(a0);
        if (GlNative.dbg) GlNative.chk("glReadBuffer");
    }
    public void glReadPixels(int a0, int a1, int a2, int a3, int a4, int a5, java.nio.Buffer a6) {
        long rp = GlBuf.readPtr(a6);
        GlNative.calls++; GlNative.glReadPixels_0(a0, a1, a2, a3, a4, a5, rp);
        if (GlNative.dbg) GlNative.chk("glReadPixels");
        GlBuf.readDone(a6);
    }
    public void glRotatef(float a0, float a1, float a2, float a3) {
        GlNative.calls++; GlNative.glRotatef_0(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glRotatef");
    }
    public void glScalef(float a0, float a1, float a2) {
        GlNative.calls++; GlNative.glScalef_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glScalef");
    }
    public void glCopyTexSubImage2D(int a0, int a1, int a2, int a3, int a4, int a5, int a6, int a7) {
        GlNative.calls++; GlNative.glCopyTexSubImage2D_0(a0, a1, a2, a3, a4, a5, a6, a7);
    }
    public void glScissor(int a0, int a1, int a2, int a3) {
        GlNative.calls++; GlNative.glScissor_0(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glScissor(" + (a0) + "," + (a1) + "," + (a2) + "," + (a3) + ")");
    }
    public void glShadeModel(int a0) {
        GlNative.calls++; GlNative.glShadeModel_0(a0);
        if (GlNative.dbg) GlNative.chk("glShadeModel");
    }
    public void glTexCoord2f(float a0, float a1) {
        GlNative.calls++; GlNative.glTexCoord2f_0(a0, a1);
    }
    public void glTexCoordPointer(int a0, int a1, int a2, java.nio.Buffer a3) {
        GlNative.calls++; GlNative.glTexCoordPointer_0(a0, a1, a2, GlBuf.ptr(a3, 3 + clientTex));
    }
    public void glTexCoordPointer(int a0, int a1, int a2, long a3) {
        GlNative.calls++; GlNative.glTexCoordPointer_1(a0, a1, a2, a3);
    }
    public void glTexEnvfv(int a0, int a1, float[] a2, int a3) {
        GlNative.calls++; GlNative.glTexEnvfv_0(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glTexEnvfv");
    }
    public void glTexEnvf(int a0, int a1, float a2) {
        GlNative.calls++; GlNative.glTexEnvf_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glTexEnvf");
    }
    public void glTexEnvi(int a0, int a1, int a2) {
        GlNative.calls++; GlNative.glTexEnvi_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glTexEnvi");
    }
    public void glTexGenfv(int a0, int a1, float[] a2, int a3) {
        GlNative.calls++; GlNative.glTexGenfv_0(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glTexGenfv");
    }
    public void glTexGeni(int a0, int a1, int a2) {
        GlNative.calls++; GlNative.glTexGeni_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glTexGeni");
    }
    public void glTexImage1D(int a0, int a1, int a2, int a3, int a4, int a5, int a6, java.nio.Buffer a7) {
        GlNative.calls++; GlNative.glTexImage1D_0(a0, a1, a2, a3, a4, a5, a6, GlBuf.ptr(a7, 8));
        if (GlNative.dbg) GlNative.chk("glTexImage1D");
    }
    /** One 3x3 box-blur pass (separable, edges clamped) over a w*h alpha image. */
    private static void softenShadow(int[] a, int w, int h) {
        int[] t = new int[a.length];
        for (int y = 0; y < h; y++) {
            int r = y * w;
            for (int x = 0; x < w; x++) {
                int l = x > 0 ? a[r + x - 1] : a[r + x], c = a[r + x], rr = x < w - 1 ? a[r + x + 1] : a[r + x];
                t[r + x] = (l + c + rr) / 3;
            }
        }
        for (int y = 0; y < h; y++) {
            int up = (y > 0 ? y - 1 : y) * w, mid = y * w, dn = (y < h - 1 ? y + 1 : y) * w;
            for (int x = 0; x < w; x++) {
                a[mid + x] = (t[up + x] + t[mid + x] + t[dn + x]) / 3;
            }
        }
    }
    public void glTexImage2D(int a0, int a1, int a2, int a3, int a4, int a5, int a6, int a7, java.nio.Buffer a8) {
        // Alpha-only textures (the shadow map) come out fully opaque through gl4es, so upload them as RGBA (0,0,0,a), which samples identically.
        if (a2 == 0x1906 && a6 == 0x1906 && a7 == 0x1401 && a8 instanceof java.nio.ByteBuffer && a3 > 0 && a4 > 0) {
            java.nio.ByteBuffer src = ((java.nio.ByteBuffer) a8).duplicate();
            int px = a3 * a4;
            if (src.remaining() >= px) {
                java.nio.ByteBuffer dst = java.nio.ByteBuffer.allocateDirect(px * 4).order(java.nio.ByteOrder.nativeOrder());
                int p0 = src.position();
                int[] al = new int[px];
                for (int i = 0; i < px; i++) al[i] = src.get(p0 + i) & 0xFF;
                if (rt4.FxConfig.softShadows && a3 >= 16 && a4 >= 16) { softenShadow(al, a3, a4); } // soft shadow edges
                for (int i = 0; i < px; i++) { dst.put((byte) 0); dst.put((byte) 0); dst.put((byte) 0); dst.put((byte) al[i]); }
                dst.flip();
                a2 = 0x1908; a6 = 0x1908; a8 = dst;
            }
        }
        GlNative.calls++; GlNative.glTexImage2D_0(a0, a1, a2, a3, a4, a5, a6, a7, GlBuf.ptr(a8, 8));
        if (GlNative.dbg) GlNative.chk("glTexImage2D");
    }
    public void glTexImage3D(int a0, int a1, int a2, int a3, int a4, int a5, int a6, int a7, int a8, java.nio.Buffer a9) {
        GlNative.calls++; GlNative.glTexImage3D_0(a0, a1, a2, a3, a4, a5, a6, a7, a8, GlBuf.ptr(a9, 8));
        if (GlNative.dbg) GlNative.chk("glTexImage3D");
    }
    public void glTexParameteri(int a0, int a1, int a2) {
        GlNative.calls++; GlNative.glTexParameteri_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glTexParameteri");
    }
    public void glTexStorage2D(int a0, int a1, int a2, int a3, int a4) {
        GlNative.calls++; GlNative.glTexStorage2D_0(a0, a1, a2, a3, a4);
        if (GlNative.dbg) GlNative.chk("glTexStorage2D");
    }
    public void glTexSubImage2D(int a0, int a1, int a2, int a3, int a4, int a5, int a6, int a7, java.nio.Buffer a8) {
        GlNative.calls++; GlNative.glTexSubImage2D_0(a0, a1, a2, a3, a4, a5, a6, a7, GlBuf.ptr(a8, 8));
        if (GlNative.dbg) GlNative.chk("glTexSubImage2D");
    }
    public void glTranslatef(float a0, float a1, float a2) {
        GlNative.calls++; GlNative.glTranslatef_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glTranslatef");
    }
    public void glVertex2f(float a0, float a1) {
        GlNative.calls++; GlNative.glVertex2f_0(a0, a1);
    }
    public void glVertexPointer(int a0, int a1, int a2, java.nio.Buffer a3) {
        GlNative.calls++; GlNative.glVertexPointer_0(a0, a1, a2, GlBuf.ptr(a3, 0));
    }
    public void glVertexPointer(int a0, int a1, int a2, long a3) {
        GlNative.calls++; GlNative.glVertexPointer_1(a0, a1, a2, a3);
    }
    public void glViewport(int a0, int a1, int a2, int a3) {
        GlNative.calls++; GlNative.glViewport_0(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glViewport(" + (a0) + "," + (a1) + "," + (a2) + "," + (a3) + ")");
    }

    public String glGetString(int a0) { return GlNative.glGetString(a0); }
    public boolean isExtensionAvailable(String a0) {
        // gl4es's ARB vertex-program translator crashes on the client's water program (native crash in libgl4es), so report it as unsupported; the client falls back to plain water.
        if (a0.equals("GL_ARB_vertex_program")) return false;
        // Shiny metal/leather gear uses a cube-map + texgen + 3-unit combiner chain that gl4es does not reproduce (worn items come out pale); use the client's plain fallback instead.
        if (a0.equals("GL_ARB_texture_cube_map")) return false;
        String e = GlNative.glGetString(GL_EXTENSIONS);
        if (e == null) return false;
        for (String s : e.split(" ")) { if (s.equals(a0)) return true; }
        return false;
    }
    public void setSwapInterval(int a0) { }
    public void glGetFloatv(int a0, java.nio.FloatBuffer a1) {
        float[] t = new float[16];
        glGetFloatv(a0, t, 0);
        int n = Math.min(16, a1.remaining());
        for (int i = 0; i < n; i++) a1.put(a1.position() + i, t[i]);
    }
    public void glProgramLocalParameter4fvARB(int a0, int a1, java.nio.FloatBuffer a2) {
        int p = a2.position();
        glProgramLocalParameter4fARB(a0, a1, a2.get(p), a2.get(p + 1), a2.get(p + 2), a2.get(p + 3));
    }
    private static int clientTex;
    private static int csIndex(int cap) {
        int k;
        switch (cap) { case 32884: k = 0; break; case 32885: k = 1; break; case 32886: k = 2; break; case 32888: k = 3; break; case 32887: k = 4; break; default: return -1; }
        return (k == 3 ? clientTexIdx() : 0) * 8 + k;
    }
    private static int clientTexIdx() { return clientTex; }
    public void glClientActiveTexture(int a0) { clientTex = Math.max(0, a0 - GL_TEXTURE0) & 3; GlNative.glClientActiveTexture_0(a0); }
}
