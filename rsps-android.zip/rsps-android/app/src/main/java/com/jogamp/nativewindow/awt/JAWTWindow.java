package com.jogamp.nativewindow.awt;

import com.jogamp.opengl.EglBackend;

/** Stand-in for the desktop window handle; the Android app installs the EGL backend before the GPU renderer starts. */
public class JAWTWindow {
    public static volatile EglBackend backend;
    public static volatile int samples;
    public static volatile String libPath = "libgl4es.so";
    public static class Lock { public boolean isLocked() { return false; } }
    private static final Lock LOCK = new Lock();
    public Lock getLock() { return LOCK; }
    public void lockSurface() { }
    public void unlockSurface() { }
}
