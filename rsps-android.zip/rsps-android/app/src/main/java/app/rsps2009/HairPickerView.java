package app.rsps2009;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.OverScroller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;

import rt4.HairPicker;

/**
 * Rainbow Scape hair picker: a full-screen, app-drawn browser for hair styles with live head previews.
 * The heads are drawn by the game's own renderer (rt4.HairPicker); taps go back to the server as Studio clicks.
 */
final class HairPickerView extends FrameLayout {
    // colours
    private static final int BG_TOP = 0xFF161A2B, BG_BOT = 0xFF0E1020;
    private static final int CARD = 0xFF1B2034, CARD2 = 0xFF22283F, CARD_HI = 0xFF2C2A20;
    private static final int GOLD = 0xFFFFC94A, GOLD_D = 0xFFB8862B;
    private static final int TXT = 0xFFF2F3F8, TXT2 = 0xFFA3A9C2, TXT3 = 0xFF6B7290;

    private static final String[] TAB_NAME = {"All", "\u2605 Faves", "Short", "Medium", "Long", "Up-dos", "Anime"};
    private static final char[] TAB_CAT = {'*', 'F', 'S', 'M', 'L', 'U', 'A'};
    private static final HashMap<Character, String> CAT_NAME = new HashMap<Character, String>();
    static {
        CAT_NAME.put('S', "Short"); CAT_NAME.put('M', "Medium"); CAT_NAME.put('L', "Long");
        CAT_NAME.put('U', "Up-do"); CAT_NAME.put('A', "Anime");
    }

    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Typeface bold = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD);
    private final Typeface reg = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL);
    private final RectF r = new RectF();
    private final Path path = new Path();
    private final EditText search;
    private final SharedPreferences prefs;
    private final Canvas2 drawer;

    // layout (pixels)
    private final RectF closeR = new RectF(), leftR = new RectF(), rightR = new RectF(), searchR = new RectF();
    private final RectF gridR = new RectF(), stripR = new RectF(), previewR = new RectF();
    private final RectF searchBtnR = new RectF(), searchCloseR = new RectF();
    private boolean searchOpen;
    private float tabSize = 13;
    private final ArrayList<RectF> tabR = new ArrayList<RectF>();
    private final ArrayList<RectF> swatchR = new ArrayList<RectF>();
    private final ArrayList<RectF> recentR = new ArrayList<RectF>();
    private final ArrayList<HairPicker.Entry> recentE = new ArrayList<HairPicker.Entry>();
    private int cols = 4;
    private float cellW, cellH, gap;

    // state
    private int tab = 0;
    private float pillX = -1, pillW = 0;
    private HairPicker.Entry[] all = new HairPicker.Entry[0];
    private final ArrayList<HairPicker.Entry> shown = new ArrayList<HairPicker.Entry>();
    private int seenVersion = -1, seenGender = -1;
    private String query = "";
    private int picked = -1;          // kit tapped last (shown at once, before the server answers)
    private long pickedAt;
    private final HashSet<Integer> faves = new HashSet<Integer>();
    private final HashMap<Integer, Bitmap> bmp = new HashMap<Integer, Bitmap>();
    private final HashMap<Integer, String> bmpKey = new HashMap<Integer, String>();
    private Bitmap big;
    private int bigSeq = -1;
    private float yaw = 0;
    private long lastSpinTouch;
    private long lastFrame;
    private Runnable onClose;

    // scrolling
    private final OverScroller scroller;
    private VelocityTracker vt;
    private final int slop;
    private float scrollY, maxScroll;
    private float swScroll, swMax, swLeft, swRight;
    private boolean downInStrip;
    private float downX, downY, lastY, lastX;
    private boolean dragging, spinning, downInGrid, downInPreview;

    HairPickerView(Context ctx) {
        super(ctx);
        d = ctx.getResources().getDisplayMetrics().density;
        setWillNotDraw(false);
        prefs = ctx.getSharedPreferences("hairpicker", Context.MODE_PRIVATE);
        scroller = new OverScroller(ctx);
        slop = ViewConfiguration.get(ctx).getScaledTouchSlop();
        drawer = new Canvas2();
        addView(drawer, new FrameLayout.LayoutParams(-1, -1));

        search = new EditText(ctx);
        search.setBackgroundColor(Color.TRANSPARENT);
        search.setTextColor(TXT);
        search.setHintTextColor(TXT3);
        search.setHint("Search styles");
        search.setSingleLine(true);
        search.setTextSize(15);
        search.setPadding(0, 0, 0, 0);
        search.setGravity(Gravity.CENTER_VERTICAL);
        search.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        search.setImeOptions(EditorInfo.IME_ACTION_DONE | EditorInfo.IME_FLAG_NO_EXTRACT_UI | EditorInfo.IME_FLAG_NO_FULLSCREEN);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                query = s.toString().trim().toLowerCase(Locale.US);
                scrollY = 0;
                refilter();
                drawer.invalidate();
            }
        });
        addView(search, new FrameLayout.LayoutParams(10, 10));
        search.setVisibility(View.GONE);
        setVisibility(View.GONE);
    }

    void setOnClose(Runnable r) { onClose = r; }

    boolean isOpen() { return getVisibility() == View.VISIBLE; }

    void open() {
        if (isOpen()) return;
        loadFaves();
        tab = 0;
        pillX = -1;
        scrollY = 0;
        picked = -1;
        query = "";
        search.setText("");
        searchOpen = false;
        search.setVisibility(View.GONE);
        yaw = 0;
        seenVersion = -1;
        setVisibility(View.VISIBLE);
        HairPicker.pickerOpen = true;
        lastFrame = System.currentTimeMillis();
        drawer.postInvalidateOnAnimation();
        // jump to the style you have on now
        post(new Runnable() { @Override public void run() { scrollToCurrent(); } });
    }

    void close() {
        if (!isOpen()) return;
        hideKeyboard();
        setVisibility(View.GONE);
        HairPicker.pickerOpen = false;
        if (onClose != null) onClose.run();
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(search.getWindowToken(), 0);
            search.clearFocus();
        } catch (Throwable ignored) { }
    }

    // ------------------------------------------------------------------ data
    private String favKey() { return "fav" + HairPicker.listGender; }
    private String recentKey() { return "recent" + HairPicker.listGender; }

    private void loadFaves() {
        faves.clear();
        String s = prefs.getString(favKey(), "");
        for (String t : s.split(",")) {
            try { if (!t.isEmpty()) faves.add(Integer.parseInt(t)); } catch (NumberFormatException ignored) { }
        }
    }

    private void saveFaves() {
        StringBuilder b = new StringBuilder();
        for (Integer k : faves) { if (b.length() > 0) b.append(','); b.append(k); }
        prefs.edit().putString(favKey(), b.toString()).apply();
    }

    private ArrayList<Integer> recent() {
        ArrayList<Integer> out = new ArrayList<Integer>();
        for (String t : prefs.getString(recentKey(), "").split(",")) {
            try { if (!t.isEmpty()) out.add(Integer.parseInt(t)); } catch (NumberFormatException ignored) { }
        }
        return out;
    }

    private void pushRecent(int kit) {
        ArrayList<Integer> l = recent();
        l.remove(Integer.valueOf(kit));
        l.add(0, kit);
        while (l.size() > 4) l.remove(l.size() - 1);
        StringBuilder b = new StringBuilder();
        for (Integer k : l) { if (b.length() > 0) b.append(','); b.append(k); }
        prefs.edit().putString(recentKey(), b.toString()).apply();
    }

    private boolean tabHas(int t) {
        if (t <= 1) return true;
        for (HairPicker.Entry e : all) if (e.cat == TAB_CAT[t]) return true;
        return false;
    }

    private void refilter() {
        shown.clear();
        for (HairPicker.Entry e : all) {
            char c = TAB_CAT[tab];
            if (c == 'F' && !faves.contains(e.kit)) continue;
            if (c != '*' && c != 'F' && e.cat != c) continue;
            if (!query.isEmpty()) {
                String n = e.name.toLowerCase(Locale.US);
                String cn = CAT_NAME.containsKey(e.cat) ? CAT_NAME.get(e.cat).toLowerCase(Locale.US) : "";
                if (!n.contains(query) && !cn.contains(query)) continue;
            }
            shown.add(e);
        }
        layoutGrid();
    }

    private HairPicker.Entry byKit(int kit) {
        for (HairPicker.Entry e : all) if (e.kit == kit) return e;
        return null;
    }

    private int currentKit() {
        if (picked >= 0 && System.currentTimeMillis() - pickedAt < 2500) return picked;
        return HairPicker.curKit;
    }

    private void scrollToCurrent() {
        int cur = currentKit();
        for (int i = 0; i < shown.size(); i++) {
            if (shown.get(i).kit == cur) {
                float top = (i / cols) * (cellH + gap);
                scrollY = Math.max(0, Math.min(maxScroll, top - (gridR.height() - cellH) / 2f));
                drawer.invalidate();
                return;
            }
        }
    }

    // ------------------------------------------------------------------ layout
    @Override protected void onLayout(boolean changed, int l, int t, int rr, int b) {
        super.onLayout(changed, l, t, rr, b);
        doLayout(rr - l, b - t);
    }

    private void doLayout(int w, int h) {
        if (w <= 0 || h <= 0) return;
        float m = 12 * d;
        float hdr = 48 * d;
        closeR.set(w - m - 38 * d, 6 * d, w - m, 44 * d);
        boolean wide = w > h * 1.15f;
        if (wide) {
            float lw = Math.min(w * 0.30f, 330 * d);
            leftR.set(m, hdr, m + lw, h - m);
            rightR.set(leftR.right + m, hdr, w - m, h - m);
        } else {
            float lh = Math.min(h * 0.30f, 340 * d);
            leftR.set(m, hdr, w - m, hdr + lh);
            rightR.set(m, leftR.bottom + m, w - m, h - m);
        }
        previewR.set(leftR.left, leftR.top + 56 * d, leftR.right, leftR.bottom - 4 * d);

        // search button + category tabs on one row; search opens over the tabs
        float in = 10 * d, rowH = 38 * d;
        searchBtnR.set(rightR.left + in, rightR.top + in, rightR.left + in + rowH, rightR.top + in + rowH);
        searchR.set(rightR.left + in, rightR.top + in, rightR.right - in, rightR.top + in + rowH);
        p.setTypeface(bold);
        p.setTextSize(13 * d);
        tabR.clear();
        float pad = 18 * d, sp = 2 * d;
        float avail = rightR.right - in - (searchBtnR.right + 8 * d);
        float need = 0;
        for (String t : TAB_NAME) need += Math.max(54 * d, p.measureText(t) + pad) + sp;
        float tx = searchBtnR.right + 8 * d, ty = searchBtnR.top, minW = 54 * d;
        if (need > avail) {
            pad = Math.max(8 * d, pad - (need - avail) / TAB_NAME.length);
            float need2 = 0;
            for (String t : TAB_NAME) need2 += Math.max(minW, p.measureText(t) + pad) + sp;
            if (need2 > avail) {
                // narrow screen: the tabs get their own row under the search button, spread to fill it
                tx = rightR.left + in;
                ty = searchBtnR.bottom + 6 * d;
                avail = rightR.width() - 2 * in;
                float text = 0;
                for (String t : TAB_NAME) text += p.measureText(t);
                pad = Math.max(6 * d, (avail - text - sp * TAB_NAME.length) / TAB_NAME.length);
                minW = 0;
                if (text + (pad + sp) * TAB_NAME.length > avail) p.setTextSize(11.5f * d);
            }
        }
        tabSize = p.getTextSize();
        for (String t : TAB_NAME) {
            float tw = Math.max(minW, p.measureText(t) + pad);
            tabR.add(new RectF(tx, ty, tx + tw, ty + rowH));
            tx += tw + sp;
        }
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) search.getLayoutParams();
        int sl = Math.round(searchR.left + 40 * d), st = Math.round(searchR.top), swd = Math.round(searchR.width() - 80 * d), sh = Math.round(searchR.height());
        if (lp.leftMargin != sl || lp.topMargin != st || lp.width != swd || lp.height != sh) {
            lp.leftMargin = sl; lp.topMargin = st; lp.width = swd; lp.height = sh;
            search.setLayoutParams(lp);
        }
        searchCloseR.set(searchR.right - 38 * d, searchR.top, searchR.right, searchR.bottom);

        float stripH = 44 * d;
        stripR.set(rightR.left + in, rightR.bottom - in - stripH, rightR.right - in, rightR.bottom - in);
        gridR.set(rightR.left + in, Math.max(searchR.bottom, tabR.get(0).bottom) + 8 * d, rightR.right - in - 10 * d, stripR.top - 6 * d);
        layoutGrid();
    }

    private void layoutGrid() {
        if (gridR.width() <= 0) return;
        gap = 10 * d;
        cols = Math.max(2, (int) ((gridR.width() + gap) / (104 * d + gap)));
        cellW = (gridR.width() - gap * (cols - 1)) / cols;
        cellH = cellW * 1.06f;
        int rows = (shown.size() + cols - 1) / cols;
        float content = rows * cellH + Math.max(0, rows - 1) * gap + 8 * d;
        maxScroll = Math.max(0, content - gridR.height());
        if (scrollY > maxScroll) scrollY = maxScroll;
    }

    // ------------------------------------------------------------------ drawing
    private final class Canvas2 extends View {
        Canvas2() { super(HairPickerView.this.getContext()); }
        @Override protected void onDraw(Canvas c) {
            try { paint(c); } catch (Throwable t) { android.util.Log.e("rsps2009", "hair picker draw", t); }
            if (isOpen()) postInvalidateOnAnimation();
        }
    }

    private void paint(Canvas c) {
        long now = System.currentTimeMillis();
        float dt = Math.min(0.05f, (now - lastFrame) / 1000f);
        lastFrame = now;
        int w = getWidth(), h = getHeight();

        // new list from the server (first open, or after switching male/female)
        if (HairPicker.listVersion != seenVersion || HairPicker.listGender != seenGender) {
            seenVersion = HairPicker.listVersion;
            if (HairPicker.listGender != seenGender) { seenGender = HairPicker.listGender; loadFaves(); bmp.clear(); bmpKey.clear(); }
            all = HairPicker.entries;
            if (!tabHas(tab)) tab = 0;
            refilter();
        }
        if (!MobileLayout_open()) { post(new Runnable() { @Override public void run() { close(); } }); return; }

        if (scroller.computeScrollOffset()) scrollY = Math.max(0, Math.min(maxScroll, scroller.getCurrY()));

        // background
        p.setShader(new LinearGradient(0, 0, 0, h, BG_TOP, BG_BOT, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);

        // header
        p.setTypeface(bold);
        p.setTextSize(19 * d);
        p.setColor(TXT);
        float hx = 16 * d, hy = 32 * d;
        c.drawText("Character Studio", hx, hy, p);
        float tw = p.measureText("Character Studio");
        p.setTextSize(14 * d);
        p.setColor(GOLD);
        c.drawText("\u203A  HAIR", hx + tw + 12 * d, hy - 1 * d, p);
        p.setColor(TXT3);
        p.setTypeface(reg);
        p.setTextSize(12.5f * d);
        String sub = all.length + " styles";
        c.drawText(sub, hx + tw + 12 * d + 72 * d, hy - 1 * d, p);

        // close
        p.setColor(0xFF3A2030);
        c.drawOval(closeR, p);
        p.setColor(0xFFFFD6DE);
        p.setStrokeWidth(2.4f * d);
        p.setStrokeCap(Paint.Cap.ROUND);
        float cx = closeR.centerX(), cy = closeR.centerY(), k = 7 * d;
        c.drawLine(cx - k, cy - k, cx + k, cy + k, p);
        c.drawLine(cx - k, cy + k, cx + k, cy - k, p);

        paintPreview(c, dt, now);
        paintRight(c, dt, now);
    }

    private static boolean MobileLayout_open() { return rt4.MobileLayout.studioOpen; }

    private void card(Canvas c, RectF rr, int fill, float rad) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x55000000);
        r.set(rr.left, rr.top + 4 * d, rr.right, rr.bottom + 6 * d);
        c.drawRoundRect(r, rad, rad, p);
        p.setColor(fill);
        c.drawRoundRect(rr, rad, rad, p);
    }

    private void paintPreview(Canvas c, float dt, long now) {
        card(c, leftR, CARD, 22 * d);
        int kit = currentKit();
        HairPicker.Entry e = byKit(kit);
        p.setTypeface(bold);
        p.setTextSize(19 * d);
        p.setColor(TXT);
        String title = e == null ? (kit < 0 ? "Hidden by your hat" : "Your hair") : e.name;
        c.drawText(ellipsize(title, leftR.width() - 32 * d), leftR.left + 16 * d, leftR.top + 30 * d, p);
        p.setTypeface(reg);
        p.setTextSize(12 * d);
        p.setColor(TXT2);
        String cat = e == null ? "" : (CAT_NAME.containsKey(e.cat) ? CAT_NAME.get(e.cat) : "");
        c.drawText((cat.isEmpty() ? "" : cat + "  \u00B7  ") + "drag to spin", leftR.left + 16 * d, leftR.top + 48 * d, p);

        // spin: slowly by itself, or by your finger
        if (!spinning && now - lastSpinTouch > 2500) yaw = (yaw + dt * 220f) % 2048f;
        int q = ((int) yaw) & 0x7F0;   // steps of 16 so the game redraws only when it really turned
        HairPicker.bigKit = kit;
        HairPicker.bigYaw = q;
        int bw = Math.max(120, Math.min(380, Math.round(previewR.width() / 1.6f)));
        int bh = Math.max(140, Math.round(bw * previewR.height() / Math.max(1f, previewR.width())));
        if (bh > 460) { bw = Math.round(bw * 460f / bh); bh = 460; }
        HairPicker.bigW = bw;
        HairPicker.bigH = bh;
        if (HairPicker.bigSeq != bigSeq && HairPicker.bigPixels != null) {
            bigSeq = HairPicker.bigSeq;
            try {
                Bitmap nb = Bitmap.createBitmap(HairPicker.bigPixels, HairPicker.bigPixW, HairPicker.bigPixH, Bitmap.Config.ARGB_8888);
                if (big != null) big.recycle();
                big = nb;
            } catch (Throwable ignored) { }
        }
        // soft spotlight behind the head
        float gx = previewR.centerX(), gy = previewR.top + previewR.height() * 0.42f;
        p.setShader(new android.graphics.RadialGradient(gx, gy, previewR.width() * 0.55f, 0x33FFC94A, 0x00FFC94A, Shader.TileMode.CLAMP));
        c.drawCircle(gx, gy, previewR.width() * 0.55f, p);
        p.setShader(null);
        if (big != null) {
            float s = Math.min(previewR.width() / big.getWidth(), previewR.height() / big.getHeight());
            float dw = big.getWidth() * s, dh = big.getHeight() * s;
            r.set(previewR.centerX() - dw / 2, previewR.bottom - dh, previewR.centerX() + dw / 2, previewR.bottom);
            c.save();
            c.clipRect(leftR);
            c.drawBitmap(big, null, r, bp);
            c.restore();
            // fade the bottom into the card
            p.setShader(new LinearGradient(0, leftR.bottom - 60 * d, 0, leftR.bottom, 0x001B2034, CARD, Shader.TileMode.CLAMP));
            r.set(leftR.left, leftR.bottom - 60 * d, leftR.right, leftR.bottom - 22 * d);
            c.drawRect(r, p);
            p.setShader(null);
            p.setColor(CARD);
            r.set(leftR.left, leftR.bottom - 22.5f * d, leftR.right, leftR.bottom);
            c.drawRoundRect(r, 22 * d, 22 * d, p);
        } else {
            spinner(c, previewR.centerX(), previewR.centerY(), 18 * d, now);
        }
        paintRecent(c, kit);
    }

    private void paintRight(Canvas c, float dt, long now) {
        card(c, rightR, CARD, 22 * d);

        // search: a round button; tap it and the search box opens over the tabs
        if (searchOpen) {
            p.setColor(CARD2);
            c.drawRoundRect(searchR, searchR.height() / 2, searchR.height() / 2, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.5f * d);
            p.setColor(GOLD);
            c.drawRoundRect(searchR, searchR.height() / 2, searchR.height() / 2, p);
            p.setStyle(Paint.Style.FILL);
            magnifier(c, searchR.left + 21 * d, searchR.centerY(), GOLD);
            p.setStrokeWidth(2 * d);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(TXT2);
            float qx = searchCloseR.centerX(), qy = searchCloseR.centerY(), qk = 5 * d;
            c.drawLine(qx - qk, qy - qk, qx + qk, qy + qk, p);
            c.drawLine(qx - qk, qy + qk, qx + qk, qy - qk, p);
        } else {
            p.setColor(query.isEmpty() ? CARD2 : 0x40FFC94A);
            c.drawOval(searchBtnR, p);
            magnifier(c, searchBtnR.centerX() + 1 * d, searchBtnR.centerY() + 1 * d, query.isEmpty() ? TXT2 : GOLD);
        }

        // tabs (the gold pill slides to the one you pick)
        p.setTypeface(bold);
        p.setTextSize(tabSize);
        RectF tr = tabR.get(tab);
        if (!searchOpen) {
        if (pillX < 0) { pillX = tr.left; pillW = tr.width(); }
        float sp = Math.min(1f, dt * 14f);
        pillX += (tr.left - pillX) * sp;
        pillW += (tr.width() - pillW) * sp;
        p.setColor(GOLD);
        r.set(pillX, tr.top, pillX + pillW, tr.bottom);
        c.drawRoundRect(r, tr.height() / 2, tr.height() / 2, p);
        for (int i = 0; i < tabR.size(); i++) {
            RectF t = tabR.get(i);
            boolean has = tabHas(i);
            p.setColor(i == tab ? 0xFF1A1405 : (has ? TXT : TXT3));
            float x = t.centerX() - p.measureText(TAB_NAME[i]) / 2;
            c.drawText(TAB_NAME[i], x, t.centerY() + 4.5f * d, p);
        }
        }

        // grid
        c.save();
        c.clipRect(gridR.left - 6 * d, gridR.top, gridR.right + 6 * d, gridR.bottom);
        int cur = currentKit();
        float pulse = 0.5f + 0.5f * (float) Math.sin(now / 420.0);
        int first = Math.max(0, (int) (scrollY / (cellH + gap)) * cols);
        for (int i = first; i < shown.size(); i++) {
            int row = i / cols, col = i % cols;
            float x = gridR.left + col * (cellW + gap);
            float y = gridR.top + 4 * d + row * (cellH + gap) - scrollY;
            if (y > gridR.bottom) break;
            if (y + cellH < gridR.top) continue;
            HairPicker.Entry e = shown.get(i);
            RectF cr = new RectF(x, y, x + cellW, y + cellH);
            boolean sel = e.kit == cur;
            if (sel) {
                // gold glow
                for (int g = 3; g >= 1; g--) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(g * 3.2f * d);
                    p.setColor(Color.argb(Math.round((22 + 26 * pulse) / g), 255, 201, 74));
                    c.drawRoundRect(cr, 14 * d, 14 * d, p);
                }
                p.setStyle(Paint.Style.FILL);
            }
            p.setColor(sel ? CARD_HI : CARD2);
            c.drawRoundRect(cr, 14 * d, 14 * d, p);
            // the head
            Bitmap b = thumb(e.kit);
            RectF ir = new RectF(x + 4 * d, y + 4 * d, x + cellW - 4 * d, y + cellH - 22 * d);
            if (b != null) {
                float s = Math.min(ir.width() / b.getWidth(), ir.height() / b.getHeight());
                float dw = b.getWidth() * s, dh = b.getHeight() * s;
                r.set(ir.centerX() - dw / 2, ir.centerY() - dh / 2, ir.centerX() + dw / 2, ir.centerY() + dh / 2);
                c.drawBitmap(b, null, r, bp);
            } else {
                spinner(c, ir.centerX(), ir.centerY(), 10 * d, now);
            }
            // name
            p.setTypeface(bold);
            p.setTextSize(11.5f * d);
            p.setColor(sel ? GOLD : TXT);
            String nm = ellipsize(e.name, cellW - 12 * d);
            c.drawText(nm, x + cellW / 2 - p.measureText(nm) / 2, y + cellH - 9 * d, p);
            // favourite star
            star(c, x + cellW - 14 * d, y + 14 * d, 7 * d, faves.contains(e.kit));
            if (sel) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2.4f * d);
                p.setColor(GOLD);
                c.drawRoundRect(cr, 14 * d, 14 * d, p);
                p.setStyle(Paint.Style.FILL);
            }
        }
        if (shown.isEmpty()) {
            p.setTypeface(reg);
            p.setTextSize(15 * d);
            p.setColor(TXT2);
            String msg = all.length == 0 ? "Loading styles\u2026" : (TAB_CAT[tab] == 'F' && query.isEmpty() ? "Tap the \u2606 on any style to add it here." : "No styles match.");
            c.drawText(msg, gridR.centerX() - p.measureText(msg) / 2, gridR.top + 60 * d, p);
        }
        c.restore();
        // faded edges
        p.setShader(new LinearGradient(0, gridR.top, 0, gridR.top + 18 * d, CARD, 0x001B2034, Shader.TileMode.CLAMP));
        c.drawRect(gridR.left - 6 * d, gridR.top, gridR.right + 6 * d, gridR.top + 18 * d, p);
        p.setShader(new LinearGradient(0, gridR.bottom - 26 * d, 0, gridR.bottom, 0x001B2034, CARD, Shader.TileMode.CLAMP));
        c.drawRect(gridR.left - 6 * d, gridR.bottom - 26 * d, gridR.right + 6 * d, gridR.bottom, p);
        p.setShader(null);
        // scrollbar
        if (maxScroll > 0) {
            float th = gridR.height() * gridR.height() / (gridR.height() + maxScroll);
            float ty = gridR.top + (gridR.height() - th) * (scrollY / maxScroll);
            float bx = gridR.right + 8 * d;
            p.setColor(0x22FFFFFF);
            r.set(bx - 2 * d, gridR.top, bx + 2 * d, gridR.bottom);
            c.drawRoundRect(r, 2 * d, 2 * d, p);
            p.setColor(GOLD);
            r.set(bx - 2 * d, ty, bx + 2 * d, ty + th);
            c.drawRoundRect(r, 2 * d, 2 * d, p);
        }

        // colour strip: all the hair colours, swipe sideways for more
        p.setColor(CARD2);
        c.drawRoundRect(stripR, stripR.height() / 2, stripR.height() / 2, p);
        p.setTypeface(bold);
        p.setTextSize(13 * d);
        p.setColor(TXT);
        float sx = stripR.left + 18 * d;
        c.drawText("Colour", sx, stripR.centerY() + 5 * d, p);
        sx += p.measureText("Colour") + 14 * d;
        int[] rgb = HairPicker.colourRgb, idx = HairPicker.colourIdx;
        swatchR.clear();
        float sr = 11 * d, step = sr * 2 + 8 * d;
        swLeft = sx;
        swRight = stripR.right - 16 * d;
        swMax = Math.max(0, rgb.length * step - (swRight - swLeft));
        if (swScroll > swMax) swScroll = swMax;
        c.save();
        c.clipRect(swLeft - 6 * d, stripR.top, swRight + 6 * d, stripR.bottom);
        for (int i = 0; i < rgb.length; i++) {
            float ccx = swLeft + sr + 2 * d + i * step - swScroll, ccy = stripR.centerY();
            swatchR.add(new RectF(ccx - step / 2, stripR.top, ccx + step / 2, stripR.bottom));
            if (ccx < swLeft - step || ccx > swRight + step) continue;
            p.setColor(0xFF000000 | rgb[i]);
            c.drawCircle(ccx, ccy, sr, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1 * d);
            p.setColor(0x30FFFFFF);
            c.drawCircle(ccx, ccy, sr, p);
            if (idx[i] == HairPicker.curColour) {
                p.setStrokeWidth(2.6f * d);
                p.setColor(Color.WHITE);
                c.drawCircle(ccx, ccy, sr + 4 * d, p);
            }
            p.setStyle(Paint.Style.FILL);
        }
        c.restore();
        // soft edges show there is more to swipe to
        if (swScroll > 1) {
            p.setShader(new LinearGradient(swLeft - 6 * d, 0, swLeft + 22 * d, 0, CARD2, 0x0022283F, Shader.TileMode.CLAMP));
            c.drawRect(swLeft - 6 * d, stripR.top + 4 * d, swLeft + 22 * d, stripR.bottom - 4 * d, p);
        }
        if (swScroll < swMax - 1) {
            p.setShader(new LinearGradient(swRight - 22 * d, 0, swRight + 6 * d, 0, 0x0022283F, CARD2, Shader.TileMode.CLAMP));
            c.drawRect(swRight - 22 * d, stripR.top + 4 * d, swRight + 6 * d, stripR.bottom - 4 * d, p);
        }
        p.setShader(null);
    }

    /** "Recent" picks as chips at the bottom of the preview card */
    private void paintRecent(Canvas c, int cur) {
        recentR.clear();
        recentE.clear();
        ArrayList<Integer> rec = recent();
        if (rec.isEmpty()) return;
        p.setTypeface(reg);
        p.setTextSize(13 * d);
        float y = leftR.bottom - 26 * d;
        float rx = leftR.left + 16 * d;
        p.setColor(TXT2);
        c.drawText("Recent", rx, y + 4.5f * d, p);
        rx += p.measureText("Recent") + 10 * d;
        for (Integer kk : rec) {
            HairPicker.Entry e = byKit(kk);
            if (e == null) continue;
            String nm = e.name;
            float cw = p.measureText(nm) + 22 * d;
            if (rx + cw > leftR.right - 12 * d) break;
            RectF chip = new RectF(rx, y - 14 * d, rx + cw, y + 14 * d);
            p.setColor(e.kit == cur ? 0x40FFC94A : 0x22FFFFFF);
            c.drawRoundRect(chip, chip.height() / 2, chip.height() / 2, p);
            p.setColor(e.kit == cur ? GOLD : TXT);
            c.drawText(nm, rx + 11 * d, y + 4.5f * d, p);
            recentR.add(chip);
            recentE.add(e);
            rx += cw + 6 * d;
        }
    }

    private Bitmap thumb(int kit) {
        String key = HairPicker.key(kit);
        Bitmap b = bmp.get(kit);
        if (b != null && key.equals(bmpKey.get(kit))) return b;
        int[] px = HairPicker.thumbs.get(key);
        if (px != null) {
            try {
                Bitmap nb = Bitmap.createBitmap(px, HairPicker.THUMB, HairPicker.THUMB, Bitmap.Config.ARGB_8888);
                if (b != null) b.recycle();
                bmp.put(kit, nb);
                bmpKey.put(kit, key);
                return nb;
            } catch (Throwable ignored) { }
        }
        HairPicker.want(kit);
        return b;   // the old colour until the new picture is ready
    }

    private void magnifier(Canvas c, float mx, float my, int col) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2 * d);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(col);
        c.drawCircle(mx - 1.5f * d, my - 1.5f * d, 6 * d, p);
        c.drawLine(mx + 3 * d, my + 3 * d, mx + 7.5f * d, my + 7.5f * d, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void openSearch(boolean on) {
        searchOpen = on;
        search.setVisibility(on ? View.VISIBLE : View.GONE);
        if (on) {
            search.requestFocus();
            try {
                InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(search, 0);
            } catch (Throwable ignored) { }
        } else {
            search.setText("");
            hideKeyboard();
        }
        drawer.invalidate();
    }

    private void star(Canvas c, float x, float y, float rad, boolean on) {
        path.reset();
        for (int i = 0; i < 10; i++) {
            double a = -Math.PI / 2 + i * Math.PI / 5;
            float rr = i % 2 == 0 ? rad : rad * 0.45f;
            float px = x + (float) Math.cos(a) * rr, py = y + (float) Math.sin(a) * rr;
            if (i == 0) path.moveTo(px, py); else path.lineTo(px, py);
        }
        path.close();
        if (on) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(GOLD);
            c.drawPath(path, p);
        } else {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.5f * d);
            p.setColor(0x88A3A9C2);
            c.drawPath(path, p);
            p.setStyle(Paint.Style.FILL);
        }
    }

    private void spinner(Canvas c, float x, float y, float rad, long now) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.5f * d);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(0x33FFFFFF);
        c.drawCircle(x, y, rad, p);
        p.setColor(GOLD);
        r.set(x - rad, y - rad, x + rad, y + rad);
        c.drawArc(r, (now / 3) % 360, 90, false, p);
        p.setStyle(Paint.Style.FILL);
    }

    private String ellipsize(String s, float max) {
        if (p.measureText(s) <= max) return s;
        String e = "\u2026";
        int n = s.length();
        while (n > 1 && p.measureText(s.substring(0, n) + e) > max) n--;
        return s.substring(0, n) + e;
    }

    // ------------------------------------------------------------------ touch
    @Override public boolean onInterceptTouchEvent(MotionEvent ev) {
        // the search box keeps its own touches; everything else is ours
        if (searchOpen && ev.getActionMasked() == MotionEvent.ACTION_DOWN && searchR.contains(ev.getX(), ev.getY()) && !searchCloseR.contains(ev.getX(), ev.getY())) return false;
        return true;
    }

    @Override public boolean onTouchEvent(MotionEvent ev) {
        float x = ev.getX(), y = ev.getY();
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (vt == null) vt = VelocityTracker.obtain(); else vt.clear();
                vt.addMovement(ev);
                scroller.forceFinished(true);
                downX = lastX = x; downY = lastY = y;
                dragging = false; spinning = false;
                downInGrid = gridR.contains(x, y);
                downInPreview = leftR.contains(x, y) && y < leftR.bottom - 44 * d;
                downInStrip = stripR.contains(x, y);
                if (searchOpen && searchR.contains(x, y) && !searchCloseR.contains(x, y)) return false;
                if (search.hasFocus()) hideKeyboard();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (vt != null) vt.addMovement(ev);
                if (!dragging && (Math.abs(x - downX) > slop || Math.abs(y - downY) > slop)) {
                    dragging = true;
                    spinning = downInPreview;
                }
                if (dragging && downInStrip) {
                    swScroll = Math.max(0, Math.min(swMax, swScroll - (x - lastX)));
                }
                if (dragging && downInGrid) {
                    scrollY = Math.max(0, Math.min(maxScroll, scrollY - (y - lastY)));
                }
                if (spinning) {
                    yaw = ((yaw - (x - lastX) * 4f) % 2048f + 2048f) % 2048f;
                    lastSpinTouch = System.currentTimeMillis();
                }
                lastX = x; lastY = y;
                drawer.invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                if (vt != null) vt.addMovement(ev);
                if (dragging && downInGrid && vt != null) {
                    vt.computeCurrentVelocity(1000);
                    float vy = vt.getYVelocity();
                    scroller.fling(0, Math.round(scrollY), 0, Math.round(-vy), 0, 0, 0, Math.round(maxScroll), 0, Math.round(40 * d));
                } else if (!dragging) {
                    tap(x, y);
                }
                if (spinning) lastSpinTouch = System.currentTimeMillis();
                spinning = false;
                dragging = false;
                drawer.invalidate();
                return true;
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                spinning = false;
                return true;
        }
        return true;
    }

    private void tap(float x, float y) {
        r.set(closeR);
        r.inset(-10 * d, -10 * d);
        if (r.contains(x, y)) { close(); return; }
        if (searchOpen && searchCloseR.contains(x, y)) { openSearch(false); return; }
        if (!searchOpen && searchBtnR.contains(x, y)) { openSearch(true); return; }
        for (int i = 0; i < tabR.size() && !searchOpen; i++) {
            r.set(tabR.get(i));
            r.inset(0, -6 * d);
            if (r.contains(x, y)) {
                if (!tabHas(i)) return;
                tab = i;
                scrollY = 0;
                scroller.forceFinished(true);
                refilter();
                if (i == 0) scrollToCurrent();
                return;
            }
        }
        for (int i = 0; i < swatchR.size(); i++) {
            if (swatchR.get(i).contains(x, y) && x >= swLeft - 6 * d && x <= swRight + 6 * d) {
                int[] hit = HairPicker.colourHit;
                if (i < hit.length) HairPicker.click(hit[i]);
                return;
            }
        }
        for (int i = 0; i < recentR.size(); i++) {
            if (recentR.get(i).contains(x, y)) { pick(recentE.get(i)); return; }
        }
        if (gridR.contains(x, y)) {
            float gy = y - gridR.top - 4 * d + scrollY;
            int row = (int) (gy / (cellH + gap));
            int col = (int) ((x - gridR.left) / (cellW + gap));
            if (col < 0 || col >= cols || row < 0) return;
            float cx0 = gridR.left + col * (cellW + gap), cy0 = row * (cellH + gap);
            if (x > cx0 + cellW || gy > cy0 + cellH) return;   // in the gap
            int i = row * cols + col;
            if (i >= shown.size()) return;
            HairPicker.Entry e = shown.get(i);
            // star corner toggles favourite
            if (x > cx0 + cellW - 30 * d && gy < cy0 + 30 * d) {
                if (!faves.remove(e.kit)) faves.add(e.kit);
                saveFaves();
                if (TAB_CAT[tab] == 'F') refilter();
                return;
            }
            pick(e);
        }
    }

    private void pick(HairPicker.Entry e) {
        picked = e.kit;
        pickedAt = System.currentTimeMillis();
        HairPicker.click(e.hit);
        pushRecent(e.kit);
        performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
    }
}
