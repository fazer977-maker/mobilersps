package app.rsps2009;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.FrameLayout;

import shim.platform.Platforms;

public class GameActivity extends Activity implements SurfaceHolder.Callback {

    private static boolean started = false;

    private GameSurface surface;
    private Settings settings;
    private AndroidPlatform platform;
    private boolean kbVisible;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        CrashLog.install(this);
        CrashLog.write(CrashLog.file(this), "");
        CrashLog.crumb(this, "GameActivity.onCreate");
        settings = Settings.load(this);
        setRequestedOrientation(settings.portrait
                ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                : ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        surface = new GameSurface(this);
        surface.setRenderScale(settings.renderScale);
        surface.getHolder().addCallback(this);
        root.addView(surface, new FrameLayout.LayoutParams(-1, -1));

        Button kb = new Button(this);
        kb.setText("⌨");
        kb.setAlpha(0.5f);
        kb.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleKeyboard(); }
        });
        float d = getResources().getDisplayMetrics().density;
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) (48 * d), (int) (40 * d));
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.topMargin = (int) (4 * d);
        lp.rightMargin = (int) (4 * d);
        root.addView(kb, lp);

        final Button out = new Button(this);
        out.setText("Logout");
        out.setAllCaps(false);
        out.setAlpha(0.6f);
        out.setVisibility(View.GONE);
        out.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                new android.app.AlertDialog.Builder(GameActivity.this)
                        .setMessage("Log out?")
                        .setPositiveButton("Log out", new android.content.DialogInterface.OnClickListener() {
                            @Override public void onClick(android.content.DialogInterface dd, int w) {
                                rt4.SavedAccount.requestLogout();
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        });
        FrameLayout.LayoutParams lp2 = new FrameLayout.LayoutParams((int) (80 * d), (int) (40 * d));
        lp2.gravity = Gravity.TOP | Gravity.END;
        lp2.topMargin = (int) (4 * d);
        lp2.rightMargin = (int) (56 * d);
        root.addView(out, lp2);
        final android.os.Handler hh = new android.os.Handler(android.os.Looper.getMainLooper());
        hh.post(new Runnable() {
            @Override public void run() {
                try {
                    out.setVisibility(rt4.client.gameState == 30 ? View.VISIBLE : View.GONE);
                } catch (Throwable ignored) { }
                hh.postDelayed(this, 500);
            }
        });
        final LoginOverlay overlay = new LoginOverlay(this, getFilesDir());
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        setContentView(root);
        goImmersive();
        GameEvents.onChatTap = new Runnable() {
            @Override public void run() {
                if (!kbVisible) toggleKeyboard();
            }
        };
        GameEvents.onEnter = new Runnable() {
            @Override public void run() {
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(surface.getWindowToken(), 0);
                kbVisible = false;
            }
        };
    }

    private void goImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) goImmersive();
        if (started) GameEvents.focus(hasFocus);
    }

    private void toggleKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        surface.requestFocus();
        if (kbVisible) imm.hideSoftInputFromWindow(surface.getWindowToken(), 0);
        else imm.showSoftInput(surface, InputMethodManager.SHOW_FORCED);
        kbVisible = !kbVisible;
    }

    @Override
    public void onBackPressed() {
        if (started) GameEvents.controlKey(shim.awt.event.KeyEvent.VK_ESCAPE, (char) 27);
    }

    // ---------------------------------------------------------------- surface

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        if (platform != null) platform.onSurfaceCreated();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
        CrashLog.crumb(this, "surfaceChanged " + w + "x" + h);
        if (platform != null) {
            platform.onSurfaceChanged(w, h);
            return;
        }
        platform = new AndroidPlatform(holder, w, h, settings.renderScale, getFilesDir().getAbsolutePath() + "/");
        Platforms.current = platform;
        if (started) return; // process survived an activity recreation; client keeps running
        started = true;
        try {
            final String cfg = settings.writeClientConfig(this).getAbsolutePath();
            System.setProperty("clientHomeOverride", getFilesDir().getAbsolutePath() + "/");
            rt4.DisplayMode.resizableSD = true;
            final java.io.File crashFile = CrashLog.file(this);
            final java.io.File dumpFile = new java.io.File(getFilesDir(), "layout.txt");
            dumpFile.delete();
            Platforms.dumpSink = new Platforms.Sink() {
                @Override public void log(String text) {
                    try (java.io.FileOutputStream o = new java.io.FileOutputStream(dumpFile, false)) {
                        o.write(text.getBytes("UTF-8"));
                    } catch (Throwable ignored) { }
                }
            };
            Platforms.sink = new Platforms.Sink() {
                @Override public void log(String text) {
                    synchronized (crashFile) {
                        try (java.io.FileOutputStream o = new java.io.FileOutputStream(crashFile, true)) {
                            String t = text.length() > 3000 ? text.substring(0, 3000) : text;
                            o.write((t + "\n---\n").getBytes("UTF-8"));
                        } catch (Throwable ignored) { }
                    }
                }
            };
            Thread t = new Thread(null, new Runnable() {
                @Override public void run() {
                    try {
                        CrashLog.crumb(GameActivity.this, "client.main begin");
                        rt4.client.main(new String[] {"--config", cfg});
                        CrashLog.crumb(GameActivity.this, "client.main returned");
                    } catch (Throwable e) {
                        android.util.Log.e("rsps2009", "client crashed", e);
                        CrashLog.write(CrashLog.file(GameActivity.this), "client main failed:\n" + CrashLog.trace(e));
                    }
                }
            }, "rs-main", 64L * 1024 * 1024);
            CrashLog.crumb(this, "starting client thread");
            t.start();
        } catch (Exception e) {
            android.util.Log.e("rsps2009", "start failed", e);
            CrashLog.write(CrashLog.file(this), "start failed:\n" + CrashLog.trace(e));
        }
    }

    @Override
    protected void onDestroy() {
        CrashLog.crumb(this, "onDestroy finishing=" + isFinishing());
        super.onDestroy();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        if (platform != null) platform.onSurfaceDestroyed();
    }
}
