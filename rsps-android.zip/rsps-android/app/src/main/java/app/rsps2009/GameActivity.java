package app.rsps2009;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.FrameLayout;

import shim.platform.Platforms;

public class GameActivity extends Activity implements SurfaceHolder.Callback {

    private static boolean started = false;
    /** only used to draw the icon's hands before the server has sent its clock */
    static final String SERVER_TZ = "UTC";

    private GameSurface surface;
    private GpuView gpuView;
    private Settings settings;
    private AndroidPlatform platform;
    private boolean kbVisible;
    private HairPickerView hairPicker;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        CrashLog.install(this);
        CrashLog.write(CrashLog.file(this), "");
        CrashLog.crumb(this, "GameActivity.onCreate");
        settings = Settings.load(this);
        setRequestedOrientation(settings.portrait
                ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                : ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        surface = new GameSurface(this);
        surface.setRenderScale(settings.renderScale);
        surface.getHolder().addCallback(this);
        root.addView(surface, new FrameLayout.LayoutParams(-1, -1));
        Platforms.gpuMode = settings.gpuMode;
        if (settings.gpuMode) {
            gpuView = new GpuView(this);
            root.addView(gpuView, new FrameLayout.LayoutParams(-1, -1));
            // gl4es picks its OpenGL ES backend from this at init; our EGL context is ES2, so tell it explicitly
            try { android.system.Os.setenv("LIBGL_ES", "2", true); android.system.Os.setenv("LIBGL_NOBANNER", "1", true); } catch (Throwable ignored) { }
            com.jogamp.opengl.GlNative.setCrashFile(new java.io.File(getFilesDir(), "native_crash.txt").getAbsolutePath());
            com.jogamp.nativewindow.awt.JAWTWindow.libPath = getApplicationInfo().nativeLibraryDir + "/libgl4es.so";
            com.jogamp.nativewindow.awt.JAWTWindow.backend = new AndroidEglBackend(gpuView);
        }

        float d = getResources().getDisplayMetrics().density;
        final View kbv = new View(this) {
            private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(android.graphics.Canvas c) {
                StoneIcon.drawStone(c, p, getWidth(), getHeight());
                StoneIcon.drawKeyboard(c, p, getWidth(), getHeight());
            }
        };
        kbv.setVisibility(View.GONE);
        kbv.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleKeyboard(); }
        });
        final FrameLayout.LayoutParams lp3 = new FrameLayout.LayoutParams(10, 10);
        lp3.gravity = Gravity.TOP | Gravity.START;
        root.addView(kbv, lp3);

        // ---- server clock: clock icon left of the keyboard button; tap to show the server time, tap again for the icon
        final boolean[] clockOpen = {false};
        final java.util.TimeZone serverTz = java.util.TimeZone.getTimeZone(SERVER_TZ);
        final View clk = new View(this) {
            private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            private android.graphics.Typeface tf;
            @Override protected void onDraw(android.graphics.Canvas c) {
                int[] st = rt4.ServerClock.now();
                boolean have = st != null;
                if (!have) { java.util.Calendar cal = java.util.Calendar.getInstance(serverTz); st = new int[] {cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE), cal.get(java.util.Calendar.SECOND)}; }
                int hh = st[0], mm = st[1], ss = st[2];
                float w = getWidth(), h = getHeight();
                StoneIcon.drawStone(c, p, w, h);
                if (!clockOpen[0]) { StoneIcon.drawClock(c, p, w, h, hh, mm, ss); return; }
                StoneIcon.drawClock(c, p, h, h, hh, mm, ss);
                if (tf == null) { try { tf = android.graphics.Typeface.createFromAsset(getAssets(), "silkscreen.ttf"); } catch (Throwable t) { tf = android.graphics.Typeface.DEFAULT_BOLD; } }
                p.setTypeface(tf); p.setStyle(android.graphics.Paint.Style.FILL); p.setTextAlign(android.graphics.Paint.Align.CENTER);
                float tx = h + (w - h) / 2f;
                p.setTextSize(h * 0.20f); p.setColor(android.graphics.Color.rgb(255, 152, 31));
                c.drawText("SERVER TIME", tx, h * 0.36f, p);
                String t = have ? String.format(java.util.Locale.US, "%02d:%02d:%02d", hh, mm, ss) : "--:--:--";
                p.setTextSize(h * 0.30f); p.setColor(android.graphics.Color.BLACK); c.drawText(t, tx + h * 0.02f, h * 0.72f + h * 0.02f, p);
                p.setColor(android.graphics.Color.rgb(255, 255, 0)); c.drawText(t, tx, h * 0.72f, p);
                p.setTextSize(h * 0.14f); p.setColor(android.graphics.Color.rgb(220, 210, 180));
                c.drawText(have ? rt4.ServerClock.label : "waiting for server", tx, h * 0.90f, p);
            }
        };
        clk.setVisibility(View.GONE);
        clk.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { clockOpen[0] = !clockOpen[0]; clk.requestLayout(); clk.invalidate(); }
        });
        final FrameLayout.LayoutParams lp4 = new FrameLayout.LayoutParams(10, 10);
        lp4.gravity = Gravity.TOP | Gravity.START;
        root.addView(clk, lp4);

        final View out = new View(this) {
            private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            private android.graphics.Bitmap door, stoneBmp;
            private int[] stoneSrc;
            @Override protected void onDraw(android.graphics.Canvas c) {
                if (door == null) {
                    android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
                    o.inScaled = false;
                    door = android.graphics.BitmapFactory.decodeResource(getResources(), R.drawable.logout_door, o);
                }
                float w = getWidth(), h = getHeight(), u = Math.min(w, h);
                int[] sp = rt4.MobileLayout.stonePx;
                if (sp != null) {
                    if (stoneBmp == null || stoneSrc != sp) {
                        stoneSrc = sp;
                        stoneBmp = android.graphics.Bitmap.createBitmap(sp, rt4.MobileLayout.stoneWpx, rt4.MobileLayout.stoneHpx, android.graphics.Bitmap.Config.ARGB_8888);
                    }
                    p.setFilterBitmap(false);
                    c.drawBitmap(stoneBmp, null, new android.graphics.RectF(0, 0, w, h), p);
                    if (door != null) {
                        c.drawBitmap(door, null, new android.graphics.RectF(0, 0, w, h), p);
                    }
                    return;
                }
                // fallback: drawn stone tab background
                p.setStyle(android.graphics.Paint.Style.FILL);
                p.setShader(null);
                p.setColor(Color.rgb(26, 22, 18));
                c.drawRoundRect(new android.graphics.RectF(0, 0, w, h), u * 0.2f, u * 0.2f, p);
                p.setShader(new android.graphics.LinearGradient(0, 0, w, h, Color.rgb(120, 112, 100), Color.rgb(66, 60, 52), android.graphics.Shader.TileMode.CLAMP));
                c.drawRoundRect(new android.graphics.RectF(u * 0.06f, u * 0.06f, w - u * 0.06f, h - u * 0.06f), u * 0.17f, u * 0.17f, p);
                p.setShader(null);
                p.setStyle(android.graphics.Paint.Style.STROKE);
                p.setStrokeWidth(Math.max(1f, u * 0.04f));
                p.setColor(Color.argb(110, 255, 255, 255));
                c.drawRoundRect(new android.graphics.RectF(u * 0.09f, u * 0.09f, w - u * 0.09f, h - u * 0.09f), u * 0.15f, u * 0.15f, p);
                p.setStyle(android.graphics.Paint.Style.FILL);
                if (door != null) {
                    p.setFilterBitmap(false);
                    c.drawBitmap(door, null, new android.graphics.RectF(0, 0, w, h), p);
                }
            }
        };
        out.setVisibility(View.GONE);
        out.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                new android.app.AlertDialog.Builder(GameActivity.this)
                        .setMessage("Log out?")
                        .setPositiveButton("Log out", new android.content.DialogInterface.OnClickListener() {
                            @Override public void onClick(android.content.DialogInterface dd, int w) {
                                rt4.SavedAccount.requestLogout();
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        });
        final FrameLayout.LayoutParams lp2 = new FrameLayout.LayoutParams(10, 10);
        lp2.gravity = Gravity.TOP | Gravity.START;
        root.addView(out, lp2);
        final android.os.Handler hh = new android.os.Handler(android.os.Looper.getMainLooper());
        hh.post(new Runnable() {
            @Override public void run() {
                try {
                    boolean in = rt4.client.gameState == 30 && rt4.MobileLayout.logoutW > 0 && rt4.MobileLayout.canvasW > 0 && surface.getWidth() > 0;
                    if (in) {
                        float sc = surface.getWidth() / (float) rt4.MobileLayout.canvasW;
                        int x = Math.round(rt4.MobileLayout.logoutX * sc), y = Math.round(rt4.MobileLayout.logoutY * sc);
                        int w2 = Math.round(rt4.MobileLayout.logoutW * sc), h2 = Math.round(rt4.MobileLayout.logoutH * sc);
                        if (lp2.leftMargin != x || lp2.topMargin != y || lp2.width != w2 || lp2.height != h2) {
                            lp2.leftMargin = x; lp2.topMargin = y; lp2.width = w2; lp2.height = h2;
                            out.setLayoutParams(lp2);
                        }
                    }
                    out.setVisibility(in && !rt4.MobileLayout.logoutHidden() ? View.VISIBLE : View.GONE);
                    if (in) {
                        float sc2 = surface.getWidth() / (float) rt4.MobileLayout.canvasW;
                        // keyboard button sits in the empty slot just left of logout
                        int kx = Math.round((rt4.MobileLayout.logoutX - rt4.MobileLayout.logoutW) * sc2), ky = Math.round(rt4.MobileLayout.logoutY * sc2);
                        int kw2 = Math.round(rt4.MobileLayout.logoutW * sc2), kh2 = Math.round(rt4.MobileLayout.logoutH * sc2);
                        if (lp3.leftMargin != kx || lp3.topMargin != ky || lp3.width != kw2 || lp3.height != kh2) {
                            lp3.leftMargin = kx; lp3.topMargin = ky; lp3.width = kw2; lp3.height = kh2;
                            kbv.setLayoutParams(lp3);
                        }
                    }
                    kbv.setVisibility(in && !rt4.MobileLayout.logoutHidden() ? View.VISIBLE : View.GONE);
                    if (in) {
                        float sc3 = surface.getWidth() / (float) rt4.MobileLayout.canvasW;
                        int bw = Math.round(rt4.MobileLayout.logoutW * sc3), bh = Math.round(rt4.MobileLayout.logoutH * sc3);
                        int right = Math.round((rt4.MobileLayout.logoutX - rt4.MobileLayout.logoutW) * sc3);   // left edge of the keyboard button
                        int cw = clockOpen[0] ? bw * 3 : bw;
                        int cx = right - cw, cy = Math.round(rt4.MobileLayout.logoutY * sc3);
                        if (lp4.leftMargin != cx || lp4.topMargin != cy || lp4.width != cw || lp4.height != bh) {
                            lp4.leftMargin = cx; lp4.topMargin = cy; lp4.width = cw; lp4.height = bh;
                            clk.setLayoutParams(lp4);
                        }
                    }
                    clk.setVisibility(in && !rt4.MobileLayout.logoutHidden() ? View.VISIBLE : View.GONE);
                    clk.invalidate();
                    out.invalidate();
                    kbv.invalidate();
                } catch (Throwable ignored) { }
                hh.postDelayed(this, 250);
            }
        });
        // ---- Studio pickers: a "HAIR / BROWSE" style button over each body row's label opens the app-drawn picker
        final HairPickerView picker = new HairPickerView(this);
        final int NR = rt4.HairPicker.ROWS;
        final HairBrowseButton[] browse = new HairBrowseButton[NR];
        final FrameLayout.LayoutParams[] blp = new FrameLayout.LayoutParams[NR];
        for (int i = 0; i < NR; i++) {
            final int row = i;
            browse[i] = new HairBrowseButton(this, rt4.HairPicker.ROW_NAME[i]);
            browse[i].setVisibility(View.GONE);
            browse[i].setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    picker.open(row);
                    for (HairBrowseButton b : browse) b.setVisibility(View.GONE);
                }
            });
            blp[i] = new FrameLayout.LayoutParams(10, 10);
            blp[i].gravity = Gravity.TOP | Gravity.START;
            root.addView(browse[i], blp[i]);
        }
        root.addView(picker, new FrameLayout.LayoutParams(-1, -1));
        hairPicker = picker;
        // intro cutscene: black bars and captions over the gliding camera
        final TourView tour = new TourView(this);
        // event messages in chat: a real [Teleport] button over the words
        final ChatButtons chatButtons = new ChatButtons(this);
        root.addView(chatButtons, new FrameLayout.LayoutParams(-1, -1));
        root.addView(tour, new FrameLayout.LayoutParams(-1, -1));
        final android.os.Handler ph = new android.os.Handler(android.os.Looper.getMainLooper());
        ph.post(new Runnable() {
            @Override public void run() {
                try {
                    boolean on = rt4.client.gameState == 30 && rt4.MobileLayout.studioOpen
                            && !picker.isOpen() && rt4.MobileLayout.canvasW > 0 && surface.getWidth() > 0;
                    float sc = on ? surface.getWidth() / (float) rt4.MobileLayout.canvasW : 1f;
                    for (int i = 0; i < NR; i++) {
                        boolean show = on && rt4.HairPicker.pillW[i] > 0;
                        if (show) {
                            int x = Math.round(rt4.HairPicker.pillX[i] * sc), y = Math.round(rt4.HairPicker.pillY[i] * sc);
                            int w = Math.round(rt4.HairPicker.pillW[i] * sc), h = Math.round(rt4.HairPicker.pillH[i] * sc);
                            FrameLayout.LayoutParams lp = blp[i];
                            if (lp.leftMargin != x || lp.topMargin != y || lp.width != w || lp.height != h) {
                                lp.leftMargin = x; lp.topMargin = y; lp.width = w; lp.height = h;
                                browse[i].setLayoutParams(lp);
                            }
                        }
                        int vis = show ? View.VISIBLE : View.GONE;
                        if (browse[i].getVisibility() != vis) { browse[i].setVisibility(vis); browse[i].invalidate(); }
                    }
                    if (picker.isOpen() && !rt4.MobileLayout.studioOpen) picker.close();
                    tour.sync();
                    boolean cbOk = rt4.client.gameState == 30 && !picker.isOpen() && rt4.MobileLayout.canvasW > 0 && surface.getWidth() > 0;
                    chatButtons.sync(cbOk, cbOk ? surface.getWidth() / (float) rt4.MobileLayout.canvasW : 1f);
                } catch (Throwable ignored) { }
                ph.postDelayed(this, 50);   // quick enough for the chat buttons to follow scrolling
            }
        });
        final LoginOverlay overlay = new LoginOverlay(this, getFilesDir());
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        {
            final android.widget.TextView fpsView = new android.widget.TextView(this);
            fpsView.setTextColor(Color.GREEN);
            fpsView.setBackgroundColor(0x88000000);
            fpsView.setTextSize(12);
            fpsView.setPadding(8, 2, 8, 2);
            fpsView.setTextSize(9);
                        fpsView.setText("FPS --");
            FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(-2, -2);
            fl.gravity = android.view.Gravity.TOP | android.view.Gravity.END;
            fl.topMargin = 40;
            root.addView(fpsView, fl);
            final android.os.Handler fh = new android.os.Handler(android.os.Looper.getMainLooper());
            fh.post(new Runnable() {
                int last = Settings.frameCount;
                long lastSwap = 0, lastFrame = 0, lastCalls = 0;
                long lastT = android.os.SystemClock.elapsedRealtime();
                @Override public void run() {
                    fpsView.setVisibility(Settings.showFps ? View.VISIBLE : View.GONE);
                    long now = android.os.SystemClock.elapsedRealtime();
                    int c = Settings.frameCount;
                    if (now > lastT) {
                        int n = Math.max(1, c - last);
                        long sw = Settings.swapNs, fr = Settings.frameNs, gc = Settings.glCalls;
                        float swapMs = (sw - lastSwap) / 1e6f / n, frameMs = (fr - lastFrame) / 1e6f / n;
                        fpsView.setText("FPS " + Math.round((c - last) * 1000f / (now - lastT))
                                + "\nframe " + Math.round(frameMs) + "ms  swap " + Math.round(swapMs) + "ms"
                                + "\ncpu " + Math.round(frameMs - swapMs) + "ms  GL " + (gc - lastCalls) / n
                                + "\nWHERE:\n" + Settings.profApp + "NATIVE:\n" + Settings.profTop);
                        lastSwap = sw; lastFrame = fr; lastCalls = gc;
                    }
                    last = c; lastT = now;
                    fh.postDelayed(this, 500);
                }
            });
        }
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        setContentView(root);
        goImmersive();
        GameEvents.onChatTap = new Runnable() {
            @Override public void run() {
                if (!kbVisible) toggleKeyboard();
            }
        };
        GameEvents.onEnter = new Runnable() {
            @Override public void run() {
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(surface.getWindowToken(), 0);
                kbVisible = false;
            }
        };
    }

    private void goImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) goImmersive();
        if (started) GameEvents.focus(hasFocus);
    }

    private void toggleKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        surface.requestFocus();
        if (kbVisible) imm.hideSoftInputFromWindow(surface.getWindowToken(), 0);
        else imm.showSoftInput(surface, InputMethodManager.SHOW_FORCED);
        kbVisible = !kbVisible;
    }

    @Override
    public void onBackPressed() {
        if (hairPicker != null && hairPicker.isOpen()) { hairPicker.close(); return; }
        if (started) GameEvents.controlKey(shim.awt.event.KeyEvent.VK_ESCAPE, (char) 27);
    }

    // ---------------------------------------------------------------- surface

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        if (platform != null) platform.onSurfaceCreated();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
        CrashLog.crumb(this, "surfaceChanged " + w + "x" + h);
        if (gpuView != null) {
            gpuView.getHolder().setFixedSize(Math.max(1, Math.round(w / settings.renderScale)), Math.max(1, Math.round(h / settings.renderScale)));
        }
        if (platform != null) {
            platform.onSurfaceChanged(w, h);
            return;
        }
        platform = new AndroidPlatform(holder, w, h, settings.renderScale, getFilesDir().getAbsolutePath() + "/");
        Platforms.current = platform;
        if (started) return; // process survived an activity recreation; client keeps running
        started = true;
        try {
            final String cfg = settings.writeClientConfig(this).getAbsolutePath();
            System.setProperty("clientHomeOverride", getFilesDir().getAbsolutePath() + "/");
            rt4.DisplayMode.resizableSD = !settings.gpuMode;
            final java.io.File crashFile = CrashLog.file(this);
            final java.io.File dumpFile = new java.io.File(getFilesDir(), "layout.txt");
            dumpFile.delete();
            Platforms.dumpSink = new Platforms.Sink() {
                @Override public void log(String text) {
                    try (java.io.FileOutputStream o = new java.io.FileOutputStream(dumpFile, false)) {
                        o.write(text.getBytes("UTF-8"));
                    } catch (Throwable ignored) { }
                }
            };
            Platforms.sink = new Platforms.Sink() {
                @Override public void log(String text) {
                    synchronized (crashFile) {
                        try (java.io.FileOutputStream o = new java.io.FileOutputStream(crashFile, true)) {
                            String t = text.length() > 3000 ? text.substring(0, 3000) : text;
                            o.write((t + "\n---\n").getBytes("UTF-8"));
                        } catch (Throwable ignored) { }
                    }
                }
            };
            Thread t = new Thread(null, new Runnable() {
                @Override public void run() {
                    try {
                        CrashLog.crumb(GameActivity.this, "client.main begin");
                        rt4.client.main(new String[] {"--config", cfg});
                        CrashLog.crumb(GameActivity.this, "client.main returned");
                    } catch (Throwable e) {
                        android.util.Log.e("rsps2009", "client crashed", e);
                        CrashLog.write(CrashLog.file(GameActivity.this), "client main failed:\n" + CrashLog.trace(e));
                    }
                }
            }, "rs-main", 64L * 1024 * 1024);
            CrashLog.crumb(this, "starting client thread");
            t.start();
        } catch (Exception e) {
            android.util.Log.e("rsps2009", "start failed", e);
            CrashLog.write(CrashLog.file(this), "start failed:\n" + CrashLog.trace(e));
        }
    }

    @Override
    protected void onDestroy() {
        CrashLog.crumb(this, "onDestroy finishing=" + isFinishing());
        super.onDestroy();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        if (platform != null) platform.onSurfaceDestroyed();
    }
}
