package app.rsps2009;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import rt4.WorldBoss;

/**
 * World boss bar at the top of the screen while the Prismatic Dragon is awake (or about to wake): name, a flowing
 * rainbow health bar, how many are helping and the time left. Everyone online sees it; tap it to go to the crater.
 * When the dragon roars a big banner flashes. Touches outside the bar pass through to the game.
 */
final class WorldBossView extends View {
    private static final int[] RAINBOW = {0xFFFF3B3B, 0xFFFF9A1E, 0xFFFFE62E, 0xFF4CFF6A, 0xFF2EE6FF, 0xFF4C7DFF, 0xFFC04CFF};
    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Typeface bold = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD);
    private Typeface pixel;
    private final RectF bar = new RectF();
    private boolean shown, pressed;
    private float shownHp = -1;
    private int seenRoar;
    private long bannerAt, wokeAt;
    private int lastState;

    WorldBossView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        try { pixel = Typeface.createFromAsset(c.getAssets(), "silkscreen.ttf"); } catch (Throwable t) { pixel = bold; }
        setVisibility(GONE);
        seenRoar = WorldBoss.roarVersion;
    }

    /** UI poller (every 50 ms) */
    void sync(boolean allowed) {
        int st = WorldBoss.state;
        if (st == 2 && lastState != 2) { wokeAt = System.currentTimeMillis(); bannerAt = wokeAt; }
        lastState = st;
        if (WorldBoss.roarVersion != seenRoar) { seenRoar = WorldBoss.roarVersion; if (st == 2 && System.currentTimeMillis() - bannerAt > 4000) bannerAt = System.currentTimeMillis(); }
        boolean on = allowed && st != 0;
        if (on != shown) { shown = on; setVisibility(on ? VISIBLE : GONE); }
        if (on) invalidate();
    }

    private static String clock(int s) {
        s = Math.max(0, s);
        return (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60);
    }

    @Override protected void onDraw(Canvas c) {
        long now = System.currentTimeMillis();
        float W = getWidth();
        float bw = Math.min(W * 0.40f, 320 * d), bh = 12 * d;
        float cx = W * 0.56f;                                   // right of the chat lines, left of the minimap
        float x0 = cx - bw / 2, y0 = 42 * d;
        int st = WorldBoss.state;
        float plateTop = y0 - 20 * d, plateBot = y0 + bh + 17 * d;
        bar.set(x0 - 10 * d, plateTop, x0 + bw + 10 * d, plateBot);
        // plate
        p.setShader(null); p.setStyle(Paint.Style.FILL);
        p.setColor(pressed ? 0xCC2A1240 : 0xB0100818);
        c.drawRoundRect(bar, 9 * d, 9 * d, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.6f * d);
        float off = (now % 3000) / 3000f * bw * 2;
        p.setShader(new LinearGradient(x0 - off, 0, x0 - off + bw, 0, RAINBOW, null, Shader.TileMode.MIRROR));
        c.drawRoundRect(bar, 9 * d, 9 * d, p);
        p.setShader(null); p.setStyle(Paint.Style.FILL);
        // title
        p.setTypeface(pixel); p.setTextSize(10.5f * d); p.setTextAlign(Paint.Align.CENTER);
        String title = st == 2 ? (WorldBoss.phase >= 3 ? "PRISMATIC DRAGON - ENRAGED" : "PRISMATIC DRAGON") : "THE PRISMATIC DRAGON STIRS";
        p.setColor(0xFF000000); c.drawText(title, cx + d, y0 - 5 * d + d, p);
        p.setColor(st == 2 && WorldBoss.phase >= 3 ? 0xFFFF6A5A : 0xFFFFE6A0); c.drawText(title, cx, y0 - 5 * d, p);
        // bar
        RectF in = new RectF(x0, y0, x0 + bw, y0 + bh);
        p.setColor(0xFF2A0008); c.drawRoundRect(in, 4 * d, 4 * d, p);
        float frac;
        if (st == 2) {
            float target = WorldBoss.hp / (float) Math.max(1, WorldBoss.max);
            shownHp = shownHp < 0 ? target : shownHp + (target - shownHp) * 0.15f;
            frac = Math.max(0, Math.min(1, shownHp));
        } else {
            frac = 1f - Math.min(1f, WorldBoss.secs / 600f);       // warning: the bar fills up as it wakes
            shownHp = -1;
        }
        if (frac > 0) {
            RectF f = new RectF(x0, y0, x0 + bw * frac, y0 + bh);
            float o2 = (now % 2000) / 2000f * bw;
            p.setShader(new LinearGradient(x0 - o2, 0, x0 - o2 + bw, 0, RAINBOW, null, Shader.TileMode.REPEAT));
            p.setAlpha(st == 2 ? 255 : 140);
            c.drawRoundRect(f, 4 * d, 4 * d, p);
            p.setShader(null); p.setAlpha(255);
            p.setColor(0x55FFFFFF); c.drawRect(x0 + 2 * d, y0 + 1.5f * d, x0 + bw * frac - 2 * d, y0 + 3.5f * d, p);
        }
        // line under the bar
        p.setTypeface(bold); p.setTextSize(9.5f * d);
        String sub;
        if (st == 2) sub = String.format("%,d / %,d   %d helping   %s left   %s", WorldBoss.hp, WorldBoss.max, WorldBoss.helping,
                clock(WorldBoss.secs), WorldBoss.inArena ? "" : "TAP TO JOIN");
        else sub = "wakes in " + clock(WorldBoss.secs) + "   TAP TO GO TO THE CRATER";
        p.setColor(0xFF000000); c.drawText(sub.trim(), cx + d, y0 + bh + 12 * d + d, p);
        p.setColor(0xFFFFFFFF); c.drawText(sub.trim(), cx, y0 + bh + 12 * d, p);
        // roar banner
        long ba = now - bannerAt;
        if (bannerAt > 0 && ba < 2600 && st == 2) {
            float a = ba < 300 ? ba / 300f : ba > 2000 ? (2600 - ba) / 600f : 1f;
            float H = getHeight();
            String big = now - wokeAt < 3000 ? "THE PRISMATIC DRAGON HAS AWAKENED!" : "RRROOOAAARRR!";
            p.setTypeface(pixel); p.setTextSize((now - wokeAt < 3000 ? 22 : 30) * d);
            float jit = (float) Math.sin(ba / 25.0) * 3 * d * (1 - Math.min(1, ba / 1200f));
            p.setAlpha((int) (200 * a)); p.setColor(0xFF000000); p.setAlpha((int) (200 * a));
            c.drawText(big, W / 2 + 2 * d + jit, H * 0.36f + 2 * d, p);
            float o3 = (now % 1500) / 1500f * W;
            p.setShader(new LinearGradient(-o3, 0, W - o3, 0, RAINBOW, null, Shader.TileMode.MIRROR));
            p.setAlpha((int) (255 * a));
            c.drawText(big, W / 2 + jit, H * 0.36f, p);
            p.setShader(null); p.setAlpha(255);
        }
        p.setTextAlign(Paint.Align.LEFT);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (!shown) return false;
        float x = e.getX(), y = e.getY();
        boolean on = x >= bar.left - 6 * d && x <= bar.right + 6 * d && y >= bar.top - 6 * d && y <= bar.bottom + 6 * d;
        if (!on) { if (pressed) { pressed = false; invalidate(); } return false; }
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) { pressed = true; invalidate(); }
        else if (a == MotionEvent.ACTION_UP) { pressed = false; if (!WorldBoss.inArena || WorldBoss.state == 1) WorldBoss.join(); invalidate(); }
        else if (a == MotionEvent.ACTION_CANCEL) { pressed = false; invalidate(); }
        return true;
    }
}
