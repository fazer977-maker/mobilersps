package shim.awt;

public class KeyboardFocusManager {
    private static final KeyboardFocusManager INSTANCE = new KeyboardFocusManager();
    public static KeyboardFocusManager getCurrentKeyboardFocusManager() { return INSTANCE; }
    public Window getFocusedWindow() { return null; }
}
