package rt4;

/** Detailed rainbow admin crown for chat names: gradient body, darker jewelled band, gold tip balls, highlights, twinkling sparkles. */
public final class RainbowCrown {
	public static final int ICON_INDEX = 15;
	private static int W = 13, H = 11;
	private static final int G = 64;
	private static final int OUT = 1, BODY = 2, BAND = 2 + G, GOLD = 2 + 2 * G, GOLD_HI = GOLD + 1, WHITE = GOLD + 2, PALE = GOLD + 3, LIGHT = GOLD + 4, PSIZE = GOLD + 5;
	private static SoftwareIndexedSprite sprite;
	private static byte[] base;
	private static long lastTick;
	// sparkles: x, y, cross (1 = may grow arms)
	private static final int[][] SP0 = {{0, 10, 1}, {29, 3, 1}, {15, 0, 1}, {7, 13, 0}, {15, 10, 0}, {23, 14, 0}, {11, 18, 0}, {20, 19, 0}};
	private static int[][] SP = SP0;

	/** Every gold admin crown (<img=1>) is drawn as the rainbow crown instead. */
	public static int map(int idx) {
		return idx == 1 && sprite != null ? ICON_INDEX : idx;
	}

	public static IndexedSprite[] extend(IndexedSprite[] icons) {
		try {
			IndexedSprite[] out = new IndexedSprite[Math.max(icons == null ? 0 : icons.length, ICON_INDEX + 1)];
			if (icons != null) System.arraycopy(icons, 0, out, 0, icons.length);
			if (icons != null && icons.length > 1 && icons[1] != null && icons[1].innerWidth > 4 && icons[1].innerHeight > 4) { W = icons[1].innerWidth; H = icons[1].innerHeight; }
			out[ICON_INDEX] = build();
			tick(true);
			return out;
		} catch (Throwable t) {
			return icons;
		}
	}

	private static SoftwareIndexedSprite build() {
		SoftwareIndexedSprite s = new SoftwareIndexedSprite(W, H, PSIZE);
		// the crown silhouette from the app icon: three points, two valleys, flat base
		float[][] pts = {{4, 58}, {0, 8}, {18, 30}, {36, 0}, {54, 30}, {72, 8}, {68, 58}};
		float[][] poly = new float[pts.length][2];
		for (int i = 0; i < pts.length; i++) { poly[i][0] = pts[i][0] * (W - 0.6f) / 72f + 0.3f; poly[i][1] = pts[i][1] * (H - 0.6f) / 58f + 0.3f; }
		boolean[][] in = new boolean[H + 2][W + 2];
		for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) in[y + 1][x + 1] = inside(poly, x + 0.5f, y + 0.5f);
		byte[] px = s.pixels;
		for (int y = 0; y < H; y++) {
			for (int x = 0; x < W; x++) {
				if (!in[y + 1][x + 1]) continue;
				boolean edge = !in[y][x + 1] || !in[y + 2][x + 1] || !in[y + 1][x] || !in[y + 1][x + 2];
				float frac = Math.max(0f, Math.min(1f, x / (float) (W - 1) + (y * 0.004f)));
				int gi = Math.round(frac * (G - 1));
				if (edge) px[y * W + x] = OUT;
				else if (y >= H * 4 / 5 + (H > 16 ? 0 : 1)) px[y * W + x] = (byte) (BAND + gi);      // slightly darker base band
				else px[y * W + x] = (byte) (BODY + gi);
			}
		}
		// glossy highlight streak on the left of each spike, running down the face
		for (int y = H / 6; y < H * 2 / 3; y++) {
			for (int x = 1; x < W - 3 && x + 2 < W; x++) {
				if (px[y * W + x] == OUT && px[y * W + x + 1] >= BODY && px[y * W + x + 1] < BAND) {
					px[y * W + x + 1] = (byte) LIGHT;
					if (y < H / 2 && px[y * W + x + 2] >= BODY && px[y * W + x + 2] < BAND) px[y * W + x + 2] = (byte) LIGHT;
					break;
				}
			}
		}
		SP = new int[SP0.length][];
		for (int i = 0; i < SP0.length; i++) SP[i] = new int[] {SP0[i][0] * (W - 1) / 29, SP0[i][1] * (H - 1) / 23, W >= 20 ? SP0[i][2] : 0};
		base = px.clone();
		sprite = s;
		return s;
	}

	private static boolean inside(float[][] p, float x, float y) {
		boolean c = false;
		for (int i = 0, j = p.length - 1; i < p.length; j = i++) {
			if (((p[i][1] > y) != (p[j][1] > y)) && (x < (p[j][0] - p[i][0]) * (y - p[i][1]) / (p[j][1] - p[i][1]) + p[i][0])) c = !c;
		}
		return c;
	}

	/** Flow the gradient and twinkle the sparkles (called every frame, throttled). */
	public static void tick(boolean force) {
		SoftwareIndexedSprite s = sprite;
		if (s == null) return;
		long now = System.currentTimeMillis();
		if (!force && now - lastTick < 50) return;
		lastTick = now;
		float off = (now % 3200L) / 3200f;
		int[] pal = s.pallet;
		pal[0] = 0;
		pal[OUT] = 0x120824;
		for (int i = 0; i < G; i++) {
			float hue = (i / (float) (G - 1) * 0.85f + off) % 1f;
			pal[BODY + i] = hsv(hue, 0.78f, 1f);
			pal[BAND + i] = hsv(hue, 0.95f, 0.62f);
		}
		pal[GOLD] = 0xFFC21A;
		pal[GOLD_HI] = 0xFFF2A0;
		pal[WHITE] = 0xFFFFFF;
		pal[PALE] = 0xFFF0A0;
		pal[LIGHT] = 0xF4EEFF;
		System.arraycopy(base, 0, s.pixels, 0, base.length);
		for (int i = 0; i < SP.length; i++) {
			float ph = (float) Math.sin(now / (330.0 + i * 85.0) + i * 2.3);
			if (ph < 0.25f) continue;
			int x = SP[i][0], y = SP[i][1];
			put(s, x, y, WHITE);
			if (SP[i][2] == 1 && ph > 0.6f) {
				put(s, x - 1, y, PALE); put(s, x + 1, y, PALE); put(s, x, y - 1, PALE); put(s, x, y + 1, PALE);
			}
		}
	}

	private static void put(SoftwareIndexedSprite s, int x, int y, int idx) {
		if (x < 0 || y < 0 || x >= W || y >= H) return;
		if (base[y * W + x] == OUT) return;
		s.pixels[y * W + x] = (byte) idx;
	}

	private static int hsv(float h, float sat, float v) {
		float x = h * 6f; int i = (int) x; float f = x - i;
		float p = v * (1 - sat), q = v * (1 - sat * f), t = v * (1 - sat * (1 - f));
		float r, g, b;
		switch (i % 6) { case 0: r = v; g = t; b = p; break; case 1: r = q; g = v; b = p; break; case 2: r = p; g = v; b = t; break;
			case 3: r = p; g = q; b = v; break; case 4: r = t; g = p; b = v; break; default: r = v; g = p; b = q; }
		return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
	}
}
