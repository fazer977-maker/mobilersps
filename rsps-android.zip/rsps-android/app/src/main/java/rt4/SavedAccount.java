package rt4;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/** Remembers the last successful login (app-private file) and signs in with it once per app start. */
public final class SavedAccount {
    private static String pendingUser, pendingPass;
    private static volatile String[] pendingRequest;
    private static volatile boolean rememberMe = true;

    public static final int MAX_ACCOUNTS = 3;

    private static File file() {
        String home = System.getProperty("clientHomeOverride");
        return home == null ? null : new File(home, "accounts.txt");
    }

    /** Saved accounts, most recently used first: {username, password, lastLoginMillis}. */
    public static synchronized java.util.List<String[]> load(File dir) {
        java.util.List<String[]> out = new java.util.ArrayList<String[]>();
        try {
            File f = new File(dir, "accounts.txt");
            File old = new File(dir, "account.txt");
            if (!f.exists() && old.exists()) {
                String[] p = new String(Files.readAllBytes(old.toPath()), StandardCharsets.ISO_8859_1).split("\n");
                if (p.length >= 2 && !p[0].isEmpty()) {
                    out.add(new String[] {p[0], p[1], "0"});
                    write(dir, out);
                }
                old.delete();
                return out;
            }
            if (f.exists()) {
                for (String line : new String(Files.readAllBytes(f.toPath()), StandardCharsets.ISO_8859_1).split("\n")) {
                    String[] p = line.split("\t");
                    if (p.length >= 2 && !p[0].isEmpty() && !p[1].isEmpty() && out.size() < MAX_ACCOUNTS) {
                        out.add(new String[] {p[0], p[1], p.length > 2 ? p[2] : "0"});
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    private static void write(File dir, java.util.List<String[]> list) {
        try {
            StringBuilder sb = new StringBuilder();
            for (String[] a : list) {
                sb.append(a[0]).append('\t').append(a[1]).append('\t').append(a[2]).append('\n');
            }
            Files.write(new File(dir, "accounts.txt").toPath(), sb.toString().getBytes(StandardCharsets.ISO_8859_1));
        } catch (Throwable ignored) {
        }
    }

    public static synchronized void remove(File dir, String name) {
        java.util.List<String[]> list = load(dir);
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i)[0].equalsIgnoreCase(name)) {
                list.remove(i);
            }
        }
        write(dir, list);
    }

    public static synchronized void forgetAll(File dir) {
        new File(dir, "accounts.txt").delete();
        new File(dir, "account.txt").delete();
    }

    /** Called when a login attempt starts. */
    public static void attempt(JagString user, JagString pass) {
        pendingUser = user.toString();
        pendingPass = pass.toString();
    }

    /** Called when the server accepted the login: save or update this account (keeps the 3 most recent). */
    public static synchronized void success() {
        File f = file();
        if (!rememberMe || f == null || pendingUser == null || pendingUser.isEmpty()) {
            return;
        }
        File dir = f.getParentFile();
        java.util.List<String[]> list = load(dir);
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i)[0].equalsIgnoreCase(pendingUser)) {
                list.remove(i);
            }
        }
        list.add(0, new String[] {pendingUser, pendingPass, String.valueOf(System.currentTimeMillis())});
        while (list.size() > MAX_ACCOUNTS) {
            list.remove(list.size() - 1);
        }
        write(dir, list);
    }

    /** Queue a login from the Android login screen; the client thread starts it. */
    public static void request(String user, String pass, boolean remember) {
        rememberMe = remember;
        pendingRequest = new String[] {user, pass};
    }

    private static volatile boolean logoutRequested;

    /** Incremented once per rendered frame (lets the app wait for the client to see a new cursor position). */
    public static volatile int frames;

    // ---- automatic reconnect after an unexpected disconnect
    public static volatile boolean reconnecting;
    public static boolean intentionalLogout;
    private static boolean wasInWorld;
    private static long reconnectAt;
    private static int reconnectTries;
    private static boolean reconnectBusy;

    /** Called from LoginManager.processLogout (every way of ending up on the login screen). */
    public static void onLogout() {
        boolean fromWorld = wasInWorld;
        wasInWorld = false;
        boolean intended = intentionalLogout;
        intentionalLogout = false;
        if (fromWorld && !intended && pendingUser != null && !pendingUser.isEmpty() && pendingPass != null) {
            reconnecting = true;
            reconnectTries = 0;
            reconnectBusy = false;
            reconnectAt = System.currentTimeMillis() + 2500L;
        } else {
            reconnecting = false;
        }
    }


    /** Ask the client thread to log out (same packet the game sends on idle logout). */
    public static void requestLogout() {
        logoutRequested = true;
    }

    /** Called every frame on the client thread. */
    public static void tick() {
        frames++;
        if (client.gameState == 30) {
            wasInWorld = true;
            reconnecting = false;
            reconnectBusy = false;
        }
        if (reconnecting && client.gameState == 10 && pendingRequest == null) {
            boolean idle = LoginManager.hopStep == 0 && LoginManager.step == 0 && CreateManager.step == 0 && WorldList.step == 0;
            if (reconnectBusy && idle) {
                // the attempt we started has finished without reaching the world
                reconnectBusy = false;
                int r = LoginManager.reply;
                if (r == 3 || r == 4 || reconnectTries >= 8) {
                    reconnecting = false;
                } else {
                    reconnectAt = System.currentTimeMillis() + 4000L;
                }
            } else if (!reconnectBusy && idle && reconnecting && System.currentTimeMillis() >= reconnectAt) {
                reconnectTries++;
                reconnectBusy = true;
                LoginManager.startLogin(JagString.of(pendingUser), JagString.of(pendingPass), 0);
            }
        }
        if (logoutRequested) {
            intentionalLogout = true;
            logoutRequested = false;
            if (client.gameState == 30 && Protocol.socket != null) {
                // press the real "Click here to logout" button of the Logout tab (interface 182, button 6), exactly like a tap on it
                Protocol.outboundBuffer.p1isaac(155);
                Protocol.outboundBuffer.p4((182 << 16) | 6);
                Protocol.outboundBuffer.p2(-1);
                Protocol.logoutOnDisconnectTimer = 250;
            }
        }
        String[] r = pendingRequest;
        if (r == null || client.gameState != 10) {
            return;
        }
        if (LoginManager.hopStep != 0 || LoginManager.step != 0 || CreateManager.step != 0 || WorldList.step != 0) {
            return;
        }
        pendingRequest = null;
        LoginManager.startLogin(JagString.of(r[0]), JagString.of(r[1]), 0);
    }
}
