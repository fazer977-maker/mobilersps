package com.jogamp.opengl;

/** OpenGL calls used by the game, forwarded to gl4es through JNI. Generated. */
public class GL2 extends GL {
    public static final int GL_EXTENSIONS = 0x1F03;
    public static final int GL_ADD = 260;
    public static final int GL_ADD_SIGNED = 34164;
    public static final int GL_ALPHA = 6406;
    public static final int GL_ALPHA_TEST = 3008;
    public static final int GL_AMBIENT = 4608;
    public static final int GL_AMBIENT_AND_DIFFUSE = 5634;
    public static final int GL_ARRAY_BUFFER = 34962;
    public static final int GL_BACK = 1029;
    public static final int GL_BACK_LEFT = 1026;
    public static final int GL_BGRA = 32993;
    public static final int GL_BLEND = 3042;
    public static final int GL_C4UB_V3F = 10787;
    public static final int GL_CLAMP_TO_EDGE = 33071;
    public static final int GL_COLOR = 6144;
    public static final int GL_COLOR_ARRAY = 32886;
    public static final int GL_COLOR_BUFFER_BIT = 16384;
    public static final int GL_COLOR_MATERIAL = 2903;
    public static final int GL_COMBINE = 34160;
    public static final int GL_COMBINE_ALPHA = 34162;
    public static final int GL_COMBINE_RGB = 34161;
    public static final int GL_COMPILE = 4864;
    public static final int GL_CONSTANT = 34166;
    public static final int GL_CONSTANT_ATTENUATION = 4615;
    public static final int GL_CULL_FACE = 2884;
    public static final int GL_DEPTH_BUFFER_BIT = 256;
    public static final int GL_DEPTH_TEST = 2929;
    public static final int GL_DIFFUSE = 4609;
    public static final int GL_DRAW_BUFFER = 3073;
    public static final int GL_DST_COLOR = 774;
    public static final int GL_ELEMENT_ARRAY_BUFFER = 34963;
    public static final int GL_ENABLE_BIT = 8192;
    public static final int GL_EYE_LINEAR = 9216;
    public static final int GL_EYE_PLANE = 9474;
    public static final int GL_FASTEST = 4353;
    public static final int GL_FILL = 6914;
    public static final int GL_FLOAT = 5126;
    public static final int GL_FOG = 2912;
    public static final int GL_FOG_BIT = 128;
    public static final int GL_FOG_COLOR = 2918;
    public static final int GL_FOG_DENSITY = 2914;
    public static final int GL_FOG_END = 2916;
    public static final int GL_FOG_HINT = 3156;
    public static final int GL_FOG_MODE = 2917;
    public static final int GL_FOG_START = 2915;
    public static final int GL_FRAGMENT_PROGRAM_ARB = 34820;
    public static final int GL_FRONT = 1028;
    public static final int GL_FRONT_LEFT = 1024;
    public static final int GL_GREATER = 516;
    public static final int GL_INTERPOLATE = 34165;
    public static final int GL_LEQUAL = 515;
    public static final int GL_LIGHT0 = 16384;
    public static final int GL_LIGHT1 = 16385;
    public static final int GL_LIGHTING = 2896;
    public static final int GL_LIGHT_MODEL_AMBIENT = 2899;
    public static final int GL_LINEAR = 9729;
    public static final int GL_LINEAR_ATTENUATION = 4616;
    public static final int GL_LINEAR_MIPMAP_LINEAR = 9987;
    public static final int GL_LINES = 1;
    public static final int GL_LINE_LOOP = 2;
    public static final int GL_LUMINANCE_ALPHA = 6410;
    public static final int GL_MAX_TEXTURE_COORDS = 34929;
    public static final int GL_MAX_TEXTURE_IMAGE_UNITS = 34930;
    public static final int GL_MAX_TEXTURE_UNITS = 34018;
    public static final int GL_MODELVIEW = 5888;
    public static final int GL_MODULATE = 8448;
    public static final int GL_NEAREST = 9728;
    public static final int GL_NORMAL_ARRAY = 32885;
    public static final int GL_NORMAL_MAP = 34065;
    public static final int GL_OBJECT_LINEAR = 9217;
    public static final int GL_OBJECT_PLANE = 9473;
    public static final int GL_ONE = 1;
    public static final int GL_ONE_MINUS_SRC_ALPHA = 771;
    public static final int GL_OPERAND0_RGB = 34192;
    public static final int GL_OPERAND1_RGB = 34193;
    public static final int GL_POINT_DISTANCE_ATTENUATION = 33065;
    public static final int GL_POINT_SIZE_MAX = 33063;
    public static final int GL_POINT_SIZE_MIN = 33062;
    public static final int GL_POSITION = 4611;
    public static final int GL_PREVIOUS = 34168;
    public static final int GL_PRIMARY_COLOR = 34167;
    public static final int GL_PROGRAM_ERROR_POSITION_ARB = 34379;
    public static final int GL_PROGRAM_FORMAT_ASCII_ARB = 34933;
    public static final int GL_PROJECTION = 5889;
    public static final int GL_Q = 8195;
    public static final int GL_QUADRATIC_ATTENUATION = 4617;
    public static final int GL_R = 8194;
    public static final int GL_READ_BUFFER = 3074;
    public static final int GL_RENDERER = 7937;
    public static final int GL_REPEAT = 10497;
    public static final int GL_REPLACE = 7681;
    public static final int GL_RGBA = 6408;
    public static final int GL_RGBA8 = 32856;
    public static final int GL_RGB_SCALE = 34163;
    public static final int GL_S = 8192;
    public static final int GL_SCISSOR_TEST = 3089;
    public static final int GL_SMOOTH = 7425;
    public static final int GL_SRC0_ALPHA = 34184;
    public static final int GL_SRC0_RGB = 34176;
    public static final int GL_SRC1_RGB = 34177;
    public static final int GL_SRC2_ALPHA = 34186;
    public static final int GL_SRC2_RGB = 34178;
    public static final int GL_SRC_ALPHA = 770;
    public static final int GL_SRC_COLOR = 768;
    public static final int GL_STATIC_DRAW = 35044;
    public static final int GL_STREAM_DRAW = 35040;
    public static final int GL_SUBTRACT = 34023;
    public static final int GL_T = 8193;
    public static final int GL_T2F_V3F = 10791;
    public static final int GL_TEXTURE = 5890;
    public static final int GL_TEXTURE0 = 33984;
    public static final int GL_TEXTURE1 = 33985;
    public static final int GL_TEXTURE2 = 33986;
    public static final int GL_TEXTURE_1D = 3552;
    public static final int GL_TEXTURE_2D = 3553;
    public static final int GL_TEXTURE_3D = 32879;
    public static final int GL_TEXTURE_COORD_ARRAY = 32888;
    public static final int GL_TEXTURE_CUBE_MAP = 34067;
    public static final int GL_TEXTURE_CUBE_MAP_POSITIVE_X = 34069;
    public static final int GL_TEXTURE_ENV = 8960;
    public static final int GL_TEXTURE_ENV_COLOR = 8705;
    public static final int GL_TEXTURE_ENV_MODE = 8704;
    public static final int GL_TEXTURE_GEN_MODE = 9472;
    public static final int GL_TEXTURE_GEN_Q = 3171;
    public static final int GL_TEXTURE_GEN_R = 3170;
    public static final int GL_TEXTURE_GEN_S = 3168;
    public static final int GL_TEXTURE_GEN_T = 3169;
    public static final int GL_TEXTURE_MAG_FILTER = 10240;
    public static final int GL_TEXTURE_MIN_FILTER = 10241;
    public static final int GL_TEXTURE_WRAP_R = 32882;
    public static final int GL_TEXTURE_WRAP_S = 10242;
    public static final int GL_TEXTURE_WRAP_T = 10243;
    public static final int GL_TRIANGLES = 4;
    public static final int GL_TRIANGLE_FAN = 6;
    public static final int GL_UNSIGNED_BYTE = 5121;
    public static final int GL_UNSIGNED_INT = 5125;
    public static final int GL_UNSIGNED_INT_8_8_8_8_REV = 33639;
    public static final int GL_VENDOR = 7936;
    public static final int GL_VERSION = 7938;
    public static final int GL_VERTEX_ARRAY = 32884;
    public static final int GL_VERTEX_PROGRAM_ARB = 34336;
    public void glActiveTexture(int a0) {
        GlNative.glActiveTexture_0(a0);
        if (GlNative.dbg) GlNative.chk("glActiveTexture");
    }
    public void glAlphaFunc(int a0, float a1) {
        GlNative.glAlphaFunc_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glAlphaFunc");
    }
    public void glBegin(int a0) {
        GlNative.glBegin_0(a0);
    }
    public void glBindBuffer(int a0, int a1) {
        GlNative.glBindBuffer_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glBindBuffer");
    }
    public void glBindProgramARB(int a0, int a1) {
        GlNative.glBindProgramARB_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glBindProgramARB");
    }
    public void glBindTexture(int a0, int a1) {
        GlNative.glBindTexture_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glBindTexture(" + (a0) + "," + (a1) + ")");
    }
    public void glBlendFunc(int a0, int a1) {
        GlNative.glBlendFunc_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glBlendFunc");
    }
    public void glBufferData(int a0, long a1, java.nio.Buffer a2, int a3) {
        GlNative.glBufferData_0(a0, a1, GlBuf.ptr(a2, 8), a3);
        if (GlNative.dbg) GlNative.chk("glBufferData");
    }
    public void glBufferSubData(int a0, long a1, long a2, java.nio.Buffer a3) {
        GlNative.glBufferSubData_0(a0, a1, a2, GlBuf.ptr(a3, 8));
        if (GlNative.dbg) GlNative.chk("glBufferSubData");
    }
    public void glCallList(int a0) {
        GlNative.glCallList_0(a0);
        if (GlNative.dbg) GlNative.chk("glCallList");
    }
    public void glClearColor(float a0, float a1, float a2, float a3) {
        GlNative.glClearColor_0(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glClearColor");
    }
    public void glClearDepth(double a0) {
        GlNative.glClearDepth_0(a0);
        if (GlNative.dbg) GlNative.chk("glClearDepth");
    }
    public void glClear(int a0) {
        GlNative.glClear_0(a0);
        if (GlNative.dbg) GlNative.chk("glClear");
    }
    public void glColor3ub(byte a0, byte a1, byte a2) {
        GlNative.glColor3ub_0(a0, a1, a2);
    }
    public void glColor4fv(float[] a0, int a1) {
        GlNative.glColor4fv_0(a0, a1);
    }
    public void glColor4f(float a0, float a1, float a2, float a3) {
        GlNative.glColor4f_0(a0, a1, a2, a3);
    }
    public void glColor4ub(byte a0, byte a1, byte a2, byte a3) {
        GlNative.glColor4ub_0(a0, a1, a2, a3);
    }
    public void glColorMaterial(int a0, int a1) {
        GlNative.glColorMaterial_0(a0, a1);
    }
    public void glColorPointer(int a0, int a1, int a2, java.nio.Buffer a3) {
        GlNative.glColorPointer_0(a0, a1, a2, GlBuf.ptr(a3, 1));
    }
    public void glColorPointer(int a0, int a1, int a2, long a3) {
        GlNative.glColorPointer_1(a0, a1, a2, a3);
    }
    public void glCopyPixels(int a0, int a1, int a2, int a3, int a4) {
        GlNative.glCopyPixels_0(a0, a1, a2, a3, a4);
        if (GlNative.dbg) GlNative.chk("glCopyPixels");
    }
    public void glCullFace(int a0) {
        GlNative.glCullFace_0(a0);
        if (GlNative.dbg) GlNative.chk("glCullFace");
    }
    public void glDeleteBuffers(int a0, int[] a1, int a2) {
        GlNative.glDeleteBuffers_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glDeleteBuffers");
    }
    public void glDeleteLists(int a0, int a1) {
        GlNative.glDeleteLists_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glDeleteLists");
    }
    public void glDeleteTextures(int a0, int[] a1, int a2) {
        GlNative.glDeleteTextures_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glDeleteTextures");
    }
    public void glDepthFunc(int a0) {
        GlNative.glDepthFunc_0(a0);
        if (GlNative.dbg) GlNative.chk("glDepthFunc");
    }
    public void glDepthMask(boolean a0) {
        GlNative.glDepthMask_0(a0);
        if (GlNative.dbg) GlNative.chk("glDepthMask");
    }
    public void glDisableClientState(int a0) {
        GlNative.glDisableClientState_0(a0);
        if (GlNative.dbg) GlNative.chk("glDisableClientState");
    }
    public void glDisable(int a0) {
        GlNative.glDisable_0(a0);
        if (GlNative.dbg) GlNative.chk("glDisable(" + (a0) + ")");
    }
    public void glDrawBuffer(int a0) {
        GlNative.glDrawBuffer_0(a0);
        if (GlNative.dbg) GlNative.chk("glDrawBuffer");
    }
    public void glDrawElements(int a0, int a1, int a2, java.nio.Buffer a3) {
        GlNative.glDrawElements_0(a0, a1, a2, GlBuf.ptr(a3, 9));
        if (GlNative.dbg) GlNative.chk("glDrawElements");
    }
    public void glDrawElements(int a0, int a1, int a2, long a3) {
        GlNative.glDrawElements_1(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glDrawElements");
    }
    public void glDrawPixels(int a0, int a1, int a2, int a3, java.nio.Buffer a4) {
        GlNative.glDrawPixels_0(a0, a1, a2, a3, GlBuf.ptr(a4, 8));
        if (GlNative.dbg) GlNative.chk("glDrawPixels");
    }
    public void glEnableClientState(int a0) {
        GlNative.glEnableClientState_0(a0);
        if (GlNative.dbg) GlNative.chk("glEnableClientState(" + (a0) + ")");
    }
    public void glEnable(int a0) {
        GlNative.glEnable_0(a0);
        if (GlNative.dbg) GlNative.chk("glEnable(" + (a0) + ")");
    }
    public void glEndList() {
        GlNative.glEndList_0();
        if (GlNative.dbg) GlNative.chk("glEndList");
    }
    public void glEnd() {
        GlNative.glEnd_0();
        if (GlNative.dbg) GlNative.chk("glEnd");
    }
    public void glFogfv(int a0, float[] a1, int a2) {
        GlNative.glFogfv_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glFogfv");
    }
    public void glFogf(int a0, float a1) {
        GlNative.glFogf_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glFogf");
    }
    public void glFogi(int a0, int a1) {
        GlNative.glFogi_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glFogi");
    }
    public void glGenBuffers(int a0, int[] a1, int a2) {
        GlNative.glGenBuffers_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glGenBuffers");
    }
    public int glGenLists(int a0) {
        return GlNative.glGenLists_0(a0);
    }
    public void glGenProgramsARB(int a0, int[] a1, int a2) {
        GlNative.glGenProgramsARB_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glGenProgramsARB");
    }
    public void glGenTextures(int a0, int[] a1, int a2) {
        GlNative.glGenTextures_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glGenTextures");
    }
    public void glGenerateMipmap(int a0) {
        GlNative.glGenerateMipmap_0(a0);
        if (GlNative.dbg) GlNative.chk("glGenerateMipmap");
    }
    public void glGetFloatv(int a0, float[] a1, int a2) {
        GlNative.glGetFloatv_1(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glGetFloatv");
    }
    public void glGetIntegerv(int a0, int[] a1, int a2) {
        GlNative.glGetIntegerv_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glGetIntegerv");
    }
    public void glHint(int a0, int a1) {
        GlNative.glHint_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glHint");
    }
    public void glInterleavedArrays(int a0, int a1, java.nio.Buffer a2) {
        GlNative.glInterleavedArrays_0(a0, a1, GlBuf.ptr(a2, 7));
        if (GlNative.dbg) GlNative.chk("glInterleavedArrays");
    }
    public void glInterleavedArrays(int a0, int a1, long a2) {
        GlNative.glInterleavedArrays_1(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glInterleavedArrays");
    }
    public void glLightModelfv(int a0, float[] a1, int a2) {
        GlNative.glLightModelfv_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glLightModelfv");
    }
    public void glLightfv(int a0, int a1, float[] a2, int a3) {
        GlNative.glLightfv_0(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glLightfv");
    }
    public void glLightf(int a0, int a1, float a2) {
        GlNative.glLightf_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glLightf");
    }
    public void glLineWidth(float a0) {
        GlNative.glLineWidth_0(a0);
        if (GlNative.dbg) GlNative.chk("glLineWidth");
    }
    public void glLoadIdentity() {
        GlNative.glLoadIdentity_0();
        if (GlNative.dbg) GlNative.chk("glLoadIdentity");
    }
    public void glLoadMatrixf(float[] a0, int a1) {
        GlNative.glLoadMatrixf_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glLoadMatrixf");
    }
    public void glMatrixMode(int a0) {
        GlNative.glMatrixMode_0(a0);
        if (GlNative.dbg) GlNative.chk("glMatrixMode(" + (a0) + ")");
    }
    public void glMultiTexCoord2f(int a0, float a1, float a2) {
        GlNative.glMultiTexCoord2f_0(a0, a1, a2);
    }
    public void glNewList(int a0, int a1) {
        GlNative.glNewList_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glNewList");
    }
    public void glNormalPointer(int a0, int a1, java.nio.Buffer a2) {
        GlNative.glNormalPointer_0(a0, a1, GlBuf.ptr(a2, 2));
    }
    public void glNormalPointer(int a0, int a1, long a2) {
        GlNative.glNormalPointer_1(a0, a1, a2);
    }
    public void glOrtho(double a0, double a1, double a2, double a3, double a4, double a5) {
        GlNative.glOrtho_0(a0, a1, a2, a3, a4, a5);
        if (GlNative.dbg) GlNative.chk("glOrtho(" + (a0) + "," + (a1) + "," + (a2) + "," + (a3) + "," + (a4) + "," + (a5) + ")");
    }
    public void glPixelZoom(float a0, float a1) {
        GlNative.glPixelZoom_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glPixelZoom(" + (a0) + "," + (a1) + ")");
    }
    public void glPointParameterfv(int a0, float[] a1, int a2) {
        GlNative.glPointParameterfv_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glPointParameterfv");
    }
    public void glPointParameterf(int a0, float a1) {
        GlNative.glPointParameterf_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glPointParameterf");
    }
    public void glPolygonMode(int a0, int a1) {
        GlNative.glPolygonMode_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glPolygonMode");
    }
    public void glPopAttrib() {
        GlNative.glPopAttrib_0();
        if (GlNative.dbg) GlNative.chk("glPopAttrib");
    }
    public void glPopMatrix() {
        GlNative.glPopMatrix_0();
        if (GlNative.dbg) GlNative.chk("glPopMatrix");
    }
    public void glProgramLocalParameter4fARB(int a0, int a1, float a2, float a3, float a4, float a5) {
        GlNative.glProgramLocalParameter4fARB_0(a0, a1, a2, a3, a4, a5);
        if (GlNative.dbg) GlNative.chk("glProgramLocalParameter4fARB");
    }
    public void glProgramLocalParameter4fvARB(int a0, int a1, float[] a2, int a3) {
        GlNative.glProgramLocalParameter4fvARB_1(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glProgramLocalParameter4fvARB");
    }
    public void glProgramStringARB(int a0, int a1, int a2, String a3) {
        GlNative.glProgramStringARB_0(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glProgramStringARB");
    }
    public void glPushAttrib(int a0) {
        GlNative.glPushAttrib_0(a0);
        if (GlNative.dbg) GlNative.chk("glPushAttrib");
    }
    public void glPushMatrix() {
        GlNative.glPushMatrix_0();
        if (GlNative.dbg) GlNative.chk("glPushMatrix");
    }
    public void glRasterPos2i(int a0, int a1) {
        GlNative.glRasterPos2i_0(a0, a1);
        if (GlNative.dbg) GlNative.chk("glRasterPos2i(" + (a0) + "," + (a1) + ")");
    }
    public void glReadBuffer(int a0) {
        GlNative.glReadBuffer_0(a0);
        if (GlNative.dbg) GlNative.chk("glReadBuffer");
    }
    public void glReadPixels(int a0, int a1, int a2, int a3, int a4, int a5, java.nio.Buffer a6) {
        long rp = GlBuf.readPtr(a6);
        GlNative.glReadPixels_0(a0, a1, a2, a3, a4, a5, rp);
        if (GlNative.dbg) GlNative.chk("glReadPixels");
        GlBuf.readDone(a6);
    }
    public void glRotatef(float a0, float a1, float a2, float a3) {
        GlNative.glRotatef_0(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glRotatef");
    }
    public void glScalef(float a0, float a1, float a2) {
        GlNative.glScalef_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glScalef");
    }
    public void glScissor(int a0, int a1, int a2, int a3) {
        GlNative.glScissor_0(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glScissor(" + (a0) + "," + (a1) + "," + (a2) + "," + (a3) + ")");
    }
    public void glShadeModel(int a0) {
        GlNative.glShadeModel_0(a0);
        if (GlNative.dbg) GlNative.chk("glShadeModel");
    }
    public void glTexCoord2f(float a0, float a1) {
        GlNative.glTexCoord2f_0(a0, a1);
    }
    public void glTexCoordPointer(int a0, int a1, int a2, java.nio.Buffer a3) {
        GlNative.glTexCoordPointer_0(a0, a1, a2, GlBuf.ptr(a3, 3 + clientTex));
    }
    public void glTexCoordPointer(int a0, int a1, int a2, long a3) {
        GlNative.glTexCoordPointer_1(a0, a1, a2, a3);
    }
    public void glTexEnvfv(int a0, int a1, float[] a2, int a3) {
        GlNative.glTexEnvfv_0(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glTexEnvfv");
    }
    public void glTexEnvf(int a0, int a1, float a2) {
        GlNative.glTexEnvf_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glTexEnvf");
    }
    public void glTexEnvi(int a0, int a1, int a2) {
        GlNative.glTexEnvi_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glTexEnvi");
    }
    public void glTexGenfv(int a0, int a1, float[] a2, int a3) {
        GlNative.glTexGenfv_0(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glTexGenfv");
    }
    public void glTexGeni(int a0, int a1, int a2) {
        GlNative.glTexGeni_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glTexGeni");
    }
    public void glTexImage1D(int a0, int a1, int a2, int a3, int a4, int a5, int a6, java.nio.Buffer a7) {
        GlNative.glTexImage1D_0(a0, a1, a2, a3, a4, a5, a6, GlBuf.ptr(a7, 8));
        if (GlNative.dbg) GlNative.chk("glTexImage1D");
    }
    public void glTexImage2D(int a0, int a1, int a2, int a3, int a4, int a5, int a6, int a7, java.nio.Buffer a8) {
        GlNative.glTexImage2D_0(a0, a1, a2, a3, a4, a5, a6, a7, GlBuf.ptr(a8, 8));
        if (GlNative.dbg) GlNative.chk("glTexImage2D");
    }
    public void glTexImage3D(int a0, int a1, int a2, int a3, int a4, int a5, int a6, int a7, int a8, java.nio.Buffer a9) {
        GlNative.glTexImage3D_0(a0, a1, a2, a3, a4, a5, a6, a7, a8, GlBuf.ptr(a9, 8));
        if (GlNative.dbg) GlNative.chk("glTexImage3D");
    }
    public void glTexParameteri(int a0, int a1, int a2) {
        GlNative.glTexParameteri_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glTexParameteri");
    }
    public void glTexStorage2D(int a0, int a1, int a2, int a3, int a4) {
        GlNative.glTexStorage2D_0(a0, a1, a2, a3, a4);
        if (GlNative.dbg) GlNative.chk("glTexStorage2D");
    }
    public void glTexSubImage2D(int a0, int a1, int a2, int a3, int a4, int a5, int a6, int a7, java.nio.Buffer a8) {
        GlNative.glTexSubImage2D_0(a0, a1, a2, a3, a4, a5, a6, a7, GlBuf.ptr(a8, 8));
        if (GlNative.dbg) GlNative.chk("glTexSubImage2D");
    }
    public void glTranslatef(float a0, float a1, float a2) {
        GlNative.glTranslatef_0(a0, a1, a2);
        if (GlNative.dbg) GlNative.chk("glTranslatef");
    }
    public void glVertex2f(float a0, float a1) {
        GlNative.glVertex2f_0(a0, a1);
    }
    public void glVertexPointer(int a0, int a1, int a2, java.nio.Buffer a3) {
        GlNative.glVertexPointer_0(a0, a1, a2, GlBuf.ptr(a3, 0));
    }
    public void glVertexPointer(int a0, int a1, int a2, long a3) {
        GlNative.glVertexPointer_1(a0, a1, a2, a3);
    }
    public void glViewport(int a0, int a1, int a2, int a3) {
        GlNative.glViewport_0(a0, a1, a2, a3);
        if (GlNative.dbg) GlNative.chk("glViewport(" + (a0) + "," + (a1) + "," + (a2) + "," + (a3) + ")");
    }

    public String glGetString(int a0) { return GlNative.glGetString(a0); }
    public boolean isExtensionAvailable(String a0) {
        String e = GlNative.glGetString(GL_EXTENSIONS);
        if (e == null) return false;
        for (String s : e.split(" ")) { if (s.equals(a0)) return true; }
        return false;
    }
    public void setSwapInterval(int a0) { }
    public void glGetFloatv(int a0, java.nio.FloatBuffer a1) {
        float[] t = new float[16];
        glGetFloatv(a0, t, 0);
        int n = Math.min(16, a1.remaining());
        for (int i = 0; i < n; i++) a1.put(a1.position() + i, t[i]);
    }
    public void glProgramLocalParameter4fvARB(int a0, int a1, java.nio.FloatBuffer a2) {
        int p = a2.position();
        glProgramLocalParameter4fARB(a0, a1, a2.get(p), a2.get(p + 1), a2.get(p + 2), a2.get(p + 3));
    }
    private int clientTex;
    public void glClientActiveTexture(int a0) { clientTex = Math.max(0, a0 - GL_TEXTURE0) & 3; GlNative.glClientActiveTexture_0(a0); }
}
