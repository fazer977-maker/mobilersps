package rt4;

/**
 * Rearranges the stock resizable top-level interface (746) into a phone layout:
 * chat at the top-left, tab icons in a column down each edge, tab panel beside the right column.
 * Runs every frame after layout, so script-driven re-layouts are simply overridden again.
 */
public final class MobileLayout {
    public static boolean enabled = true;

    // stone component indexes (layer 25). overlay = +15 (layer 40), icon = +30 (layer 55)
    // 2 columns x 7 rows, filled row by row (stone component indexes)
    private static final int[] GRID = {29, 27, 30, 26, 31, 32, 28, 34, 35, 36, 37, 38, 39, 33};
    private static int gridX, gridY;

    private static boolean captured;
    private static final int[] ovDx = new int[70], ovDy = new int[70], icDx = new int[70], icDy = new int[70];
    private static final int[] stW = new int[70], stH = new int[70], ovW = new int[70], ovH = new int[70], icW = new int[70], icH = new int[70];
    private static int stoneW = 46;

    private MobileLayout() {}

    public static void apply() {
        if (!enabled || InterfaceList.topLevelInterface != 746) {
            return;
        }
        Component[][] all = InterfaceList.components;
        if (all == null || all.length <= 746 || all[746] == null || all[746].length < 111) {
            return;
        }
        Component[] c = all[746];
        if (c[24] == null || c[25] == null || c[40] == null || c[55] == null || c[23] == null || c[70] == null || c[73] == null) {
            return;
        }
        final int w = GameShell.canvasWidth;
        final int h = GameShell.canvasHeight;
        if (w <= 0 || h <= 0) {
            return;
        }

        if (!captured) {
            for (int s = 26; s <= 39; s++) {
                Component st = c[s], ov = c[s + 15], ic = c[s + 30];
                if (st == null || ov == null || ic == null) {
                    return;
                }
                ovDx[s] = ov.x - st.x;
                ovDy[s] = ov.y - st.y;
                icDx[s] = ic.x - st.x;
                icDy[s] = ic.y - st.y;
                stW[s] = st.width; stH[s] = st.height;
                ovW[s] = ov.width; ovH[s] = ov.height;
                icW[s] = ic.width; icH[s] = ic.height;
            }
            captured = true;
        }

        // chat: tab buttons on top, chat box below, overlay under that
        set(c[23], 0, 0);
        set(c[70], 0, 23);
        if (c[71] != null) set(c[71], 9, 165);
        if (c[72] != null) set(c[72], 9, 165);

        // tab containers become full-screen so children can use screen coordinates
        for (int id : new int[] {24, 25, 40, 55}) {
            c[id].x = 0;
            c[id].y = 0;
            c[id].width = w;
            c[id].height = h;
            c[id].noClickThrough = false; // full-screen now, so it must not swallow world clicks
        }

        // 2x7 block of touching icons in the bottom-right, like OSRS mobile
        int top = 190;
        float f = Math.max(1f, Math.min(1.6f, (h - top - 6) / (8f * 36f)));
        int cellH = Math.round(36 * f);
        stoneW = Math.round(33 * f);
        gridX = w - 2 * stoneW - 4;
        gridY = h - 8 * cellH - 4;
        // cell 1 (top right) is the logout button, drawn natively by the app; stones fill cells 2..15
        logoutX = gridX + stoneW;
        logoutY = gridY;
        logoutW = stoneW;
        logoutH = cellH;
        canvasW = w;
        for (int i = 0; i < GRID.length; i++) {
            int cell = i + 2;
            placeOne(c, GRID[i], gridX + (cell % 2) * stoneW, gridY + (cell / 2) * cellH, f);
        }

        // the last slot is the logout tab; the stock script leaves it blank in this layout, so show it
        for (int id : new int[] {33, 48, 63}) {
            if (c[id] != null) {
                c[id].hidden = false;
            }
        }

        // opened tab panel sits to the left of the right column
        c[73].x = Math.max(0, gridX - 4 - c[73].width);
        c[73].y = Math.max(0, h - 4 - c[73].height);
        panelX = c[73].x;
        panelY = c[73].y;
        panelW = c[73].width;
        panelH = c[73].height;
        panelOpen = !c[73].hidden && c[77] != null && !c[77].hidden && c[75] != null && !c[75].hidden;
    }

    /** Hide the native button when a full-screen interface would be covered by it (never, for now). */
    public static boolean logoutHidden() { return false; }

    public static volatile int logoutX, logoutY, logoutW, logoutH, canvasW;
    private static volatile boolean panelOpen;
    private static volatile int panelX, panelY, panelW, panelH;

    /** True when logical point (x, y) is over the 3D world rather than a button, panel, chat or minimap. */
    public static boolean touchIsWorld(int x, int y) {
        int w = GameShell.canvasWidth;
        if (x >= gridX && y >= gridY) return false;          // icon block
        if (x < 520 && y < 170) return false;                // chat
        if (x >= w - 225 && y < 190) return false;           // minimap and orbs
        if (panelOpen && x >= panelX && x < panelX + panelW && y >= panelY && y < panelY + panelH) return false;
        return true;
    }

    /** True when logical point (x, y) is over the chat message box (below the filter buttons). */
    public static boolean isChat(int x, int y) {
        return enabled && x >= 0 && x < 519 && y >= 23 && y < 165;
    }

    private static void set(Component comp, int x, int y) {
        comp.x = x;
        comp.y = y;
    }

    private static void placeOne(Component[] c, int s, int x, int y, float f) {
        c[s].x = x;
        c[s].y = y;
        c[s].width = Math.round(stW[s] * f);
        c[s].height = Math.round(stH[s] * f);
        c[s + 15].x = x + Math.round(ovDx[s] * f);
        c[s + 15].y = y + Math.round(ovDy[s] * f);
        c[s + 15].width = Math.round(ovW[s] * f);
        c[s + 15].height = Math.round(ovH[s] * f);
        c[s + 30].x = x + Math.round(icDx[s] * f);
        c[s + 30].y = y + Math.round(icDy[s] * f);
        c[s + 30].width = Math.round(icW[s] * f);
        c[s + 30].height = Math.round(icH[s] * f);
    }
}
