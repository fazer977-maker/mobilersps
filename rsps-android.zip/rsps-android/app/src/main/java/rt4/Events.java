package rt4;

/**
 * Rainbow Scape world events, game-thread side, for the app's countdown banner.
 * The server (RainbowEvents) sends  ~ev~state|secs|name|where  (W warning, L live, N next event) after the app
 * says hello with ::evcheck, and again whenever an event changes. Shooting stars and crop circles are picked up
 * from the game's own news lines (shown on the banner, no teleport yet).
 */
public final class Events {
    private Events() {}

    public static final String TAG = "~ev~";

    // ---- published to the app
    public static volatile char state = 0;          // 0 nothing known yet, 'N', 'W', 'L'
    public static volatile long endsAt;             // warning: start time / live: end time / N: next warning
    public static volatile String name = "", where = "";
    public static volatile String starWhere = "", cropWhere = "";
    public static volatile long starUntil, cropUntil;
    public static volatile int version;

    private static volatile boolean tpWanted;
    private static int lastState;
    private static long loginAt;
    private static boolean helloSent;

    public static void teleport() { tpWanted = true; }

    /** a hidden event line: true (never shown in chat) */
    public static boolean handle(JagString msg, JagString from) {
        if (msg == null) return false;
        String s = msg.toString();
        if (!s.startsWith(TAG)) {
            // only the game's own messages, never a player typing the same words
            if (from == null || from.length() == 0) observe(s);
            return false;
        }
        try {
            String[] p = s.substring(TAG.length()).split("\\|", 4);
            char st = p[0].charAt(0);
            long secs = Long.parseLong(p[1].trim());
            name = p.length > 2 ? p[2] : "";
            where = p.length > 3 ? p[3] : "";
            endsAt = System.currentTimeMillis() + secs * 1000L;
            state = st;
            version++;
        } catch (RuntimeException ignored) {
        }
        return true;
    }

    private static String plain(String s) {
        return s.replaceAll("<[^>]*>", "").trim();
    }

    /** the game's own news: "A shooting star (Level 1) has just crashed near X!" / "A crop circle is active near X." */
    private static void observe(String raw) {
        String s = plain(raw);
        String low = s.toLowerCase();
        int near = low.lastIndexOf(" near ");
        if (near < 0) return;
        String w = s.substring(near + 6).replaceAll("[!.]+$", "").trim();
        long now = System.currentTimeMillis();
        if (low.contains("shooting star") && low.contains("crash")) {
            starWhere = w; starUntil = now + 20 * 60_000L; version++;
        } else if (low.contains("crop circle") && low.contains("active")) {
            cropWhere = w; cropUntil = now + 30 * 60_000L; version++;
        }
    }

    public static void tick() {
        try {
            int gs = client.gameState;
            long now = System.currentTimeMillis();
            if (gs == 30 && lastState != 30) { loginAt = now; helloSent = false; }
            lastState = gs;
            if (gs != 30) return;
            if (!helloSent && now - loginAt > 4000) { helloSent = true; send("::evcheck"); }
            if (tpWanted) { tpWanted = false; send("::eventtp"); }
        } catch (Throwable ignored) {
        }
    }

    private static void send(String cmd) {
        JagString line = JagString.parse(cmd);
        Protocol.outboundBuffer.p1isaac(ClientProt.CLIENT_CHEAT);
        Protocol.outboundBuffer.p1(line.length() - 1);
        Protocol.outboundBuffer.pjstr(line.substring(2));
    }
}
