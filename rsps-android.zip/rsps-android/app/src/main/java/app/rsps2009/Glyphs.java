package app.rsps2009;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import java.util.HashMap;

/**
 * Small line icons drawn with Canvas paths (24 x 24 design box, 2-unit strokes). Each icon is a list of parts
 * separated by ';'. A part starts with S (stroke) or F (fill), then SVG-style absolute path data (M L C Q Z)
 * or "O cx cy r" for a circle. The same strings drive the web preview, so what is previewed is what is drawn.
 */
final class Glyphs {
    private Glyphs() {}

    static final HashMap<String, String> ICONS = new HashMap<String, String>();
    static {
        String heart = "S M19 14 C20.5 12.5 22 10.8 22 8.5 C22 5.5 19.8 3.5 17.2 3.5 C15.3 3.5 13.8 4.4 12 6.2 C10.2 4.4 8.7 3.5 6.8 3.5 C4.2 3.5 2 5.5 2 8.5 C2 10.8 3.5 12.5 5 14 L12 21 Z";
        String shield = "S M12 22 C12 22 20 18 20 12 L20 5 L12 2 L4 5 L4 12 C4 18 12 22 12 22 Z";
        String wind = "S M3 8 L14 8 C16.2 8 17.5 6.5 17 5 M3 12 L19 12 C21 12 22 14 21 15.5 M3 16 L12 16 C14 16 15 17.5 14.5 19";
        ICONS.put("sword", "S M14.5 17.5 L3 6 L3 3 L6 3 L17.5 14.5 M13 19 L19 13 M16 16 L20 20 M19 21 L21 19");
        ICONS.put("crosshair", "S O 12 12 9;S M22 12 L18 12 M6 12 L2 12 M12 6 L12 2 M12 22 L12 18;F O 12 12 1.6");
        ICONS.put("burst", "F M12 2 L14 9 L21 7 L16 12 L21 17 L14 15 L12 22 L10 15 L3 17 L8 12 L3 7 L10 9 Z");
        ICONS.put("chevrons", "S M6 17 L11 12 L6 7 M13 17 L18 12 L13 7");
        ICONS.put("skull", "S M12 3 C7 3 4 6.5 4 11 C4 13.5 5.2 15.3 7 16.3 L7 20 L17 20 L17 16.3 C18.8 15.3 20 13.5 20 11 C20 6.5 17 3 12 3 Z;F O 9 11.5 1.7;F O 15 11.5 1.7;S M10 20 L10 17.5 M14 20 L14 17.5");
        ICONS.put("drop", "S M12 2.7 C12 2.7 5 10 5 14.5 C5 18.4 8.1 21.5 12 21.5 C15.9 21.5 19 18.4 19 14.5 C19 10 12 2.7 12 2.7 Z;S M9 15 C9 16.7 10.3 18 12 18");
        ICONS.put("bleed", "S M10 2.7 C10 2.7 4 9 4 13 C4 16.3 6.7 19 10 19 C13.3 19 16 16.3 16 13 C16 9 10 2.7 10 2.7 Z;F O 19.5 14.5 1.5;F O 20 20 1.2");
        ICONS.put("shield", shield);
        ICONS.put("shieldsplit", shield + ";S M12 2.5 L12 21.5;F M12 2 L20 5 L20 12 C20 18 12 22 12 22 Z");
        ICONS.put("wind", wind);
        ICONS.put("reflect", "S M9 14 L4 9 L9 4 M4 9 L14.5 9 C17.5 9 20 11.5 20 14.5 C20 17.5 17.5 20 14.5 20 L11 20");
        ICONS.put("heart", heart);
        ICONS.put("heartplus", heart + ";S M12 8.5 L12 15.5 M8.5 12 L15.5 12");
        ICONS.put("heartup", heart + ";S M12 16 L12 8.5 M9 11.5 L12 8.5 L15 11.5");
        ICONS.put("flask", "S M9 3 L15 3 M10 3 L10 9 L4.5 18.5 C3.8 19.7 4.7 21 6 21 L18 21 C19.3 21 20.2 19.7 19.5 18.5 L14 9 L14 3 M6.5 15 L17.5 15");
        ICONS.put("star", "S M12 2 L15.1 8.3 L22 9.3 L17 14.1 L18.2 21 L12 17.8 L5.8 21 L7 14.1 L2 9.3 L8.9 8.3 Z");
        ICONS.put("sparkles", "S M12 3 L13.9 8.1 L19 10 L13.9 11.9 L12 17 L10.1 11.9 L5 10 L10.1 8.1 Z M19 15 L19 21 M16 18 L22 18 M5 3 L5 7 M3 5 L7 5");
        ICONS.put("sun", "S O 12 12 4;S M12 2 L12 4 M12 20 L12 22 M4.9 4.9 L6.3 6.3 M17.7 17.7 L19.1 19.1 M2 12 L4 12 M20 12 L22 12 M6.3 17.7 L4.9 19.1 M19.1 4.9 L17.7 6.3");
        ICONS.put("layers2", "S M12 3 L2 8 L12 13 L22 8 Z M2 13 L12 18 L22 13");
        ICONS.put("layers3", "S M12 2 L2 7 L12 12 L22 7 Z M2 12 L12 17 L22 12 M2 17 L12 22 L22 17");
        ICONS.put("bolt", "S M13 2 L3 14 L12 14 L11 22 L21 10 L12 10 Z");
        ICONS.put("trend", "S M22 7 L13.5 15.5 L8.5 10.5 L2 17 M16 7 L22 7 L22 13");
        ICONS.put("gem", "S M6 3 L18 3 L22 9 L12 22 L2 9 Z M11 3 L8 9 L12 22 M13 3 L16 9 L12 22 M2 9 L22 9");
        ICONS.put("crown", "S M2.5 18 L4 6.5 L9 11 L12 4 L15 11 L20 6.5 L21.5 18 Z M3 21.5 L21 21.5");
        ICONS.put("dumbbell", "S M6.5 6.5 L17.5 17.5 M21 21 L20 20 M3 3 L4 4 M18 22 L22 18 M2 6 L6 2 M3 10 L10 3 M14 21 L21 14");
        ICONS.put("bow", "S M6 3 C15 5 19 9 21 18 M6 3 L21 18 M3 21 L16 8 M16 8 L12 8 M16 8 L16 12");
        ICONS.put("wand", "S M15 4 L15 2 M15 16 L15 14 M8 9 L10 9 M20 9 L22 9 M17.8 11.8 L19 13 M17.8 6.2 L19 5 M3 21 L12 12 M12.2 6.2 L11 5");
        ICONS.put("pickaxe", "S M3 21 L14.5 9.5 M8 4 C13 4.5 19.5 11 20 16");
        ICONS.put("axe", "S M3 21 L14 10 M13 3 L21 11 C19 13 16 13 14.5 11.5 L12.5 9.5 C11 8 11 5 13 3 Z");
        ICONS.put("fish", "S M2 12 C5 7.5 11 6 16 9 L21 6 L21 18 L16 15 C11 18 5 16.5 2 12 Z;F O 7 11 1.1");
        ICONS.put("lock", "S M5 11 L19 11 L19 21 L5 21 Z M8 11 L8 7.5 C8 5.3 9.8 3.5 12 3.5 C14.2 3.5 16 5.3 16 7.5 L16 11");
        ICONS.put("plus", "S M12 5 L12 19 M5 12 L19 12");
    }

    /** talent effect -> icon */
    static String forEffect(String e) {
        if (e == null) return "star";
        switch (e) {
            case "ACC": return "crosshair";   case "DMG": return "sword";       case "CRIT": return "burst";
            case "EXTRA": return "chevrons";  case "EXEC": return "skull";       case "LEECH": return "drop";
            case "BLEED": return "bleed";     case "DR": return "shield";       case "DR_LOW": return "shieldsplit";
            case "DODGE": case "DODGE_LOW": return "wind";                      case "REFLECT": return "reflect";
            case "MAXHP": return "heartplus"; case "SECONDWIND": return "heartup"; case "HEALF": return "flask";
            case "PRAYDRAIN": return "star";  case "PRAYRESTORE": return "sparkles"; case "PRAYHEAL": return "sun";
            case "DOUBLE": return "layers2";  case "EXTRA2": return "layers3";  case "SPEED": return "bolt";
            case "XP": return "trend";        case "RARE": return "gem";        case "RARE2": return "crown";
            default: return "star";
        }
    }

    /** skill slot -> icon (null = none) */
    static String forSkill(int s) {
        switch (s) {
            case 0: return "sword"; case 1: return "shield"; case 2: return "dumbbell"; case 3: return "heart";
            case 4: return "bow"; case 5: return "star"; case 6: return "wand"; case 8: return "axe";
            case 10: return "fish"; case 14: return "pickaxe";
            default: return null;
        }
    }

    private static final class Part { boolean fill; Path path; }
    private static final HashMap<String, Part[]> parsed = new HashMap<String, Part[]>();

    private static Part[] parse(String key) {
        Part[] r = parsed.get(key);
        if (r != null) return r;
        String src = ICONS.get(key);
        if (src == null) return null;
        String[] bits = src.split(";");
        r = new Part[bits.length];
        for (int i = 0; i < bits.length; i++) {
            String b = bits[i].trim();
            Part pt = new Part();
            pt.fill = b.charAt(0) == 'F';
            pt.path = new Path();
            String[] tk = b.substring(1).replace(",", " ").replaceAll("([A-Za-z])", " $1 ").trim().split("\\s+");
            int k = 0;
            char cmd = 'M';
            while (k < tk.length) {
                String t = tk[k];
                if (t.isEmpty()) { k++; continue; }
                char ch = t.charAt(0);
                if (Character.isLetter(ch)) { cmd = ch; k++; if (cmd == 'Z') { pt.path.close(); continue; } }
                try {
                    switch (cmd) {
                        case 'M': pt.path.moveTo(f(tk[k]), f(tk[k + 1])); k += 2; cmd = 'L'; break;
                        case 'L': pt.path.lineTo(f(tk[k]), f(tk[k + 1])); k += 2; break;
                        case 'Q': pt.path.quadTo(f(tk[k]), f(tk[k + 1]), f(tk[k + 2]), f(tk[k + 3])); k += 4; break;
                        case 'C': pt.path.cubicTo(f(tk[k]), f(tk[k + 1]), f(tk[k + 2]), f(tk[k + 3]), f(tk[k + 4]), f(tk[k + 5])); k += 6; break;
                        case 'O': pt.path.addCircle(f(tk[k]), f(tk[k + 1]), f(tk[k + 2]), Path.Direction.CW); k += 3; break;
                        default: k++;
                    }
                } catch (RuntimeException e) { break; }
            }
            r[i] = pt;
        }
        parsed.put(key, r);
        return r;
    }

    private static float f(String s) { return Float.parseFloat(s); }

    /** draw icon key centred at (cx, cy), size px wide, in color; restores the paint's style afterwards */
    static void draw(Canvas c, Paint p, String key, float cx, float cy, float size, int color) {
        Part[] parts = key == null ? null : parse(key);
        if (parts == null) return;
        Paint.Style st = p.getStyle();
        float sw = p.getStrokeWidth();
        Paint.Cap cap = p.getStrokeCap();
        Paint.Join join = p.getStrokeJoin();
        c.save();
        c.translate(cx - size / 2f, cy - size / 2f);
        c.scale(size / 24f, size / 24f);
        p.setShader(null);
        p.setColor(color);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        for (Part pt : parts) {
            if (pt.fill) { p.setStyle(Paint.Style.FILL); }
            else { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.9f); }
            c.drawPath(pt.path, p);
        }
        c.restore();
        p.setStyle(st); p.setStrokeWidth(sw); p.setStrokeCap(cap); p.setStrokeJoin(join);
    }
}
