package app.rsps2009;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.FrameLayout;

import shim.platform.Platforms;

public class GameActivity extends Activity implements SurfaceHolder.Callback {

    private static boolean started = false;

    private GameSurface surface;
    private Settings settings;
    private AndroidPlatform platform;
    private boolean kbVisible;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        settings = Settings.load(this);
        setRequestedOrientation(settings.portrait
                ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                : ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        surface = new GameSurface(this);
        surface.setRenderScale(settings.renderScale);
        surface.getHolder().addCallback(this);
        root.addView(surface, new FrameLayout.LayoutParams(-1, -1));

        Button kb = new Button(this);
        kb.setText("⌨");
        kb.setAlpha(0.5f);
        kb.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleKeyboard(); }
        });
        float d = getResources().getDisplayMetrics().density;
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) (48 * d), (int) (40 * d));
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.topMargin = (int) (4 * d);
        lp.rightMargin = (int) (4 * d);
        root.addView(kb, lp);
        setContentView(root);
        goImmersive();
    }

    private void goImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) goImmersive();
        if (started) GameEvents.focus(hasFocus);
    }

    private void toggleKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        surface.requestFocus();
        if (kbVisible) imm.hideSoftInputFromWindow(surface.getWindowToken(), 0);
        else imm.showSoftInput(surface, InputMethodManager.SHOW_FORCED);
        kbVisible = !kbVisible;
    }

    @Override
    public void onBackPressed() {
        if (started) GameEvents.controlKey(shim.awt.event.KeyEvent.VK_ESCAPE, (char) 27);
    }

    // ---------------------------------------------------------------- surface

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        if (platform != null) platform.onSurfaceCreated();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
        if (platform != null) {
            platform.onSurfaceChanged(w, h);
            return;
        }
        platform = new AndroidPlatform(holder, w, h, settings.renderScale, getFilesDir().getAbsolutePath() + "/");
        Platforms.current = platform;
        if (started) return; // process survived an activity recreation; client keeps running
        started = true;
        try {
            final String cfg = settings.writeClientConfig(this).getAbsolutePath();
            System.setProperty("clientHomeOverride", getFilesDir().getAbsolutePath() + "/");
            rt4.DisplayMode.resizableSD = true;
            Thread t = new Thread(null, new Runnable() {
                @Override public void run() {
                    try {
                        rt4.client.main(new String[] {"--config", cfg});
                    } catch (Throwable e) {
                        android.util.Log.e("rsps2009", "client crashed", e);
                    }
                }
            }, "rs-main", 64L * 1024 * 1024);
            t.start();
        } catch (Exception e) {
            android.util.Log.e("rsps2009", "start failed", e);
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        if (platform != null) platform.onSurfaceDestroyed();
    }
}
