package app.rsps2009;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import rt4.Events;

/** Real buttons drawn over the "[Teleport]" words of event messages in the chat box. Other touches pass through. */
final class ChatButtons extends View {
    private static final int[] RAINBOW = {0xFFFF3030, 0xFFFF8A1E, 0xFFFFE62E, 0xFF4CFF4C, 0xFF2EE6FF, 0xFF4C7DFF, 0xFFC04CFF};
    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Typeface bold = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD);
    private final RectF[] rs = new RectF[Events.MAX];
    private int n;
    private float scale = 1f;
    private long pressedAt;
    private int pressed = -1;

    ChatButtons(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        for (int i = 0; i < rs.length; i++) rs[i] = new RectF();
    }

    /** UI thread poller: copy where the buttons go */
    void sync(boolean allowed, float sc) {
        scale = sc;
        int c = allowed ? Events.btnCount : 0;
        for (int i = 0; i < c; i++) {
            float x = Events.btnX[i] * sc, y = Events.btnY[i] * sc, w = Events.btnW[i] * sc, h = Events.btnH[i] * sc;
            rs[i].set(x - 1 * sc, y - 1 * sc, x + w + 3 * sc, y + h + 1 * sc);
        }
        n = c;
        setVisibility(n > 0 ? VISIBLE : GONE);
        if (n > 0) invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        long now = System.currentTimeMillis();
        int k = (int) ((now / 110L) % RAINBOW.length);
        for (int i = 0; i < n; i++) {
            RectF r = rs[i];
            float rad = r.height() / 2;
            boolean down = i == pressed && now - pressedAt < 350;
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0, r.top, 0, r.bottom, down ? 0xFF5A4A10 : 0xFF2B2F52, down ? 0xFF3A300A : 0xFF171A2E, Shader.TileMode.CLAMP));
            c.drawRoundRect(r, rad, rad, p);
            p.setShader(new LinearGradient(r.left, 0, r.right, 0,
                    new int[] {RAINBOW[k], RAINBOW[(k + 2) % 7], RAINBOW[(k + 4) % 7], RAINBOW[(k + 6) % 7]}, null, Shader.TileMode.CLAMP));
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1.5f, 1.6f * d));
            c.drawRoundRect(r, rad, rad, p);
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            p.setTypeface(bold);
            float ts = r.height() * 0.62f;
            p.setTextSize(ts);
            String t = "Teleport";
            String ic = "✦ ";
            float tw = p.measureText(ic + t);
            while (tw > r.width() - 10 && ts > 6) { ts *= 0.92f; p.setTextSize(ts); tw = p.measureText(ic + t); }
            float x = r.centerX() - tw / 2, y = r.centerY() + ts * 0.36f;
            p.setColor(RAINBOW[(k + 3) % 7]);
            c.drawText(ic, x, y, p);
            p.setColor(0xFFFFFFFF);
            c.drawText(t, x + p.measureText(ic), y, p);
        }
        if (n > 0) postInvalidateDelayed(60);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        int hit = -1;
        for (int i = 0; i < n; i++) {
            RectF r = rs[i];
            if (x >= r.left - 6 * d && x <= r.right + 6 * d && y >= r.top - 6 * d && y <= r.bottom + 6 * d) { hit = i; break; }
        }
        if (hit < 0) return false;                       // not on a button: the game gets the touch
        if (e.getActionMasked() == MotionEvent.ACTION_UP) {
            pressed = hit;
            pressedAt = System.currentTimeMillis();
            Events.teleport(hit);
            invalidate();
        }
        return true;
    }
}
