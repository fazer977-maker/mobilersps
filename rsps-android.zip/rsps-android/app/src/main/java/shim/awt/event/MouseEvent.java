package shim.awt.event;

import shim.awt.Point;

public class MouseEvent extends InputEvent {
    public static final int MOUSE_CLICKED = 500, MOUSE_PRESSED = 501, MOUSE_RELEASED = 502, MOUSE_MOVED = 503,
            MOUSE_ENTERED = 504, MOUSE_EXITED = 505, MOUSE_DRAGGED = 506, MOUSE_WHEEL = 507;
    public static final int NOBUTTON = 0, BUTTON1 = 1, BUTTON2 = 2, BUTTON3 = 3;
    protected int x, y, clickCount, button;
    protected boolean popupTrigger;
    public MouseEvent(Object source, int id, long when, int modifiers, int x, int y, int clickCount, boolean popupTrigger, int button) {
        super(source, id, when, modifiers);
        this.x = x; this.y = y; this.clickCount = clickCount; this.popupTrigger = popupTrigger; this.button = button;
    }
    public MouseEvent(Object source, int id, long when, int modifiers, int x, int y, int clickCount, boolean popupTrigger) {
        this(source, id, when, modifiers, x, y, clickCount, popupTrigger, NOBUTTON);
    }
    public int getX() { return x; }
    public int getY() { return y; }
    public Point getPoint() { return new Point(x, y); }
    public int getClickCount() { return clickCount; }
    public int getButton() { return button; }
    public boolean isPopupTrigger() { return popupTrigger; }
}
