package shim.awt;

public class Dimension {
    public int width, height;
    public Dimension() {}
    public Dimension(int w, int h) { width = w; height = h; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
}
