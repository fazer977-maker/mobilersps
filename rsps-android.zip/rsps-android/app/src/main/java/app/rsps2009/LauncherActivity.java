package app.rsps2009;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

/** Connection settings + Play button. Built in code so the project needs no layout resources. */
public class LauncherActivity extends Activity {

    private static final String[] SCALE_LABELS = {"1.0x (sharpest, most to see)", "1.25x", "1.5x", "2.0x", "2.5x (default)", "3.0x (biggest UI)"};
    private static final float[] SCALE_VALUES = {1.0f, 1.25f, 1.5f, 2.0f, 2.5f, 3.0f};

    private EditText host, serverPort, wlPort, js5Port, world;
    private Spinner scale;
    private CheckBox portrait;
    private CheckBox smooth;
    private CheckBox shade;
    private CheckBox gpu;
    private CheckBox fps;
    private CheckBox softCb, msaaCb, sway, bloomCb, dofCb, vigCb, skyCb, ambCb;
    private Spinner look, todSp, weatherSp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CrashLog.install(this);
        // Rainbow Scape: always play on our own server, skip the settings screen and go straight to the game + login screen.
        // The log/settings screen only shows when started with the extra "settings" (never automatically).
        getSharedPreferences(Settings.PREFS, Context.MODE_PRIVATE).edit().putString("host", Settings.DEFAULT_HOST).apply();
        if (!getIntent().getBooleanExtra("settings", false)) {
            startActivity(new Intent(this, GameActivity.class));
            finish();
            return;
        }
        Settings s = Settings.load(this);
        float d = getResources().getDisplayMetrics().density;
        int pad = (int) (16 * d);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad * 2, pad, pad);
        root.setBackgroundColor(Color.rgb(24, 20, 14));

        final java.io.File nativeCrashFile = new java.io.File(getFilesDir(), "native_crash.txt");
        if (nativeCrashFile.exists() && nativeCrashFile.length() > 0) {
            String nc = "";
            try (java.io.FileInputStream in = new java.io.FileInputStream(nativeCrashFile)) {
                byte[] bb = new byte[(int) Math.min(nativeCrashFile.length(), 3000)];
                int n = in.read(bb);
                nc = new String(bb, 0, Math.max(n, 0), "UTF-8");
            } catch (Throwable ignored) { }
            TextView nct = text("NATIVE CRASH (send a screenshot to Claude):\n" + nc, 12, Color.rgb(255, 220, 90), false);
            nct.setTextIsSelectable(true);
            root.addView(nct);
            Button ncClear = new Button(this);
            ncClear.setText("Clear native crash");
            ncClear.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { nativeCrashFile.delete(); recreate(); }
            });
            root.addView(ncClear);
        }
        final String crash = CrashLog.read(this);
        if (crash != null) {
            TextView ct = text("LAST RUN LOG, build 98 (GPU) (send a screenshot to Claude):\n" + crash, 11, Color.rgb(255, 120, 120), false);
            ct.setTextIsSelectable(true);
            root.addView(ct);
            Button clear = new Button(this);
            clear.setText("Clear log");
            clear.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { CrashLog.file(LauncherActivity.this).delete(); recreate(); }
            });
            root.addView(clear);
        }
        final java.io.File accFile = new java.io.File(getFilesDir(), "accounts.txt");
        if (accFile.exists() || new java.io.File(getFilesDir(), "account.txt").exists()) {
            Button forget = new Button(this);
            forget.setText("Forget all saved accounts");
            forget.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { rt4.SavedAccount.forgetAll(getFilesDir()); recreate(); }
            });
            root.addView(forget);
        }
        final java.io.File dumpFile = new java.io.File(getFilesDir(), "layout.txt");
        if (dumpFile.exists()) {
            Button copy = new Button(this);
            copy.setText("Copy layout dump");
            copy.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    try {
                        java.io.FileInputStream in = new java.io.FileInputStream(dumpFile);
                        byte[] b = new byte[(int) dumpFile.length()];
                        int n = in.read(b); in.close();
                        android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("layout", new String(b, 0, Math.max(n, 0), "UTF-8")));
                        android.widget.Toast.makeText(LauncherActivity.this, "Copied. Paste it to Claude.", android.widget.Toast.LENGTH_LONG).show();
                    } catch (Throwable t) {
                        android.widget.Toast.makeText(LauncherActivity.this, "Copy failed", android.widget.Toast.LENGTH_LONG).show();
                    }
                }
            });
            root.addView(copy);
        }
        root.addView(text("Rainbow Scape", 26, Color.rgb(255, 176, 0), true));
        root.addView(text("RuneScape build 4530 client for Android. The first launch downloads the game cache from the server, so use Wi-Fi.", 14, Color.LTGRAY, false));

        host = field(root, "Server address", s.host, InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        serverPort = field(root, "Game port", String.valueOf(s.serverPort), InputType.TYPE_CLASS_NUMBER);
        wlPort = field(root, "World list port", String.valueOf(s.worldListPort), InputType.TYPE_CLASS_NUMBER);
        js5Port = field(root, "Cache (JS5) port", String.valueOf(s.js5Port), InputType.TYPE_CLASS_NUMBER);
        world = field(root, "World", String.valueOf(s.world), InputType.TYPE_CLASS_NUMBER);

        root.addView(text("UI size", 14, Color.LTGRAY, false));
        scale = new Spinner(this);
        scale.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, SCALE_LABELS));
        int sel = 4;
        for (int i = 0; i < SCALE_VALUES.length; i++) {
            if (Math.abs(SCALE_VALUES[i] - s.renderScale) < 0.01f) sel = i;
        }
        scale.setSelection(sel);
        root.addView(scale);

        portrait = new CheckBox(this);
        portrait.setText("Portrait mode");
        portrait.setTextColor(Color.WHITE);
        portrait.setChecked(s.portrait);
        root.addView(portrait);

        smooth = new CheckBox(this);
        smooth.setText("Anti-aliasing (smooth edges)");
        smooth.setTextColor(Color.WHITE);
        smooth.setChecked(Settings.smoothEdges);
        root.addView(smooth);

        shade = new CheckBox(this);
        shade.setText("Soft shading (depth + vignette)");
        shade.setTextColor(Color.WHITE);
        shade.setChecked(Settings.softShading);
        root.addView(shade);

        gpu = new CheckBox(this);
        gpu.setText("GPU renderer (experimental, may show black screen)");
        gpu.setTextColor(Color.WHITE);
        gpu.setChecked(Settings.gpuMode);
        root.addView(gpu);

        fps = new CheckBox(this);
        fps.setText("Show FPS counter");
        fps.setTextColor(Color.WHITE);
        fps.setChecked(Settings.showFps);
        root.addView(fps);

        sway = new CheckBox(this);
        sway.setText("Swaying trees and plants (GPU)");
        sway.setTextColor(Color.WHITE);
        sway.setChecked(rt4.FxConfig.sway);
        root.addView(sway);
        softCb = new CheckBox(this); softCb.setText("Soft shadows (slower)"); softCb.setTextColor(Color.WHITE); softCb.setChecked(rt4.FxConfig.softShadows); root.addView(softCb);
        msaaCb = new CheckBox(this); msaaCb.setText("4x anti-aliasing (slower)"); msaaCb.setTextColor(Color.WHITE); msaaCb.setChecked(Settings.msaa); root.addView(msaaCb);
        bloomCb = new CheckBox(this); bloomCb.setText("Bloom glow (GPU)"); bloomCb.setTextColor(Color.WHITE); bloomCb.setChecked(rt4.FxConfig.bloom); root.addView(bloomCb);
        dofCb = new CheckBox(this); dofCb.setText("Tilt-shift blur (GPU)"); dofCb.setTextColor(Color.WHITE); dofCb.setChecked(rt4.FxConfig.dof); root.addView(dofCb);
        vigCb = new CheckBox(this); vigCb.setText("Vignette (GPU)"); vigCb.setTextColor(Color.WHITE); vigCb.setChecked(rt4.FxConfig.vignette); root.addView(vigCb);
        skyCb = new CheckBox(this); skyCb.setText("Skybox: sun, moon, stars, clouds (GPU, needs Time of day)"); skyCb.setTextColor(Color.WHITE); skyCb.setChecked(rt4.FxConfig.skybox); root.addView(skyCb);
        ambCb = new CheckBox(this); ambCb.setText("Light pools + fireflies (GPU, needs Time of day)"); ambCb.setTextColor(Color.WHITE); ambCb.setChecked(rt4.FxConfig.ambient); root.addView(ambCb);
        weatherSp = new Spinner(this);
        weatherSp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, Settings.WEATHERS));
        weatherSp.setSelection(rt4.FxConfig.weather);
        root.addView(weatherSp);

        root.addView(text("Color look (GPU)", 14, Color.LTGRAY, false));
        look = new Spinner(this);
        look.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, Settings.LOOKS));
        look.setSelection(rt4.FxConfig.look);
        root.addView(look);
        root.addView(text("Time of day (GPU)", 14, Color.LTGRAY, false));
        todSp = new Spinner(this);
        todSp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, Settings.TODS));
        todSp.setSelection(rt4.FxConfig.tod);
        root.addView(todSp);

        Button play = new Button(this);
        play.setText("Play");
        play.setTextSize(20);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = pad;
        play.setLayoutParams(lp);
        play.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { save(); startActivity(new Intent(LauncherActivity.this, GameActivity.class)); }
        });
        root.addView(play);

        Button gpuTest = new Button(this);
        gpuTest.setText("GPU test (shows what your phone supports)");
        gpuTest.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(LauncherActivity.this, GpuProbeActivity.class)); }
        });
        root.addView(gpuTest);

        Button gl4esTest = new Button(this);
        gl4esTest.setText("GL4ES test (old OpenGL on your phone)");
        gl4esTest.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(LauncherActivity.this, Gl4esTestActivity.class)); }
        });
        root.addView(gl4esTest);

        final Button export = new Button(this);
        export.setText("Export cache to Download folder");
        export.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                export.setEnabled(false);
                export.setText("Exporting…");
                new Thread(new Runnable() {
                    @Override public void run() {
                        final String r = CacheExport.export(LauncherActivity.this);
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                export.setEnabled(true);
                                export.setText("Export cache to Download folder");
                                new android.app.AlertDialog.Builder(LauncherActivity.this).setMessage(r).setPositiveButton("OK", null).show();
                            }
                        });
                    }
                }).start();
            }
        });
        root.addView(export);

        Button reset = new Button(this);
        reset.setText("Reset server to default");
        reset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                host.setText(Settings.DEFAULT_HOST);
                serverPort.setText("43594");
                wlPort.setText("43595");
                js5Port.setText("43595");
                world.setText("1");
            }
        });
        root.addView(reset);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.rgb(24, 20, 14));
        sv.addView(root);
        setContentView(sv);
    }

    private TextView text(String t, int sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setPadding(0, 8, 0, 8);
        if (bold) tv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        tv.setGravity(Gravity.START);
        return tv;
    }

    private EditText field(LinearLayout parent, String label, String value, int inputType) {
        parent.addView(text(label, 14, Color.LTGRAY, false));
        EditText e = new EditText(this);
        e.setText(value);
        e.setInputType(inputType);
        e.setTextColor(Color.WHITE);
        e.setSingleLine(true);
        parent.addView(e);
        return e;
    }

    private static int num(EditText e, int fallback) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (Exception ex) { return fallback; }
    }

    private void save() {
        SharedPreferences.Editor ed = getSharedPreferences(Settings.PREFS, Context.MODE_PRIVATE).edit();
        String h = host.getText().toString().trim();
        ed.putString("host", h.isEmpty() ? Settings.DEFAULT_HOST : h);
        ed.putInt("serverPort", num(serverPort, 43594));
        ed.putInt("wlPort", num(wlPort, 43595));
        ed.putInt("js5Port", num(js5Port, 43595));
        ed.putInt("world", num(world, 1));
        ed.putFloat("scale2", SCALE_VALUES[Math.max(0, Math.min(SCALE_VALUES.length - 1, scale.getSelectedItemPosition()))]);
        ed.putBoolean("portrait", portrait.isChecked());
        ed.putBoolean("smooth", smooth.isChecked());
        ed.putBoolean("shade", shade.isChecked());
        ed.putBoolean("gpu", gpu.isChecked());
        ed.putBoolean("fps", fps.isChecked());
        ed.putBoolean("sway", sway.isChecked());
        ed.putBoolean("softshadow", softCb.isChecked());
        ed.putBoolean("msaa", msaaCb.isChecked());
        ed.putBoolean("bloom", bloomCb.isChecked());
        ed.putBoolean("dof", dofCb.isChecked());
        ed.putBoolean("vignette", vigCb.isChecked());
        ed.putBoolean("skybox", skyCb.isChecked());
        ed.putBoolean("ambient", ambCb.isChecked());
        ed.putInt("weather", weatherSp.getSelectedItemPosition());
        ed.putInt("look", look.getSelectedItemPosition());
        ed.putInt("tod", todSp.getSelectedItemPosition());
        ed.apply();
    }
}
