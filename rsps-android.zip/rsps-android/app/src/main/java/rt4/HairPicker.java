package rt4;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Rainbow Scape hair picker, game-thread side.
 *
 * The server (CharStudio "hairpick") sends the hair list as hidden chat lines:
 *   ~hp~S|iface|gender|count|prevComp|rowComp     start of a list
 *   ~hp~E|idx,kit,hit,C:Name;idx,kit,hit,C:Name   styles (C = S short, M medium, L long, U up-do, A anime)
 *   ~hp~C|comp,colourIndex;...                    hair colour swatches
 *   ~hp~D                                         end of list
 * The app draws the picker; this class renders the head previews with the game's own model renderer
 * (on the game thread) and sends the taps back as ordinary Studio button clicks.
 */
public final class HairPicker {
    private HairPicker() {}

    public static final String TAG = "~hp~";

    public static final class Entry {
        public final int idx, kit, hit;
        public final char cat;
        public final String name;
        public Entry(int idx, int kit, int hit, char cat, String name) { this.idx = idx; this.kit = kit; this.hit = hit; this.cat = cat; this.name = name; }
    }

    // ---- published to the app (read on the UI thread)
    public static volatile Entry[] entries = new Entry[0];
    public static volatile int listGender = -1;          // 0 male, 1 female
    public static volatile int listVersion = 0;
    public static volatile int[] colourHit = new int[0];
    public static volatile int[] colourIdx = new int[0];
    public static volatile int[] colourRgb = new int[0];
    public static volatile int curKit = -1;              // hair kit the character has right now
    public static volatile int curColour = -1;           // hair colour index right now
    public static volatile int curGender = -1;
    /** where the "Browse" button goes, in game-canvas pixels; pillW == 0 means hidden */
    public static volatile int pillX, pillY, pillW, pillH;
    /** set by the app while the picker is on screen */
    public static volatile boolean pickerOpen;

    // ---- thumbnails: the app asks, the game thread renders
    public static final int THUMB = 224;                 // output size (rendered at 2x, then smoothed down)
    public static final ConcurrentHashMap<String, int[]> thumbs = new ConcurrentHashMap<String, int[]>();
    private static final ConcurrentLinkedQueue<Integer> wanted = new ConcurrentLinkedQueue<Integer>();
    private static final ConcurrentHashMap<Integer, Boolean> wantedSet = new ConcurrentHashMap<Integer, Boolean>();
    private static final ConcurrentLinkedQueue<Integer> clicks = new ConcurrentLinkedQueue<Integer>();

    // ---- big preview (head and shoulders, spins)
    public static volatile int bigKit = -1, bigYaw = 0, bigW = 300, bigH = 360;
    public static volatile int[] bigPixels;
    public static volatile int bigPixW, bigPixH;
    public static volatile int bigSeq;
    private static String bigKey = "";

    // ---- building a list
    private static int buildGender, buildIface;
    private static final java.util.ArrayList<Entry> building = new java.util.ArrayList<Entry>();
    private static int[] bHit = new int[0], bIdx = new int[0];
    private static int prevComp = -1, rowComp = -1, iface = -1;
    private static long lastAsk;
    private static int asks;
    private static boolean wasOpen;

    /** key for a thumbnail in the current colours */
    public static String key(int kit) { return kit + ":" + looksKey; }
    private static volatile String looksKey = "";

    public static void want(int kit) {
        if (wantedSet.putIfAbsent(kit, Boolean.TRUE) == null) wanted.add(kit);
    }

    public static void click(int componentId) { clicks.add(componentId); }

    // ------------------------------------------------------------------ chat lines
    /** true if the line was a picker line (never shown in chat). Game thread. */
    public static boolean handle(JagString msg) {
        if (msg == null) return false;
        String s = msg.toString();
        if (!s.startsWith(TAG)) return false;
        try {
            String body = s.substring(TAG.length());
            char t = body.charAt(0);
            String rest = body.length() > 2 ? body.substring(2) : "";
            if (t == 'S') {
                String[] p = rest.split("\\|");
                buildIface = Integer.parseInt(p[0].trim());
                buildGender = Integer.parseInt(p[1].trim());
                if (p.length > 3) prevComp = Integer.parseInt(p[3].trim());
                if (p.length > 4) rowComp = Integer.parseInt(p[4].trim());
                building.clear();
                bHit = new int[0]; bIdx = new int[0];
            } else if (t == 'E') {
                for (String e : rest.split(";")) {
                    String[] f = e.split(",", 4);
                    if (f.length < 4) continue;
                    String cn = f[3];
                    char cat = cn.length() > 1 && cn.charAt(1) == ':' ? cn.charAt(0) : 'M';
                    String name = cn.length() > 1 && cn.charAt(1) == ':' ? cn.substring(2) : cn;
                    building.add(new Entry(Integer.parseInt(f[0].trim()), Integer.parseInt(f[1].trim()), (buildIface << 16) | Integer.parseInt(f[2].trim()), cat, name));
                }
            } else if (t == 'C') {
                String[] parts = rest.split(";");
                int[] h = new int[parts.length], ix = new int[parts.length];
                int n = 0;
                for (String e : parts) {
                    String[] f = e.split(",");
                    if (f.length < 2) continue;
                    h[n] = (buildIface << 16) | Integer.parseInt(f[0].trim());
                    ix[n] = Integer.parseInt(f[1].trim());
                    n++;
                }
                // colours may come over several lines: add to what we have
                int o = bHit.length;
                bHit = java.util.Arrays.copyOf(bHit, o + n); bIdx = java.util.Arrays.copyOf(bIdx, o + n);
                System.arraycopy(h, 0, bHit, o, n); System.arraycopy(ix, 0, bIdx, o, n);
            } else if (t == 'D') {
                int[] rgb = new int[bIdx.length];
                for (int i = 0; i < bIdx.length; i++) rgb[i] = hairRgb(bIdx[i]);
                iface = buildIface;
                colourHit = bHit; colourIdx = bIdx; colourRgb = rgb;
                entries = building.toArray(new Entry[0]);
                listGender = buildGender;
                listVersion++;
            }
        } catch (RuntimeException ignored) {
        }
        return true;
    }

    private static int hairRgb(int idx) {
        try {
            short[] d = PlayerAppearance.destinationBodyColors[0];
            if (idx < 0 || idx >= d.length) return 0x808080;
            return Rasteriser.palette[d[idx] & 0xFFFF] & 0xFFFFFF;
        } catch (RuntimeException e) {
            return 0x808080;
        }
    }

    // ------------------------------------------------------------------ every frame (game thread)
    public static void tick() {
        try {
            tick0();
        } catch (Throwable ignored) {
        }
    }

    private static void tick0() {
        boolean open = MobileLayout.studioOpen;
        if (!open) {
            if (wasOpen) {
                wasOpen = false;
                entries = new Entry[0];
                listGender = -1;
                listVersion++;
                pillW = 0;
                asks = 0;
                clicks.clear();
            }
            return;
        }
        wasOpen = true;
        Player me = PlayerList.self;
        PlayerAppearance a = me == null ? null : me.appearance;
        if (a == null) return;
        int gender = a.gender ? 1 : 0;
        curGender = gender;
        int[] idk = a.studioIdentikit();
        int[] cols = a.studioColors();
        int hair = -1, beard = -1;
        if (idk != null) {
            for (int slot : idk) {
                if ((slot & Integer.MIN_VALUE) == 0 || (slot & 0x40000000) != 0) continue;
                IdkType t = IdkTypeList.get(slot & 0x3FFFFFFF);
                if (t == null) continue;
                if (t.feature == 0 || t.feature == 7) hair = slot & 0x3FFFFFFF;
                else if (t.feature == 1 || t.feature == 8) beard = slot & 0x3FFFFFFF;
            }
        }
        curKit = hair;
        curColour = cols == null ? -1 : cols[0];
        String lk = gender + ":" + (cols == null ? 0 : cols[0]) + ":" + (cols == null ? 0 : cols[4]) + ":" + beard + ":" + extrasKey(a.extraKits);
        if (!lk.equals(looksKey)) {
            looksKey = lk;
            // new colours: the app keeps showing its old pictures until the new ones are drawn
            wantedSet.clear();
            wanted.clear();
            thumbs.clear();
        }

        // ask the server for the list when it's missing or for the other gender
        long now = System.currentTimeMillis();
        if (listGender != gender && asks < 3 && now - lastAsk > 2500 && client.gameState == 30) {
            lastAsk = now;
            asks++;
            sendCommand("hairpick");
        }

        // taps from the app
        Integer c;
        int sent = 0;
        while ((c = clicks.poll()) != null && sent < 4) {
            Protocol.outboundBuffer.p1isaac(10);
            Protocol.outboundBuffer.p4(c);
            sent++;
        }

        placePill();

        // render: the big preview first (it's what you look at), then a few thumbnails
        long t0 = System.nanoTime();
        if (pickerOpen && bigKit >= 0) {
            String bk = bigKit + ":" + bigYaw + ":" + bigW + "x" + bigH + ":" + looksKey + ":" + torsoKey(idk);
            if (!bk.equals(bigKey)) {
                int[] px = renderBig(bigKit, beard, idk, cols, a.extraKits, bigYaw, bigW, bigH);
                if (px != null) {
                    bigKey = bk;
                    bigPixW = bigW; bigPixH = bigH;
                    bigPixels = px;
                    bigSeq++;
                }
            }
        }
        if (!pickerOpen) return;
        Integer k;
        int done = 0;
        java.util.ArrayList<Integer> later = null;
        while (done < 3 && System.nanoTime() - t0 < 9_000_000L && (k = wanted.poll()) != null) {
            String key = k + ":" + looksKey;
            if (thumbs.containsKey(key)) { continue; }
            int[] px = renderThumb(k, beard, cols, a.extraKits);
            if (px == null) {
                if (later == null) later = new java.util.ArrayList<Integer>();
                later.add(k);   // models still downloading; try again next frame
                continue;
            }
            thumbs.put(key, px);
            done++;
        }
        if (later != null) wanted.addAll(later);
    }

    private static String extrasKey(int[] e) {
        if (e == null || e.length == 0) return "-";
        StringBuilder b = new StringBuilder();
        for (int x : e) b.append(x).append('.');
        return b.toString();
    }

    private static String torsoKey(int[] idk) {
        if (idk == null) return "";
        StringBuilder b = new StringBuilder();
        for (int x : idk) b.append(x).append('.');
        return b.toString();
    }

    private static void sendCommand(String cmd) {
        JagString line = JagString.parse("::" + cmd);
        Protocol.outboundBuffer.p1isaac(ClientProt.CLIENT_CHEAT);
        Protocol.outboundBuffer.p1(line.length() - 1);
        Protocol.outboundBuffer.pjstr(line.substring(2));
    }

    /** the Browse button covers the "HAIR" label: from the left of the hair row to just before its "<" button */
    private static void placePill() {
        if (iface < 0 || prevComp < 0 || rowComp < 0 || entries.length == 0) { pillW = 0; return; }
        Component prev = InterfaceList.getComponent((iface << 16) | prevComp);
        Component row = InterfaceList.getComponent((iface << 16) | rowComp);
        if (prev == null || row == null || !shown(prev) || !shown(row)) { pillW = 0; return; }
        int[] pa = abs(prev), ra = abs(row);
        if (pa == null || ra == null) { pillW = 0; return; }
        int pad = Math.max(2, prev.height / 10);
        int x0 = ra[0] + pad, x1 = pa[0] - pad;
        if (x1 - x0 < 20) { pillW = 0; return; }
        pillX = x0; pillY = pa[1]; pillW = x1 - x0; pillH = prev.height;
    }

    private static boolean shown(Component c) {
        for (int i = 0; c != null && i < 32; i++) {
            if (c.hidden) return false;
            if (c.overlayer == -1) return true;
            c = InterfaceList.getComponent(c.overlayer);
        }
        return c == null;
    }

    private static int[] abs(Component c) {
        int x = 0, y = 0;
        for (int i = 0; c != null && i < 32; i++) {
            x += c.x; y += c.y;
            if (c.overlayer == -1) return new int[] {x, y};
            Component p = InterfaceList.getComponent(c.overlayer);
            if (p == null) return new int[] {x, y};
            x -= p.scrollX; y -= p.scrollY;
            c = p;
        }
        return null;
    }

    // ------------------------------------------------------------------ rendering
    private static RawModel combine(int[] kits, int[] cols) {
        RawModel[] ms = new RawModel[kits.length];
        int n = 0;
        for (int id : kits) {
            if (id < 0) continue;
            IdkType t = IdkTypeList.get(id);
            if (t == null) continue;
            if (!t.isBodyModelReady()) return null;
            RawModel m = t.getBodyModel();
            if (m != null) ms[n++] = m;
        }
        if (n == 0) return null;
        RawModel combined = new RawModel(ms, n);
        if (cols != null) {
            for (int s = 0; s < 5 && s < cols.length; s++) {
                if (PlayerAppearance.destinationBodyColors[s].length > cols[s]) combined.recolor(PlayerAppearance.sourceBodyColors[s], PlayerAppearance.destinationBodyColors[s][cols[s]]);
                if (PlayerAppearance.destinationSkinColors[s].length > cols[s]) combined.recolor(PlayerAppearance.sourceSkinColors[s], PlayerAppearance.destinationSkinColors[s][cols[s]]);
            }
        }
        return combined;
    }

    private static int[] withExtras(int[] base, int[] extras) {
        if (extras == null || extras.length == 0) return base;
        int[] out = java.util.Arrays.copyOf(base, base.length + extras.length);
        int n = base.length;
        for (int e : extras) {
            IdkType t = IdkTypeList.get(e);
            if (t != null && t.feature != 98) out[n++] = e;   // rainbow extras cycle colour; leave them out of still pictures
        }
        return java.util.Arrays.copyOf(out, n);
    }

    private static int[] renderThumb(int kit, int beard, int[] cols, int[] extras) {
        RawModel m = combine(withExtras(new int[] {kit, beard}, extras), cols);
        if (m == null) return null;
        int S = 2, W = THUMB * S, H = THUMB * S;
        // head centre about 176 units above the feet; show about 66 units around it
        int[] px = draw(m, W, H, 210, 72, 0, -180, 25);
        return px == null ? null : down(px, W, H, S);
    }

    private static int[] renderBig(int kit, int beard, int[] idk, int[] cols, int[] extras, int yaw, int w, int h) {
        int torso = -1, arms = -1;
        if (idk != null) {
            for (int slot : idk) {
                if ((slot & Integer.MIN_VALUE) == 0 || (slot & 0x40000000) != 0) continue;
                IdkType t = IdkTypeList.get(slot & 0x3FFFFFFF);
                if (t == null) continue;
                if (t.feature == 2 || t.feature == 9) torso = slot & 0x3FFFFFFF;
                else if (t.feature == 3 || t.feature == 10) arms = slot & 0x3FFFFFFF;
            }
        }
        RawModel m = combine(withExtras(new int[] {kit, beard, torso, arms}, extras), cols);
        if (m == null) return null;
        int S = 2, W = w * S, H = h * S;
        int[] px = draw(m, W, H, yaw & 0x7FF, 60, 0, -166, 54);
        return px == null ? null : down(px, W, H, S);
    }

    /** renders with the game's software renderer into a private buffer, like inventory icons; half = units shown above/below the centre */
    public static int[] draw(RawModel raw, int W, int H, int yaw, int pitch, int cx, int cy, int half) {
        SoftwareModel model = new SoftwareModel(raw, 64, 850, -30, -50, -30);
        int[] savedPx = SoftwareRaster.pixels;
        int savedW = SoftwareRaster.width, savedH = SoftwareRaster.height;
        int[] clip = new int[4];
        SoftwareRaster.saveClip(clip);
        boolean jag = Rasteriser.jagged;
        int[] out = new int[W * H];
        try {
            SoftwareRaster.setSize(out, W, H);
            Rasteriser.prepare();
            Rasteriser.setBounds(W / 2, H / 2);
            Rasteriser.jagged = false;
            int zoom = Math.max(40, half * 512 / (H / 2));
            int s = MathUtils.sin[pitch] * zoom >> 16, c = MathUtils.cos[pitch] * zoom >> 16;
            model.setCamera(yaw, 0, pitch, -cx, s - cy, c, -1L);
        } catch (RuntimeException e) {
            out = null;
        } finally {
            SoftwareRaster.setSize(savedPx, savedW, savedH);
            SoftwareRaster.restoreClip(clip);
            Rasteriser.prepare();
            Rasteriser.jagged = jag;
        }
        return out;
    }

    /** S x S box filter down to the output size, with alpha (0 = empty) so edges are smooth */
    public static int[] down(int[] src, int W, int H, int S) {
        int w = W / S, h = H / S, n = S * S;
        int[] out = new int[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int r = 0, g = 0, b = 0, cnt = 0;
                for (int dy = 0; dy < S; dy++) {
                    int row = (y * S + dy) * W + x * S;
                    for (int dx = 0; dx < S; dx++) {
                        int p = src[row + dx];
                        if (p == 0) continue;
                        r += (p >> 16) & 0xFF; g += (p >> 8) & 0xFF; b += p & 0xFF; cnt++;
                    }
                }
                if (cnt == 0) continue;
                int al = cnt * 255 / n;
                out[y * w + x] = (al << 24) | ((r / cnt) << 16) | ((g / cnt) << 8) | (b / cnt);
            }
        }
        return out;
    }
}
