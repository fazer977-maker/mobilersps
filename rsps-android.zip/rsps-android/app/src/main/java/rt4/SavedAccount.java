package rt4;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/** Remembers the last successful login (app-private file) and signs in with it once per app start. */
public final class SavedAccount {
    private static String pendingUser, pendingPass;
    private static volatile String[] pendingRequest;
    private static volatile boolean rememberMe = true;

    private static File file() {
        String home = System.getProperty("clientHomeOverride");
        return home == null ? null : new File(home, "account.txt");
    }

    /** Called when a login attempt starts. */
    public static void attempt(JagString user, JagString pass) {
        pendingUser = user.toString();
        pendingPass = pass.toString();
    }

    /** Called when the server accepted the login. */
    public static void success() {
        File f = file();
        if (!rememberMe || f == null || pendingUser == null || pendingUser.isEmpty()) {
            return;
        }
        try {
            Files.write(f.toPath(), (pendingUser + "\n" + pendingPass + "\n").getBytes(StandardCharsets.ISO_8859_1));
        } catch (Throwable ignored) {
        }
    }

    /** Queue a login from the Android login screen; the client thread starts it. */
    public static void request(String user, String pass, boolean remember) {
        rememberMe = remember;
        if (!remember) {
            forget();
        }
        pendingRequest = new String[] {user, pass};
    }

    public static void forget() {
        File f = file();
        if (f != null) {
            f.delete();
        }
    }

    /** Called every frame on the client thread. */
    public static void tick() {
        String[] r = pendingRequest;
        if (r == null || client.gameState != 10) {
            return;
        }
        if (LoginManager.hopStep != 0 || LoginManager.step != 0 || CreateManager.step != 0 || WorldList.step != 0) {
            return;
        }
        pendingRequest = null;
        LoginManager.startLogin(JagString.of(r[0]), JagString.of(r[1]), 0);
    }
}
