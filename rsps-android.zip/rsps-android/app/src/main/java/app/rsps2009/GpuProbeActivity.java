package app.rsps2009;

import android.app.Activity;
import android.graphics.Color;
import android.opengl.EGL14;
import android.opengl.EGLDisplay;
import android.opengl.GLES20;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileWriter;
import javax.microedition.khronos.opengles.GL10;

/** Read-only GPU test: opens an OpenGL ES context, reports what the phone's GPU supports and how fast it runs a heavy shader. Changes nothing. */
public class GpuProbeActivity extends Activity {
    private GLSurfaceView gl;
    private TextView out;
    private final StringBuilder report = new StringBuilder();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(3);
        gl.setRenderer(new R());
        root.addView(gl, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        ScrollView sv = new ScrollView(this);
        out = new TextView(this);
        out.setTextColor(Color.WHITE);
        out.setBackgroundColor(0xCC000000);
        out.setTextSize(12);
        out.setPadding(24, 48, 24, 24);
        out.setText("Running GPU test...");
        sv.addView(out);
        root.addView(sv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }

    @Override protected void onPause() { super.onPause(); gl.onPause(); }
    @Override protected void onResume() { super.onResume(); gl.onResume(); }

    private void show(final String s) {
        runOnUiThread(new Runnable() { @Override public void run() { out.setText(s); } });
        try {
            FileWriter w = new FileWriter(new File(getFilesDir(), "gpuprobe.txt"));
            w.write(s);
            w.close();
        } catch (Throwable ignored) { }
    }

    private static String get(int name) { String s = GLES20.glGetString(name); return s == null ? "?" : s; }
    private static int geti(int name) { int[] v = new int[1]; GLES20.glGetIntegerv(name, v, 0); return v[0]; }

    private static boolean msaa4() {
        try {
            EGLDisplay d = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
            int[] ver = new int[2];
            if (!EGL14.eglInitialize(d, ver, 0, ver, 1)) return false;
            int[] attrs = {EGL14.EGL_RENDERABLE_TYPE, 0x40, EGL14.EGL_SAMPLE_BUFFERS, 1, EGL14.EGL_SAMPLES, 4, EGL14.EGL_NONE};
            android.opengl.EGLConfig[] cfg = new android.opengl.EGLConfig[1];
            int[] n = new int[1];
            boolean ok = EGL14.eglChooseConfig(d, attrs, 0, cfg, 0, 1, n, 0);
            return ok && n[0] > 0;
        } catch (Throwable t) { return false; }
    }

    private static int shader(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        return s;
    }

    private final class R implements GLSurfaceView.Renderer {
        int prog = -1, frames = 0, w = 1, h = 1;
        long start = 0;
        boolean done = false;

        @Override public void onSurfaceCreated(GL10 g, javax.microedition.khronos.egl.EGLConfig c) {
            StringBuilder sb = new StringBuilder();
            sb.append("GPU TEST\n\n");
            sb.append("Renderer: ").append(get(GLES20.GL_RENDERER)).append('\n');
            sb.append("Vendor:   ").append(get(GLES20.GL_VENDOR)).append('\n');
            sb.append("Version:  ").append(get(GLES20.GL_VERSION)).append('\n');
            sb.append("GLSL:     ").append(get(GLES20.GL_SHADING_LANGUAGE_VERSION)).append('\n');
            sb.append("Max texture size: ").append(geti(GLES20.GL_MAX_TEXTURE_SIZE)).append('\n');
            sb.append("Texture units (fragment): ").append(geti(GLES20.GL_MAX_TEXTURE_IMAGE_UNITS)).append('\n');
            sb.append("Vertex uniform vectors: ").append(geti(GLES20.GL_MAX_VERTEX_UNIFORM_VECTORS)).append('\n');
            sb.append("Fragment uniform vectors: ").append(geti(GLES20.GL_MAX_FRAGMENT_UNIFORM_VECTORS)).append('\n');
            sb.append("4x multisample anti-aliasing: ").append(msaa4() ? "YES" : "no").append('\n');
            String ext = get(GLES20.GL_EXTENSIONS);
            String[] want = {"GL_OES_texture_3D", "GL_EXT_texture_filter_anisotropic", "GL_OES_depth_texture", "GL_OES_packed_depth_stencil", "GL_OES_standard_derivatives", "GL_EXT_multisampled_render_to_texture", "GL_OES_element_index_uint", "GL_OES_vertex_array_object"};
            sb.append("\nExtensions:\n");
            for (String e : want) sb.append("  ").append(ext.contains(e) ? "yes  " : "no   ").append(e).append('\n');
            report.append(sb);
            prog = -1;
            try {
                String vs = "#version 300 es\nvoid main(){vec2 p=vec2((gl_VertexID<<1)&2,gl_VertexID&2);gl_Position=vec4(p*2.0-1.0,0.0,1.0);}";
                String fs = "#version 300 es\nprecision highp float;uniform float t;out vec4 o;void main(){vec2 p=gl_FragCoord.xy*0.001;float a=0.0;for(int i=0;i<48;i++){p=vec2(sin(p.y*3.1+t)+cos(p.x*2.3),cos(p.x*3.7-t)+sin(p.y*1.9));a+=dot(p,p)*0.01;}o=vec4(fract(a),fract(a*1.7),fract(a*2.3),1.0);}";
                int v = shader(GLES30.GL_VERTEX_SHADER, vs), f = shader(GLES30.GL_FRAGMENT_SHADER, fs);
                int p = GLES20.glCreateProgram();
                GLES20.glAttachShader(p, v); GLES20.glAttachShader(p, f); GLES20.glLinkProgram(p);
                int[] ok = new int[1]; GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0);
                prog = ok[0] == 1 ? p : -1;
            } catch (Throwable t) { prog = -1; }
            if (prog < 0) { report.append("\nShader test: could not compile a version 3.00 shader\n"); finish(false); }
            show(report.toString() + "\nRunning speed test (3 seconds)...");
        }

        @Override public void onSurfaceChanged(GL10 g, int width, int height) { w = width; h = height; GLES20.glViewport(0, 0, w, h); }

        @Override public void onDrawFrame(GL10 g) {
            if (done || prog < 0) return;
            if (start == 0) start = System.nanoTime();
            GLES20.glUseProgram(prog);
            GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "t"), (System.nanoTime() - start) / 1e9f);
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3);
            frames++;
            long el = System.nanoTime() - start;
            if (el > 3_000_000_000L) {
                report.append(String.format(java.util.Locale.US, "\nSpeed test: %.1f fps at %dx%d with a heavy shader\n", frames / (el / 1e9), w, h));
                finish(true);
            }
        }

        private void finish(boolean ok) {
            done = true;
            report.append(ok ? "\nRESULT: GPU path looks usable. Send a screenshot of this screen.\n" : "\nRESULT: GPU test failed. Send a screenshot of this screen.\n");
            show(report.toString());
        }
    }
}
