package shim.awt.event;

import shim.awt.AWTEvent;

public class WindowEvent extends AWTEvent {
    public static final int WINDOW_OPENED = 200, WINDOW_CLOSING = 201, WINDOW_CLOSED = 202;
    public WindowEvent(Object source, int id) { super(source, id); }
}
