package rt4;

/** Visual extras set from the launcher settings (read by the GPU renderer). */
public final class FxConfig {
	/** 0 off, 1 warm, 2 cool, 3 sunset, 4 moonlight */
	public static volatile int look = 0;
	public static volatile boolean sway = false;
	private FxConfig() {
	}
}
