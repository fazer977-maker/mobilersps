package app.rsps2009;

import android.content.Context;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

/** Transparent-to-touch surface that the GPU renderer draws into. */
public class GpuView extends SurfaceView implements SurfaceHolder.Callback {
    public volatile Surface surface;
    public GpuView(Context c) {
        super(c);
        setZOrderMediaOverlay(true);
        getHolder().addCallback(this);
        // OPAQUE layer: the game clears/blends with alpha 0, so a translucent surface would show whatever is behind it (gray).
        getHolder().setFormat(android.graphics.PixelFormat.RGBX_8888);
    }
    @Override public boolean onTouchEvent(android.view.MotionEvent e) { return false; }
    @Override public void surfaceCreated(SurfaceHolder h) { surface = h.getSurface(); }
    @Override public void surfaceChanged(SurfaceHolder h, int f, int w, int hh) { surface = h.getSurface(); }
    @Override public void surfaceDestroyed(SurfaceHolder h) { surface = null; }
}
