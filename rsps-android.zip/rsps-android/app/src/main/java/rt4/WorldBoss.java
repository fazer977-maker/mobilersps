package rt4;

/**
 * Rainbow Scape world boss (the Prismatic Dragon), game-thread side. Hidden chat lines from the server:
 *   ~wb~H|hp|max|secsLeft|helping|phase|inArena   the dragon is awake (sent every couple of seconds)
 *   ~wb~W|secs                                    it wakes in secs
 *   ~wb~E                                         nothing on
 *   ~wb~S|ms|power                                shake the screen (it roared)
 * The app's WorldBossView reads the state and draws the boss bar; tapping it calls join().
 * We say hello (::wbcheck) a few seconds after login so the server knows this app understands the lines.
 */
public final class WorldBoss {
    private WorldBoss() {}

    public static volatile int state;            // 0 none, 1 warning, 2 live
    public static volatile int hp, max, secs, helping, phase, version, roarVersion;
    public static volatile boolean inArena;
    public static volatile long updated, roarAt;
    private static volatile boolean joinWanted;

    private static long loginAt, lastHello, shakeUntil;
    private static int lastState = -1;
    private static boolean shaking;

    public static boolean handle(JagString message) {
        if (message == null) return false;
        String s = message.toString();
        if (!s.startsWith("~wb~")) return false;
        try {
            char t = s.length() > 4 ? s.charAt(4) : 'E';
            String[] p = s.length() > 6 ? s.substring(6).split("\\|") : new String[0];
            if (t == 'H') {
                hp = Integer.parseInt(p[0].trim()); max = Math.max(1, Integer.parseInt(p[1].trim()));
                secs = Integer.parseInt(p[2].trim()); helping = Integer.parseInt(p[3].trim());
                phase = Integer.parseInt(p[4].trim()); inArena = p.length > 5 && p[5].trim().equals("1");
                state = 2; updated = System.currentTimeMillis(); version++;
            } else if (t == 'W') {
                secs = Integer.parseInt(p[0].trim()); state = 1; updated = System.currentTimeMillis(); version++;
            } else if (t == 'S') {
                int ms = Integer.parseInt(p[0].trim()), power = p.length > 1 ? Integer.parseInt(p[1].trim()) : 2;
                shake(ms, power);
                roarAt = System.currentTimeMillis(); roarVersion++;
            } else {
                state = 0; version++;
            }
        } catch (Throwable ignored) { }
        return true;
    }

    /** the boss bar was tapped */
    public static void join() { joinWanted = true; }

    private static void shake(int ms, int power) {
        power = Math.max(1, Math.min(4, power));
        int[] axes = {0, 1, 2};
        for (int i : axes) {
            Camera.cameraJitter[i] = power * 2;
            Camera.cameraAmplitude[i] = power * 7;
            Camera.cameraFrequency[i] = 55 + 10 * i;
            Camera.customCameraActive[i] = true;
        }
        shaking = true;
        shakeUntil = System.currentTimeMillis() + Math.max(200, Math.min(4000, ms));
    }

    /** game thread, every frame */
    public static void tick() {
        try {
            long now = System.currentTimeMillis();
            if (shaking && now > shakeUntil) {
                shaking = false;
                for (int i = 0; i < 3; i++) { Camera.customCameraActive[i] = false; Camera.cameraAmplitude[i] = 0; Camera.cameraJitter[i] = 0; }
            }
            int st = client.gameState;
            if (st == 30 && lastState != 30) { loginAt = now; lastHello = 0; state = 0; }
            lastState = st;
            if (st != 30) return;
            if ((lastHello == 0 && now - loginAt > 8000) || (lastHello > 0 && now - lastHello > 300_000)) { lastHello = now; send("wbcheck"); }
            if (state == 2 && now - updated > 20_000) state = 0;           // lost the updates: hide the bar
            if (joinWanted) { joinWanted = false; send("wbtp"); }
        } catch (Throwable ignored) { }
    }

    private static void send(String cmd) {
        JagString line = JagString.parse("::" + cmd);
        Protocol.outboundBuffer.p1isaac(ClientProt.CLIENT_CHEAT);
        Protocol.outboundBuffer.p1(line.length() - 1);
        Protocol.outboundBuffer.pjstr(line.substring(2));
    }
}
