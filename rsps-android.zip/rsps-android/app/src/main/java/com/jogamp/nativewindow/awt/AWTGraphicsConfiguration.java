package com.jogamp.nativewindow.awt;
public class AWTGraphicsConfiguration { }
