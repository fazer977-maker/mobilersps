package rt4;

/**
 * Rearranges the stock resizable top-level interface (746) into a phone layout:
 * chat at the top-left, tab icons in a column down each edge, tab panel beside the right column.
 * Runs every frame after layout, so script-driven re-layouts are simply overridden again.
 */
public final class MobileLayout {
    public static boolean enabled = true;

    // stone component indexes (layer 25). overlay = +15 (layer 40), icon = +30 (layer 55)
    private static final int[] RIGHT = {29, 30, 27, 28, 31, 32, 26}; // inventory, equipment, skills, quests, prayer, magic, combat
    private static final int[] LEFT = {34, 35, 36, 37, 38, 39, 33};  // friends, ignores, clan, settings, emotes, music, extra

    private static boolean captured;
    private static final int[] ovDx = new int[70], ovDy = new int[70], icDx = new int[70], icDy = new int[70];

    private MobileLayout() {}

    public static void apply() {
        if (!enabled || InterfaceList.topLevelInterface != 746) {
            return;
        }
        Component[][] all = InterfaceList.components;
        if (all == null || all.length <= 746 || all[746] == null || all[746].length < 111) {
            return;
        }
        Component[] c = all[746];
        if (c[24] == null || c[25] == null || c[40] == null || c[55] == null || c[23] == null || c[70] == null || c[73] == null) {
            return;
        }
        final int w = GameShell.canvasWidth;
        final int h = GameShell.canvasHeight;
        if (w <= 0 || h <= 0) {
            return;
        }

        if (!captured) {
            for (int s = 26; s <= 39; s++) {
                Component st = c[s], ov = c[s + 15], ic = c[s + 30];
                if (st == null || ov == null || ic == null) {
                    return;
                }
                ovDx[s] = ov.x - st.x;
                ovDy[s] = ov.y - st.y;
                icDx[s] = ic.x - st.x;
                icDy[s] = ic.y - st.y;
            }
            captured = true;
        }

        // chat: tab buttons on top, chat box below, overlay under that
        set(c[23], 0, 0);
        set(c[70], 0, 23);
        if (c[71] != null) set(c[71], 9, 165);
        if (c[72] != null) set(c[72], 9, 165);

        // tab containers become full-screen so children can use screen coordinates
        for (int id : new int[] {24, 25, 40, 55}) {
            c[id].x = 0;
            c[id].y = 0;
            c[id].width = w;
            c[id].height = h;
        }

        int top = 190;
        int pitch = Math.max(30, Math.min(54, (h - top - 6) / 7));
        place(c, RIGHT, w - 33 - 6, top, pitch);
        place(c, LEFT, 6, top, pitch);

        // opened tab panel sits to the left of the right column
        c[73].x = Math.max(0, w - 33 - 6 - 8 - c[73].width);
        c[73].y = Math.max(0, h - c[73].height - 6);
    }

    private static void set(Component comp, int x, int y) {
        comp.x = x;
        comp.y = y;
    }

    private static void place(Component[] c, int[] slots, int x, int top, int pitch) {
        for (int i = 0; i < slots.length; i++) {
            int s = slots[i];
            int y = top + i * pitch;
            c[s].x = x;
            c[s].y = y;
            c[s + 15].x = x + ovDx[s];
            c[s + 15].y = y + ovDy[s];
            c[s + 30].x = x + icDx[s];
            c[s + 30].y = y + icDy[s];
        }
    }
}
