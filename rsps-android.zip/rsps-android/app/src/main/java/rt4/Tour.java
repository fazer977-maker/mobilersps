package rt4;

/**
 * Rainbow Scape intro cutscene, game-thread side.
 *
 * The app asks with ::tourcheck (after the Character Studio closes, and once after logging in); if the server
 * has a tour waiting for this player (a brand-new character, or ::tour) it answers with hidden chat lines:
 *   ~cs~B|count                   begin
 *   ~cs~S|i|x|y|plane             scene i looks at this world tile
 *   ~cs~H|i|title                 its title
 *   ~cs~T|i|text                  its text (several lines are joined)
 *   ~cs~G                         play
 * While it plays the game's camera glides around each spot; the app draws the black bars and the captions,
 * and moves on with Next / Skip.
 */
public final class Tour {
    private Tour() {}

    public static final String TAG = "~cs~";

    public static final class Scene {
        public int x, y, plane;
        public String title = "", text = "";
    }

    /** published to the app */
    public static volatile Scene[] scenes = new Scene[0];
    public static volatile boolean playing;
    public static volatile int index;
    public static volatile int version;
    private static volatile boolean stopAsked;

    private static Scene[] building = new Scene[0];
    private static boolean wasStudio;
    private static long loginAt;
    private static boolean askedThisLogin;
    private static int lastState;

    // camera state
    private static int shownIndex = -1;
    private static long sceneStart;
    private static float fromX, fromY, fromZ, fromYaw, fromPitch;
    private static float curX, curY, curZ, curYaw, curPitch;

    // ------------------------------------------------------------------ app side calls (UI thread)
    public static void next() {
        if (!playing) return;
        if (index + 1 >= scenes.length) stop(); else index++;
    }

    public static void stop() { stopAsked = true; }

    // ------------------------------------------------------------------ chat lines (game thread)
    public static boolean handle(JagString msg) {
        if (msg == null) return false;
        String s = msg.toString();
        if (!s.startsWith(TAG)) return false;
        try {
            String body = s.substring(TAG.length());
            char t = body.charAt(0);
            String rest = body.length() > 2 ? body.substring(2) : "";
            if (t == 'B') {
                int n = Math.max(0, Math.min(40, Integer.parseInt(rest.trim())));
                building = new Scene[n];
                for (int i = 0; i < n; i++) building[i] = new Scene();
            } else if (t == 'S') {
                String[] p = rest.split("\\|");
                Scene sc = at(Integer.parseInt(p[0].trim()));
                if (sc != null) { sc.x = Integer.parseInt(p[1].trim()); sc.y = Integer.parseInt(p[2].trim()); sc.plane = Integer.parseInt(p[3].trim()); }
            } else if (t == 'H' || t == 'T') {
                int bar = rest.indexOf('|');
                Scene sc = at(Integer.parseInt(rest.substring(0, bar).trim()));
                String v = rest.substring(bar + 1);
                if (sc != null) {
                    if (t == 'H') sc.title = v;
                    else sc.text = sc.text.isEmpty() ? v : sc.text + " " + v;
                }
            } else if (t == 'G') {
                if (building.length > 0) {
                    scenes = building;
                    index = 0;
                    shownIndex = -1;
                    stopAsked = false;
                    playing = true;
                    version++;
                }
            }
        } catch (RuntimeException ignored) {
        }
        return true;
    }

    private static Scene at(int i) { return i >= 0 && i < building.length ? building[i] : null; }

    // ------------------------------------------------------------------ every frame (game thread)
    public static void tick() {
        try {
            tick0();
        } catch (Throwable t) {
            finish();
        }
    }

    private static void tick0() {
        int state = client.gameState;
        long now = System.currentTimeMillis();
        if (state == 30 && lastState != 30) { loginAt = now; askedThisLogin = false; }
        lastState = state;
        if (state != 30) { if (playing) finish(); return; }

        // ask whether a tour is waiting: once a few seconds after logging in, and every time the Studio closes
        boolean studio = MobileLayout.studioReal();
        if (wasStudio && !studio) ask();
        wasStudio = studio;
        if (!askedThisLogin && now - loginAt > 6000 && !studio) { askedThisLogin = true; ask(); }

        if (!playing) return;
        if (stopAsked) { finish(); return; }
        drive(now);
    }

    private static void ask() {
        JagString line = JagString.parse("::tourcheck");
        Protocol.outboundBuffer.p1isaac(ClientProt.CLIENT_CHEAT);
        Protocol.outboundBuffer.p1(line.length() - 1);
        Protocol.outboundBuffer.pjstr(line.substring(2));
    }

    private static void finish() {
        playing = false;
        stopAsked = false;
        shownIndex = -1;
        try { Camera.resetCameraEffects(); } catch (Throwable ignored) { }
    }

    private static float smooth(float t) {
        t = Math.max(0f, Math.min(1f, t));
        return t * t * (3f - 2f * t);
    }

    private static float angleLerp(float a, float b, float t) {
        float d = b - a;
        while (d > 1024) d -= 2048;
        while (d < -1024) d += 2048;
        return a + d * t;
    }

    private static int ground(int fx, int fy) {
        fx = Math.max(0, Math.min(103 * 128, fx));
        fy = Math.max(0, Math.min(103 * 128, fy));
        return SceneGraph.getTileHeight(Player.plane, fx, fy);
    }

    /** glide around the current spot; the first 2 seconds of each spot blend over from where the camera was */
    private static void drive(long now) {
        Scene[] ss = scenes;
        int i = Math.max(0, Math.min(ss.length - 1, index));
        Scene s = ss[i];
        if (shownIndex != i) {
            if (shownIndex == -1) {
                fromX = Camera.renderX; fromY = Camera.renderY; fromZ = Camera.renderZ;
                fromYaw = Camera.cameraYaw; fromPitch = Camera.cameraPitch;
            } else {
                fromX = curX; fromY = curY; fromZ = curZ; fromYaw = curYaw; fromPitch = curPitch;
            }
            shownIndex = i;
            sceneStart = now;
        }
        // the spot, in the loaded scene; if it is too far away, circle the player instead
        int lx = s.x - Camera.originX, ly = s.y - Camera.originY;
        if (lx < 1 || ly < 1 || lx > 102 || ly > 102 || s.plane != Player.plane) {
            lx = PlayerList.self.xFine >> 7;
            ly = PlayerList.self.yFine >> 7;
        }
        int tx = lx * 128 + 64, ty = ly * 128 + 64;
        int tz = ground(tx, ty) - 90;

        float t = (now - sceneStart) / 1000f;
        double ang = i * 1.1 + 0.6 + t * 0.10;          // a slow orbit, each spot from a new side
        float R = 1150f;
        float ox = tx + (float) Math.sin(ang) * R, oy = ty + (float) Math.cos(ang) * R;
        float oz = ground(Math.round(ox), Math.round(oy)) - 620;
        float dx = tx - ox, dy = ty - oy, dz = tz - oz;
        float horiz = (float) Math.sqrt(dx * dx + dy * dy);
        float pitch = (float) (Math.atan2(dz, horiz) * 325.949D);
        pitch = Math.max(128f, Math.min(383f, pitch));
        float yaw = (float) (((int) (-325.949D * Math.atan2(dx, dy))) & 0x7FF);

        float b = smooth(t / 2.0f);
        curX = fromX + (ox - fromX) * b;
        curY = fromY + (oy - fromY) * b;
        curZ = fromZ + (oz - fromZ) * b;
        curYaw = angleLerp(fromYaw, yaw, b);
        curPitch = fromPitch + (pitch - fromPitch) * b;

        // the game's "locked" camera, held still by us: no speed of its own, we move it every frame
        Camera.cameraType = 2;
        Camera.lockedMoveSpeed = 0;
        Camera.lockedMinMoveStep = 0;
        Camera.lockedAngleSpeed = 0;
        Camera.lockedMinStep = 0;
        Camera.lockedTargetX = lx;
        Camera.lockedTargetY = ly;
        Camera.lockedLookAtX = lx;
        Camera.lockedLookAtY = ly;
        Camera.renderX = Math.round(curX);
        Camera.renderY = Math.round(curY);
        Camera.renderZ = Math.round(curZ);
        Camera.cameraYaw = ((Math.round(curYaw) % 2048) + 2048) % 2048;
        Camera.cameraPitch = Math.round(curPitch);
    }
}
