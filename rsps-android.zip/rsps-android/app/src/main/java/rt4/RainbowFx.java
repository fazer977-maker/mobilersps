package rt4;

/**
 * Rainbow Scape particle system.
 * Players wearing the Rainbow cape shed sparks from the cape that fall under gravity and stay in the world
 * (so a trail is left behind when walking). The Halo gives a slow rising shimmer around the head.
 * Each particle is a tiny real 3D model added to the scene graph every frame, so walls, roofs and
 * characters hide it naturally (true depth), like the RS3 cape effects.
 */
public final class RainbowFx {

	/** item ids (must match the server) */
	public static final int CAPE_ID = 14670;
	public static final int HALO_ID = 14671;

	private static final int MAX = 500;
	private static final float[] px = new float[MAX], py = new float[MAX], ph = new float[MAX];
	private static final float[] vx = new float[MAX], vy = new float[MAX], vh = new float[MAX];
	private static final float[] age = new float[MAX], life = new float[MAX], hue = new float[MAX], grav = new float[MAX];
	private static final byte[] size = new byte[MAX];
	private static int count = 0;
	private static long last = 0L;
	private static float clock = 0.0F;
	private static final java.util.Random rnd = new java.util.Random();

	private static void spawn(float x, float y, float h, float dx, float dy, float dh, float g, float lifeSec, float hu, int sz) {
		if (count >= MAX) {
			return;
		}
		int i = count++;
		px[i] = x; py[i] = y; ph[i] = h;
		vx[i] = dx; vy[i] = dy; vh[i] = dh;
		grav[i] = g; age[i] = 0.0F; life[i] = lifeSec; hue[i] = hu; size[i] = (byte) sz;
	}

	private static void emit(Player p, float dt) {
		if (p.fxCape == CAPE_ID) {
			p.fxAcc += 70.0F * dt;
			int a = p.currentAngle & 0x7FF;
			float sin = MathUtils.sin[a] / 65536.0F, cos = MathUtils.cos[a] / 65536.0F;
			while (p.fxAcc >= 1.0F) {
				p.fxAcc -= 1.0F;
				// attached to the bottom hem of the cape (like the RS3 120 capes): along the hem edge, just above the ground
				float across = rnd.nextFloat() * 2.0F - 1.0F;
				float lx = across * 28.0F;
				float h = 3.0F + rnd.nextFloat() * 16.0F;
				float lz = 24.0F + rnd.nextFloat() * 12.0F - Math.abs(across) * 4.0F;
				float wx = p.xFine + lx * cos - lz * sin;
				float wy = p.yFine - lz * cos - lx * sin;
				float hu = across * 0.42F + 0.5F + clock * 0.3F;      // the rainbow runs along the hem and slowly rotates
				float dx = (rnd.nextFloat() - 0.5F) * 10.0F - sin * 8.0F;
				float dy = (rnd.nextFloat() - 0.5F) * 10.0F - cos * 8.0F;
				if (rnd.nextInt(100) < 55) {
					// soft glowing puff that hangs at the hem and fades
					spawn(wx, wy, h, dx, dy, 8.0F + rnd.nextFloat() * 18.0F, 45.0F, 0.6F + rnd.nextFloat() * 0.6F, hu, 3);
				} else {
					// bright spark that lifts off the hem, then falls
					spawn(wx, wy, h, dx, dy, 14.0F + rnd.nextFloat() * 36.0F, 190.0F + rnd.nextFloat() * 90.0F,
						0.8F + rnd.nextFloat() * 0.8F, hu, rnd.nextInt(4) == 0 ? 2 : 1);
				}
			}
		}
		if (p.fxHat == HALO_ID) {
			p.fxAcc += 16.0F * dt;
			while (p.fxAcc >= 1.0F) {
				p.fxAcc -= 1.0F;
				float ang = rnd.nextFloat() * 6.2831855F;
				float wx = p.xFine + 14.0F * (float) Math.cos(ang);
				float wy = p.yFine + 14.0F * (float) Math.sin(ang);
				spawn(wx, wy, 204.0F + rnd.nextFloat() * 8.0F, 0.0F, 0.0F, 10.0F + rnd.nextFloat() * 14.0F, -2.0F,
					0.8F + rnd.nextFloat() * 0.8F, ang / 6.2831855F + clock * 0.3F, 1);
			}
		}
	}


	// ---- 3D particle models: 12 hues x 3 size tiers, built lazily
	private static final int HUES = 12, TIERS = 3;
	private static final Model[] models = new Model[HUES * TIERS];
	private static final int[] tierR = {7, 4, 2};

	private static Model getModel(int hueIdx, int tier) {
		int k = hueIdx * TIERS + tier;
		Model m = models[k];
		if (m != null) {
			return m;
		}
		int r = tierR[tier];
		RawModel raw = new RawModel(6, 8, 0);
		int[][] v = {{r, 0, 0}, {-r, 0, 0}, {0, r, 0}, {0, -r, 0}, {0, 0, r}, {0, 0, -r}};
		for (int i = 0; i < 6; i++) {
			raw.vertexX[i] = v[i][0];
			raw.vertexY[i] = v[i][1];
			raw.vertexZ[i] = v[i][2];
		}
		raw.vertexCount = 6;
		int hue6 = (int) ((hueIdx / (float) HUES) * 60.0F) & 63;
		short col = (short) ((hue6 << 10) | (6 << 7) | 100);
		int[][] f = {{0, 2, 4}, {2, 1, 4}, {1, 3, 4}, {3, 0, 4}, {2, 0, 5}, {1, 2, 5}, {3, 1, 5}, {0, 3, 5}};
		byte alpha = (byte) (tier == 0 ? 90 : 40);
		for (int i = 0; i < 8; i++) {
			raw.addTriangle(f[i][0], f[i][1], f[i][2], col, alpha);
		}
		m = raw.createModel(180, 300, -50, -10, -50);
		models[k] = m;
		return m;
	}

	private static void render(int i) {
		float t = age[i] / life[i];
		int tier = t < 0.45F ? (size[i] >= 3 ? 0 : 1) : (t < 0.8F ? 1 : 2);
		if (size[i] == 1 && tier == 0) {
			tier = 1;
		}
		float hu = hue[i] + t * 0.15F;
		hu -= (float) Math.floor(hu);
		int hi = (int) (hu * HUES) % HUES;
		int x = (int) px[i], y = (int) py[i];
		if (x < 128 || y < 128 || x > 103 * 128 || y > 103 * 128) {
			return;
		}
		int z = SceneGraph.getTileHeight(Player.plane, x, y) - (int) ph[i];
		SceneGraph.add(Player.plane, x, y, z, 24, getModel(hi, tier), 0, -1L, false);
	}

	/** called once per frame while the scene is being built */
	public static void update() {
		long now = System.nanoTime();
		float dt = last == 0L ? 0.0F : (now - last) / 1.0E9F;
		last = now;
		if (dt > 0.1F) {
			dt = 0.1F;
		}
		clock += dt;
		try {
			Player self = PlayerList.self;
			if (self != null && self.isVisible()) {
				emit(self, dt);
			}
			for (int i = 0; i < PlayerList.size; i++) {
				Player p = PlayerList.players[PlayerList.ids[i]];
				if (p != null && p != self && p.isVisible()) {
					emit(p, dt);
				}
			}
		} catch (RuntimeException e) {
			// never let the effect break the game
		}
		for (int i = 0; i < count; ) {
			age[i] += dt;
			vh[i] -= grav[i] * dt;
			ph[i] += vh[i] * dt;
			px[i] += vx[i] * dt;
			py[i] += vy[i] * dt;
			if (age[i] >= life[i] || ph[i] < 0.0F) {
				count--;
				px[i] = px[count]; py[i] = py[count]; ph[i] = ph[count];
				vx[i] = vx[count]; vy[i] = vy[count]; vh[i] = vh[count];
				age[i] = age[count]; life[i] = life[count]; hue[i] = hue[count]; grav[i] = grav[count]; size[i] = size[count];
				continue;
			}
			try {
				render(i);
			} catch (RuntimeException e) {
			}
			i++;
		}
	}
}
