package shim.awt;

public class AWTEvent {
    protected Object source;
    protected int id;
    protected boolean consumed;
    public AWTEvent(Object source, int id) { this.source = source; this.id = id; }
    public Object getSource() { return source; }
    public int getID() { return id; }
    public void consume() { consumed = true; }
    public boolean isConsumed() { return consumed; }
}
