package com.jogamp.opengl;

public class GL {
    public GL2 getGL2() { return (GL2) this; }
}
