package app.rsps2009;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.view.SurfaceHolder;

import shim.platform.Platform;

/** Android implementation of the platform layer the client's AWT replacement talks to. */
public final class AndroidPlatform implements Platform {

    private final SurfaceHolder holder;
    private final String dataDir;
    private final float renderScale;
    private volatile int surfaceW, surfaceH;
    private volatile boolean surfaceValid;

    private Bitmap bitmap;
    private int bitmapW, bitmapH;
    private int[] scratch = new int[0];
    private final Paint blitPaint = new Paint();
    private final Rect dst = new Rect();

    public AndroidPlatform(SurfaceHolder holder, int surfaceW, int surfaceH, float renderScale, String dataDir) {
        this.holder = holder;
        this.surfaceW = surfaceW;
        this.surfaceH = surfaceH;
        this.renderScale = renderScale;
        this.dataDir = dataDir;
        this.surfaceValid = true;
        // Non-integer scales look better with filtering; integer scales stay crisp.
        blitPaint.setFilterBitmap(Math.abs(renderScale - Math.round(renderScale)) > 0.01f);
    }

    public void onSurfaceChanged(int w, int h) { surfaceW = w; surfaceH = h; }
    public void onSurfaceDestroyed() { surfaceValid = false; }
    public void onSurfaceCreated() { surfaceValid = true; }
    public float scale() { return renderScale; }

    // ------------------------------------------------------------------ display

    @Override
    public int viewWidth() { return Math.max(1, (int) (surfaceW / renderScale)); }

    @Override
    public int viewHeight() { return Math.max(1, (int) (surfaceH / renderScale)); }

    @Override
    public float renderScale() { return renderScale; }

    @Override
    public void setTitle(String title) { }

    @Override
    public synchronized void present(int[] pixels, int w, int h, int cx, int cy, int cw, int ch) {
        if (!surfaceValid || w <= 0 || h <= 0) {
            return;
        }
        if (bitmap == null || bitmapW != w || bitmapH != h) {
            bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            bitmapW = w;
            bitmapH = h;
            cx = 0; cy = 0; cw = w; ch = h;
        }
        // clamp the dirty rectangle
        if (cx < 0) { cw += cx; cx = 0; }
        if (cy < 0) { ch += cy; cy = 0; }
        if (cx + cw > w) { cw = w - cx; }
        if (cy + ch > h) { ch = h - cy; }
        if (cw > 0 && ch > 0) {
            int needed = cw * ch;
            if (scratch.length < needed) {
                scratch = new int[needed];
            }
            for (int row = 0; row < ch; row++) {
                int src = (cy + row) * w + cx;
                int out = row * cw;
                for (int col = 0; col < cw; col++) {
                    scratch[out + col] = pixels[src + col] | 0xFF000000;
                }
            }
            bitmap.setPixels(scratch, 0, cw, cx, cy, cw, ch);
        }
        Canvas canvas = null;
        try {
            canvas = holder.lockCanvas();
            if (canvas != null) {
                dst.set(0, 0, canvas.getWidth(), canvas.getHeight());
                canvas.drawBitmap(bitmap, null, dst, blitPaint);
            }
        } catch (Throwable ignored) {
        } finally {
            if (canvas != null) {
                try { holder.unlockCanvasAndPost(canvas); } catch (Throwable ignored) { }
            }
        }
    }

    // --------------------------------------------------------------------- text

    private static Paint paintFor(String font, int style, int size) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int tfStyle = (style & 1) != 0 ? ((style & 2) != 0 ? Typeface.BOLD_ITALIC : Typeface.BOLD)
                : ((style & 2) != 0 ? Typeface.ITALIC : Typeface.NORMAL);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, tfStyle));
        p.setTextSize(Math.max(1, size));
        return p;
    }

    @Override
    public int[] textMetrics(String font, int style, int size) {
        Paint.FontMetricsInt fm = paintFor(font, style, size).getFontMetricsInt();
        return new int[] { -fm.ascent, fm.descent, Math.max(0, fm.leading) };
    }

    @Override
    public int textWidth(String text, String font, int style, int size) {
        return (int) Math.ceil(paintFor(font, style, size).measureText(text));
    }

    @Override
    public void drawText(int[] dstPixels, int dw, int dh, String text, int x, int y, String font, int style, int size, int argb) {
        Paint p = paintFor(font, style, size);
        Paint.FontMetricsInt fm = p.getFontMetricsInt();
        int tw = (int) Math.ceil(p.measureText(text)) + 2;
        int th = fm.descent - fm.ascent + 2;
        if (tw <= 0 || th <= 0 || tw > 4096) {
            return;
        }
        Bitmap bm = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        p.setColor(argb | 0xFF000000);
        c.drawText(text, 1, 1 - fm.ascent, p);
        int[] px = new int[tw * th];
        bm.getPixels(px, 0, tw, 0, 0, tw, th);
        bm.recycle();
        int left = x - 1;
        int top = y + fm.ascent - 1;
        int r = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
        for (int row = 0; row < th; row++) {
            int dy = top + row;
            if (dy < 0 || dy >= dh) continue;
            for (int col = 0; col < tw; col++) {
                int dx = left + col;
                if (dx < 0 || dx >= dw) continue;
                int a = px[row * tw + col] >>> 24;
                if (a == 0) continue;
                int di = dy * dw + dx;
                if (a == 255) {
                    dstPixels[di] = 0xFF000000 | (r << 16) | (g << 8) | b;
                } else {
                    int d = dstPixels[di];
                    int rr = (r * a + ((d >> 16) & 255) * (255 - a)) / 255;
                    int gg = (g * a + ((d >> 8) & 255) * (255 - a)) / 255;
                    int bb = (b * a + (d & 255) * (255 - a)) / 255;
                    dstPixels[di] = 0xFF000000 | (rr << 16) | (gg << 8) | bb;
                }
            }
        }
    }

    // -------------------------------------------------------------------- audio

    @Override
    public AudioOut openAudio(int sampleRate, int channels, int bufferBytes) {
        try {
            int mask = channels >= 2 ? AudioFormat.CHANNEL_OUT_STEREO : AudioFormat.CHANNEL_OUT_MONO;
            int minBuf = AudioTrack.getMinBufferSize(sampleRate, mask, AudioFormat.ENCODING_PCM_16BIT);
            int size = Math.max(Math.max(bufferBytes, minBuf), 4096);
            AudioTrack track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(mask)
                            .build())
                    .setBufferSizeInBytes(size)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
            track.play();
            return new TrackOut(track, channels >= 2 ? 4 : 2);
        } catch (Throwable t) {
            return null;
        }
    }

    private static final class TrackOut implements AudioOut {
        private final AudioTrack track;
        private final int frameSize;
        private long written; // bytes handed to the track
        private long headBase; // playback head at the last flush
        TrackOut(AudioTrack track, int frameSize) { this.track = track; this.frameSize = frameSize; }

        @Override
        public synchronized int write(byte[] data, int off, int len) {
            int n = track.write(data, off, len, AudioTrack.WRITE_NON_BLOCKING);
            if (n > 0) written += n;
            return Math.max(n, 0);
        }

        @Override
        public synchronized int available() {
            long played = Math.max(0, (track.getPlaybackHeadPosition() & 0xFFFFFFFFL) - headBase) * frameSize;
            long capacity = (long) track.getBufferSizeInFrames() * frameSize;
            long buffered = Math.max(0, written - played);
            return (int) Math.max(0, capacity - buffered);
        }

        @Override
        public synchronized void flush() {
            try { track.pause(); track.flush(); track.play(); } catch (Throwable ignored) { }
            written = 0;
            headBase = track.getPlaybackHeadPosition() & 0xFFFFFFFFL;
        }

        @Override
        public synchronized void close() {
            try { track.stop(); } catch (Throwable ignored) { }
            try { track.release(); } catch (Throwable ignored) { }
        }
    }

    @Override
    public String dataDir() { return dataDir; }
}
