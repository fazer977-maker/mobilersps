package rt4;

/**
 * RuneScape-style XP counter and XP drops, drawn into the game frame just left of the minimap.
 * The counter shows total XP; every XP gain rises up into it as "+123 Mining". Skills at 99 rise in gold
 * (that XP is Mastery XP). Drops queue one line apart so they never overlap.
 * Each drop carries the skill's own icon, taken from the stats tab (the icon next to each skill's level).
 * Text is built raw: JagString.parse treats ( ) * + , - as escape codes, which ate the "+" and the commas.
 * Game thread only: fed by the stat packet, drawn after the interfaces each frame.
 */
public final class XpDrops {
    private XpDrops() {}

    private static final String[] NAME = {"Attack", "Defence", "Strength", "Hitpoints", "Ranged", "Prayer", "Magic", "Cooking",
            "Woodcutting", "Fletching", "Fishing", "Firemaking", "Crafting", "Smithing", "Mining", "Herblore", "Agility", "Thieving",
            "Slayer", "Farming", "Runecrafting", "Hunter", "Construction", "Summoning"};
    private static final int MAX = 12;
    private static final long LIFE = 1700;
    private static final long GAP = 280;               // ms between drops = one text line of travel

    public static boolean enabled = true;
    private static final boolean[] seen = new boolean[25];
    private static final JagString[] text = new JagString[MAX];
    private static final int[] color = new int[MAX];
    private static final long[] born = new long[MAX];
    private static final int[] slotY = new int[MAX];
    private static final int[] skillOf = new int[MAX];
    private static final Sprite[] icons = new Sprite[25];
    private static boolean iconsTried;
    private static int iconTries;
    private static int count;
    private static long lastBorn;
    private static int lastState;
    private static JagString totalText;
    private static long totalShown = -1;

    /** from the stat packet, before the new value is stored */
    public static void onXp(int skill, int oldXp, int newXp) {
        try {
            if (skill < 0 || skill > 24) return;
            if (client.gameState != 30) { seen[skill] = false; return; }
            if (!seen[skill]) { seen[skill] = true; return; }          // first value after login is not a gain
            int gain = newXp - oldXp;
            if (gain <= 0) return;
            boolean mastery = skill < 24 && PlayerSkillXpTable.baseLevels[skill] >= 99;
            add(skill, "+" + fmt(gain) + " " + (skill < 24 ? NAME[skill] : "XP"), mastery ? 0xFFB000 : 0xFFFFFF);
        } catch (Throwable ignored) { }
    }

    private static void add(int skill, String s, int col) {
        long now = System.currentTimeMillis();
        if (count == MAX) shift();                         // drop the oldest if full
        long b = Math.max(now, lastBorn + GAP);            // queue so drops never overlap (one line apart)
        text[count] = raw(s);
        color[count] = col;
        skillOf[count] = skill;
        born[count] = b;
        slotY[count] = 0;
        count++;
        lastBorn = b;
    }

    private static void shift() {
        for (int i = 1; i < count; i++) { text[i - 1] = text[i]; color[i - 1] = color[i]; born[i - 1] = born[i]; slotY[i - 1] = slotY[i]; skillOf[i - 1] = skillOf[i]; }
        count--;
    }

    /** a JagString straight from the characters (no escape decoding) */
    static JagString raw(String s) {
        JagString j = new JagString();
        byte[] b = new byte[s.length()];
        for (int i = 0; i < b.length; i++) { char ch = s.charAt(i); b[i] = (byte) (ch < 256 ? ch : '?'); }
        j.chars = b; j.length = b.length;
        return j;
    }

    /** absolute position of a component inside its interface */
    private static int[] abs(Component[] cs, Component c) {
        int x = c.x, y = c.y, guard = 0;
        Component p = c;
        while (p.overlayer != -1 && guard++ < 20) {
            int idx = p.overlayer & 0xFFFF;
            if ((p.overlayer >>> 16) != 320 || idx < 0 || idx >= cs.length || cs[idx] == null) break;
            p = cs[idx]; x += p.x; y += p.y;
        }
        return new int[] {x, y};
    }

    /** find each skill's icon in the stats tab: the one-off graphic closest to that skill's level number */
    private static void loadIcons() {
        if (iconsTried || iconTries > 30) return;
        iconTries++;
        try {
            if (!InterfaceList.load(320)) return;
            Component[] cs = InterfaceList.components[320];
            if (cs == null) return;
            java.util.HashMap<Integer, Integer> freq = new java.util.HashMap<Integer, Integer>();
            for (Component c : cs) if (c != null && c.type == 5 && c.spriteId >= 0) freq.put(c.spriteId, (freq.containsKey(c.spriteId) ? freq.get(c.spriteId) : 0) + 1);
            int found = 0;
            for (Component t : cs) {
                if (t == null || t.cs1Scripts == null || t.cs1Scripts.length == 0 || t.cs1Scripts[0] == null || t.cs1Scripts[0].length < 2) continue;
                int op = t.cs1Scripts[0][0], sk = t.cs1Scripts[0][1];
                if ((op != 1 && op != 2) || sk < 0 || sk > 24 || icons[sk] != null) continue;
                int[] tp = abs(cs, t);
                float tx = tp[0] + t.width / 2f, ty = tp[1] + t.height / 2f;
                Component best = null; float bd = 70f;
                for (Component g : cs) {
                    if (g == null || g.type != 5 || g.spriteId < 0 || freq.get(g.spriteId) > 2) continue;
                    int[] gp = abs(cs, g);
                    float dx = gp[0] + g.width / 2f - tx, dy = gp[1] + g.height / 2f - ty;
                    float dd = (float) Math.sqrt(dx * dx + dy * dy);
                    if (dd < bd) { bd = dd; best = g; }
                }
                if (best == null) continue;
                Sprite[] sp = SpriteLoader.loadAlphaSprites(best.spriteId, client.js5Archive8);
                if (sp != null && sp.length > 0 && sp[0] != null) { icons[sk] = sp[0]; found++; }
            }
            iconsTried = true;
        } catch (Throwable ignored) { iconsTried = true; }
    }

    private static String fmt(long v) {
        String s = Long.toString(v);
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) { if (i > 0 && (s.length() - i) % 3 == 0) b.append(','); b.append(s.charAt(i)); }
        return b.toString();
    }

    private static void fill(int x, int y, int w, int h, int col, int alpha) {
        if (GlRenderer.enabled) GlRaster.fillRectAlpha(x, y, w, h, col, alpha); else SoftwareRaster.fillRectAlpha(x, y, w, h, col, alpha);
    }

    private static void rect(int x, int y, int w, int h, int col) {
        if (GlRenderer.enabled) GlRaster.drawRect(x, y, w, h, col); else SoftwareRaster.drawRect(x, y, w, h, col);
    }

    /** every frame, after the interfaces */
    public static void draw() {
        try {
            int st = client.gameState;
            if (st != lastState) { if (st != 30) { java.util.Arrays.fill(seen, false); count = 0; } lastState = st; }
            if (!enabled || st != 30 || !MobileLayout.enabled || MobileLayout.studioOpen || MobileLayout.bankOpen || Tour.playing) return;
            Font f = Fonts.p12Full, fb = Fonts.b12Full;
            if (f == null || fb == null) return;
            int w = GameShell.canvasWidth;
            int bw = 150, bh = 22, bx = Math.max(525, w - 225 - 8 - bw), by = 6;          // left of the minimap, like the real XP counter

            // counter box: total XP
            long total = 0;
            for (int i = 0; i < 25; i++) total += PlayerSkillXpTable.experience[i] & 0xFFFFFFFFL;
            if (total != totalShown || totalText == null) { totalShown = total; totalText = raw(fmt(total)); }
            loadIcons();
            fill(bx, by, bw, bh, 0x000000, 150);
            rect(bx, by, bw, bh, 0x5A4D3D);
            rect(bx + 1, by + 1, bw - 2, bh - 2, 0x2A231B);
            fb.renderLeft(LABEL, bx + 6, by + 16, 0xFF981F, 0);
            fb.renderRight(totalText, bx + bw - 6, by + 16, 0xFFFFFF, 0);

            // drops rise from below into the box and disappear at its bottom edge
            long now = System.currentTimeMillis();
            while (count > 0 && now - born[0] > LIFE + 400) shift();
            int travel = 84, floor = by + bh;
            for (int i = 0; i < count; i++) {
                if (now < born[i]) continue;                      // still queued
                float t = (now - born[i]) / (float) LIFE;
                int y = floor + 14 + travel - (int) ((travel + 2) * t) + slotY[i];   // stacked drops keep their gap
                if (y - 12 < floor) continue;                     // reached the counter
                f.renderRight(text[i], bx + bw - 6, y, color[i], 0);
                Sprite ic = skillOf[i] >= 0 && skillOf[i] < 25 ? icons[skillOf[i]] : null;
                if (ic != null) {                                 // the skill icon, 16 px tall, left of the text
                    int ih = 16, iw = Math.max(8, Math.round(ic.width * 16f / Math.max(1, ic.height)));
                    int tx = bx + bw - 6 - f.getStringWidth(text[i]);
                    ic.renderResized(tx - iw - 3, y - 13, iw, ih);
                }
            }
            if (!GlRenderer.enabled) InterfaceList.redrawScreen(bx, bw, by, bh + travel + 60);
        } catch (Throwable ignored) { }
    }

    private static final JagString LABEL = raw("XP:");
}
