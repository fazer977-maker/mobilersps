package shim.awt;

import java.util.ArrayList;
import java.util.List;

public class Container extends Component {
    private final List<Component> children = new ArrayList<>();
    public Component add(Component c) {
        if (c.parent != null) c.parent.remove(c);
        c.parent = this;
        children.add(c);
        return c;
    }
    public void remove(Component c) {
        if (children.remove(c)) c.parent = null;
    }
    public void setLayout(Object layout) {}
    public Insets getInsets() { return new Insets(0, 0, 0, 0); }
    public void setFocusCycleRoot(boolean b) {}
    public Component[] getComponents() { return children.toArray(new Component[0]); }
}
