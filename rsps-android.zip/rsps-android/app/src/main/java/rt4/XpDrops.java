package rt4;

/**
 * RuneScape-style XP counter and XP drops, drawn into the game frame just left of the minimap.
 * The counter shows total XP; every XP gain rises up into it as "+123 Mining". Skills at 99 rise in gold
 * (that XP is Mastery XP). Drops queue one line apart so they never overlap.
 * Game thread only: fed by the stat packet, drawn after the interfaces each frame.
 */
public final class XpDrops {
    private XpDrops() {}

    private static final String[] NAME = {"Attack", "Defence", "Strength", "Hitpoints", "Ranged", "Prayer", "Magic", "Cooking",
            "Woodcutting", "Fletching", "Fishing", "Firemaking", "Crafting", "Smithing", "Mining", "Herblore", "Agility", "Thieving",
            "Slayer", "Farming", "Runecrafting", "Hunter", "Construction", "Summoning"};
    private static final int MAX = 12;
    private static final long LIFE = 1700;
    private static final long GAP = 280;               // ms between drops = one text line of travel

    public static boolean enabled = true;
    private static final boolean[] seen = new boolean[25];
    private static final JagString[] text = new JagString[MAX];
    private static final int[] color = new int[MAX];
    private static final long[] born = new long[MAX];
    private static final int[] slotY = new int[MAX];
    private static int count;
    private static long lastBorn;
    private static int lastState;
    private static JagString totalText;
    private static long totalShown = -1;

    /** from the stat packet, before the new value is stored */
    public static void onXp(int skill, int oldXp, int newXp) {
        try {
            if (skill < 0 || skill > 24) return;
            if (client.gameState != 30) { seen[skill] = false; return; }
            if (!seen[skill]) { seen[skill] = true; return; }          // first value after login is not a gain
            int gain = newXp - oldXp;
            if (gain <= 0) return;
            boolean mastery = skill < 24 && PlayerSkillXpTable.baseLevels[skill] >= 99;
            add("+" + fmt(gain) + " " + (skill < 24 ? NAME[skill] : "XP"), mastery ? 0xFFB000 : 0xFFFFFF);
        } catch (Throwable ignored) { }
    }

    private static void add(String s, int col) {
        long now = System.currentTimeMillis();
        if (count == MAX) shift();                         // drop the oldest if full
        long b = Math.max(now, lastBorn + GAP);            // queue so drops never overlap (one line apart)
        text[count] = JagString.parse(s);
        color[count] = col;
        born[count] = b;
        slotY[count] = 0;
        count++;
        lastBorn = b;
    }

    private static void shift() {
        for (int i = 1; i < count; i++) { text[i - 1] = text[i]; color[i - 1] = color[i]; born[i - 1] = born[i]; slotY[i - 1] = slotY[i]; }
        count--;
    }

    private static String fmt(long v) {
        String s = Long.toString(v);
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) { if (i > 0 && (s.length() - i) % 3 == 0) b.append(','); b.append(s.charAt(i)); }
        return b.toString();
    }

    private static void fill(int x, int y, int w, int h, int col, int alpha) {
        if (GlRenderer.enabled) GlRaster.fillRectAlpha(x, y, w, h, col, alpha); else SoftwareRaster.fillRectAlpha(x, y, w, h, col, alpha);
    }

    private static void rect(int x, int y, int w, int h, int col) {
        if (GlRenderer.enabled) GlRaster.drawRect(x, y, w, h, col); else SoftwareRaster.drawRect(x, y, w, h, col);
    }

    /** every frame, after the interfaces */
    public static void draw() {
        try {
            int st = client.gameState;
            if (st != lastState) { if (st != 30) { java.util.Arrays.fill(seen, false); count = 0; } lastState = st; }
            if (!enabled || st != 30 || !MobileLayout.enabled || MobileLayout.studioOpen || MobileLayout.bankOpen || Tour.playing) return;
            Font f = Fonts.p12Full, fb = Fonts.b12Full;
            if (f == null || fb == null) return;
            int w = GameShell.canvasWidth;
            int bw = 150, bh = 22, bx = Math.max(525, w - 225 - 8 - bw), by = 6;          // left of the minimap, like the real XP counter

            // counter box: total XP
            long total = 0;
            for (int i = 0; i < 25; i++) total += PlayerSkillXpTable.experience[i] & 0xFFFFFFFFL;
            if (total != totalShown || totalText == null) { totalShown = total; totalText = JagString.parse(fmt(total)); }
            fill(bx, by, bw, bh, 0x000000, 150);
            rect(bx, by, bw, bh, 0x5A4D3D);
            rect(bx + 1, by + 1, bw - 2, bh - 2, 0x2A231B);
            fb.renderLeft(LABEL, bx + 6, by + 16, 0xFF981F, 0);
            fb.renderRight(totalText, bx + bw - 6, by + 16, 0xFFFFFF, 0);

            // drops rise from below into the box and disappear at its bottom edge
            long now = System.currentTimeMillis();
            while (count > 0 && now - born[0] > LIFE + 400) shift();
            int travel = 84, floor = by + bh;
            for (int i = 0; i < count; i++) {
                if (now < born[i]) continue;                      // still queued
                float t = (now - born[i]) / (float) LIFE;
                int y = floor + 14 + travel - (int) ((travel + 2) * t) + slotY[i];   // stacked drops keep their gap
                if (y - 12 < floor) continue;                     // reached the counter
                f.renderRight(text[i], bx + bw - 6, y, color[i], 0);
            }
            if (!GlRenderer.enabled) InterfaceList.redrawScreen(bx, bw, by, bh + travel + 60);
        } catch (Throwable ignored) { }
    }

    private static final JagString LABEL = JagString.parse("XP:");
}
