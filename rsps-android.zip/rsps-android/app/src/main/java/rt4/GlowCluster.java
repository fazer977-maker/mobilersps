package rt4;

/**
 * A scene entity that draws a few soft additive glow sprites. It is placed in the scene graph like any model,
 * so the software renderer paints it in the right depth order (walls, roofs and characters cover it) and the
 * additive light blend gives the RS3 glow look. Particles in the same tile are merged into one cluster.
 */
public final class GlowCluster extends Entity {

	public static final int CAP = 48;
	public int n = 0;
	public final float[] dx = new float[CAP], dy = new float[CAP], dz = new float[CAP], rad = new float[CAP];
	public final int[] color = new int[CAP], inten = new int[CAP];

	public boolean add(float x, float y, float z, float radius, int rgb, int intensity) {
		if (n >= CAP) {
			return false;
		}
		dx[n] = x; dy[n] = y; dz[n] = z; rad[n] = radius; color[n] = rgb; inten[n] = intensity;
		n++;
		return true;
	}

	private static final int SEG = 10;
	private static final java.nio.FloatBuffer vbuf = java.nio.ByteBuffer.allocateDirect((SEG + 2) * 3 * 4).order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer();
	private static final java.nio.ByteBuffer cbuf = java.nio.ByteBuffer.allocateDirect((SEG + 2) * 4).order(java.nio.ByteOrder.nativeOrder());
	private static final float[] mv = new float[16];
	private static final java.nio.ByteBuffer ibuf = java.nio.ByteBuffer.allocateDirect((SEG + 2) * 4).order(java.nio.ByteOrder.nativeOrder());
	static {
		for (int i = 0; i < SEG + 2; i++) {
			ibuf.putInt(i);
		}
		ibuf.flip();
	}

	/** GPU path: additive soft-edged billboards (center bright, rim transparent), depth-tested but not depth-writing. */
	private void renderGl(int sceneX, int vert, int horiz) {
		if (n == 0) {
			return;
		}
		com.jogamp.opengl.GL2 gl = GlRenderer.gl;
		gl.glGetFloatv(2982, mv, 0);
		float rx = mv[0], ry = mv[4], rz = mv[8];
		float ux = mv[1], uy = mv[5], uz = mv[9];
		boolean lit = GlRenderer.isLightingEnabled();
		GlRenderer.setTextureId(-1);
		MaterialManager.setMaterial(0, 0);
		GlRenderer.setLightingEnabled(false);
		GlRenderer.disableDepthMask();
		gl.glEnable(com.jogamp.opengl.GL2.GL_BLEND);
		gl.glBlendFunc(com.jogamp.opengl.GL2.GL_SRC_ALPHA, com.jogamp.opengl.GL2.GL_ONE);
		gl.glDisableClientState(com.jogamp.opengl.GL2.GL_NORMAL_ARRAY);
		GlRenderer.normalArrayEnabled = false;
		gl.glDisableClientState(com.jogamp.opengl.GL2.GL_TEXTURE_COORD_ARRAY);
		gl.glEnableClientState(com.jogamp.opengl.GL2.GL_COLOR_ARRAY);
		gl.glEnableClientState(com.jogamp.opengl.GL2.GL_VERTEX_ARRAY);
		if (GlRenderer.arbVboSupported) {
			gl.glBindBuffer(com.jogamp.opengl.GL2.GL_ARRAY_BUFFER, 0);
		}
		for (int i = 0; i < n; i++) {
			float cx = sceneX + dx[i], cy = vert + dz[i], cz = horiz + dy[i];
			float r = rad[i] * 1.8F;
			int col = color[i];
			int cr = col >> 16 & 0xFF, cg = col >> 8 & 0xFF, cb = col & 0xFF;
			int a = Math.min(255, inten[i]);
			vbuf.clear();
			cbuf.clear();
			vbuf.put(cx).put(cy).put(cz);
			cbuf.put((byte) ((cr + 255) >> 1)).put((byte) ((cg + 255) >> 1)).put((byte) ((cb + 255) >> 1)).put((byte) a);
			for (int s = 0; s <= SEG; s++) {
				double t = s * (Math.PI * 2.0 / SEG);
				float c = (float) Math.cos(t) * r, sn = (float) Math.sin(t) * r;
				vbuf.put(cx + rx * c + ux * sn).put(cy + ry * c + uy * sn).put(cz + rz * c + uz * sn);
				cbuf.put((byte) cr).put((byte) cg).put((byte) cb).put((byte) 0);
			}
			vbuf.flip();
			cbuf.flip();
			gl.glVertexPointer(3, com.jogamp.opengl.GL2.GL_FLOAT, 0, vbuf);
			gl.glColorPointer(4, com.jogamp.opengl.GL2.GL_UNSIGNED_BYTE, 0, cbuf);
			gl.glDrawElements(com.jogamp.opengl.GL2.GL_TRIANGLE_FAN, SEG + 2, com.jogamp.opengl.GL2.GL_UNSIGNED_INT, ibuf);
		}
		gl.glBlendFunc(com.jogamp.opengl.GL2.GL_SRC_ALPHA, com.jogamp.opengl.GL2.GL_ONE_MINUS_SRC_ALPHA);
		GlRenderer.enableDepthMask();
		gl.glEnableClientState(com.jogamp.opengl.GL2.GL_TEXTURE_COORD_ARRAY);
		GlRenderer.setLightingEnabled(lit);
	}

	@Override
	public void updateModel(int pitch, int yaw, int roll, int x, int z) {
	}

	@Override
	public int getMinY() {
		return -20;
	}

	@Override
	public void render(int yaw, int sinPitch, int cosPitch, int sinYaw, int cosYaw, int sceneX, int sceneZ, int sceneY, long key, int plane, ParticleSystem ps) {
		if (GlRenderer.enabled) {
			renderGl(sceneX, sceneZ, sceneY);
			return;
		}
		if (SoftwareRaster.pixels == null) {
			return;
		}
		int stride = SoftwareRaster.width;
		int off0 = Rasteriser.originOffset();
		int vTop = off0 / stride;
		int vLeft = off0 - vTop * stride;
		int minX = vLeft, maxX = vLeft + (Rasteriser.screenUpperX - Rasteriser.screenLowerX);
		int minY = vTop, maxY = vTop + (Rasteriser.screenUpperY - Rasteriser.screenLowerY);
		int[] px = SoftwareRaster.pixels;
		for (int i = 0; i < n; i++) {
			int wx = sceneX + (int) dx[i];
			int wy = sceneY + (int) dy[i];
			int wz = sceneZ + (int) dz[i];
			int a = wy * cosYaw - wx * sinYaw >> 16;
			int b = wz * sinPitch + a * cosPitch >> 16;
			if (b <= 50) {
				continue;
			}
			int e = wy * sinYaw + wx * cosYaw >> 16;
			int f = wz * cosPitch - a * sinPitch >> 16;
			int cx = vLeft + Rasteriser.centerX + (e << 9) / b;
			int cy = vTop + Rasteriser.centerY + (f << 9) / b;
			int r = (int) (rad[i] * 512.0F / b);
			if (r < 1) {
				r = 1;
			}
			if (r > 44) {
				r = 44;
			}
			int x0 = Math.max(minX, cx - r), x1 = Math.min(maxX - 1, cx + r);
			int y0 = Math.max(minY, cy - r), y1 = Math.min(maxY - 1, cy + r);
			if (x0 > x1 || y0 > y1) {
				continue;
			}
			int col = color[i], k = inten[i];
			int cr = (col >> 16 & 0xFF) * k, cg = (col >> 8 & 0xFF) * k, cb = (col & 0xFF) * k;
			int r2 = r * r;
			for (int y = y0; y <= y1; y++) {
				int dyy = y - cy;
				int row = y * stride;
				for (int x = x0; x <= x1; x++) {
					int dxx = x - cx;
					int d2 = dxx * dxx + dyy * dyy;
					if (d2 >= r2) {
						continue;
					}
					int w = 256 - (d2 << 8) / r2;      // 256 centre -> 0 edge
					w = w * w >> 8;                     // soft falloff
					// bright white-hot core on top of the coloured glow
					int core = w > 150 ? (w - 150) * 2 : 0;
					int dst = px[row + x];
					int rr = (dst >> 16 & 0xFF) + ((cr * w >> 16) + core * k / 256 / 2);
					int gg = (dst >> 8 & 0xFF) + ((cg * w >> 16) + core * k / 256 / 2);
					int bb = (dst & 0xFF) + ((cb * w >> 16) + core * k / 256 / 2);
					if (rr > 255) rr = 255;
					if (gg > 255) gg = 255;
					if (bb > 255) bb = 255;
					px[row + x] = rr << 16 | gg << 8 | bb;
				}
			}
		}
	}
}
