package app.rsps2009;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/** Custom RuneScape-styled loading + login screen drawn over the game surface. */
final class LoginOverlay extends FrameLayout {
    private static final int GOLD = Color.rgb(255, 176, 0);
    private static final int PARCH = Color.rgb(220, 205, 160);
    private static final int STONE = Color.rgb(62, 53, 41);

    private final Handler h = new Handler(Looper.getMainLooper());
    private final BarView bar;
    private final TextView status, error;
    private final LinearLayout form;
    private final EditText user, pass;
    private final CheckBox remember;
    private final Button login;
    private final File accFile;
    private final float d;

    private boolean inWorld, attempting, sawBusy, wasInGame, autoDone, prefilled;
    private long attemptAt;

    LoginOverlay(Context c, File filesDir) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        accFile = new File(filesDir, "account.txt");
        setClickable(true);
        setFocusable(true);
        setFocusableInTouchMode(true);

        setBackground(new BgDrawable());

        ScrollView sv = new ScrollView(c);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        addView(sv, new LayoutParams(-1, -1));

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(16), dp(18), dp(16), dp(12));
        sv.addView(col, new ScrollView.LayoutParams(-1, -2));

        TextView title = new TextView(c);
        title.setText("2009Scape");
        title.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        title.setTextSize(38);
        title.setTextColor(GOLD);
        title.setShadowLayer(dp(2), dp(2), dp(2), Color.BLACK);
        title.setGravity(Gravity.CENTER);
        col.addView(title);

        TextView sub = new TextView(c);
        sub.setText("MOBILE");
        sub.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        sub.setTextSize(13);
        sub.setLetterSpacing(0.5f);
        sub.setTextColor(PARCH);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, dp(10));
        col.addView(sub);

        FrameLayout panel = new FrameLayout(c);
        panel.setBackground(panelBg());
        panel.setPadding(dp(14), dp(12), dp(14), dp(12));
        col.addView(panel, new LinearLayout.LayoutParams(dp(330), -2));

        LinearLayout in = new LinearLayout(c);
        in.setOrientation(LinearLayout.VERTICAL);
        in.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.addView(in, new LayoutParams(-1, -2));

        bar = new BarView(c);
        in.addView(bar, new LinearLayout.LayoutParams(-1, dp(176)));

        status = label(c, "Loading...", 13, PARCH);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(6), 0, 0);
        in.addView(status, new LinearLayout.LayoutParams(-1, -2));

        form = new LinearLayout(c);
        form.setOrientation(LinearLayout.VERTICAL);
        in.addView(form, new LinearLayout.LayoutParams(-1, -2));

        form.addView(label(c, "Login", 14, GOLD));
        user = field(c, "Username", false);
        form.addView(user, fieldLp());
        pass = field(c, "Password", true);
        form.addView(pass, fieldLp());

        remember = new CheckBox(c);
        remember.setText("Remember me");
        remember.setTextColor(PARCH);
        remember.setChecked(true);
        remember.setButtonTintList(android.content.res.ColorStateList.valueOf(GOLD));
        form.addView(remember);

        error = label(c, "", 13, Color.rgb(255, 90, 70));
        error.setGravity(Gravity.CENTER);
        form.addView(error);

        login = new Button(c);
        login.setText("Login");
        login.setAllCaps(false);
        login.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        login.setTextSize(17);
        login.setTextColor(GOLD);
        login.setBackground(btnBg());
        login.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) { submit(); }
        });
        form.addView(login, new LinearLayout.LayoutParams(-1, dp(46)));

        pass.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int a, android.view.KeyEvent e) {
                submit();
                return true;
            }
        });
        form.setVisibility(GONE);
        h.post(poll);
    }

    private int dp(int v) { return (int) (v * d + 0.5f); }

    private TextView label(Context c, String t, int sp, int color) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        return v;
    }

    private LinearLayout.LayoutParams fieldLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(44));
        lp.topMargin = dp(6);
        return lp;
    }

    private EditText field(Context c, String hint, boolean pw) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(130, 120, 95));
        e.setTextColor(Color.rgb(255, 240, 190));
        e.setSingleLine(true);
        e.setTextSize(16);
        e.setPadding(dp(10), 0, dp(10), 0);
        e.setInputType(pw ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD
                : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.setImeOptions(pw ? EditorInfo.IME_ACTION_GO : EditorInfo.IME_ACTION_NEXT);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.rgb(20, 16, 11));
        g.setStroke(dp(2), Color.rgb(105, 90, 62));
        g.setCornerRadius(dp(2));
        e.setBackground(g);
        return e;
    }

    private GradientDrawable panelBg() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(STONE);
        g.setStroke(dp(3), Color.rgb(20, 15, 9));
        g.setCornerRadius(dp(3));
        return g;
    }

    private android.graphics.drawable.Drawable btnBg() {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] {Color.rgb(95, 80, 56), Color.rgb(52, 42, 29)});
        g.setStroke(dp(2), Color.rgb(20, 15, 9));
        g.setCornerRadius(dp(3));
        return g;
    }

    private void submit() {
        if (attempting) return;
        String u = user.getText().toString().trim();
        String p = pass.getText().toString();
        if (u.isEmpty() || p.isEmpty()) {
            error.setText("Please enter your username and password.");
            return;
        }
        hideIme();
        error.setText("");
        attempting = true;
        sawBusy = false;
        attemptAt = System.currentTimeMillis();
        rt4.SavedAccount.request(u, p, remember.isChecked());
    }

    private void ime(boolean pan) {
        if (getContext() instanceof android.app.Activity) {
            ((android.app.Activity) getContext()).getWindow().setSoftInputMode(pan
                    ? android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
                    : android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        }
    }

    private void hideIme() {
        InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(getWindowToken(), 0);
    }

    private void prefill() {
        prefilled = true;
        try {
            if (accFile.exists()) {
                String[] p = new String(Files.readAllBytes(accFile.toPath()), StandardCharsets.ISO_8859_1).split("\n");
                if (p.length >= 2) {
                    user.setText(p[0]);
                    pass.setText(p[1]);
                    remember.setChecked(true);
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static String replyText(int r) {
        switch (r) {
            case 3: return "Invalid username or password.";
            case 4: return "Your account has been disabled.";
            case 5: return "Your account is already logged in. Try again in a minute.";
            case 6: case 14: return "The server is being updated. Try again in a minute.";
            case 7: return "This world is full.";
            case 9: case 16: return "Too many login attempts. Wait and try again.";
            case 12: return "This world needs a members account.";
            case 18: return "Your account is locked.";
            case 26: return "Your connection has been blocked.";
            case -4: case 8: case 10: case 11: case 20: case 23: case -5:
                return "Unable to connect to the server.";
            default: return "Login failed (code " + r + ").";
        }
    }

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            try {
                update();
            } catch (Throwable ignored) {
            }
            if (getVisibility() == VISIBLE || true) h.postDelayed(this, 120);
        }
    };

    private void update() {
        int gs = rt4.client.gameState;
        if (gs == 30) {
            wasInGame = true;
            inWorld = true;
            attempting = false;
            if (getVisibility() != GONE) {
                hideIme();
                setVisibility(GONE);
                ime(false);
            }
            return;
        }
        if (gs > 10 && gs < 30 && inWorld) {
            // moving between map regions while playing: never cover the game
            if (getVisibility() != GONE) {
                setVisibility(GONE);
                ime(false);
            }
            return;
        }
        if (gs <= 10) {
            inWorld = false;
        }
        if (getVisibility() != VISIBLE) {
            setVisibility(VISIBLE);
            ime(true);
        }
        if (gs < 10 || gs == 1000) {
            form.setVisibility(GONE);
            String t = rt4.client.mainLoadSecondaryText == null ? "Loading..." : rt4.client.mainLoadSecondaryText.toString();
            int pct = rt4.client.mainLoadPercentage;
            bar.setVisibility(VISIBLE);
            bar.set(pct, "");
            status.setText(t);
            return;
        }
        if (gs == 10) {
            if (!prefilled) prefill();
            if (attempting) {
                int step = rt4.LoginManager.step;
                int hop = rt4.LoginManager.hopStep;
                if (step != 0 || hop != 0) sawBusy = true;
                if (sawBusy && step == 0 && hop == 0) {
                    attempting = false;
                    int r = rt4.LoginManager.reply;
                    if (r != 2) error.setText(replyText(r));
                } else if (!sawBusy && System.currentTimeMillis() - attemptAt > 6000) {
                    attempting = false;
                    error.setText("Unable to connect to the server.");
                }
            }
            if (attempting) {
                form.setVisibility(GONE);
                bar.setVisibility(VISIBLE);
                bar.set(-1, "");
                status.setText("Logging in...");
            } else {
                form.setVisibility(VISIBLE);
                bar.setVisibility(GONE);
                status.setText("Welcome to 2009Scape");
                if (!autoDone && !wasInGame && accFile.exists() && user.length() > 0 && pass.length() > 0) {
                    autoDone = true;
                    submit();
                }
            }
            return;
        }
        // 20..29: logged in, loading the world
        form.setVisibility(GONE);
        bar.setVisibility(VISIBLE);
        bar.set(-1, "");
        status.setText("Entering the world...");
    }

    /** Potion flask that fills with purple liquid as loading progresses, with twinkling sparkles. */
    private final class BarView extends View {
        private int pct = 0;
        private float shown = 0;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path flask = new Path();
        private final Path star = new Path();
        private final long t0 = System.currentTimeMillis();
        // sparkle: x, y (flask units, flask is 90 x 120), size, phase
        private final float[][] sparks = {
            {-34, 18, 11, 0.0f}, {112, 34, 13, 1.7f}, {-26, 76, 9, 3.1f},
            {108, 92, 8, 4.4f}, {20, -2, 7, 2.2f}, {82, 8, 6, 5.3f}, {-8, 110, 6, 0.9f}, {96, 120, 7, 3.8f}
        };

        BarView(Context c) {
            super(c);
            setLayerType(LAYER_TYPE_SOFTWARE, null);
        }

        void set(int pct, String ignored) {
            this.pct = pct;
        }

        private void drawStar(Canvas c, float cx, float cy, float r) {
            star.reset();
            float in = r * 0.26f;
            star.moveTo(cx, cy - r);
            star.lineTo(cx + in, cy - in);
            star.lineTo(cx + r, cy);
            star.lineTo(cx + in, cy + in);
            star.lineTo(cx, cy + r);
            star.lineTo(cx - in, cy + in);
            star.lineTo(cx - r, cy);
            star.lineTo(cx - in, cy - in);
            star.close();
            c.drawPath(star, p);
        }

        @Override protected void onDraw(Canvas c) {
            float s = d * 1.0f;
            float t = (System.currentTimeMillis() - t0) / 1000f;
            float ox = getWidth() / 2f - 45 * s, oy = dp(8);
            float frac;
            if (pct >= 0) {
                shown += (Math.min(100, pct) / 100f - shown) * 0.12f;
                frac = shown;
            } else {
                frac = 0.5f + 0.12f * (float) Math.sin(t * 2.2f);
            }

            // flask outline in absolute coordinates
            flask.reset();
            flask.moveTo(ox + 34 * s, oy + 14 * s);
            flask.lineTo(ox + 56 * s, oy + 14 * s);
            flask.lineTo(ox + 56 * s, oy + 46 * s);
            flask.lineTo(ox + 85 * s, oy + 100 * s);
            flask.quadTo(ox + 92 * s, oy + 118 * s, ox + 74 * s, oy + 118 * s);
            flask.lineTo(ox + 16 * s, oy + 118 * s);
            flask.quadTo(ox - 2 * s, oy + 118 * s, ox + 5 * s, oy + 100 * s);
            flask.lineTo(ox + 34 * s, oy + 46 * s);
            flask.close();

            // sparkles behind
            p.setStyle(Paint.Style.FILL);
            for (float[] k : sparks) {
                float tw = 0.5f + 0.5f * (float) Math.sin(t * 2.6f + k[3]);
                p.setColor(Color.argb((int) (60 + 195 * tw), 170, 205, 255));
                drawStar(c, ox + k[0] * s, oy + k[1] * s, k[2] * s * (0.55f + 0.6f * tw));
            }

            // glass body fill
            p.setColor(Color.argb(45, 200, 225, 255));
            c.drawPath(flask, p);

            // liquid, clipped to the flask
            float top = 118f - (118f - 48f) * Math.min(1f, frac);
            c.save();
            c.clipPath(flask);
            p.setShader(new LinearGradient(0, oy + top * s, 0, oy + 118 * s,
                    Color.rgb(165, 50, 215), Color.rgb(85, 10, 130), Shader.TileMode.CLAMP));
            Path liquid = new Path();
            liquid.moveTo(ox - 5 * s, oy + 124 * s);
            for (int x = -5; x <= 95; x += 4) {
                float y = top + 1.8f * (float) Math.sin(t * 3f + x * 0.16f);
                if (x == -5) liquid.lineTo(ox + x * s, oy + y * s);
                else liquid.lineTo(ox + x * s, oy + y * s);
            }
            liquid.lineTo(ox + 95 * s, oy + 124 * s);
            liquid.close();
            c.drawPath(liquid, p);
            p.setShader(null);
            // bubbles
            p.setColor(Color.argb(140, 235, 200, 255));
            for (int i = 0; i < 5; i++) {
                float ph = (t * (0.35f + 0.07f * i) + i * 0.37f) % 1f;
                float by = 116f - (116f - top) * ph;
                float bx = 30 + i * 8 + 3 * (float) Math.sin(t * 2f + i);
                c.drawCircle(ox + bx * s, oy + by * s, (1.4f + (i % 3) * 0.7f) * s, p);
            }
            // surface shine
            p.setColor(Color.argb(110, 255, 230, 255));
            c.drawRect(ox, oy + (top - 0.5f) * s, ox + 90 * s, oy + (top + 1.2f) * s, p);
            c.restore();

            // glass highlight stripe
            p.setColor(Color.argb(95, 255, 255, 255));
            Path hl = new Path();
            hl.moveTo(ox + 30 * s, oy + 62 * s);
            hl.lineTo(ox + 36 * s, oy + 56 * s);
            hl.lineTo(ox + 18 * s, oy + 98 * s);
            hl.lineTo(ox + 13 * s, oy + 98 * s);
            hl.close();
            c.drawPath(hl, p);

            // outline
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.2f * s);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setColor(Color.argb(230, 225, 238, 255));
            c.drawPath(flask, p);
            p.setStyle(Paint.Style.FILL);

            // lip ring
            p.setColor(Color.rgb(228, 238, 255));
            c.drawRoundRect(new RectF(ox + 28 * s, oy + 11 * s, ox + 62 * s, oy + 20 * s), 2 * s, 2 * s, p);
            p.setColor(Color.rgb(150, 170, 205));
            c.drawRect(ox + 28 * s, oy + 18 * s, ox + 62 * s, oy + 20 * s, p);
            // cork
            p.setColor(Color.rgb(176, 148, 62));
            c.drawRoundRect(new RectF(ox + 32 * s, oy - 2 * s, ox + 58 * s, oy + 13 * s), 2.5f * s, 2.5f * s, p);
            p.setColor(Color.rgb(120, 98, 38));
            c.drawRect(ox + 32 * s, oy + 9 * s, ox + 58 * s, oy + 13 * s, p);

            // percentage under the flask
            if (pct >= 0) {
                p.setColor(Color.WHITE);
                p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(dp(20));
                p.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
                p.setShadowLayer(3, 1, 1, Color.BLACK);
                c.drawText(Math.min(100, pct) + "%", getWidth() / 2f, oy + 146 * s, p);
                p.clearShadowLayer();
            }
            postInvalidateOnAnimation();
        }
    }

    /** Dark vignette background with a faint gold border pattern. */
    private final class BgDrawable extends android.graphics.drawable.Drawable {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        @Override public void draw(Canvas c) {
            Rect r = getBounds();
            p.setShader(new RadialGradient(r.exactCenterX(), r.exactCenterY(), Math.max(r.width(), r.height()) * 0.7f,
                    Color.rgb(48, 38, 26), Color.rgb(10, 7, 4), Shader.TileMode.CLAMP));
            c.drawRect(r, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(3));
            p.setColor(Color.argb(150, 120, 90, 30));
            c.drawRect(dp(8), dp(8), r.width() - dp(8), r.height() - dp(8), p);
            p.setStrokeWidth(dp(1));
            p.setColor(Color.argb(110, 255, 176, 0));
            c.drawRect(dp(13), dp(13), r.width() - dp(13), r.height() - dp(13), p);
            p.setStyle(Paint.Style.FILL);
        }
        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.OPAQUE; }
    }
}
