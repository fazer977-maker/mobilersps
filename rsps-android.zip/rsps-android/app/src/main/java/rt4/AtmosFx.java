package rt4;

import com.jogamp.opengl.GL2;

/**
 * World-space atmosphere for the GPU renderer, drawn inside the scene right after the map's own lights:
 *  - soft light pools on the ground under every map light (lamps, fires, lanterns) at night,
 *  - fireflies at night and slow drifting motes by day,
 * plus per-frame tints that follow the time of day:
 *  - water colour and glints reflect the sky,
 *  - shadow colour and strength change (cool and soft at night, warm in the evening).
 * Any GL trouble switches the drawing off.
 */
public final class AtmosFx {
	private static boolean broken, waterTouched;
	private static final float[] mv = new float[16];
	private static final SkyBox.Batch batch = new SkyBox.Batch(160);

	// morning, midday, evening, night
	private static final float[][] WATER = {{0.20F, 0.19F, 0.27F}, {0.06F, 0.22F, 0.36F}, {0.28F, 0.13F, 0.17F}, {0.015F, 0.035F, 0.09F}};
	private static final float[][] WSPEC = {{0.30F, 0.22F, 0.20F, 0.22F}, {0.28F, 0.28F, 0.28F, 0.22F}, {0.45F, 0.25F, 0.12F, 0.35F}, {0.14F, 0.16F, 0.28F, 0.25F}};
	private static final float[] WATER0 = {0.073F, 0.169F, 0.24F};
	private static final float[] WSPEC0 = {0.1F, 0.1F, 0.15F, 0.1F};
	private static final float[][] SHADOW = {{0.06F, 0.03F, 0.10F, 0.85F}, {0.0F, 0.0F, 0.04F, 1.0F}, {0.12F, 0.02F, 0.09F, 0.90F}, {0.0F, 0.02F, 0.10F, 0.55F}};

	private AtmosFx() {
	}

	private static float hash(int x, int y, int s) {
		int h = x * 374761393 + y * 668265263 + s * 1442695041;
		h = (h ^ (h >>> 13)) * 1274126177;
		h ^= h >>> 16;
		return (h & 0xFFFF) / 65535.0F;
	}

	private static float mixk(float[][] k, int c, int k0, int k1, float f) {
		return k[k0][c] + (k[k1][c] - k[k0][c]) * f;
	}

	/** Colour and alpha for shadows at the current time of day, or null when time of day is off. */
	public static float[] shadowTint() {
		float pos = ColorGrade.todPos();
		if (pos < 0.0F) {
			return null;
		}
		int k0 = ((int) Math.floor(pos)) & 3, k1 = (k0 + 1) & 3;
		float f = pos - (float) Math.floor(pos);
		f = f * f * (3.0F - 2.0F * f);
		float oc = Weather.overcast();
		return new float[]{mixk(SHADOW, 0, k0, k1, f), mixk(SHADOW, 1, k0, k1, f), mixk(SHADOW, 2, k0, k1, f), mixk(SHADOW, 3, k0, k1, f) * (1.0F - 0.45F * oc)};
	}

	/** Water takes the colour of the sky (and the glint colour of sun or moon). */
	private static void updateWater() {
		float pos = ColorGrade.todPos();
		if (pos < 0.0F) {
			if (waterTouched) {
				for (int c = 0; c < 3; c++) {
					WaterMaterialRenderer.waterColor[c] = WATER0[c];
				}
				for (int c = 0; c < 4; c++) {
					WaterMaterialRenderer.waterSpecularColor[c] = WSPEC0[c];
				}
				waterTouched = false;
			}
			return;
		}
		int k0 = ((int) Math.floor(pos)) & 3, k1 = (k0 + 1) & 3;
		float f = pos - (float) Math.floor(pos);
		f = f * f * (3.0F - 2.0F * f);
		float oc = Weather.overcast();
		float lum = 0.15F + 0.85F * (1.0F - ColorGrade.nightAmount());
		for (int c = 0; c < 3; c++) {
			float target = mixk(WATER, c, k0, k1, f);
			target += (0.30F * lum - target) * oc * 0.6F;
			WaterMaterialRenderer.waterColor[c] = WATER0[c] * 0.4F + target * 0.6F;
		}
		for (int c = 0; c < 4; c++) {
			WaterMaterialRenderer.waterSpecularColor[c] = mixk(WSPEC, c, k0, k1, f) * (c == 3 ? 1.0F : 1.0F - 0.4F * oc);
		}
		waterTouched = true;
	}

	/** Called inside the scene (world coordinates) right after the map lights have been drawn. */
	public static void drawWorld(GL2 gl) {
		if (!GlRenderer.enabled || broken) {
			return;
		}
		try {
			updateWater();
			float night = ColorGrade.nightAmount();
			float pos = ColorGrade.todPos();
			if (!FxConfig.ambient || pos < 0.0F) {
				return;
			}
			boolean pools = night > 0.03F && LightingManager.lights != null;
			draw(gl, night, pools);
		} catch (Throwable t) {
			broken = true;
			shim.platform.Platforms.error("ATMOS failed: " + t, t);
		}
	}

	private static void quad(float cx, float cy, float cz, float rx, float ry, float rz, float ux, float uy, float uz, float r, float g, float b, float a) {
		batch.vert(cx - rx - ux, cy - ry - uy, cz - rz - uz, 0, 0, r, g, b, a);
		batch.vert(cx + rx - ux, cy + ry - uy, cz + rz - uz, 1, 0, r, g, b, a);
		batch.vert(cx + rx + ux, cy + ry + uy, cz + rz + uz, 1, 1, r, g, b, a);
		batch.vert(cx - rx + ux, cy - ry + uy, cz - rz + uz, 0, 1, r, g, b, a);
		batch.quadIdx();
	}

	private static void draw(GL2 gl, float night, boolean pools) {
		SkyBox.ensureInit(gl);
		int plane = Player.plane;
		int px = PlayerList.self.xFine, py = PlayerList.self.yFine;
		batch.clear();
		int maxQuads = 150;
		// --- light pools: a flat additive disc on the ground under each light
		if (pools) {
			int lim = 26 * 128;
			for (int i = 0; i < LightingManager.lightCount && batch.n < 60; i++) {
				Light l = LightingManager.lights[i];
				if (l == null || l.level != plane) {
					continue;
				}
				int dx = l.x - px, dy = l.y - py;
				if (dx > lim || dx < -lim || dy > lim || dy < -lim) {
					continue;
				}
				int tx = l.x >> 7, ty = l.y >> 7;
				if (tx < LightingManager.visibleMinX || tx >= LightingManager.visibleMaxX || ty < LightingManager.visibleMinY || ty >= LightingManager.visibleMaxY) {
					continue;
				}
				float gy = SceneGraph.getTileHeight(l.level, l.x, l.y) - 6.0F;
				int col = l.color;
				float cr = (col >> 16 & 0xFF) / 255.0F, cg = (col >> 8 & 0xFF) / 255.0F, cb = (col & 0xFF) / 255.0F;
				float m = Math.max(0.2F, Math.max(cr, Math.max(cg, cb)));
				cr = Math.min(1.0F, cr / m);
				cg = Math.min(1.0F, cg / m);
				cb = Math.min(1.0F, cb / m);
				float fl = Math.max(0.35F, Math.min(1.0F, l.alpha));
				float h = Math.max(1.5F, l.radius) * 128.0F * 0.85F;
				quad(l.x, gy, l.y, h, 0, 0, 0, 0, h, cr, cg, cb, 0.55F * night * fl);
			}
		}
		// --- fireflies at night, drifting motes by day
		float t = System.currentTimeMillis() / 1000.0F;
		gl.glGetFloatv(2982, mv, 0);
		float rx = mv[0], ry = mv[4], rz = mv[8], ux = mv[1], uy = mv[5], uz = mv[9];
		int cell = 384, cx0 = (px / cell) - 11, cy0 = (py / cell) - 11;
		float density = 0.035F + 0.045F * night;
		for (int cx = cx0; cx <= cx0 + 22 && batch.n < maxQuads; cx++) {
			for (int cy = cy0; cy <= cy0 + 22 && batch.n < maxQuads; cy++) {
				if (hash(cx, cy, 1) > density) {
					continue;
				}
				float ph = hash(cx, cy, 2) * 6.2832F;
				float wx = cx * cell + hash(cx, cy, 3) * cell + 70.0F * (float) Math.sin(t * 0.45F + ph);
				float wy = cy * cell + hash(cx, cy, 4) * cell + 70.0F * (float) Math.cos(t * 0.38F + ph * 1.3F);
				if (wx < 0 || wy < 0) {
					continue;
				}
				float ground = SceneGraph.getTileHeight(plane, (int) wx, (int) wy);
				float hgt = 50.0F + hash(cx, cy, 5) * 170.0F + 18.0F * (float) Math.sin(t * 0.9F + ph);
				float blink = (float) Math.sin(t * (1.1F + hash(cx, cy, 6)) + ph);
				blink = Math.max(0.0F, blink);
				blink *= blink;
				float s;
				float r, g, b, a;
				if (night > 0.25F) {
					s = 11.0F + 5.0F * hash(cx, cy, 7);
					r = 0.75F;
					g = 1.0F;
					b = 0.35F;
					a = (0.25F + 0.75F * blink) * Math.min(1.0F, night * 1.3F);
				} else {
					s = 6.0F + 3.0F * hash(cx, cy, 7);
					r = 1.0F;
					g = 0.98F;
					b = 0.85F;
					a = 0.30F * (0.4F + 0.6F * blink) * (1.0F - night * 3.0F);
				}
				if (a <= 0.02F) {
					continue;
				}
				quad(wx, ground - hgt, wy, rx * s, ry * s, rz * s, ux * s, uy * s, uz * s, r, g, b, a);
			}
		}
		if (batch.n == 0) {
			return;
		}
		// state for additive soft sprites that are depth-tested but do not write depth
		gl.glClientActiveTexture(GL2.GL_TEXTURE0);
		MaterialManager.setMaterial(0, 0);
		GlRenderer.setTextureCombineRgbMode(0);
		GlRenderer.setLightingEnabled(false);
		GlRenderer.disableDepthMask();
		GlRenderer.setDepthTestEnabled(true);
		GlRenderer.setDepthLayer(201.5F - (float) plane * 50.0F - 1.8F);
		GlRenderer.setTextureId(SkyBox.glowTex());
		gl.glDisable(GL2.GL_CULL_FACE);
		gl.glEnable(GL2.GL_BLEND);
		gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE);
		gl.glDisableClientState(GL2.GL_NORMAL_ARRAY);
		GlRenderer.normalArrayEnabled = false;
		gl.glEnableClientState(GL2.GL_VERTEX_ARRAY);
		gl.glEnableClientState(GL2.GL_COLOR_ARRAY);
		gl.glEnableClientState(GL2.GL_TEXTURE_COORD_ARRAY);
		if (GlRenderer.arbVboSupported) {
			gl.glBindBuffer(GL2.GL_ARRAY_BUFFER, 0);
			gl.glBindBuffer(GL2.GL_ELEMENT_ARRAY_BUFFER, 0);
		}
		batch.flush(gl);
		gl.glEnable(GL2.GL_CULL_FACE);
		gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
		gl.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		GlRenderer.enableDepthMask();
		GlRenderer.restoreLighting();
		GlRenderer.normalizeModelState();
	}
}
