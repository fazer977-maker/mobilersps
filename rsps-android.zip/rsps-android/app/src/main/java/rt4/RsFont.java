package rt4;

/**
 * The game's own fonts (p11, p12, b12) loaded as software fonts once after login, so the app's native windows
 * can draw text in the real RuneScape typefaces. Game thread loads; the UI thread only reads.
 */
public final class RsFont {
    private RsFont() {}
    public static final int P11 = 0, P12 = 1, B12 = 2;
    public static final SoftwareFont[] fonts = new SoftwareFont[3];
    public static volatile boolean ready;
    public static volatile int version;
    private static int tries;
    private static long lastTry;

    /** game thread, every frame */
    public static void tick() {
        if (ready || tries > 20) return;
        try {
            if (client.gameState != 30 || client.js5Archive8 == null || client.js5Archive13 == null) return;
            long now = System.currentTimeMillis();
            if (now - lastTry < 2000) return;
            lastTry = now; tries++;
            int[] ids = {Sprites.p11FullId, Sprites.p12FullId, Sprites.b12FullId};
            for (int i = 0; i < 3; i++) {
                if (fonts[i] == null) fonts[i] = SoftwareFont.load(ids[i], client.js5Archive13, client.js5Archive8);
            }
            if (fonts[0] != null && fonts[1] != null && fonts[2] != null) { ready = true; version++; }
        } catch (Throwable ignored) { }
    }
}
