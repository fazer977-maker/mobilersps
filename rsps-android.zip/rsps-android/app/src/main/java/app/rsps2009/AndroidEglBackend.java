package app.rsps2009;

import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import com.jogamp.opengl.EglBackend;
import shim.platform.Platforms;

/** EGL (ES2) context + window surface for gl4es, driven from the client thread. */
public class AndroidEglBackend implements EglBackend {
    private final GpuView view;
    private EGLDisplay dpy = EGL14.EGL_NO_DISPLAY;
    private EGLContext ctx = EGL14.EGL_NO_CONTEXT;
    private EGLSurface surf = EGL14.EGL_NO_SURFACE;
    private EGLConfig cfg;
    private android.view.Surface bound;
    private int rebinds;

    public AndroidEglBackend(GpuView v) { view = v; }

    private static void log(String s) { Platforms.error("EGL: " + s, null); }

    private static int[] configAttrs(int samples, boolean alpha) {
        java.util.ArrayList<Integer> a = new java.util.ArrayList<>();
        int[] base = { EGL14.EGL_RENDERABLE_TYPE, 4 /*ES2*/, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT,
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_DEPTH_SIZE, 24, EGL14.EGL_STENCIL_SIZE, 8 };
        for (int v : base) a.add(v);
        if (alpha) { a.add(EGL14.EGL_ALPHA_SIZE); a.add(8); }
        if (samples > 1) { a.add(EGL14.EGL_SAMPLE_BUFFERS); a.add(1); a.add(EGL14.EGL_SAMPLES); a.add(samples); }
        a.add(EGL14.EGL_NONE);
        int[] r = new int[a.size()];
        for (int i = 0; i < r.length; i++) r[i] = a.get(i);
        return r;
    }

    @Override public boolean create(int samples) {
        try {
            long end = System.currentTimeMillis() + 90000; // wait for the window (app may start in the background or while the screen turns on) instead of falling back to the software renderer
            while (view.surface == null || !view.surface.isValid()) {
                if (System.currentTimeMillis() > end) { log("no surface"); return false; }
                Thread.sleep(20);
            }
            // The client tears the renderer down and rebuilds it whenever a graphics setting (e.g. anti-aliasing) changes.
            // gl4es keeps its own state tied to the first context, so keep that context alive and just re-attach to it.
            if (ctx != EGL14.EGL_NO_CONTEXT && cfg != null) {
                log("re-using existing context (samples change applies on next launch)");
                if (surf == EGL14.EGL_NO_SURFACE || view.surface != bound) {
                    surf = EGL14.EGL_NO_SURFACE;
                    bound = view.surface;
                    surf = EGL14.eglCreateWindowSurface(dpy, cfg, bound, new int[] { EGL14.EGL_NONE }, 0);
                    if (surf == EGL14.EGL_NO_SURFACE) { log("re-create surface failed " + EGL14.eglGetError()); return false; }
                }
                return true;
            }
            dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
            int[] ver = new int[2];
            EGL14.eglInitialize(dpy, ver, 0, ver, 1);
            EGLConfig[] cfgs = new EGLConfig[1];
            int[] n = new int[1];
            int ms = Settings.msaa ? 4 : 0; // phones offer 4x; the client asks for 8x/16x which most GPUs don't have
            boolean ok = ms > 0 && EGL14.eglChooseConfig(dpy, configAttrs(ms, true), 0, cfgs, 0, 1, n, 0) && n[0] >= 1;
            if (ms > 0) log("MSAA " + ms + "x config " + (ok ? "found" : "not available"));
            if (!ok) ok = EGL14.eglChooseConfig(dpy, configAttrs(0, true), 0, cfgs, 0, 1, n, 0) && n[0] >= 1;
            if (!ok) ok = EGL14.eglChooseConfig(dpy, configAttrs(0, false), 0, cfgs, 0, 1, n, 0) && n[0] >= 1;
            if (!ok) { log("no config"); return false; }
            cfg = cfgs[0];
            ctx = EGL14.eglCreateContext(dpy, cfg, EGL14.EGL_NO_CONTEXT, new int[] { EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE }, 0);
            bound = view.surface;
            surf = EGL14.eglCreateWindowSurface(dpy, cfg, bound, new int[] { EGL14.EGL_NONE }, 0);
            if (ctx == EGL14.EGL_NO_CONTEXT || surf == EGL14.EGL_NO_SURFACE) { log("create failed " + EGL14.eglGetError()); return false; }
            log("created ok");
            return true;
        } catch (Throwable t) { Platforms.error("EGL create", t); return false; }
    }
    @Override public boolean makeCurrent() {
        boolean ok = EGL14.eglMakeCurrent(dpy, surf, surf, ctx);
        if (!ok) log("makeCurrent failed " + EGL14.eglGetError());
        return ok;
    }
    @Override public void release() { EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT); }
    private int frame, inGame;
    private long lastSwapEnd;
    private boolean sampling;

    /** Keeps sampling the client thread's stack and publishes where the time goes (top frame, and the first client/renderer frame) for the FPS overlay. */
    private void startSampler(final Thread target) {
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                java.util.HashMap<String, Integer> top = new java.util.HashMap<>(), app = new java.util.HashMap<>();
                int n = 0, rounds = 0;
                try {
                    while (true) {
                        StackTraceElement[] st = target.getStackTrace();
                        if (st.length > 0) {
                            n++;
                            String k = st[0].getClassName() + "." + st[0].getMethodName();
                            top.merge(k, 1, Integer::sum);
                            String a = "(none)";
                            for (StackTraceElement e : st) {
                                String c = e.getClassName();
                                if (c.startsWith("rt4.") || c.startsWith("app.rsps2009")) { a = c.substring(c.lastIndexOf('.') + 1) + "." + e.getMethodName() + ":" + e.getLineNumber(); break; }
                            }
                            app.merge(a, 1, Integer::sum);
                        }
                        if (n >= 150) {
                            Settings.profTop = fmt(top, n, 3);
                            Settings.profApp = fmt(app, n, 4);
                            if (rounds++ < 3) { log("PROFILE " + n + " samples. TOP FRAME: " + fmt(top, n, 9)); log("PROFILE FIRST CLIENT FRAME: " + fmt(app, n, 9)); }
                            top.clear(); app.clear(); n = 0;
                        }
                        Thread.sleep(12);
                    }
                } catch (Throwable ignored) { }
            }
        }, "sampler");
        t.setDaemon(true);
        t.start();
    }

    private static String fmt(java.util.HashMap<String, Integer> m, int n, int lim) {
        java.util.ArrayList<java.util.Map.Entry<String, Integer>> l = new java.util.ArrayList<>(m.entrySet());
        java.util.Collections.sort(l, new java.util.Comparator<java.util.Map.Entry<String, Integer>>() {
            @Override public int compare(java.util.Map.Entry<String, Integer> a, java.util.Map.Entry<String, Integer> b) { return b.getValue() - a.getValue(); }
        });
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(lim, l.size()); i++) sb.append(l.get(i).getValue() * 100 / Math.max(1, n)).append("% ").append(l.get(i).getKey()).append("\n");
        return sb.toString();
    }
    private boolean autoReinit;
    private String px(com.jogamp.opengl.GL2 gl, int w, int h) {
        java.nio.ByteBuffer bb = java.nio.ByteBuffer.allocateDirect(4).order(java.nio.ByteOrder.nativeOrder());
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= 3; i++) {
            bb.clear();
            gl.glReadPixels(w * i / 4, h / 2, 1, 1, 0x1908, 0x1401, bb);
            sb.append(String.format(" %02x%02x%02x%02x", bb.get(0) & 255, bb.get(1) & 255, bb.get(2) & 255, bb.get(3) & 255));
        }
        return sb.toString();
    }
    private void diag() {
        try {
            com.jogamp.opengl.GL2 gl = (com.jogamp.opengl.GL2) com.jogamp.opengl.GLContext.getCurrentGL();
            int[] wh = new int[2];
            EGL14.eglQuerySurface(dpy, surf, EGL14.EGL_WIDTH, wh, 0);
            EGL14.eglQuerySurface(dpy, surf, EGL14.EGL_HEIGHT, wh, 1);
            String before = px(gl, wh[0], wh[1]);
            gl.glDisable(0x0B90); gl.glDisable(0x0C11); gl.glDisable(0x0BE2); gl.glDisable(0x0B71);
            gl.glClearColor(1f, 0f, 1f, 1f);
            gl.glClear(0x4000);
            String after = px(gl, wh[0], wh[1]);
            log("GPU diag frame " + frame + " surface " + wh[0] + "x" + wh[1] + " game:" + before + " | after magenta clear (want ff00ffff):" + after
                + " | LIBGL_ES=" + android.system.Os.getenv("LIBGL_ES") + " | surfaceValid=" + view.surface.isValid() + " viewVis=" + view.getVisibility() + " viewSize=" + view.getWidth() + "x" + view.getHeight());
        } catch (Throwable t) { Platforms.error("diag failed", t); }
    }

    private int gi(com.jogamp.opengl.GL2 gl, int name, int n) {
        int[] v = new int[4];
        gl.glGetIntegerv(name, v, 0);
        return v[n];
    }
    private String q(com.jogamp.opengl.GL2 gl, int name, int cnt) {
        int[] v = new int[4];
        gl.glGetIntegerv(name, v, 0);
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < cnt; i++) b.append(i > 0 ? "," : "").append(v[i]);
        return b.toString();
    }
    /** Build 54 diagnostic: logs raw GL state, then draws a magenta half-screen + green square with every state turned off. */
    private void testQuad(boolean report) { testQuad(report, true); }
    private void testQuad(boolean report, boolean visible) {
        try {
            com.jogamp.opengl.GL2 gl = (com.jogamp.opengl.GL2) com.jogamp.opengl.GLContext.getCurrentGL();
            int[] wh = new int[2];
            EGL14.eglQuerySurface(dpy, surf, EGL14.EGL_WIDTH, wh, 0);
            EGL14.eglQuerySurface(dpy, surf, EGL14.EGL_HEIGHT, wh, 1);
            if (report) {
                log("STATE scissorBox=" + q(gl, 0x0C10, 4) + " viewport=" + q(gl, 0x0BA2, 4) + " colorMask=" + q(gl, 0x0C23, 4)
                    + " scissorOn=" + q(gl, 0x0C11, 1) + " depthOn=" + q(gl, 0x0B71, 1) + " depthMask=" + q(gl, 0x0B72, 1)
                    + " depthFunc=" + q(gl, 0x0B74, 1) + " cullOn=" + q(gl, 0x0B44, 1) + " matrixMode=" + q(gl, 0x0BA0, 1)
                    + " fb=" + q(gl, 0x8CA6, 1) + " arrayBuf=" + q(gl, 0x8894, 1) + " elemBuf=" + q(gl, 0x8895, 1));
                log("STATE before test: " + px(gl, wh[0], wh[1]));
            }
            gl.glPushAttrib(-1);
            gl.glViewport(0, 0, wh[0], wh[1]);
            gl.glMatrixMode(0x1701); gl.glPushMatrix(); gl.glLoadIdentity();
            gl.glMatrixMode(0x1700); gl.glPushMatrix(); gl.glLoadIdentity();
            gl.glDisable(0x0C11); gl.glDisable(0x0B71); gl.glDisable(0x0BE2); gl.glDisable(0x0B44);
            gl.glDisable(0x0B50); gl.glDisable(0x0B60); gl.glDisable(0x0DE1); gl.glDisable(0x0BC0);
            gl.glColor4f(1f, 0f, 1f, 1f);
            gl.glBegin(7);
            float o = visible ? 0f : 5f;
            gl.glVertex2f(-1f + o, -1f + o); gl.glVertex2f(0f + o, -1f + o); gl.glVertex2f(0f + o, 1f + o); gl.glVertex2f(-1f + o, 1f + o);
            gl.glEnd();
            gl.glColor4f(0f, 1f, 0f, 1f);
            gl.glBegin(7);
            gl.glVertex2f(0.4f + o, -0.3f + o); gl.glVertex2f(0.8f + o, -0.3f + o); gl.glVertex2f(0.8f + o, 0.3f + o); gl.glVertex2f(0.4f + o, 0.3f + o);
            gl.glEnd();
            if (report) log("STATE after test quad (want ff00ffff at left): " + px(gl, wh[0], wh[1]));
            gl.glMatrixMode(0x1700); gl.glPopMatrix();
            gl.glMatrixMode(0x1701); gl.glPopMatrix();
            gl.glPopAttrib();
        } catch (Throwable t) { Platforms.error("testQuad failed", t); }
    }
    /** Re-attach to the view's current surface (it gets rebuilt when the size changes). */
    private boolean rebind() {
        try {
            EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
            if (surf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, surf);
            surf = EGL14.EGL_NO_SURFACE;
            long end = System.currentTimeMillis() + 3000;
            while (view.surface == null || !view.surface.isValid()) {
                if (System.currentTimeMillis() > end) return false;
                Thread.sleep(10);
            }
            bound = view.surface;
            surf = EGL14.eglCreateWindowSurface(dpy, cfg, bound, new int[] { EGL14.EGL_NONE }, 0);
            if (surf == EGL14.EGL_NO_SURFACE) { log("rebind create failed " + EGL14.eglGetError()); return false; }
            boolean ok = EGL14.eglMakeCurrent(dpy, surf, surf, ctx);
            if (rebinds++ < 6) log("rebound surface #" + rebinds + " ok=" + ok);
            return ok;
        } catch (Throwable t) { Platforms.error("rebind", t); return false; }
    }
    @Override public void swap() {
        frame++;
        Settings.frameCount++;
        if (inGame == 200 && !sampling) { sampling = true; startSampler(Thread.currentThread()); }
        rt4.ColorGrade.frameDone();
        rt4.PostFx.frameDone();
        com.jogamp.opengl.GL2.resetStateCache();
        if (frame == 120) { diag(); log("VBO supported=" + rt4.GlRenderer.arbVboSupported); }
        if (rt4.client.gameState == 30) inGame++;
        if (inGame == 250) com.jogamp.opengl.GlNative.dbg = true;
        if (inGame == 254) { com.jogamp.opengl.GlNative.dbg = false; log("GLCALLS in-game(4 frames) " + com.jogamp.opengl.GlNative.report()); }
        if (false) {
            try {
                com.jogamp.opengl.GL2 gl = (com.jogamp.opengl.GL2) com.jogamp.opengl.GLContext.getCurrentGL();
                gl.glClearColor(1f, 0f, 1f, 1f);
                gl.glClear(0x4000);
            } catch (Throwable t) { }
        }
        // Build 55 ran fine with a push/draw/pop pass here and build 56 (without it) crashed, so keep an invisible one until the real cause is known.
        // Build 62: stabilizer off (its glPushAttrib(-1) every frame is expensive in gl4es; the crash it hid was the vertex-program parser, fixed in build 58).
        if (false && inGame >= 1) testQuad(false, false);
        // First-time renderer state comes out wrong (opaque shadows / chat box) until the client rebuilds its renderer once,
        // which is what toggling the anti-aliasing setting does. Do that rebuild automatically, once, just after entering the world.
        // Prefer doing it on the login screen so the world never shows the broken first pass; if the player got in before that, do it in-world.
        if (inGame == 6 && !autoReinit) { autoReinit = true; rt4.GameShell.replaceCanvas = true; log("auto renderer rebuild"); }
        if (view.surface != bound && view.surface != null) rebind();
        long t0 = System.nanoTime();
        boolean ok = EGL14.eglSwapBuffers(dpy, surf);
        long t1 = System.nanoTime();
        Settings.swapNs += t1 - t0;
        if (lastSwapEnd != 0) Settings.frameNs += t1 - lastSwapEnd;
        lastSwapEnd = t1;
        Settings.glCalls += com.jogamp.opengl.GlNative.calls;
        com.jogamp.opengl.GlNative.calls = 0;
        if (!ok) {
            int err = EGL14.eglGetError();
            if (rebinds < 6) log("swap failed frame " + frame + " err " + err);
            if (rebind()) EGL14.eglSwapBuffers(dpy, surf);
        }
    }
    @Override public void destroy() {
        // Intentionally keeps the EGL context and surface alive (see create()); only detach from this thread.
        try { release(); } catch (Throwable ignored) { }
    }
}
