package app.rsps2009;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/** Custom RuneScape-styled loading + login screen drawn over the game surface. */
final class LoginOverlay extends FrameLayout {
    private static final int GOLD = Color.rgb(255, 176, 0);
    private static final int PARCH = Color.rgb(220, 205, 160);
    private static final int STONE = Color.rgb(62, 53, 41);

    private final Handler h = new Handler(Looper.getMainLooper());
    private final BarView bar;
    private final TextView status, error;
    private TextView backLink;
    private final LinearLayout form;
    private final EditText user, pass;
    private final LinearLayout accountsBox, manualBox;
    private final View panelView;
    private boolean manual, fadingOut, formShown;
    private java.util.List<String[]> accounts = new java.util.ArrayList<String[]>();
    private final CheckBox remember;
    private final Button login;
    private final File dir;
    private final float d;

    private boolean inWorld, attempting, sawBusy, wasInGame, autoDone, prefilled;
    private final TransitionView tv;
    private boolean loggingOut, enterWait;
    private long logoutAt, enterAt;
    private long attemptAt, lastLoadChange;
    private String lastLoadKey = "";

    LoginOverlay(Context c, File filesDir) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        dir = filesDir;
        setClickable(true);
        setFocusable(true);
        setFocusableInTouchMode(true);

        setBackground(new BgDrawable());

        ScrollView sv = new ScrollView(c);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        addView(sv, new LayoutParams(-1, -1));

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(16), dp(18), dp(16), dp(12));
        sv.addView(col, new ScrollView.LayoutParams(-1, -2));

        TextView title = new ShimmerTitle(c);
        title.setText("Rainbow Scape");
        title.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        title.setTextSize(38);
        title.setTextColor(GOLD);
        title.setShadowLayer(dp(2), dp(2), dp(2), Color.BLACK);
        title.setGravity(Gravity.CENTER);
        col.addView(title);

        TextView sub = new TextView(c);
        sub.setText("MOBILE");
        sub.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        sub.setTextSize(13);
        sub.setLetterSpacing(0.5f);
        sub.setTextColor(PARCH);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, dp(10));
        col.addView(sub);

        FrameLayout panel = new FrameLayout(c);
        panel.setBackground(panelBg());
        panel.setPadding(dp(14), dp(12), dp(14), dp(12));
        col.addView(panel, new LinearLayout.LayoutParams(dp(330), -2));
        panelView = panel;

        LinearLayout in = new LinearLayout(c);
        in.setOrientation(LinearLayout.VERTICAL);
        in.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.addView(in, new LayoutParams(-1, -2));

        bar = new BarView(c);
        in.addView(bar, new LinearLayout.LayoutParams(-1, dp(210)));

        status = label(c, "Loading...", 13, PARCH);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(6), 0, 0);
        in.addView(status, new LinearLayout.LayoutParams(-1, -2));

        form = new LinearLayout(c);
        form.setOrientation(LinearLayout.VERTICAL);
        in.addView(form, new LinearLayout.LayoutParams(-1, -2));

        accountsBox = new LinearLayout(c);
        accountsBox.setOrientation(LinearLayout.VERTICAL);

        manualBox = new LinearLayout(c);
        manualBox.setOrientation(LinearLayout.VERTICAL);
        manualBox.addView(label(c, "Login", 14, GOLD));
        user = field(c, "Username", false);
        manualBox.addView(user, fieldLp());
        pass = field(c, "Password", true);
        manualBox.addView(pass, fieldLp());

        remember = new CheckBox(c);
        remember.setText("Remember me (up to 3 accounts)");
        remember.setTextColor(PARCH);
        remember.setChecked(true);
        remember.setButtonTintList(android.content.res.ColorStateList.valueOf(GOLD));
        manualBox.addView(remember);

        login = new Button(c);
        login.setText("Login");
        login.setAllCaps(false);
        login.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        login.setTextSize(17);
        login.setTextColor(GOLD);
        login.setBackground(pressable(btnBg()));
        login.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) { submit(); }
        });
        pressScale(login);
        manualBox.addView(login, new LinearLayout.LayoutParams(-1, dp(46)));

        final TextView back = label(c, "< Back to saved accounts", 13, PARCH);
        back.setGravity(Gravity.CENTER);
        back.setPadding(0, dp(10), 0, dp(4));
        back.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) {
                manual = false;
                error.setText("");
                hideIme();
                refreshAccounts();
                animateIn();
            }
        });
        backLink = back;
        manualBox.addView(back);

        form.addView(accountsBox, new LinearLayout.LayoutParams(-1, -2));
        form.addView(manualBox, new LinearLayout.LayoutParams(-1, -2));

        error = label(c, "", 13, Color.rgb(255, 90, 70));
        error.setGravity(Gravity.CENTER);
        error.setPadding(0, dp(6), 0, 0);
        form.addView(error);

        pass.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int a, android.view.KeyEvent e) {
                submit();
                return true;
            }
        });
        tv = new TransitionView(c);
        addView(tv, new LayoutParams(-1, -1));
        tv.setVisibility(GONE);
        form.setVisibility(GONE);
        h.post(poll);
        h.post(animTick);
    }

    // ---------------------------------------------------------------- accounts

    private void refreshAccounts() {
        accounts = rt4.SavedAccount.load(dir);
        accountsBox.removeAllViews();
        boolean showList = !accounts.isEmpty() && !manual;
        if (showList) {
            Context c = getContext();
            accountsBox.addView(label(c, "Choose an account", 14, GOLD));
            int i = 0;
            for (final String[] a : accounts) {
                View card = accountCard(c, a);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(58));
                lp.topMargin = dp(8);
                accountsBox.addView(card, lp);
                card.setAlpha(0f);
                card.setTranslationY(dp(18));
                card.animate().alpha(1f).translationY(0f).setStartDelay(90L * i).setDuration(280L).start();
                i++;
            }
            if (accounts.size() < rt4.SavedAccount.MAX_ACCOUNTS) {
                TextView add = label(c, "+  Add account", 15, GOLD);
                add.setGravity(Gravity.CENTER);
                add.setBackground(pressable(addBg()));
                add.setOnClickListener(new OnClickListener() {
                    @Override public void onClick(View v) {
                        manual = true;
                        user.setText("");
                        pass.setText("");
                        error.setText("");
                        refreshAccounts();
                        animateIn();
                    }
                });
                pressScale(add);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(46));
                lp.topMargin = dp(10);
                accountsBox.addView(add, lp);
                add.setAlpha(0f);
                add.animate().alpha(1f).setStartDelay(90L * i).setDuration(280L).start();
            }
        }
        accountsBox.setVisibility(showList ? VISIBLE : GONE);
        manualBox.setVisibility(showList ? GONE : VISIBLE);
        backLink.setVisibility(accounts.isEmpty() ? GONE : VISIBLE);
    }

    private View accountCard(final Context c, final String[] a) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10), 0, dp(6), 0);
        row.setBackground(pressable(cardBg()));

        final String name = a[0];
        View avatar = new View(c) {
            private final Paint ap = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas cv) {
                float r = Math.min(getWidth(), getHeight()) / 2f;
                ap.setStyle(Paint.Style.FILL);
                ap.setColor(Color.rgb(24, 18, 11));
                cv.drawCircle(getWidth() / 2f, getHeight() / 2f, r, ap);
                ap.setShader(new LinearGradient(0, 0, 0, getHeight(), Color.rgb(255, 200, 70), Color.rgb(200, 120, 0), Shader.TileMode.CLAMP));
                cv.drawCircle(getWidth() / 2f, getHeight() / 2f, r * 0.88f, ap);
                ap.setShader(null);
                ap.setColor(Color.rgb(50, 30, 5));
                ap.setTextAlign(Paint.Align.CENTER);
                ap.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
                ap.setTextSize(r * 1.1f);
                cv.drawText(name.substring(0, 1).toUpperCase(), getWidth() / 2f, getHeight() / 2f + r * 0.38f, ap);
            }
        };
        row.addView(avatar, new LinearLayout.LayoutParams(dp(38), dp(38)));

        LinearLayout mid = new LinearLayout(c);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setPadding(dp(10), 0, 0, 0);
        TextView n = label(c, name, 17, Color.rgb(255, 232, 160));
        n.setSingleLine(true);
        mid.addView(n);
        TextView sub = new TextView(c);
        sub.setText("Saved  -  " + ago(a[2]));
        sub.setTextSize(12);
        sub.setTextColor(Color.rgb(170, 155, 120));
        mid.addView(sub);
        row.addView(mid, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView x = new TextView(c);
        x.setText("\u2715");
        x.setTextSize(16);
        x.setTextColor(Color.rgb(180, 120, 100));
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) {
                new android.app.AlertDialog.Builder(c)
                        .setMessage("Forget " + name + "?")
                        .setPositiveButton("Forget", new android.content.DialogInterface.OnClickListener() {
                            @Override public void onClick(android.content.DialogInterface dd, int w) {
                                rt4.SavedAccount.remove(dir, name);
                                refreshAccounts();
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        });
        row.addView(x, new LinearLayout.LayoutParams(dp(40), dp(40)));

        row.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) {
                user.setText(a[0]);
                pass.setText(a[1]);
                remember.setChecked(true);
                submit();
            }
        });
        pressScale(row);
        return row;
    }

    private static String ago(String ts) {
        try {
            long t = Long.parseLong(ts);
            if (t <= 0) return "not played yet";
            long m = (System.currentTimeMillis() - t) / 60000L;
            if (m < 1) return "played just now";
            if (m < 60) return "played " + m + " min ago";
            if (m < 60 * 24) return "played " + (m / 60) + " h ago";
            return "played " + (m / (60 * 24)) + " d ago";
        } catch (Throwable e) {
            return "";
        }
    }

    private android.graphics.drawable.Drawable cardBg() {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] {Color.rgb(88, 76, 58), Color.rgb(50, 42, 31)});
        g.setStroke(dp(2), Color.rgb(22, 16, 10));
        g.setCornerRadius(dp(5));
        return g;
    }

    private android.graphics.drawable.Drawable addBg() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.argb(60, 255, 176, 0));
        g.setStroke(dp(2), Color.argb(170, 255, 176, 0), dp(6), dp(4));
        g.setCornerRadius(dp(5));
        return g;
    }

    private android.graphics.drawable.Drawable pressable(android.graphics.drawable.Drawable base) {
        return new android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(Color.argb(90, 255, 200, 90)), base, null);
    }

    private void pressScale(View v) {
        v.setOnTouchListener(new OnTouchListener() {
            @Override public boolean onTouch(View view, android.view.MotionEvent e) {
                int a = e.getActionMasked();
                if (a == android.view.MotionEvent.ACTION_DOWN) {
                    view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80L).start();
                } else if (a == android.view.MotionEvent.ACTION_UP || a == android.view.MotionEvent.ACTION_CANCEL) {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(140L).start();
                }
                return false;
            }
        });
    }

    /** Fade and slide the form in. */
    private void animateIn() {
        form.setAlpha(0f);
        form.setTranslationY(dp(14));
        form.animate().alpha(1f).translationY(0f).setStartDelay(0L).setDuration(260L).start();
    }

    /** Short horizontal shake of the panel (wrong password, can't connect...). */
    private void shake() {
        android.animation.ValueAnimator va = android.animation.ValueAnimator.ofFloat(0f, 1f);
        va.setDuration(420L);
        va.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(android.animation.ValueAnimator an) {
                float t = (Float) an.getAnimatedValue();
                panelView.setTranslationX((float) (Math.sin(t * Math.PI * 6) * (1f - t) * dp(12)));
            }
        });
        va.start();
    }

    /** Gold shimmer sweeping across the title. */
    private final class ShimmerTitle extends TextView {
        ShimmerTitle(Context c) { super(c); }
        @Override protected void onDraw(Canvas cv) {
            float w = Math.max(1f, getWidth());
            float t = (System.currentTimeMillis() % 2600L) / 2600f;
            float x = -w * 0.4f + t * w * 1.8f;
            Shader sh = new LinearGradient(x, 0, x + w * 0.35f, 0,
                    new int[] {GOLD, Color.rgb(255, 245, 190), GOLD}, new float[] {0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
            getPaint().setShader(sh);
            super.onDraw(cv);
            getPaint().setShader(null);
            postInvalidateOnAnimation();
        }
    }

    /** Full-screen animated cover shown while logging in, entering the world and logging out (hides the stock title screen). */
    private final class TransitionView extends View {
        private final android.graphics.Paint ring = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Paint dot = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Paint txt = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Paint sub = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private String text = "";
        TransitionView(Context c) {
            super(c);
            setClickable(true);
            ring.setStyle(android.graphics.Paint.Style.STROKE);
            ring.setStrokeCap(android.graphics.Paint.Cap.ROUND);
            txt.setTextAlign(android.graphics.Paint.Align.CENTER);
            txt.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
            sub.setTextAlign(android.graphics.Paint.Align.CENTER);
            sub.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        }
        void show(String t) {
            text = t;
            if (getVisibility() != VISIBLE) setVisibility(VISIBLE);
            invalidate();
        }
        void hide() { if (getVisibility() != GONE) setVisibility(GONE); }
        @Override protected void onDraw(Canvas cv) {
            int w = getWidth(), hh = getHeight();
            float cx = w / 2f, cy = hh * 0.44f;
            long now = System.currentTimeMillis();
            Shader bg = new android.graphics.RadialGradient(cx, cy, Math.max(w, hh) * 0.75f,
                    new int[] {Color.rgb(24, 20, 44), Color.rgb(8, 9, 16)}, new float[] {0f, 1f}, Shader.TileMode.CLAMP);
            android.graphics.Paint bp = new android.graphics.Paint();
            bp.setShader(bg);
            cv.drawRect(0, 0, w, hh, bp);
            float r = Math.min(w, hh) * 0.13f;
            float t = (now % 1700L) / 1700f;
            int[] cols = new int[8];
            for (int i = 0; i < 8; i++) {
                float hue = (i / 7f) * 300f;
                int a = Math.round(255f * (i / 7f));
                cols[i] = Color.HSVToColor(a, new float[] {hue, 0.75f, 1f});
            }
            ring.setStrokeWidth(r * 0.30f);
            ring.setShader(new android.graphics.SweepGradient(cx, cy, cols, null));
            cv.save();
            cv.rotate(t * 360f, cx, cy);
            cv.drawArc(new android.graphics.RectF(cx - r, cy - r, cx + r, cy + r), 0f, 300f, false, ring);
            cv.restore();
            ring.setShader(null);
            // three small glowing stars orbiting the other way
            for (int k = 0; k < 3; k++) {
                double ang = -(now % 3200L) / 3200.0 * Math.PI * 2 + k * Math.PI * 2 / 3;
                float ox = cx + (float) Math.cos(ang) * r * 1.65f, oy = cy + (float) Math.sin(ang) * r * 1.65f;
                int c1 = Color.HSVToColor(255, new float[] {(k * 120f + (now % 3600L) / 10f) % 360f, 0.6f, 1f});
                dot.setColor(c1);
                dot.setAlpha(70);
                cv.drawCircle(ox, oy, r * 0.16f, dot);
                dot.setAlpha(255);
                cv.drawCircle(ox, oy, r * 0.07f, dot);
            }
            float pulse = 0.65f + 0.35f * (float) Math.sin(now / 380.0);
            txt.setTextSize(Math.min(w, hh) * 0.055f);
            txt.setColor(Color.argb(Math.round(255 * pulse), 255, 214, 90));
            txt.setShadowLayer(dp(2), dp(1), dp(1), Color.BLACK);
            cv.drawText(text, cx, cy + r * 2.55f, txt);
            sub.setTextSize(Math.min(w, hh) * 0.034f);
            sub.setColor(Color.argb(190, 200, 190, 230));
            cv.drawText("Rainbow Scape", cx, cy + r * 3.5f, sub);
            postInvalidateOnAnimation();
        }
    }

    private final Runnable animTick = new Runnable() {
        @Override public void run() {
            if (getVisibility() == VISIBLE) {
                invalidate();
            }
            h.postDelayed(this, 33L);
        }
    };

    private int dp(int v) { return (int) (v * d + 0.5f); }

    private TextView label(Context c, String t, int sp, int color) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        return v;
    }

    private LinearLayout.LayoutParams fieldLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(44));
        lp.topMargin = dp(6);
        return lp;
    }

    private EditText field(Context c, String hint, boolean pw) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(130, 120, 95));
        e.setTextColor(Color.rgb(255, 240, 190));
        e.setSingleLine(true);
        e.setTextSize(16);
        e.setPadding(dp(10), 0, dp(10), 0);
        e.setInputType(pw ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD
                : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.setImeOptions(pw ? EditorInfo.IME_ACTION_GO : EditorInfo.IME_ACTION_NEXT);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.rgb(20, 16, 11));
        g.setStroke(dp(2), Color.rgb(105, 90, 62));
        g.setCornerRadius(dp(2));
        e.setBackground(g);
        return e;
    }

    private GradientDrawable panelBg() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(STONE);
        g.setStroke(dp(3), Color.rgb(20, 15, 9));
        g.setCornerRadius(dp(3));
        return g;
    }

    private android.graphics.drawable.Drawable btnBg() {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] {Color.rgb(95, 80, 56), Color.rgb(52, 42, 29)});
        g.setStroke(dp(2), Color.rgb(20, 15, 9));
        g.setCornerRadius(dp(3));
        return g;
    }

    private void submit() {
        if (attempting) return;
        String u = user.getText().toString().trim();
        String p = pass.getText().toString();
        if (u.isEmpty() || p.isEmpty()) {
            error.setText("Please enter your username and password.");
            return;
        }
        hideIme();
        error.setText("");
        attempting = true;
        sawBusy = false;
        attemptAt = System.currentTimeMillis();
        rt4.SavedAccount.request(u, p, remember.isChecked());
    }

    private void ime(boolean pan) {
        if (getContext() instanceof android.app.Activity) {
            ((android.app.Activity) getContext()).getWindow().setSoftInputMode(pan
                    ? android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
                    : android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        }
    }

    private void hideIme() {
        InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(getWindowToken(), 0);
    }

    private void prefill() {
        prefilled = true;
        manual = false;
        refreshAccounts();
    }

    private static String replyText(int r) {
        switch (r) {
            case 3: return "Invalid username or password.";
            case 4: return "Your account has been disabled.";
            case 5: return "Your account is already logged in. Try again in a minute.";
            case 6: case 14: return "The server is being updated. Try again in a minute.";
            case 7: return "This world is full.";
            case 9: case 16: return "Too many login attempts. Wait and try again.";
            case 12: return "This world needs a members account.";
            case 18: return "Your account is locked.";
            case 26: return "Your connection has been blocked.";
            case -4: case 8: case 10: case 11: case 20: case 23: case -5:
                return "Unable to connect to the server.";
            default: return "Login failed (code " + r + ").";
        }
    }

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            try {
                update();
            } catch (Throwable ignored) {
            }
            if (getVisibility() == VISIBLE || true) h.postDelayed(this, 120);
        }
    };

    private void ensureVisible() {
        if (getVisibility() != VISIBLE) {
            animate().cancel();
            fadingOut = false;
            setAlpha(1f);
            setVisibility(VISIBLE);
        }
    }

    private void update() {
        int gs = rt4.client.gameState;
        long nowT = System.currentTimeMillis();
        // logging out: cover the game at once, keep covering until the login form is ready
        if (gs == 30 && rt4.SavedAccount.intentionalLogout && !loggingOut) {
            loggingOut = true; logoutAt = nowT; enterWait = false;
        }
        if (loggingOut) {
            if (gs == 30 && nowT - logoutAt > 6000L) {
                loggingOut = false;          // logout did not happen (e.g. in combat): back to the game
                rt4.SavedAccount.intentionalLogout = false;
            } else if (gs != 30 || rt4.SavedAccount.intentionalLogout) {
                inWorld = false; wasInGame = false;
                if (gs == 10 && nowT - logoutAt > 1300L) {
                    loggingOut = false;
                    tv.hide();
                } else {
                    if (getVisibility() != VISIBLE) { animate().cancel(); setAlpha(0f); setVisibility(VISIBLE); animate().alpha(1f).setDuration(220L).start(); }
                    form.setVisibility(GONE); bar.setVisibility(GONE);
                    tv.show("Logging out...");
                    return;
                }
            }
        }
        if (gs == 30) {
            wasInGame = true;
            inWorld = true;
            attempting = false;
            if (getVisibility() != GONE && !fadingOut) {
                hideIme();
                fadingOut = true;
                animate().alpha(0f).setDuration(380L).withEndAction(new Runnable() {
                    @Override public void run() {
                        setVisibility(GONE);
                        setAlpha(1f);
                        fadingOut = false;
                        enterWait = false;
                        tv.hide();
                        ime(false);
                    }
                }).start();
            }
            return;
        }
        if (gs == 40) {
            // connection lost: the game shows its own message and tries to reconnect
            if (getVisibility() != GONE) {
                setVisibility(GONE);
                ime(false);
            }
            return;
        }
        if (gs > 10 && gs < 30 && inWorld) {
            // moving between map regions while playing: never cover the game
            if (getVisibility() != GONE) {
                setVisibility(GONE);
                ime(false);
            }
            return;
        }
        if (gs <= 10) {
            inWorld = false;
        }
        if (getVisibility() != VISIBLE) {
            animate().cancel();
            fadingOut = false;
            setAlpha(1f);
            setVisibility(VISIBLE);
            ime(true);
        }
        if (gs < 10 || gs == 1000) {
            form.setVisibility(GONE);
            tv.hide();
            String t = rt4.client.mainLoadSecondaryText == null ? "Loading..." : rt4.client.mainLoadSecondaryText.toString();
            int pct = rt4.client.mainLoadPercentage;
            bar.setVisibility(VISIBLE);
            bar.set(pct, "");
            String key = pct + "|" + t + "|" + gs + "|" + rt4.client.mainLoadState;
            long nowMs = System.currentTimeMillis();
            if (!key.equals(lastLoadKey)) {
                lastLoadKey = key;
                lastLoadChange = nowMs;
            }
            if (nowMs - lastLoadChange > 15000L) {
                status.setText(t + "\nStill waiting for the server... check your connection.");
            } else {
                status.setText(t);
            }
            return;
        }
        if (gs == 10) {
            if (!prefilled) prefill();
            if (rt4.SavedAccount.reconnecting) {
                form.setVisibility(GONE);
                bar.setVisibility(VISIBLE);
                bar.set(-1, "");
                status.setText("Connection lost. Reconnecting...");
                return;
            }
            if (attempting) {
                int step = rt4.LoginManager.step;
                int hop = rt4.LoginManager.hopStep;
                if (step != 0 || hop != 0) sawBusy = true;
                if (sawBusy && step == 0 && hop == 0) {
                    attempting = false;
                    int r = rt4.LoginManager.reply;
                    if (r != 2) {
                        error.setText(replyText(r));
                        shake();
                    } else {
                        enterWait = true; enterAt = nowT;
                    }
                } else if (!sawBusy && System.currentTimeMillis() - attemptAt > 6000) {
                    attempting = false;
                    error.setText("Unable to connect to the server.");
                    shake();
                }
            }
            if (enterWait && nowT - enterAt < 25000L) {
                form.setVisibility(GONE); bar.setVisibility(GONE);
                tv.show("Entering Rainbow Scape...");
                return;
            }
            enterWait = false;
            if (attempting) {
                form.setVisibility(GONE);
                bar.setVisibility(VISIBLE);
                bar.set(-1, "");
                status.setText("Logging in...");
            } else {
                tv.hide();
                if (form.getVisibility() != VISIBLE) {
                    form.setVisibility(VISIBLE);
                    if (!inWorld) refreshAccounts();
                    animateIn();
                }
                bar.setVisibility(GONE);
                status.setText("Welcome to Rainbow Scape");
            }
            return;
        }
        // 20..29: logged in, loading the world
        form.setVisibility(GONE);
        bar.setVisibility(GONE);
        tv.show("Entering Rainbow Scape...");
    }

    // RuneScape herbs in Herblore-level order (RuneScape Wiki: Herb), drawn here as simple leaf sprigs.
    // name, leaf colour, flower colour (0 = none), potion colour (approximate)
    private static final String[] HERB_NAME = {
        "Guam leaf", "Marrentill", "Tarromin", "Harralander", "Ranarr weed", "Toadflax", "Irit leaf",
        "Avantoe", "Kwuarm", "Snapdragon", "Cadantine", "Lantadyme", "Dwarf weed", "Torstol"
    };
    private static final int[] HERB_LEAF = {
        0xFF58AA46, 0xFF468C50, 0xFF3C7846, 0xFF82AA3C, 0xFF3C9646, 0xFF64A05A, 0xFF3C963C,
        0xFF6EAA46, 0xFF46729A, 0xFF5AA050, 0xFF3C6E46, 0xFF5A9678, 0xFF326432, 0xFF503C6E
    };
    private static final int[] HERB_FLOWER = {
        0, 0, 0, 0, 0xFFE65A82, 0xFFF0A040, 0, 0, 0xFF9BD0FF, 0xFFF06AA0, 0, 0, 0, 0xFFB070F0
    };
    private static final int[] HERB_POTION = {
        0xFF5AE646, 0xFF28DCAA, 0xFF1EAA5A, 0xFFE6E628, 0xFF28D2E6, 0xFFF09628, 0xFFFFDC32,
        0xFFFF6E1E, 0xFF3278FF, 0xFFFF46A0, 0xFF1EC878, 0xFF5AC8FF, 0xFFE63C32, 0xFFA03CFF
    };

    /** Potion flask: herbs drop in one by one, each tinting the potion, and it fills as loading progresses. */
    private final class BarView extends View {
        private int pct = 0;
        private float shown = 0;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path flask = new Path();
        private final Path star = new Path();
        private final long t0 = System.currentTimeMillis();
        // sparkle: x, y (flask units, flask is 90 x 120), size, phase
        private final float[][] sparks = {
            {-34, 18, 11, 0.0f}, {112, 34, 13, 1.7f}, {-26, 76, 9, 3.1f},
            {108, 92, 8, 4.4f}, {20, -2, 7, 2.2f}, {82, 8, 6, 5.3f}, {-8, 110, 6, 0.9f}, {96, 120, 7, 3.8f}
        };
        private int lastHerb = -1;
        private int dropHerb = -1;
        private long dropStart;
        private boolean landed;
        private long splashAt;
        private final int[] bandCol = new int[14];
        private final long[] bandStart = new long[14];
        private int nb = 0;
        private final float[] col = {110, 120, 130};
        private final float[] target = {110, 120, 130};

        BarView(Context c) {
            super(c);
            setLayerType(LAYER_TYPE_SOFTWARE, null);
        }

        void set(int pct, String ignored) {
            this.pct = pct;
        }

        private void drawStar(Canvas c, float cx, float cy, float r) {
            star.reset();
            float in = r * 0.26f;
            star.moveTo(cx, cy - r);
            star.lineTo(cx + in, cy - in);
            star.lineTo(cx + r, cy);
            star.lineTo(cx + in, cy + in);
            star.lineTo(cx, cy + r);
            star.lineTo(cx - in, cy + in);
            star.lineTo(cx - r, cy);
            star.lineTo(cx - in, cy - in);
            star.close();
            c.drawPath(star, p);
        }

        /** A little herb sprig: stem, five leaves and an optional flower. u = unit size in px. */
        private void drawHerb(Canvas c, int herb, float cx, float cy, float u, float rot, int alpha) {
            c.save();
            c.translate(cx, cy);
            c.rotate(rot);
            int leaf = HERB_LEAF[herb];
            int dark = Color.rgb((int) (Color.red(leaf) * 0.6f), (int) (Color.green(leaf) * 0.6f), (int) (Color.blue(leaf) * 0.6f));
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(u * 0.5f);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(Color.argb(alpha, Color.red(dark), Color.green(dark), Color.blue(dark)));
            c.drawLine(0, u * 5f, 0, -u * 1f, p);
            p.setStyle(Paint.Style.FILL);
            float[][] leaves = {{-1, 0.6f, -50}, {1, 0.6f, 50}, {-1, -1.6f, -28}, {1, -1.6f, 28}, {0, -3.4f, 0}};
            for (float[] l : leaves) {
                c.save();
                c.translate(l[0] * u * 1.4f, l[1] * u * 1.3f);
                c.rotate(l[2]);
                p.setColor(Color.argb(alpha, Color.red(leaf), Color.green(leaf), Color.blue(leaf)));
                c.drawOval(new RectF(-u * 1.2f, -u * 2.6f, u * 1.2f, u * 1.2f), p);
                p.setColor(Color.argb(alpha, Color.red(dark), Color.green(dark), Color.blue(dark)));
                c.drawRect(-u * 0.12f, -u * 2.2f, u * 0.12f, u * 1.0f, p);
                c.restore();
            }
            if (HERB_FLOWER[herb] != 0) {
                int f = HERB_FLOWER[herb];
                p.setColor(Color.argb(alpha, Color.red(f), Color.green(f), Color.blue(f)));
                c.drawCircle(0, -u * 4.4f, u * 1.0f, p);
                c.drawCircle(-u * 1.2f, -u * 3.4f, u * 0.7f, p);
                c.drawCircle(u * 1.2f, -u * 3.4f, u * 0.7f, p);
            }
            c.restore();
        }

        /** Layered potion: one colour band per herb added, newest on top, each growing in as it lands. */
        private Shader bandShader(float yTop, float yBot, long now, int waterTop, int waterBot) {
            if (nb == 0) {
                return new LinearGradient(0, yTop, 0, yBot, Color.rgb(170, 200, 225), Color.rgb(90, 120, 150), Shader.TileMode.CLAMP);
            }
            float[] w = new float[nb];
            float sum = 0;
            for (int j = 0; j < nb; j++) {
                float k = Math.min(1f, (now - bandStart[j]) / 900f);
                w[j] = 0.05f + 0.95f * (k * k * (3f - 2f * k));
                sum += w[j];
            }
            int[] cols = new int[nb * 2];
            float[] pos = new float[nb * 2];
            float at = 0f;
            int i = 0;
            for (int j = nb - 1; j >= 0; j--) {
                float end = at + w[j] / sum;
                cols[i] = bandCol[j];
                pos[i++] = at;
                cols[i] = bandCol[j];
                pos[i++] = Math.min(1f, end);
                at = end;
            }
            pos[pos.length - 1] = 1f;
            return new LinearGradient(0, yTop, 0, yBot, cols, pos, Shader.TileMode.CLAMP);
        }

        @Override protected void onDraw(Canvas c) {
            float s = d * 1.0f;
            long now = System.currentTimeMillis();
            float t = (now - t0) / 1000f;
            float ox = getWidth() / 2f - 45 * s, oy = dp(26);
            float frac;
            int herbNow;
            if (pct >= 0) {
                shown += (Math.min(100, pct) / 100f - shown) * 0.12f;
                frac = 0.05f + 0.95f * shown;
                herbNow = Math.min(13, (int) (Math.min(100, pct) * 14 / 100f));
            } else {
                frac = 0.5f + 0.12f * (float) Math.sin(t * 2.2f);
                herbNow = ((int) (t / 1.6f)) % 14;
            }

            // herb drop state machine: one herb at a time
            if (dropHerb >= 0 && now - dropStart > 700) {
                dropHerb = -1;
            }
            if (dropHerb < 0) {
                if (pct < 0 && herbNow != lastHerb) {
                    lastHerb = herbNow;
                    dropHerb = herbNow;
                    dropStart = now;
                    landed = false;
                } else if (pct >= 0 && lastHerb < herbNow) {
                    lastHerb++;
                    dropHerb = lastHerb;
                    dropStart = now;
                    landed = false;
                }
            }
            float prog = dropHerb >= 0 ? (now - dropStart) / 700f : 1f;
            if (dropHerb >= 0 && !landed && prog > 0.62f) {
                landed = true;
                splashAt = now;
                if (nb >= 14) nb = 0;
                bandCol[nb] = HERB_POTION[dropHerb];
                bandStart[nb] = now;
                nb++;
                int pc = HERB_POTION[dropHerb];
                target[0] = Color.red(pc);
                target[1] = Color.green(pc);
                target[2] = Color.blue(pc);
            }
            for (int i = 0; i < 3; i++) {
                col[i] += (target[i] - col[i]) * 0.06f;
            }
            float splash = Math.max(0f, 1f - (now - splashAt) / 900f);

            // flask outline in absolute coordinates
            flask.reset();
            flask.moveTo(ox + 34 * s, oy + 14 * s);
            flask.lineTo(ox + 56 * s, oy + 14 * s);
            flask.lineTo(ox + 56 * s, oy + 46 * s);
            flask.lineTo(ox + 85 * s, oy + 100 * s);
            flask.quadTo(ox + 92 * s, oy + 118 * s, ox + 74 * s, oy + 118 * s);
            flask.lineTo(ox + 16 * s, oy + 118 * s);
            flask.quadTo(ox - 2 * s, oy + 118 * s, ox + 5 * s, oy + 100 * s);
            flask.lineTo(ox + 34 * s, oy + 46 * s);
            flask.close();

            // sparkles behind
            p.setStyle(Paint.Style.FILL);
            for (float[] k : sparks) {
                float tw = 0.5f + 0.5f * (float) Math.sin(t * 2.6f + k[3]);
                p.setColor(Color.argb((int) (60 + 195 * tw), 170, 205, 255));
                drawStar(c, ox + k[0] * s, oy + k[1] * s, k[2] * s * (0.55f + 0.6f * tw));
            }

            // glass body fill
            p.setColor(Color.argb(45, 200, 225, 255));
            c.drawPath(flask, p);

            // liquid, clipped to the flask
            int top1 = Color.rgb((int) col[0], (int) col[1], (int) col[2]);
            int bot1 = Color.rgb((int) (col[0] * 0.55f), (int) (col[1] * 0.55f), (int) (col[2] * 0.55f));
            float top = 118f - (118f - 48f) * Math.min(1f, frac);
            c.save();
            c.clipPath(flask);
            p.setShader(bandShader(oy + top * s, oy + 118 * s, now, top1, bot1));
            Path liquid = new Path();
            liquid.moveTo(ox - 5 * s, oy + 124 * s);
            float amp = 1.8f + 4.5f * splash;
            for (int x = -5; x <= 95; x += 4) {
                float y = top + amp * (float) Math.sin(t * (3f + 5f * splash) + x * 0.16f);
                liquid.lineTo(ox + x * s, oy + y * s);
            }
            liquid.lineTo(ox + 95 * s, oy + 124 * s);
            liquid.close();
            c.drawPath(liquid, p);
            // depth: darker toward the bottom
            p.setShader(new LinearGradient(0, oy + top * s, 0, oy + 118 * s, Color.argb(0, 0, 0, 0), Color.argb(110, 0, 0, 0), Shader.TileMode.CLAMP));
            c.drawPath(liquid, p);
            p.setShader(null);
            // bubbles
            p.setColor(Color.argb(150, 255, 255, 255));
            int nBub = 5 + (int) (6 * splash);
            for (int i = 0; i < nBub; i++) {
                float ph = (t * (0.35f + 0.07f * (i % 5)) + i * 0.37f) % 1f;
                float by = 116f - (116f - top) * ph;
                float bx = 26 + (i % 7) * 6 + 3 * (float) Math.sin(t * 2f + i);
                c.drawCircle(ox + bx * s, oy + by * s, (1.4f + (i % 3) * 0.7f) * s, p);
            }
            // surface shine
            p.setColor(Color.argb(110, 255, 255, 255));
            c.drawRect(ox, oy + (top - 0.5f) * s, ox + 90 * s, oy + (top + 1.2f) * s, p);
            c.restore();

            // glass highlight stripe
            p.setColor(Color.argb(95, 255, 255, 255));
            Path hl = new Path();
            hl.moveTo(ox + 30 * s, oy + 62 * s);
            hl.lineTo(ox + 36 * s, oy + 56 * s);
            hl.lineTo(ox + 18 * s, oy + 98 * s);
            hl.lineTo(ox + 13 * s, oy + 98 * s);
            hl.close();
            c.drawPath(hl, p);

            // outline
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.2f * s);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setColor(Color.argb(230, 225, 238, 255));
            c.drawPath(flask, p);
            p.setStyle(Paint.Style.FILL);

            // lip ring
            p.setColor(Color.rgb(228, 238, 255));
            c.drawRoundRect(new RectF(ox + 28 * s, oy + 11 * s, ox + 62 * s, oy + 20 * s), 2 * s, 2 * s, p);
            p.setColor(Color.rgb(150, 170, 205));
            c.drawRect(ox + 28 * s, oy + 18 * s, ox + 62 * s, oy + 20 * s, p);
            // cork, popped off and resting beside the flask
            c.save();
            c.translate(ox + 80 * s, oy + 4 * s);
            c.rotate(24);
            p.setColor(Color.rgb(176, 148, 62));
            c.drawRoundRect(new RectF(-13 * s, -7 * s, 13 * s, 8 * s), 2.5f * s, 2.5f * s, p);
            p.setColor(Color.rgb(120, 98, 38));
            c.drawRect(-13 * s, 4 * s, 13 * s, 8 * s, p);
            c.restore();

            // the falling herb
            if (dropHerb >= 0) {
                float k = Math.min(1f, prog / 0.62f);
                float hy = -34f + (24f + 34f) * k * k;
                float scale = prog > 0.62f ? Math.max(0.2f, 1f - (prog - 0.62f) / 0.38f * 0.8f) : 1f;
                int al = prog > 0.62f ? (int) (255 * (1f - (prog - 0.62f) / 0.38f)) : 255;
                drawHerb(c, dropHerb, ox + 45 * s, oy + hy * s, 3.3f * s * scale, 18f * (float) Math.sin(prog * 9f) + 200f * prog, Math.max(0, al));
            }

            // percentage and herb name under the flask
            p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
            if (pct >= 0) {
                p.setColor(Color.WHITE);
                p.setTextSize(dp(20));
                p.setShadowLayer(3, 1, 1, Color.BLACK);
                c.drawText(Math.min(100, pct) + "%", getWidth() / 2f, oy + 144 * s, p);
                p.clearShadowLayer();
            }
            if (lastHerb >= 0 || pct < 0) {
                int hn = dropHerb >= 0 ? dropHerb : Math.max(0, lastHerb);
                p.setColor(Color.argb(220, 255, 214, 130));
                p.setTextSize(dp(12));
                c.drawText("Adding " + HERB_NAME[hn], getWidth() / 2f, oy + 164 * s, p);
            }
            postInvalidateOnAnimation();
        }
    }

    /** Dark vignette background with a faint gold border pattern. */
    private final class BgDrawable extends android.graphics.drawable.Drawable {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Bitmap bg;
        private boolean bgTried;
        @Override public void draw(Canvas c) {
            Rect r = getBounds();
            // the embers leave a translucent colour on the paint; reset it or the picture draws nearly invisible
            p.setStyle(Paint.Style.FILL);
            p.setShader(null);
            p.setColor(Color.WHITE);
            p.setAlpha(255);
            if (bg == null && !bgTried) {
                bgTried = true;
                try {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inScaled = false;
                    bg = BitmapFactory.decodeResource(getResources(), R.drawable.login_bg, o);
                } catch (Throwable ignored) {
                }
            }
            if (bg != null) {
                // centre-crop the map picture over the whole screen
                float sc = Math.max(r.width() / (float) bg.getWidth(), r.height() / (float) bg.getHeight());
                float sw = bg.getWidth() * sc, sh = bg.getHeight() * sc;
                float l = r.left + (r.width() - sw) / 2f, t = r.top + (r.height() - sh) / 2f;
                p.setFilterBitmap(true);
                c.drawBitmap(bg, null, new RectF(l, t, l + sw, t + sh), p);
                // vignette so the panel and title stay readable
                p.setShader(new RadialGradient(r.exactCenterX(), r.exactCenterY(), Math.max(r.width(), r.height()) * 0.75f,
                        Color.argb(70, 0, 0, 0), Color.argb(190, 0, 0, 0), Shader.TileMode.CLAMP));
                c.drawRect(r, p);
            } else {
                p.setShader(new RadialGradient(r.exactCenterX(), r.exactCenterY(), Math.max(r.width(), r.height()) * 0.7f,
                        Color.rgb(48, 38, 26), Color.rgb(10, 7, 4), Shader.TileMode.CLAMP));
                c.drawRect(r, p);
            }
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            // drifting embers
            long now = System.currentTimeMillis();
            for (int i = 0; i < 34; i++) {
                float seed = i * 12.9898f;
                float speed = 0.03f + (i % 7) * 0.012f;
                float ph = ((now / 1000f) * speed + (i * 0.173f)) % 1f;
                float x = r.width() * (0.5f + 0.5f * (float) Math.sin(seed)) + dp(14) * (float) Math.sin(now / 900f + i);
                float y = r.height() * (1.05f - ph * 1.1f);
                float tw = 0.5f + 0.5f * (float) Math.sin(now / 350f + i * 2.1f);
                int a = (int) (190 * Math.sin(ph * Math.PI) * (0.4f + 0.6f * tw));
                p.setColor(Color.argb(Math.max(0, a), 255, 170 + (i % 4) * 20, 40));
                c.drawCircle(x, y, dp(1) + (i % 3) * 0.6f * d, p);
            }
        }
        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.OPAQUE; }
    }
}
