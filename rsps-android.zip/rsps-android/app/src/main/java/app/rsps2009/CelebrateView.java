package app.rsps2009;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

import rt4.CasinoFx;

/** Casino win celebration over everything: a coin shower, rainbow confetti and a big banner. Never takes touches. */
final class CelebrateView extends View {
    private static final int[] RAINBOW = {0xFFFF3B3B, 0xFFFF9A1E, 0xFFFFE62E, 0xFF4CFF6A, 0xFF2EE6FF, 0xFF4C7DFF, 0xFFC04CFF};
    private static final String[] TITLE = {"", "WIN!", "BIG WIN!", "MEGA WIN!", "JACKPOT!!!"};
    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Typeface bold = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD);
    private Typeface pixel;
    private int seen;
    private long startAt; private int tier; private String text = "";
    private final java.util.Random rnd = new java.util.Random();
    private float[] px, py, vx, vy, rot, vr; private int[] kind, col;
    private int n;

    CelebrateView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        try { pixel = Typeface.createFromAsset(c.getAssets(), "silkscreen.ttf"); } catch (Throwable t) { pixel = bold; }
        setVisibility(GONE);
        seen = CasinoFx.winVersion;
    }

    private long duration() { return tier >= 4 ? 7000 : tier == 3 ? 5000 : tier == 2 ? 4000 : 2200; }

    /** UI poller */
    void sync() {
        if (CasinoFx.winVersion != seen) {
            seen = CasinoFx.winVersion;
            tier = Math.max(1, Math.min(4, CasinoFx.winTier)); text = CasinoFx.winText == null ? "" : CasinoFx.winText;
            start();
        }
        boolean on = startAt > 0 && System.currentTimeMillis() - startAt < duration();
        if (getVisibility() != (on ? VISIBLE : GONE)) setVisibility(on ? VISIBLE : GONE);
        if (!on) startAt = 0;
    }

    private void start() {
        startAt = System.currentTimeMillis();
        n = tier >= 4 ? 260 : tier == 3 ? 180 : tier == 2 ? 120 : 50;
        px = new float[n]; py = new float[n]; vx = new float[n]; vy = new float[n]; rot = new float[n]; vr = new float[n]; kind = new int[n]; col = new int[n];
        float W = Math.max(1, getWidth()), H = Math.max(1, getHeight());
        for (int i = 0; i < n; i++) {
            boolean coin = i % 3 == 0 || tier == 1;
            kind[i] = coin ? 1 : 0;
            col[i] = RAINBOW[rnd.nextInt(RAINBOW.length)];
            if (i % 2 == 0) {                       // burst from the middle
                px[i] = W / 2; py[i] = H * 0.42f;
                double a = rnd.nextDouble() * Math.PI * 2; float sp = (300 + rnd.nextFloat() * 700) * d / 2.6f;
                vx[i] = (float) Math.cos(a) * sp; vy[i] = (float) Math.sin(a) * sp - 400 * d / 2.6f;
            } else {                                // rain from the top
                px[i] = rnd.nextFloat() * W; py[i] = -rnd.nextFloat() * H * 0.6f;
                vx[i] = (rnd.nextFloat() - 0.5f) * 80 * d / 2.6f; vy[i] = (120 + rnd.nextFloat() * 220) * d / 2.6f;
            }
            rot[i] = rnd.nextFloat() * 360; vr[i] = (rnd.nextFloat() - 0.5f) * 720;
        }
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        if (startAt == 0) return;
        long now = System.currentTimeMillis();
        float t = (now - startAt) / 1000f, dur = duration() / 1000f;
        float W = getWidth(), H = getHeight();
        float fadeAll = Math.min(1f, (dur - t) / 0.6f);
        // soft golden flash at the start
        if (t < 0.5f && tier >= 2) {
            p.setShader(new RadialGradient(W / 2, H * 0.42f, Math.max(W, H) * 0.6f, new int[] {((int) (140 * (1 - t / 0.5f)) << 24) | 0xFFE680, 0x00FFE680}, null, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, W, H, p); p.setShader(null);
        }
        float g = 900 * d / 2.6f, dt = 1 / 60f;
        for (int i = 0; i < n; i++) {
            // simple physics, stepped by time since start so it does not depend on the frame rate
            float tt = t;
            float x = px[i] + vx[i] * tt, y = py[i] + vy[i] * tt + 0.5f * (kind[i] == 1 ? g : g * 0.35f) * tt * tt;
            if (kind[i] == 0) x += (float) Math.sin(tt * 3 + i) * 18 * d;     // confetti flutters
            if (y > H + 30 * d) continue;
            float r = rot[i] + vr[i] * tt;
            int alpha = (int) (255 * Math.max(0, fadeAll));
            c.save();
            c.rotate(r, x, y);
            if (kind[i] == 1) {
                float s = 9 * d;
                float squash = Math.abs((float) Math.cos(Math.toRadians(r * 2)));
                p.setColor((alpha << 24) | 0xB8860B);
                c.drawOval(new android.graphics.RectF(x - s, y - s * (0.35f + 0.65f * squash), x + s, y + s * (0.35f + 0.65f * squash)), p);
                p.setColor((alpha << 24) | 0xFFD84A);
                c.drawOval(new android.graphics.RectF(x - s * 0.82f, y - s * 0.82f * (0.35f + 0.65f * squash), x + s * 0.82f, y + s * 0.82f * (0.35f + 0.65f * squash) * 0.9f), p);
            } else {
                p.setColor((alpha << 24) | (col[i] & 0xFFFFFF));
                c.drawRect(x - 4 * d, y - 2 * d, x + 4 * d, y + 2 * d, p);
            }
            c.restore();
        }
        // banner
        if (tier >= 1) {
            float pop = Math.min(1f, t / 0.25f);
            float sc = 0.6f + 0.4f * pop + (t < 0.4f ? 0.12f * (float) Math.sin(pop * Math.PI) : 0);
            float size = (tier >= 4 ? 46 : tier == 3 ? 40 : tier == 2 ? 34 : 26) * d * sc;
            p.setTypeface(pixel); p.setTextSize(size); p.setTextAlign(Paint.Align.CENTER);
            String title = TITLE[tier];
            float ty = H * 0.38f;
            int a = (int) (255 * Math.max(0, fadeAll));
            p.setShader(null); p.setColor(a << 24); c.drawText(title, W / 2 + 3 * d, ty + 3 * d, p);
            if (tier >= 4) {
                float tw = p.measureText(title);
                int[] rb = new int[RAINBOW.length]; for (int k = 0; k < rb.length; k++) rb[k] = (a << 24) | (RAINBOW[k] & 0xFFFFFF);
                p.setShader(new LinearGradient(W / 2 - tw / 2 - t * 200 * d, 0, W / 2 + tw / 2 - t * 200 * d, 0, rb, null, Shader.TileMode.MIRROR));
            } else {
                p.setShader(new LinearGradient(0, ty - size, 0, ty, (a << 24) | 0xFFF4C0, (a << 24) | (tier == 3 ? 0xFF9A1E : tier == 2 ? 0xFFD84A : 0xFFFFFF), Shader.TileMode.CLAMP));
            }
            c.drawText(title, W / 2, ty, p);
            p.setShader(null);
            if (text.length() > 0) {
                p.setTypeface(bold); p.setTextSize(20 * d);
                p.setColor(a << 24); c.drawText(text, W / 2 + 2 * d, ty + 34 * d + 2 * d, p);
                p.setColor((a << 24) | 0xFFFF66); c.drawText(text, W / 2, ty + 34 * d, p);
            }
            p.setTextAlign(Paint.Align.LEFT);
        }
        postInvalidateOnAnimation();
    }
}
