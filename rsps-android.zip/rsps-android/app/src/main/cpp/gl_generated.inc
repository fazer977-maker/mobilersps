/* generated */
typedef void (*t_glActiveTexture)(int); static t_glActiveTexture p_glActiveTexture;
typedef void (*t_glAlphaFunc)(int, float); static t_glAlphaFunc p_glAlphaFunc;
typedef void (*t_glBegin)(int); static t_glBegin p_glBegin;
typedef void (*t_glBindBuffer)(int, int); static t_glBindBuffer p_glBindBuffer;
typedef void (*t_glBindProgramARB)(int, int); static t_glBindProgramARB p_glBindProgramARB;
typedef void (*t_glBindTexture)(int, int); static t_glBindTexture p_glBindTexture;
typedef void (*t_glBlendFunc)(int, int); static t_glBlendFunc p_glBlendFunc;
typedef void (*t_glBufferData)(int, long long, void*, int); static t_glBufferData p_glBufferData;
typedef void (*t_glBufferSubData)(int, long long, long long, void*); static t_glBufferSubData p_glBufferSubData;
typedef void (*t_glCallList)(int); static t_glCallList p_glCallList;
typedef void (*t_glClearColor)(float, float, float, float); static t_glClearColor p_glClearColor;
typedef void (*t_glClearDepth)(double); static t_glClearDepth p_glClearDepth;
typedef void (*t_glClear)(int); static t_glClear p_glClear;
typedef void (*t_glClientActiveTexture)(int); static t_glClientActiveTexture p_glClientActiveTexture;
typedef void (*t_glColor3ub)(signed char, signed char, signed char); static t_glColor3ub p_glColor3ub;
typedef void (*t_glColor4fv)(float*); static t_glColor4fv p_glColor4fv;
typedef void (*t_glColor4f)(float, float, float, float); static t_glColor4f p_glColor4f;
typedef void (*t_glColor4ub)(signed char, signed char, signed char, signed char); static t_glColor4ub p_glColor4ub;
typedef void (*t_glColorMaterial)(int, int); static t_glColorMaterial p_glColorMaterial;
typedef void (*t_glColorPointer)(int, int, int, void*); static t_glColorPointer p_glColorPointer;
typedef void (*t_glCopyPixels)(int, int, int, int, int); static t_glCopyPixels p_glCopyPixels;
typedef void (*t_glCullFace)(int); static t_glCullFace p_glCullFace;
typedef void (*t_glDeleteBuffers)(int, int*); static t_glDeleteBuffers p_glDeleteBuffers;
typedef void (*t_glDeleteLists)(int, int); static t_glDeleteLists p_glDeleteLists;
typedef void (*t_glDeleteTextures)(int, int*); static t_glDeleteTextures p_glDeleteTextures;
typedef void (*t_glDepthFunc)(int); static t_glDepthFunc p_glDepthFunc;
typedef void (*t_glDepthMask)(unsigned char); static t_glDepthMask p_glDepthMask;
typedef void (*t_glDisableClientState)(int); static t_glDisableClientState p_glDisableClientState;
typedef void (*t_glDisable)(int); static t_glDisable p_glDisable;
typedef void (*t_glDrawBuffer)(int); static t_glDrawBuffer p_glDrawBuffer;
typedef void (*t_glDrawElements)(int, int, int, void*); static t_glDrawElements p_glDrawElements;
typedef void (*t_glDrawPixels)(int, int, int, int, void*); static t_glDrawPixels p_glDrawPixels;
typedef void (*t_glEnableClientState)(int); static t_glEnableClientState p_glEnableClientState;
typedef void (*t_glEnable)(int); static t_glEnable p_glEnable;
typedef void (*t_glEndList)(void); static t_glEndList p_glEndList;
typedef void (*t_glEnd)(void); static t_glEnd p_glEnd;
typedef void (*t_glFogfv)(int, float*); static t_glFogfv p_glFogfv;
typedef void (*t_glFogf)(int, float); static t_glFogf p_glFogf;
typedef void (*t_glFogi)(int, int); static t_glFogi p_glFogi;
typedef void (*t_glGenBuffers)(int, int*); static t_glGenBuffers p_glGenBuffers;
typedef int (*t_glGenLists)(int); static t_glGenLists p_glGenLists;
typedef void (*t_glGenProgramsARB)(int, int*); static t_glGenProgramsARB p_glGenProgramsARB;
typedef void (*t_glGenTextures)(int, int*); static t_glGenTextures p_glGenTextures;
typedef void (*t_glGenerateMipmap)(int); static t_glGenerateMipmap p_glGenerateMipmap;
typedef void (*t_glGetFloatv)(int, void*); static t_glGetFloatv p_glGetFloatv;
typedef void (*t_glGetIntegerv)(int, int*); static t_glGetIntegerv p_glGetIntegerv;
typedef void (*t_glHint)(int, int); static t_glHint p_glHint;
typedef void (*t_glInterleavedArrays)(int, int, void*); static t_glInterleavedArrays p_glInterleavedArrays;
typedef void (*t_glLightModelfv)(int, float*); static t_glLightModelfv p_glLightModelfv;
typedef void (*t_glLightfv)(int, int, float*); static t_glLightfv p_glLightfv;
typedef void (*t_glLightf)(int, int, float); static t_glLightf p_glLightf;
typedef void (*t_glLineWidth)(float); static t_glLineWidth p_glLineWidth;
typedef void (*t_glLoadIdentity)(void); static t_glLoadIdentity p_glLoadIdentity;
typedef void (*t_glLoadMatrixf)(float*); static t_glLoadMatrixf p_glLoadMatrixf;
typedef void (*t_glMatrixMode)(int); static t_glMatrixMode p_glMatrixMode;
typedef void (*t_glMultiTexCoord2f)(int, float, float); static t_glMultiTexCoord2f p_glMultiTexCoord2f;
typedef void (*t_glNewList)(int, int); static t_glNewList p_glNewList;
typedef void (*t_glNormalPointer)(int, int, void*); static t_glNormalPointer p_glNormalPointer;
typedef void (*t_glOrtho)(double, double, double, double, double, double); static t_glOrtho p_glOrtho;
typedef void (*t_glPixelZoom)(float, float); static t_glPixelZoom p_glPixelZoom;
typedef void (*t_glPointParameterfv)(int, float*); static t_glPointParameterfv p_glPointParameterfv;
typedef void (*t_glPointParameterf)(int, float); static t_glPointParameterf p_glPointParameterf;
typedef void (*t_glPolygonMode)(int, int); static t_glPolygonMode p_glPolygonMode;
typedef void (*t_glPopAttrib)(void); static t_glPopAttrib p_glPopAttrib;
typedef void (*t_glPopMatrix)(void); static t_glPopMatrix p_glPopMatrix;
typedef void (*t_glProgramLocalParameter4fARB)(int, int, float, float, float, float); static t_glProgramLocalParameter4fARB p_glProgramLocalParameter4fARB;
typedef void (*t_glProgramLocalParameter4fvARB)(int, int, void*); static t_glProgramLocalParameter4fvARB p_glProgramLocalParameter4fvARB;
typedef void (*t_glProgramStringARB)(int, int, int, const char*); static t_glProgramStringARB p_glProgramStringARB;
typedef void (*t_glPushAttrib)(int); static t_glPushAttrib p_glPushAttrib;
typedef void (*t_glPushMatrix)(void); static t_glPushMatrix p_glPushMatrix;
typedef void (*t_glRasterPos2i)(int, int); static t_glRasterPos2i p_glRasterPos2i;
typedef void (*t_glReadBuffer)(int); static t_glReadBuffer p_glReadBuffer;
typedef void (*t_glReadPixels)(int, int, int, int, int, int, void*); static t_glReadPixels p_glReadPixels;
typedef void (*t_glRotatef)(float, float, float, float); static t_glRotatef p_glRotatef;
typedef void (*t_glScalef)(float, float, float); static t_glScalef p_glScalef;
typedef void (*t_glScissor)(int, int, int, int); static t_glScissor p_glScissor;
typedef void (*t_glShadeModel)(int); static t_glShadeModel p_glShadeModel;
typedef void (*t_glTexCoord2f)(float, float); static t_glTexCoord2f p_glTexCoord2f;
typedef void (*t_glTexCoordPointer)(int, int, int, void*); static t_glTexCoordPointer p_glTexCoordPointer;
typedef void (*t_glTexEnvfv)(int, int, float*); static t_glTexEnvfv p_glTexEnvfv;
typedef void (*t_glTexEnvf)(int, int, float); static t_glTexEnvf p_glTexEnvf;
typedef void (*t_glTexEnvi)(int, int, int); static t_glTexEnvi p_glTexEnvi;
typedef void (*t_glTexGenfv)(int, int, float*); static t_glTexGenfv p_glTexGenfv;
typedef void (*t_glTexGeni)(int, int, int); static t_glTexGeni p_glTexGeni;
typedef void (*t_glTexImage1D)(int, int, int, int, int, int, int, void*); static t_glTexImage1D p_glTexImage1D;
typedef void (*t_glTexImage2D)(int, int, int, int, int, int, int, int, void*); static t_glTexImage2D p_glTexImage2D;
typedef void (*t_glTexImage3D)(int, int, int, int, int, int, int, int, int, void*); static t_glTexImage3D p_glTexImage3D;
typedef void (*t_glTexParameteri)(int, int, int); static t_glTexParameteri p_glTexParameteri;
typedef void (*t_glTexStorage2D)(int, int, int, int, int); static t_glTexStorage2D p_glTexStorage2D;
typedef void (*t_glTexSubImage2D)(int, int, int, int, int, int, int, int, void*); static t_glTexSubImage2D p_glTexSubImage2D;
typedef void (*t_glTranslatef)(float, float, float); static t_glTranslatef p_glTranslatef;
typedef void (*t_glVertex2f)(float, float); static t_glVertex2f p_glVertex2f;
typedef void (*t_glVertexPointer)(int, int, int, void*); static t_glVertexPointer p_glVertexPointer;
typedef void (*t_glViewport)(int, int, int, int); static t_glViewport p_glViewport;
static void load_all(void) {
    p_glActiveTexture = (t_glActiveTexture)sym("glActiveTexture");
    p_glAlphaFunc = (t_glAlphaFunc)sym("glAlphaFunc");
    p_glBegin = (t_glBegin)sym("glBegin");
    p_glBindBuffer = (t_glBindBuffer)sym("glBindBuffer");
    p_glBindProgramARB = (t_glBindProgramARB)sym("glBindProgramARB");
    p_glBindTexture = (t_glBindTexture)sym("glBindTexture");
    p_glBlendFunc = (t_glBlendFunc)sym("glBlendFunc");
    p_glBufferData = (t_glBufferData)sym("glBufferData");
    p_glBufferSubData = (t_glBufferSubData)sym("glBufferSubData");
    p_glCallList = (t_glCallList)sym("glCallList");
    p_glClearColor = (t_glClearColor)sym("glClearColor");
    p_glClearDepth = (t_glClearDepth)sym("glClearDepth");
    p_glClear = (t_glClear)sym("glClear");
    p_glClientActiveTexture = (t_glClientActiveTexture)sym("glClientActiveTexture");
    p_glColor3ub = (t_glColor3ub)sym("glColor3ub");
    p_glColor4fv = (t_glColor4fv)sym("glColor4fv");
    p_glColor4f = (t_glColor4f)sym("glColor4f");
    p_glColor4ub = (t_glColor4ub)sym("glColor4ub");
    p_glColorMaterial = (t_glColorMaterial)sym("glColorMaterial");
    p_glColorPointer = (t_glColorPointer)sym("glColorPointer");
    p_glCopyPixels = (t_glCopyPixels)sym("glCopyPixels");
    p_glCullFace = (t_glCullFace)sym("glCullFace");
    p_glDeleteBuffers = (t_glDeleteBuffers)sym("glDeleteBuffers");
    p_glDeleteLists = (t_glDeleteLists)sym("glDeleteLists");
    p_glDeleteTextures = (t_glDeleteTextures)sym("glDeleteTextures");
    p_glDepthFunc = (t_glDepthFunc)sym("glDepthFunc");
    p_glDepthMask = (t_glDepthMask)sym("glDepthMask");
    p_glDisableClientState = (t_glDisableClientState)sym("glDisableClientState");
    p_glDisable = (t_glDisable)sym("glDisable");
    p_glDrawBuffer = (t_glDrawBuffer)sym("glDrawBuffer");
    p_glDrawElements = (t_glDrawElements)sym("glDrawElements");
    p_glDrawPixels = (t_glDrawPixels)sym("glDrawPixels");
    p_glEnableClientState = (t_glEnableClientState)sym("glEnableClientState");
    p_glEnable = (t_glEnable)sym("glEnable");
    p_glEndList = (t_glEndList)sym("glEndList");
    p_glEnd = (t_glEnd)sym("glEnd");
    p_glFogfv = (t_glFogfv)sym("glFogfv");
    p_glFogf = (t_glFogf)sym("glFogf");
    p_glFogi = (t_glFogi)sym("glFogi");
    p_glGenBuffers = (t_glGenBuffers)sym("glGenBuffers");
    p_glGenLists = (t_glGenLists)sym("glGenLists");
    p_glGenProgramsARB = (t_glGenProgramsARB)sym("glGenProgramsARB");
    p_glGenTextures = (t_glGenTextures)sym("glGenTextures");
    p_glGenerateMipmap = (t_glGenerateMipmap)sym("glGenerateMipmap");
    p_glGetFloatv = (t_glGetFloatv)sym("glGetFloatv");
    p_glGetIntegerv = (t_glGetIntegerv)sym("glGetIntegerv");
    p_glHint = (t_glHint)sym("glHint");
    p_glInterleavedArrays = (t_glInterleavedArrays)sym("glInterleavedArrays");
    p_glLightModelfv = (t_glLightModelfv)sym("glLightModelfv");
    p_glLightfv = (t_glLightfv)sym("glLightfv");
    p_glLightf = (t_glLightf)sym("glLightf");
    p_glLineWidth = (t_glLineWidth)sym("glLineWidth");
    p_glLoadIdentity = (t_glLoadIdentity)sym("glLoadIdentity");
    p_glLoadMatrixf = (t_glLoadMatrixf)sym("glLoadMatrixf");
    p_glMatrixMode = (t_glMatrixMode)sym("glMatrixMode");
    p_glMultiTexCoord2f = (t_glMultiTexCoord2f)sym("glMultiTexCoord2f");
    p_glNewList = (t_glNewList)sym("glNewList");
    p_glNormalPointer = (t_glNormalPointer)sym("glNormalPointer");
    p_glOrtho = (t_glOrtho)sym("glOrtho");
    p_glPixelZoom = (t_glPixelZoom)sym("glPixelZoom");
    p_glPointParameterfv = (t_glPointParameterfv)sym("glPointParameterfv");
    p_glPointParameterf = (t_glPointParameterf)sym("glPointParameterf");
    p_glPolygonMode = (t_glPolygonMode)sym("glPolygonMode");
    p_glPopAttrib = (t_glPopAttrib)sym("glPopAttrib");
    p_glPopMatrix = (t_glPopMatrix)sym("glPopMatrix");
    p_glProgramLocalParameter4fARB = (t_glProgramLocalParameter4fARB)sym("glProgramLocalParameter4fARB");
    p_glProgramLocalParameter4fvARB = (t_glProgramLocalParameter4fvARB)sym("glProgramLocalParameter4fvARB");
    p_glProgramStringARB = (t_glProgramStringARB)sym("glProgramStringARB");
    p_glPushAttrib = (t_glPushAttrib)sym("glPushAttrib");
    p_glPushMatrix = (t_glPushMatrix)sym("glPushMatrix");
    p_glRasterPos2i = (t_glRasterPos2i)sym("glRasterPos2i");
    p_glReadBuffer = (t_glReadBuffer)sym("glReadBuffer");
    p_glReadPixels = (t_glReadPixels)sym("glReadPixels");
    p_glRotatef = (t_glRotatef)sym("glRotatef");
    p_glScalef = (t_glScalef)sym("glScalef");
    p_glScissor = (t_glScissor)sym("glScissor");
    p_glShadeModel = (t_glShadeModel)sym("glShadeModel");
    p_glTexCoord2f = (t_glTexCoord2f)sym("glTexCoord2f");
    p_glTexCoordPointer = (t_glTexCoordPointer)sym("glTexCoordPointer");
    p_glTexEnvfv = (t_glTexEnvfv)sym("glTexEnvfv");
    p_glTexEnvf = (t_glTexEnvf)sym("glTexEnvf");
    p_glTexEnvi = (t_glTexEnvi)sym("glTexEnvi");
    p_glTexGenfv = (t_glTexGenfv)sym("glTexGenfv");
    p_glTexGeni = (t_glTexGeni)sym("glTexGeni");
    p_glTexImage1D = (t_glTexImage1D)sym("glTexImage1D");
    p_glTexImage2D = (t_glTexImage2D)sym("glTexImage2D");
    p_glTexImage3D = (t_glTexImage3D)sym("glTexImage3D");
    p_glTexParameteri = (t_glTexParameteri)sym("glTexParameteri");
    p_glTexStorage2D = (t_glTexStorage2D)sym("glTexStorage2D");
    p_glTexSubImage2D = (t_glTexSubImage2D)sym("glTexSubImage2D");
    p_glTranslatef = (t_glTranslatef)sym("glTranslatef");
    p_glVertex2f = (t_glVertex2f)sym("glVertex2f");
    p_glVertexPointer = (t_glVertexPointer)sym("glVertexPointer");
    p_glViewport = (t_glViewport)sym("glViewport");
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glActiveTexture_10(JNIEnv* env, jclass cls, jint a0) {
    if (!p_glActiveTexture) return;
    p_glActiveTexture((int)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glAlphaFunc_10(JNIEnv* env, jclass cls, jint a0, jfloat a1) {
    if (!p_glAlphaFunc) return;
    p_glAlphaFunc((int)a0, (float)a1);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glBegin_10(JNIEnv* env, jclass cls, jint a0) {
    if (!p_glBegin) return;
    p_glBegin((int)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glBindBuffer_10(JNIEnv* env, jclass cls, jint a0, jint a1) {
    if (!p_glBindBuffer) return;
    p_glBindBuffer((int)a0, (int)a1);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glBindProgramARB_10(JNIEnv* env, jclass cls, jint a0, jint a1) {
    if (!p_glBindProgramARB) return;
    p_glBindProgramARB((int)a0, (int)a1);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glBindTexture_10(JNIEnv* env, jclass cls, jint a0, jint a1) {
    if (!p_glBindTexture) return;
    p_glBindTexture((int)a0, (int)a1);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glBlendFunc_10(JNIEnv* env, jclass cls, jint a0, jint a1) {
    if (!p_glBlendFunc) return;
    p_glBlendFunc((int)a0, (int)a1);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glBufferData_10(JNIEnv* env, jclass cls, jint a0, jlong a1, jlong a2, jint a3) {
    if (!p_glBufferData) return;
    p_glBufferData((int)a0, (long long)a1, (void*)(intptr_t)a2, (int)a3);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glBufferSubData_10(JNIEnv* env, jclass cls, jint a0, jlong a1, jlong a2, jlong a3) {
    if (!p_glBufferSubData) return;
    p_glBufferSubData((int)a0, (long long)a1, (long long)a2, (void*)(intptr_t)a3);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glCallList_10(JNIEnv* env, jclass cls, jint a0) {
    if (!p_glCallList) return;
    p_glCallList((int)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glClearColor_10(JNIEnv* env, jclass cls, jfloat a0, jfloat a1, jfloat a2, jfloat a3) {
    if (!p_glClearColor) return;
    p_glClearColor((float)a0, (float)a1, (float)a2, (float)a3);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glClearDepth_10(JNIEnv* env, jclass cls, jdouble a0) {
    if (!p_glClearDepth) return;
    p_glClearDepth((double)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glClear_10(JNIEnv* env, jclass cls, jint a0) {
    if (!p_glClear) return;
    p_glClear((int)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glClientActiveTexture_10(JNIEnv* env, jclass cls, jint a0) {
    if (!p_glClientActiveTexture) return;
    p_glClientActiveTexture((int)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glColor3ub_10(JNIEnv* env, jclass cls, jbyte a0, jbyte a1, jbyte a2) {
    if (!p_glColor3ub) return;
    p_glColor3ub((signed char)a0, (signed char)a1, (signed char)a2);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glColor4fv_10(JNIEnv* env, jclass cls, jfloatArray a0, jint a1) {
    if (!p_glColor4fv) return;
    jfloat* e0 = (*env)->GetFloatArrayElements(env, a0, 0);
    p_glColor4fv(e0 + a1);
    (*env)->ReleaseFloatArrayElements(env, a0, e0, 0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glColor4f_10(JNIEnv* env, jclass cls, jfloat a0, jfloat a1, jfloat a2, jfloat a3) {
    if (!p_glColor4f) return;
    p_glColor4f((float)a0, (float)a1, (float)a2, (float)a3);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glColor4ub_10(JNIEnv* env, jclass cls, jbyte a0, jbyte a1, jbyte a2, jbyte a3) {
    if (!p_glColor4ub) return;
    p_glColor4ub((signed char)a0, (signed char)a1, (signed char)a2, (signed char)a3);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glColorMaterial_10(JNIEnv* env, jclass cls, jint a0, jint a1) {
    if (!p_glColorMaterial) return;
    p_glColorMaterial((int)a0, (int)a1);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glColorPointer_10(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jlong a3) {
    if (!p_glColorPointer) return;
    p_glColorPointer((int)a0, (int)a1, (int)a2, (void*)(intptr_t)a3);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glColorPointer_11(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jlong a3) {
    if (!p_glColorPointer) return;
    p_glColorPointer((int)a0, (int)a1, (int)a2, (void*)(intptr_t)a3);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glCopyPixels_10(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jint a3, jint a4) {
    if (!p_glCopyPixels) return;
    p_glCopyPixels((int)a0, (int)a1, (int)a2, (int)a3, (int)a4);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glCullFace_10(JNIEnv* env, jclass cls, jint a0) {
    if (!p_glCullFace) return;
    p_glCullFace((int)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glDeleteBuffers_10(JNIEnv* env, jclass cls, jint a0, jintArray a1, jint a2) {
    if (!p_glDeleteBuffers) return;
    jint* e1 = (*env)->GetIntArrayElements(env, a1, 0);
    p_glDeleteBuffers((int)a0, e1 + a2);
    (*env)->ReleaseIntArrayElements(env, a1, e1, 0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glDeleteLists_10(JNIEnv* env, jclass cls, jint a0, jint a1) {
    if (!p_glDeleteLists) return;
    p_glDeleteLists((int)a0, (int)a1);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glDeleteTextures_10(JNIEnv* env, jclass cls, jint a0, jintArray a1, jint a2) {
    if (!p_glDeleteTextures) return;
    jint* e1 = (*env)->GetIntArrayElements(env, a1, 0);
    p_glDeleteTextures((int)a0, e1 + a2);
    (*env)->ReleaseIntArrayElements(env, a1, e1, 0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glDepthFunc_10(JNIEnv* env, jclass cls, jint a0) {
    if (!p_glDepthFunc) return;
    p_glDepthFunc((int)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glDepthMask_10(JNIEnv* env, jclass cls, jboolean a0) {
    if (!p_glDepthMask) return;
    p_glDepthMask((unsigned char)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glDisableClientState_10(JNIEnv* env, jclass cls, jint a0) {
    if (!p_glDisableClientState) return;
    p_glDisableClientState((int)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glDisable_10(JNIEnv* env, jclass cls, jint a0) {
    if (!p_glDisable) return;
    p_glDisable((int)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glDrawBuffer_10(JNIEnv* env, jclass cls, jint a0) {
    if (!p_glDrawBuffer) return;
    p_glDrawBuffer((int)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glDrawElements_10(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jlong a3) {
    if (!p_glDrawElements) return;
    p_glDrawElements((int)a0, (int)a1, (int)a2, (void*)(intptr_t)a3);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glDrawElements_11(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jlong a3) {
    if (!p_glDrawElements) return;
    p_glDrawElements((int)a0, (int)a1, (int)a2, (void*)(intptr_t)a3);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glDrawPixels_10(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jint a3, jlong a4) {
    if (!p_glDrawPixels) return;
    p_glDrawPixels((int)a0, (int)a1, (int)a2, (int)a3, (void*)(intptr_t)a4);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glEnableClientState_10(JNIEnv* env, jclass cls, jint a0) {
    if (!p_glEnableClientState) return;
    p_glEnableClientState((int)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glEnable_10(JNIEnv* env, jclass cls, jint a0) {
    if (!p_glEnable) return;
    p_glEnable((int)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glEndList_10(JNIEnv* env, jclass cls) {
    if (!p_glEndList) return;
    p_glEndList();
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glEnd_10(JNIEnv* env, jclass cls) {
    if (!p_glEnd) return;
    p_glEnd();
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glFogfv_10(JNIEnv* env, jclass cls, jint a0, jfloatArray a1, jint a2) {
    if (!p_glFogfv) return;
    jfloat* e1 = (*env)->GetFloatArrayElements(env, a1, 0);
    p_glFogfv((int)a0, e1 + a2);
    (*env)->ReleaseFloatArrayElements(env, a1, e1, 0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glFogf_10(JNIEnv* env, jclass cls, jint a0, jfloat a1) {
    if (!p_glFogf) return;
    p_glFogf((int)a0, (float)a1);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glFogi_10(JNIEnv* env, jclass cls, jint a0, jint a1) {
    if (!p_glFogi) return;
    p_glFogi((int)a0, (int)a1);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glGenBuffers_10(JNIEnv* env, jclass cls, jint a0, jintArray a1, jint a2) {
    if (!p_glGenBuffers) return;
    jint* e1 = (*env)->GetIntArrayElements(env, a1, 0);
    p_glGenBuffers((int)a0, e1 + a2);
    (*env)->ReleaseIntArrayElements(env, a1, e1, 0);
}
JNIEXPORT jint JNICALL Java_com_jogamp_opengl_GlNative_glGenLists_10(JNIEnv* env, jclass cls, jint a0) {
    if (!p_glGenLists) return 0;
    jint r = (jint)p_glGenLists((int)a0);
    return r;
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glGenProgramsARB_10(JNIEnv* env, jclass cls, jint a0, jintArray a1, jint a2) {
    if (!p_glGenProgramsARB) return;
    jint* e1 = (*env)->GetIntArrayElements(env, a1, 0);
    p_glGenProgramsARB((int)a0, e1 + a2);
    (*env)->ReleaseIntArrayElements(env, a1, e1, 0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glGenTextures_10(JNIEnv* env, jclass cls, jint a0, jintArray a1, jint a2) {
    if (!p_glGenTextures) return;
    jint* e1 = (*env)->GetIntArrayElements(env, a1, 0);
    p_glGenTextures((int)a0, e1 + a2);
    (*env)->ReleaseIntArrayElements(env, a1, e1, 0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glGenerateMipmap_10(JNIEnv* env, jclass cls, jint a0) {
    if (!p_glGenerateMipmap) return;
    p_glGenerateMipmap((int)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glGetFloatv_10(JNIEnv* env, jclass cls, jint a0, jlong a1) {
    if (!p_glGetFloatv) return;
    p_glGetFloatv((int)a0, (void*)(intptr_t)a1);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glGetFloatv_11(JNIEnv* env, jclass cls, jint a0, jfloatArray a1, jint a2) {
    if (!p_glGetFloatv) return;
    jfloat* e1 = (*env)->GetFloatArrayElements(env, a1, 0);
    p_glGetFloatv((int)a0, e1 + a2);
    (*env)->ReleaseFloatArrayElements(env, a1, e1, 0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glGetIntegerv_10(JNIEnv* env, jclass cls, jint a0, jintArray a1, jint a2) {
    if (!p_glGetIntegerv) return;
    jint* e1 = (*env)->GetIntArrayElements(env, a1, 0);
    p_glGetIntegerv((int)a0, e1 + a2);
    (*env)->ReleaseIntArrayElements(env, a1, e1, 0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glHint_10(JNIEnv* env, jclass cls, jint a0, jint a1) {
    if (!p_glHint) return;
    p_glHint((int)a0, (int)a1);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glInterleavedArrays_10(JNIEnv* env, jclass cls, jint a0, jint a1, jlong a2) {
    if (!p_glInterleavedArrays) return;
    p_glInterleavedArrays((int)a0, (int)a1, (void*)(intptr_t)a2);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glInterleavedArrays_11(JNIEnv* env, jclass cls, jint a0, jint a1, jlong a2) {
    if (!p_glInterleavedArrays) return;
    p_glInterleavedArrays((int)a0, (int)a1, (void*)(intptr_t)a2);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glLightModelfv_10(JNIEnv* env, jclass cls, jint a0, jfloatArray a1, jint a2) {
    if (!p_glLightModelfv) return;
    jfloat* e1 = (*env)->GetFloatArrayElements(env, a1, 0);
    p_glLightModelfv((int)a0, e1 + a2);
    (*env)->ReleaseFloatArrayElements(env, a1, e1, 0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glLightfv_10(JNIEnv* env, jclass cls, jint a0, jint a1, jfloatArray a2, jint a3) {
    if (!p_glLightfv) return;
    jfloat* e2 = (*env)->GetFloatArrayElements(env, a2, 0);
    p_glLightfv((int)a0, (int)a1, e2 + a3);
    (*env)->ReleaseFloatArrayElements(env, a2, e2, 0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glLightf_10(JNIEnv* env, jclass cls, jint a0, jint a1, jfloat a2) {
    if (!p_glLightf) return;
    p_glLightf((int)a0, (int)a1, (float)a2);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glLineWidth_10(JNIEnv* env, jclass cls, jfloat a0) {
    if (!p_glLineWidth) return;
    p_glLineWidth((float)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glLoadIdentity_10(JNIEnv* env, jclass cls) {
    if (!p_glLoadIdentity) return;
    p_glLoadIdentity();
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glLoadMatrixf_10(JNIEnv* env, jclass cls, jfloatArray a0, jint a1) {
    if (!p_glLoadMatrixf) return;
    jfloat* e0 = (*env)->GetFloatArrayElements(env, a0, 0);
    p_glLoadMatrixf(e0 + a1);
    (*env)->ReleaseFloatArrayElements(env, a0, e0, 0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glMatrixMode_10(JNIEnv* env, jclass cls, jint a0) {
    if (!p_glMatrixMode) return;
    p_glMatrixMode((int)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glMultiTexCoord2f_10(JNIEnv* env, jclass cls, jint a0, jfloat a1, jfloat a2) {
    if (!p_glMultiTexCoord2f) return;
    p_glMultiTexCoord2f((int)a0, (float)a1, (float)a2);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glNewList_10(JNIEnv* env, jclass cls, jint a0, jint a1) {
    if (!p_glNewList) return;
    p_glNewList((int)a0, (int)a1);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glNormalPointer_10(JNIEnv* env, jclass cls, jint a0, jint a1, jlong a2) {
    if (!p_glNormalPointer) return;
    p_glNormalPointer((int)a0, (int)a1, (void*)(intptr_t)a2);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glNormalPointer_11(JNIEnv* env, jclass cls, jint a0, jint a1, jlong a2) {
    if (!p_glNormalPointer) return;
    p_glNormalPointer((int)a0, (int)a1, (void*)(intptr_t)a2);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glOrtho_10(JNIEnv* env, jclass cls, jdouble a0, jdouble a1, jdouble a2, jdouble a3, jdouble a4, jdouble a5) {
    if (!p_glOrtho) return;
    p_glOrtho((double)a0, (double)a1, (double)a2, (double)a3, (double)a4, (double)a5);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glPixelZoom_10(JNIEnv* env, jclass cls, jfloat a0, jfloat a1) {
    if (!p_glPixelZoom) return;
    p_glPixelZoom((float)a0, (float)a1);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glPointParameterfv_10(JNIEnv* env, jclass cls, jint a0, jfloatArray a1, jint a2) {
    if (!p_glPointParameterfv) return;
    jfloat* e1 = (*env)->GetFloatArrayElements(env, a1, 0);
    p_glPointParameterfv((int)a0, e1 + a2);
    (*env)->ReleaseFloatArrayElements(env, a1, e1, 0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glPointParameterf_10(JNIEnv* env, jclass cls, jint a0, jfloat a1) {
    if (!p_glPointParameterf) return;
    p_glPointParameterf((int)a0, (float)a1);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glPolygonMode_10(JNIEnv* env, jclass cls, jint a0, jint a1) {
    if (!p_glPolygonMode) return;
    p_glPolygonMode((int)a0, (int)a1);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glPopAttrib_10(JNIEnv* env, jclass cls) {
    if (!p_glPopAttrib) return;
    p_glPopAttrib();
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glPopMatrix_10(JNIEnv* env, jclass cls) {
    if (!p_glPopMatrix) return;
    p_glPopMatrix();
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glProgramLocalParameter4fARB_10(JNIEnv* env, jclass cls, jint a0, jint a1, jfloat a2, jfloat a3, jfloat a4, jfloat a5) {
    if (!p_glProgramLocalParameter4fARB) return;
    p_glProgramLocalParameter4fARB((int)a0, (int)a1, (float)a2, (float)a3, (float)a4, (float)a5);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glProgramLocalParameter4fvARB_10(JNIEnv* env, jclass cls, jint a0, jint a1, jlong a2) {
    if (!p_glProgramLocalParameter4fvARB) return;
    p_glProgramLocalParameter4fvARB((int)a0, (int)a1, (void*)(intptr_t)a2);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glProgramLocalParameter4fvARB_11(JNIEnv* env, jclass cls, jint a0, jint a1, jfloatArray a2, jint a3) {
    if (!p_glProgramLocalParameter4fvARB) return;
    jfloat* e2 = (*env)->GetFloatArrayElements(env, a2, 0);
    p_glProgramLocalParameter4fvARB((int)a0, (int)a1, e2 + a3);
    (*env)->ReleaseFloatArrayElements(env, a2, e2, 0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glProgramStringARB_10(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jstring a3) {
    if (!p_glProgramStringARB) return;
    const char* s3 = (*env)->GetStringUTFChars(env, a3, 0);
    p_glProgramStringARB((int)a0, (int)a1, (int)a2, s3);
    (*env)->ReleaseStringUTFChars(env, a3, s3);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glPushAttrib_10(JNIEnv* env, jclass cls, jint a0) {
    if (!p_glPushAttrib) return;
    p_glPushAttrib((int)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glPushMatrix_10(JNIEnv* env, jclass cls) {
    if (!p_glPushMatrix) return;
    p_glPushMatrix();
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glRasterPos2i_10(JNIEnv* env, jclass cls, jint a0, jint a1) {
    if (!p_glRasterPos2i) return;
    p_glRasterPos2i((int)a0, (int)a1);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glReadBuffer_10(JNIEnv* env, jclass cls, jint a0) {
    if (!p_glReadBuffer) return;
    p_glReadBuffer((int)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glReadPixels_10(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jint a3, jint a4, jint a5, jlong a6) {
    if (!p_glReadPixels) return;
    p_glReadPixels((int)a0, (int)a1, (int)a2, (int)a3, (int)a4, (int)a5, (void*)(intptr_t)a6);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glRotatef_10(JNIEnv* env, jclass cls, jfloat a0, jfloat a1, jfloat a2, jfloat a3) {
    if (!p_glRotatef) return;
    p_glRotatef((float)a0, (float)a1, (float)a2, (float)a3);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glScalef_10(JNIEnv* env, jclass cls, jfloat a0, jfloat a1, jfloat a2) {
    if (!p_glScalef) return;
    p_glScalef((float)a0, (float)a1, (float)a2);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glScissor_10(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jint a3) {
    if (!p_glScissor) return;
    p_glScissor((int)a0, (int)a1, (int)a2, (int)a3);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glShadeModel_10(JNIEnv* env, jclass cls, jint a0) {
    if (!p_glShadeModel) return;
    p_glShadeModel((int)a0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glTexCoord2f_10(JNIEnv* env, jclass cls, jfloat a0, jfloat a1) {
    if (!p_glTexCoord2f) return;
    p_glTexCoord2f((float)a0, (float)a1);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glTexCoordPointer_10(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jlong a3) {
    if (!p_glTexCoordPointer) return;
    p_glTexCoordPointer((int)a0, (int)a1, (int)a2, (void*)(intptr_t)a3);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glTexCoordPointer_11(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jlong a3) {
    if (!p_glTexCoordPointer) return;
    p_glTexCoordPointer((int)a0, (int)a1, (int)a2, (void*)(intptr_t)a3);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glTexEnvfv_10(JNIEnv* env, jclass cls, jint a0, jint a1, jfloatArray a2, jint a3) {
    if (!p_glTexEnvfv) return;
    jfloat* e2 = (*env)->GetFloatArrayElements(env, a2, 0);
    p_glTexEnvfv((int)a0, (int)a1, e2 + a3);
    (*env)->ReleaseFloatArrayElements(env, a2, e2, 0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glTexEnvf_10(JNIEnv* env, jclass cls, jint a0, jint a1, jfloat a2) {
    if (!p_glTexEnvf) return;
    p_glTexEnvf((int)a0, (int)a1, (float)a2);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glTexEnvi_10(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2) {
    if (!p_glTexEnvi) return;
    p_glTexEnvi((int)a0, (int)a1, (int)a2);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glTexGenfv_10(JNIEnv* env, jclass cls, jint a0, jint a1, jfloatArray a2, jint a3) {
    if (!p_glTexGenfv) return;
    jfloat* e2 = (*env)->GetFloatArrayElements(env, a2, 0);
    p_glTexGenfv((int)a0, (int)a1, e2 + a3);
    (*env)->ReleaseFloatArrayElements(env, a2, e2, 0);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glTexGeni_10(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2) {
    if (!p_glTexGeni) return;
    p_glTexGeni((int)a0, (int)a1, (int)a2);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glTexImage1D_10(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jint a3, jint a4, jint a5, jint a6, jlong a7) {
    if (!p_glTexImage1D) return;
    p_glTexImage1D((int)a0, (int)a1, (int)a2, (int)a3, (int)a4, (int)a5, (int)a6, (void*)(intptr_t)a7);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glTexImage2D_10(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jint a3, jint a4, jint a5, jint a6, jint a7, jlong a8) {
    if (!p_glTexImage2D) return;
    p_glTexImage2D((int)a0, (int)a1, (int)a2, (int)a3, (int)a4, (int)a5, (int)a6, (int)a7, (void*)(intptr_t)a8);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glTexImage3D_10(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jint a3, jint a4, jint a5, jint a6, jint a7, jint a8, jlong a9) {
    if (!p_glTexImage3D) return;
    p_glTexImage3D((int)a0, (int)a1, (int)a2, (int)a3, (int)a4, (int)a5, (int)a6, (int)a7, (int)a8, (void*)(intptr_t)a9);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glTexParameteri_10(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2) {
    if (!p_glTexParameteri) return;
    p_glTexParameteri((int)a0, (int)a1, (int)a2);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glTexStorage2D_10(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jint a3, jint a4) {
    if (!p_glTexStorage2D) return;
    p_glTexStorage2D((int)a0, (int)a1, (int)a2, (int)a3, (int)a4);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glTexSubImage2D_10(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jint a3, jint a4, jint a5, jint a6, jint a7, jlong a8) {
    if (!p_glTexSubImage2D) return;
    p_glTexSubImage2D((int)a0, (int)a1, (int)a2, (int)a3, (int)a4, (int)a5, (int)a6, (int)a7, (void*)(intptr_t)a8);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glTranslatef_10(JNIEnv* env, jclass cls, jfloat a0, jfloat a1, jfloat a2) {
    if (!p_glTranslatef) return;
    p_glTranslatef((float)a0, (float)a1, (float)a2);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glVertex2f_10(JNIEnv* env, jclass cls, jfloat a0, jfloat a1) {
    if (!p_glVertex2f) return;
    p_glVertex2f((float)a0, (float)a1);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glVertexPointer_10(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jlong a3) {
    if (!p_glVertexPointer) return;
    p_glVertexPointer((int)a0, (int)a1, (int)a2, (void*)(intptr_t)a3);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glVertexPointer_11(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jlong a3) {
    if (!p_glVertexPointer) return;
    p_glVertexPointer((int)a0, (int)a1, (int)a2, (void*)(intptr_t)a3);
}
JNIEXPORT void JNICALL Java_com_jogamp_opengl_GlNative_glViewport_10(JNIEnv* env, jclass cls, jint a0, jint a1, jint a2, jint a3) {
    if (!p_glViewport) return;
    p_glViewport((int)a0, (int)a1, (int)a2, (int)a3);
}
