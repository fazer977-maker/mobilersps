package rt4;

import com.jogamp.opengl.GL2;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

/** Full-screen color look applied to the 3D view with two blend passes (multiply tint, then a small add). */
public final class ColorGrade {
	/** multiply factors (0..2) and additive amounts per preset */
	private static final float[][] MUL = {{1, 1, 1}, {1.10F, 1.00F, 0.86F}, {0.88F, 0.98F, 1.12F}, {1.20F, 0.95F, 0.78F}, {0.62F, 0.72F, 1.00F}};
	private static final float[][] ADD = {{0, 0, 0}, {0.030F, 0.012F, 0.0F}, {0.0F, 0.010F, 0.030F}, {0.050F, 0.0F, 0.020F}, {0.0F, 0.010F, 0.040F}};
	/** time-of-day keyframes: morning, midday, evening, night */
	private static final float[][] TMUL = {{1.10F, 1.00F, 0.86F}, {1.04F, 1.04F, 1.02F}, {1.25F, 0.90F, 0.70F}, {0.38F, 0.48F, 0.82F}};
	private static final float[][] TADD = {{0.030F, 0.015F, 0.0F}, {0.0F, 0.0F, 0.0F}, {0.050F, 0.0F, 0.015F}, {0.0F, 0.010F, 0.035F}};
	private static final long CYCLE_MS = 10 * 60 * 1000L;
	private static long cycleStart = System.currentTimeMillis();
	private static boolean done;

	/** Writes the time-of-day multiply (m) and add (a) for the current setting; returns false if time of day is off. */
	private static boolean timeOfDay(float[] m, float[] a) {
		int tod = FxConfig.tod;
		if (tod <= 0) {
			return false;
		}
		float pos;
		if (tod >= 5) {
			pos = ((System.currentTimeMillis() - cycleStart) % CYCLE_MS) / (float) CYCLE_MS * 4.0F;
		} else {
			pos = tod - 1;
		}
		int k0 = ((int) Math.floor(pos)) & 3, k1 = (k0 + 1) & 3;
		float f = pos - (float) Math.floor(pos);
		f = f * f * (3.0F - 2.0F * f);
		for (int c = 0; c < 3; c++) {
			m[c] = TMUL[k0][c] + (TMUL[k1][c] - TMUL[k0][c]) * f;
			a[c] = TADD[k0][c] + (TADD[k1][c] - TADD[k0][c]) * f;
		}
		return true;
	}

	private static final FloatBuffer quad = ByteBuffer.allocateDirect(12 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
	private static final ByteBuffer idx = ByteBuffer.allocateDirect(6 * 4).order(ByteOrder.nativeOrder());
	static {
		int[] i = {0, 1, 2, 0, 2, 3};
		for (int v : i) {
			idx.putInt(v);
		}
		idx.flip();
	}

	public static void frameDone() {
		done = false;
	}

	/** Called once per frame right after the 3D view is finished and the 2D (interface) projection is set up. */
	public static void apply(GL2 gl) {
		int look = FxConfig.look;
		if (look < 0 || look >= MUL.length) {
			look = 0;
		}
		if (done || (look == 0 && FxConfig.tod <= 0)) {
			return;
		}
		done = true;
		float w = GlRenderer.canvasWidth, h = GlRenderer.canvasHeight;
		quad.clear();
		quad.put(0).put(0).put(0).put(w).put(0).put(0).put(w).put(h).put(0).put(0).put(h).put(0);
		quad.flip();
		MaterialManager.setMaterial(0, 0);
		GlRenderer.setTextureId(-1);
		GlRenderer.setLightingEnabled(false);
		GlRenderer.setDepthTestEnabled(false);
		GlRenderer.setFogEnabled(false);
		GlRenderer.disableDepthMask();
		gl.glEnable(GL2.GL_BLEND);
		gl.glDisableClientState(GL2.GL_COLOR_ARRAY);
		gl.glDisableClientState(GL2.GL_NORMAL_ARRAY);
		GlRenderer.normalArrayEnabled = false;
		gl.glDisableClientState(GL2.GL_TEXTURE_COORD_ARRAY);
		gl.glEnableClientState(GL2.GL_VERTEX_ARRAY);
		if (GlRenderer.arbVboSupported) {
			gl.glBindBuffer(GL2.GL_ARRAY_BUFFER, 0);
			gl.glBindBuffer(GL2.GL_ELEMENT_ARRAY_BUFFER, 0);
		}
		gl.glVertexPointer(3, GL2.GL_FLOAT, 0, quad);
		float[] m = {MUL[look][0], MUL[look][1], MUL[look][2]}, a = {ADD[look][0], ADD[look][1], ADD[look][2]};
		float[] tm = new float[3], ta = new float[3];
		if (timeOfDay(tm, ta)) {
			for (int c = 0; c < 3; c++) {
				m[c] *= tm[c];
				a[c] += ta[c];
			}
		}
		// result = 2 * src * dst, so a source color of f/2 multiplies the picture by f
		gl.glBlendFunc(GL2.GL_DST_COLOR, GL2.GL_SRC_COLOR);
		gl.glColor4f(Math.min(1.0F, m[0] * 0.5F), Math.min(1.0F, m[1] * 0.5F), Math.min(1.0F, m[2] * 0.5F), 1.0F);
		gl.glDrawElements(GL2.GL_TRIANGLES, 6, GL2.GL_UNSIGNED_INT, idx);
		if (a[0] + a[1] + a[2] > 0) {
			gl.glBlendFunc(GL2.GL_ONE, GL2.GL_ONE);
			gl.glColor4f(a[0], a[1], a[2], 1.0F);
			gl.glDrawElements(GL2.GL_TRIANGLES, 6, GL2.GL_UNSIGNED_INT, idx);
		}
		gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
		gl.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		gl.glEnableClientState(GL2.GL_COLOR_ARRAY);
		gl.glEnableClientState(GL2.GL_TEXTURE_COORD_ARRAY);
		GlRenderer.enableDepthMask();
	}

	private ColorGrade() {
	}
}
