package com.jogamp.opengl;

public class GLCapabilities {
    public boolean sampleBuffers;
    public int numSamples;
    public GLCapabilities(GLProfile p) { }
    public void setSampleBuffers(boolean b) { sampleBuffers = b; }
    public static volatile int lastSamples;
    public void setNumSamples(int n) { numSamples = n; lastSamples = n; }
}
