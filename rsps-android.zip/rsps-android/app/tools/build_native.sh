#!/bin/bash
# Best-effort native build for the experimental GPU mode: gl4es (old OpenGL -> OpenGL ES) plus a tiny JNI bridge.
# Never fails the app build: if anything goes wrong the APK is still produced, just without GPU mode.
cd "$(dirname "$0")/.." || exit 0
APP=$(pwd); OUT=$APP/src/main/jniLibs/arm64-v8a; B=$APP/build/native
mkdir -p "$OUT" "$B"
mkdir -p "$APP/src/main/assets"
LOGF="$APP/src/main/assets/native_build.log"; : > "$LOGF"
exec > >(tee -a "$LOGF") 2>&1
echo "=== native build (GPU mode) ==="
NDK=""
for c in "$ANDROID_NDK_HOME" "$ANDROID_NDK_ROOT" "$ANDROID_NDK_LATEST_HOME"; do [ -n "$c" ] && [ -d "$c" ] && NDK=$c && break; done
if [ -z "$NDK" ] && [ -d "$ANDROID_HOME/ndk" ]; then NDK=$(ls -d "$ANDROID_HOME"/ndk/* 2>/dev/null | sort -V | tail -1); fi
if [ -z "$NDK" ] && [ -d "$ANDROID_SDK_ROOT/ndk" ]; then NDK=$(ls -d "$ANDROID_SDK_ROOT"/ndk/* 2>/dev/null | sort -V | tail -1); fi
echo "NDK: ${NDK:-NOT FOUND}"
[ -n "$NDK" ] || { echo "GPU mode skipped: no NDK"; exit 0; }
TC=$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin
CC=$TC/aarch64-linux-android26-clang
[ -x "$CC" ] || { echo "GPU mode skipped: compiler not found at $CC"; ls "$TC" | head; exit 0; }

# 1) gl4es
if [ ! -d "$B/gl4es" ]; then
  git clone --depth 1 https://github.com/ptitSeb/gl4es.git "$B/gl4es" || { echo "GPU mode skipped: could not download gl4es"; exit 0; }
fi
G=$B/gl4es
# patch: changing a light's position/spot flag must force the fixed-function shader to be re-selected (stale shader = lights treated as wrong type)
python3 - "$G/src/gl/light.c" <<'PYE'
import sys,re
p=sys.argv[1]; s=open(p).read()
if 'RS_PATCH' not in s:
    s=s.replace("glstate->fpe_state->light_direction |= (1<<nl);","glstate->fpe_state->light_direction |= (1<<nl); glstate->fpe = NULL; /*RS_PATCH*/")
    s=s.replace("glstate->fpe_state->light_direction &= ~(1<<nl);","glstate->fpe_state->light_direction &= ~(1<<nl); glstate->fpe = NULL;")
    s=s.replace("glstate->fpe_state->light_cutoff180 |= (1<<nl);","glstate->fpe_state->light_cutoff180 |= (1<<nl); glstate->fpe = NULL;")
    s=s.replace("glstate->fpe_state->light_cutoff180 &= ~(1<<nl);","glstate->fpe_state->light_cutoff180 &= ~(1<<nl); glstate->fpe = NULL;")
    open(p,'w').write(s)
PYE
echo "gl4es commit: $(git -C "$G" rev-parse --short HEAD 2>/dev/null)"
ls "$G" | head -30; echo "src dirs:"; ls "$G/src" | head -30; ls "$G/src/gl" 2>/dev/null | head -5
rm -f "$OUT/libgl4es.so"
built=0
SYS=$NDK/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/26
NM=$TC/llvm-nm
# link, then give every still-missing function an empty stand-in so the library can load (the names are logged)
dolink() {  # args: link inputs...
  "$CC" -shared -o "$OUT/libgl4es.so" "$@" -llog -ldl -lGLESv2 -lEGL -lm 2>&1 | grep -E 'error' | head -5
  [ -f "$OUT/libgl4es.so" ] || return 1
  "$NM" -D --undefined-only "$OUT/libgl4es.so" 2>/dev/null | awk '{print $2}' | sed 's/@.*//' | sort -u > "$B/undef.txt"
  : > "$B/prov.txt"
  for l in libc.so libm.so libdl.so liblog.so libGLESv2.so libEGL.so libandroid.so; do [ -f "$SYS/$l" ] && "$NM" -D --defined-only "$SYS/$l" 2>/dev/null | awk '{print $3}' | sed 's/@.*//' >> "$B/prov.txt"; done
  sort -u "$B/prov.txt" -o "$B/prov.txt"
  comm -23 "$B/undef.txt" "$B/prov.txt" | grep -E '^[A-Za-z_][A-Za-z0-9_]*$' > "$B/missing.txt"
  n=$(wc -l < "$B/missing.txt")
  echo "functions still missing after linking: $n"
  if [ "$n" -gt 0 ]; then
    head -25 "$B/missing.txt" | tr '\n' ' '; echo
    awk '{print "void " $1 "(void) {}"}' "$B/missing.txt" > "$B/stubs.c"
    "$CC" -c -fPIC -o "$B/stubs.o" "$B/stubs.c" && "$CC" -shared -o "$OUT/libgl4es.so" "$@" "$B/stubs.o" -llog -ldl -lGLESv2 -lEGL -lm 2>&1 | grep error | head -5
    echo "stand-ins added for $n functions (they do nothing if called)"
  fi
  return 0
}
# 1) compile every gl4es source file except the Amiga ones
echo "--- direct compile of gl4es sources"
SRCS=$(cd "$G/src" && find . -name '*.c' | grep -v -E '^agl/' | sed 's|^\./||')
mkdir -p "$B/obj"; : > "$B/objs.txt"; fail=0
for s in $SRCS; do
  o="$B/obj/$(echo "$s" | tr '/' '_').o"
  "$CC" -c -O2 -fPIC -std=gnu99 -w -fvisibility=hidden -DNOX11 -DNO_GBM -DNO_INIT_CONSTRUCTOR=0 -DANDROID -I"$G/src" -I"$G/include" -I"$G/src/glx" -o "$o" "$G/src/$s" 2> "$B/err.txt" || { fail=$((fail+1)); echo "compile failed: $s"; head -3 "$B/err.txt"; continue; }
  echo "$o" >> "$B/objs.txt"
done
echo "compile failures: $fail of $(echo "$SRCS" | wc -w) files; objects: $(wc -l < "$B/objs.txt")"
if dolink $(cat "$B/objs.txt"); then built=1; echo "linked from compiled sources"; fi
# 2) backup: gl4es's own Android.mk build
if [ $built = 0 ] && [ -f "$G/Android.mk" ]; then
  echo "--- backup: ndk-build with gl4es's own Android.mk"
  ( cd "$G" && "$NDK/ndk-build" NDK_PROJECT_PATH="$G" APP_BUILD_SCRIPT="$G/Android.mk" APP_ABI=arm64-v8a APP_PLATFORM=android-26 NDK_OUT="$B/ndkout" NDK_LIBS_OUT="$B/ndklibs" -j4 ) 2>&1 | tail -15
  a=$(find "$B/ndkout" "$B/ndklibs" -name 'libGL.a' 2>/dev/null | head -1)
  [ -n "$a" ] && dolink -Wl,--whole-archive "$a" -Wl,--no-whole-archive && built=1 && echo "linked from the ndk-build static library"
fi
[ $built = 1 ] && echo "gl4es library: OK ($(du -k "$OUT/libgl4es.so" | cut -f1) KB)" || echo "gl4es library: FAILED (GPU mode will be unavailable)"

# 2) JNI bridge
"$CC" -shared -fPIC -O2 -o "$OUT/libgl4esbridge.so" "$APP/src/main/cpp/bridge.c" -llog -ldl 2>&1 | tail -20
[ -f "$OUT/libgl4esbridge.so" ] && echo "bridge: OK" || echo "bridge: FAILED"
exit 0
