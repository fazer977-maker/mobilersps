package app.rsps2009;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

/** Small settings store + writer for the client's config.json. */
public final class Settings {
    static final String PREFS = "rsps2009";
    static final String DEFAULT_HOST = "144.202.35.127";

    final String host;
    final int serverPort;
    final int worldListPort;
    final int js5Port;
    final int world;
    final float renderScale;
    final boolean portrait;
    /** Edge smoothing (anti-aliasing) for the 3D view; read by AndroidPlatform. */
    static volatile boolean smoothEdges = true;
    /** Soft contact shading + vignette on the 3D view; read by AndroidPlatform. */
    static volatile boolean softShading = true;
    static volatile boolean gpuMode = false;
    /** GL fixed-function lighting (High) misrenders through gl4es; GPU mode always uses the Low lighting path. */
    public static boolean gpuLowLight() { return gpuMode; }
    public static volatile boolean showFps = false;
    public static boolean msaa = false;
    static final String[] TODS = {"Off (normal)", "Morning", "Mid day", "Evening", "Night", "Auto cycle (10 min)"};
    static final String[] LOOKS = {"Off", "Warm", "Cool", "Sunset", "Moonlight"};
    /** Incremented once per presented frame by the GPU backend; read by the FPS overlay. */
    static volatile int frameCount = 0;
    /** Profiling totals for the FPS overlay: nanoseconds spent waiting in eglSwapBuffers, nanoseconds of whole frames, GL calls. */
    static volatile long swapNs = 0, frameNs = 0, glCalls = 0;

    Settings(SharedPreferences p) {
        host = p.getString("host", DEFAULT_HOST);
        serverPort = p.getInt("serverPort", 43594);
        worldListPort = p.getInt("wlPort", 43595);
        js5Port = p.getInt("js5Port", 43595);
        world = p.getInt("world", 1);
        renderScale = p.getFloat("scale2", 2.5f);
        portrait = p.getBoolean("portrait", false);
        smoothEdges = p.getBoolean("smooth", true);
        softShading = p.getBoolean("shade", true);
        gpuMode = p.getBoolean("gpu", false);
        showFps = p.getBoolean("fps", false);
        rt4.FxConfig.look = Math.max(0, Math.min(LOOKS.length - 1, p.getInt("look", 0)));
        rt4.FxConfig.sway = p.getBoolean("sway", false);
        rt4.FxConfig.softShadows = p.getBoolean("softshadow", false);
        msaa = p.getBoolean("msaa", false);
        rt4.FxConfig.tod = Math.max(0, Math.min(TODS.length - 1, p.getInt("tod", 0)));
        rt4.FxConfig.bloom = p.getBoolean("bloom", false);
        rt4.FxConfig.dof = p.getBoolean("dof", false);
        rt4.FxConfig.vignette = p.getBoolean("vignette", false);
    }

    static Settings load(Context c) {
        return new Settings(c.getSharedPreferences(PREFS, Context.MODE_PRIVATE));
    }

    /** Writes the config.json the client reads (same keys as the desktop client). */
    File writeClientConfig(Context c) throws Exception {
        File f = new File(c.getFilesDir(), "config.json");
        String json = "{\n"
                + "  \"ip_management\": \"" + esc(host) + "\",\n"
                + "  \"ip_address\": \"" + esc(host) + "\",\n"
                + "  \"world\": " + world + ",\n"
                + "  \"server_port\": " + serverPort + ",\n"
                + "  \"wl_port\": " + worldListPort + ",\n"
                + "  \"js5_port\": " + js5Port + ",\n"
                + "  \"mouseWheelZoom\": true,\n"
                + "  \"pluginsFolder\": \"plugins\"\n"
                + "}\n";
        try (Writer w = new OutputStreamWriter(new FileOutputStream(f), "UTF-8")) {
            w.write(json);
        }
        return f;
    }

    private static String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
