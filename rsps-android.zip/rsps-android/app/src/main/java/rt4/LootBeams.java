package rt4;

/**
 * Rainbow Scape loot beams: a column of light over valuable items on the ground, coloured by how rare the drop is.
 *   green 50k+   blue 500k+   purple 2m+   gold 10m+   RAINBOW 50m+ or a Rainbow Scape special (Sun set, sunblade, partyhats)
 * Drawn as a 2D overlay right after the 3D scene (before names and hit splats), so it works on GPU and software modes.
 */
public final class LootBeams {
    private LootBeams() {}

    public static volatile boolean enabled = true;

    private static final int T_NONE = 0, T_GREEN = 1, T_BLUE = 2, T_PURPLE = 3, T_GOLD = 4, T_RAINBOW = 5;
    private static final int[] COLOR = {0, 0x3cff5a, 0x3c9bff, 0xc04cff, 0xffb21e, 0};
    private static final int[] RAINBOW = {0xff3b3b, 0xff9a1e, 0xffe62e, 0x4cff6a, 0x2ee6ff, 0x4c7dff, 0xc04cff};
    private static final String[] SPECIAL = {"sun helm", "sun chestplate", "sun tassets", "sun boots", "sun gauntlets",
            "sun kiteshield", "golden sunblade", "partyhat", "christmas cracker", "h'ween mask"};
    private static final java.util.HashMap<Integer, Integer> tierCache = new java.util.HashMap<Integer, Integer>();

    private static int tierOf(ObjStack s) {
        try {
            ObjType t = ObjTypeList.get(s.type);
            if (t == null) return T_NONE;
            Integer special = tierCache.get(s.type);
            if (special == null) {
                String n = t.name == null ? "" : t.name.toString().toLowerCase();
                int sp = T_NONE;
                for (String k : SPECIAL) if (n.contains(k)) { sp = T_RAINBOW; break; }
                tierCache.put(s.type, sp);
                special = sp;
            }
            if (special == T_RAINBOW) return T_RAINBOW;
            long value = (long) Math.max(1, t.cost) * Math.max(1, s.amount);
            if (value >= 50_000_000L) return T_RAINBOW;
            if (value >= 10_000_000L) return T_GOLD;
            if (value >= 2_000_000L) return T_PURPLE;
            if (value >= 500_000L) return T_BLUE;
            if (value >= 50_000L) return T_GREEN;
        } catch (Throwable ignored) { }
        return T_NONE;
    }

    private static void rect(int x, int y, int w, int h, int col, int alpha) {
        if (w <= 0 || h <= 0 || alpha <= 0) return;
        if (alpha > 255) alpha = 255;
        if (GlRenderer.enabled) GlRaster.fillRectAlpha(x, y, w, h, col, alpha);
        else SoftwareRaster.fillRectAlpha(x, y, w, h, col, alpha);
    }

    // beams over players who just won big at the casino: name -> {tier, until}
    private static final java.util.HashMap<String, long[]> playerBeams = new java.util.HashMap<String, long[]>();

    public static void playerBeam(String name, int tier, int secs) {
        int t = tier >= 4 ? T_RAINBOW : tier == 3 ? T_GOLD : tier == 2 ? T_PURPLE : T_BLUE;
        synchronized (playerBeams) { playerBeams.put(name.toLowerCase().replace('_', ' ').trim(), new long[] {t, System.currentTimeMillis() + secs * 1000L}); }
    }

    private static void drawPlayerBeams(int top, int width, int left, int zoomH, int height, int zoomV, long now) {
        synchronized (playerBeams) {
            if (playerBeams.isEmpty()) return;
            java.util.Iterator<java.util.Map.Entry<String, long[]>> it = playerBeams.entrySet().iterator();
            while (it.hasNext()) {
                java.util.Map.Entry<String, long[]> e = it.next();
                if (now > e.getValue()[1]) { it.remove(); continue; }
                Player found = null;
                for (int i = -1; i < PlayerList.size && found == null; i++) {
                    Player pl = i == -1 ? PlayerList.self : PlayerList.players[PlayerList.ids[i]];
                    if (pl == null || pl.username == null) continue;
                    if (pl.username.toString().toLowerCase().replace('_', ' ').trim().equals(e.getKey())) found = pl;
                }
                if (found == null) continue;
                beamAt(top, width, left, zoomH, height, zoomV, found.xFine, found.yFine, (int) e.getValue()[0], now, 11, 7);
            }
        }
    }

    /** called at the start of ScriptRunner.drawOverheads (same arguments) */
    public static void draw(int top, int width, int left, int zoomH, int height, int zoomV) {
        if (!enabled) return;
        try {
            LinkedList[][] stacks = SceneGraph.objStacks[Player.plane];
            if (stacks == null) return;
            long now = System.currentTimeMillis();
            for (int x = 1; x < 103; x++) {
                LinkedList[] col = stacks[x];
                if (col == null) continue;
                for (int y = 1; y < 103; y++) {
                    LinkedList list = col[y];
                    if (list == null) continue;
                    int best = T_NONE;
                    for (Node n = list.head(); n != null; n = list.next()) {
                        if (n instanceof ObjStackNode) {
                            int t = tierOf(((ObjStackNode) n).value);
                            if (t > best) best = t;
                        }
                    }
                    if (best == T_NONE) continue;
                    beam(top, width, left, zoomH, height, zoomV, x, y, best, now);
                }
            }
            drawPlayerBeams(top, width, left, zoomH, height, zoomV, now);
        } catch (Throwable ignored) { }
    }

    private static void beam(int top, int width, int left, int zoomH, int height, int zoomV, int tx, int ty, int tier, long now) {
        beamAt(top, width, left, zoomH, height, zoomV, tx * 128 + 64, ty * 128 + 64, tier, now, tx, ty);
    }

    private static void beamAt(int top, int width, int left, int zoomH, int height, int zoomV, int xf, int yf, int tier, long now, int tx, int ty) {
        ScriptRunner.projectToScreen(width >> 1, zoomH, yf, 0, height >> 1, xf, zoomV);
        int gx = ScriptRunner.screenX, gy = ScriptRunner.screenY;
        if (gx < 0) return;
        int beamUnits = tier >= T_GOLD ? 900 : 700;
        ScriptRunner.projectToScreen(width >> 1, zoomH, yf, beamUnits, height >> 1, xf, zoomV);
        int hy = ScriptRunner.screenY;
        if (ScriptRunner.screenX < 0) hy = gy - 200;
        int len = gy - hy;
        if (len < 8) return;
        float ppu = len / (float) beamUnits;                 // pixels per world unit at this distance
        int core = Math.max(3, Math.round(26 * ppu)), glow = Math.max(6, Math.round(72 * ppu));
        gx += left; gy += top;
        if (gx + glow < left || gx - glow > left + width) return;
        double t = now / 1000.0;
        double pulse = 0.82 + 0.18 * Math.sin(t * 3.0 + tx * 0.7 + ty * 1.3);
        int slices = Math.min(40, Math.max(8, len / 6));
        for (int i = 0; i < slices; i++) {
            int y0 = gy - (int) ((long) len * (i + 1) / slices);
            int y1 = gy - (int) ((long) len * i / slices);
            float f = i / (float) slices;                    // 0 at the ground, 1 at the top
            float fade = (float) Math.pow(1 - f, 1.3);
            int c = tier == T_RAINBOW ? RAINBOW[(int) ((f * 7 + t * 2.2) % 7 + 7) % 7] : COLOR[tier];
            int ga = (int) (105 * fade * pulse), ca = (int) (225 * fade * pulse);
            rect(gx - glow / 2, y0, glow, y1 - y0, c, ga);
            rect(gx - core / 2, y0, core, y1 - y0, c, ca);
            rect(gx - Math.max(1, core / 4), y0, Math.max(1, core / 2), y1 - y0, 0xffffff, (int) (ca * 0.6));
        }
        // a soft pool of light on the ground
        int c0 = tier == T_RAINBOW ? RAINBOW[(int) (t * 3) % 7] : COLOR[tier];
        for (int k = 0; k < 4; k++) {
            int w = glow * (4 - k) / 2, h = Math.max(2, w / 4);
            rect(gx - w / 2, gy - h / 2, w, h, c0, (int) ((35 + k * 25) * pulse));
        }
        // sparkles drifting up the beam (gold and rainbow only)
        if (tier >= T_GOLD) {
            for (int k = 0; k < 4; k++) {
                double p = ((t * 0.35 + k * 0.25) % 1.0);
                int sy = gy - (int) (len * 0.8 * p);
                int sx = gx + (int) (Math.sin(t * 2 + k * 1.9) * glow * 0.35);
                int sc = tier == T_RAINBOW ? RAINBOW[(k * 2 + (int) (t * 2)) % 7] : 0xfff2b0;
                int a = (int) (230 * (1 - p));
                int r = Math.max(1, core / 3);
                rect(sx - r, sy, r * 2 + 1, 1, sc, a);
                rect(sx, sy - r, 1, r * 2 + 1, sc, a);
            }
        }
    }
}
