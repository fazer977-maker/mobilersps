package shim.awt;

public class Color {
    public static final Color black = new Color(0, 0, 0);
    public static final Color BLACK = black;
    public static final Color white = new Color(255, 255, 255);
    public static final Color WHITE = white;
    public static final Color red = new Color(255, 0, 0);
    public static final Color RED = red;
    public static final Color green = new Color(0, 255, 0);
    public static final Color GREEN = green;
    public static final Color blue = new Color(0, 0, 255);
    public static final Color BLUE = blue;
    public static final Color yellow = new Color(255, 255, 0);
    public static final Color YELLOW = yellow;
    public static final Color gray = new Color(128, 128, 128);
    public static final Color GRAY = gray;
    public static final Color lightGray = new Color(192, 192, 192);
    public static final Color darkGray = new Color(64, 64, 64);
    private final int argb;
    public Color(int r, int g, int b) { this(r, g, b, 255); }
    public Color(int r, int g, int b, int a) { argb = (a & 255) << 24 | (r & 255) << 16 | (g & 255) << 8 | (b & 255); }
    public Color(int rgb) { argb = 0xFF000000 | rgb; }
    public Color(int rgba, boolean hasAlpha) { argb = hasAlpha ? rgba : (0xFF000000 | rgba); }
    public int getRGB() { return argb; }
    public int getRed() { return argb >> 16 & 255; }
    public int getGreen() { return argb >> 8 & 255; }
    public int getBlue() { return argb & 255; }
    public int getAlpha() { return argb >>> 24; }
}
