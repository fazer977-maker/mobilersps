package rt4;

/**
 * Rearranges the stock resizable top-level interface (746) into a phone layout:
 * chat at the top-left, tab icons in a column down each edge, tab panel beside the right column.
 * Runs every frame after layout, so script-driven re-layouts are simply overridden again.
 */
public final class MobileLayout {
    public static boolean enabled = true;

    // stone component indexes (layer 25). overlay = +15 (layer 40), icon = +30 (layer 55)
    // 2 columns x 7 rows, filled row by row (stone component indexes)
    private static final int[] GRID = {29, 27, 30, 26, 31, 32, 28, 34, 35, 36, 37, 38, 39, 33};
    private static int gridX, gridY;

    private static boolean captured;
    private static final int[] ovDx = new int[70], ovDy = new int[70], icDx = new int[70], icDy = new int[70];
    private static final int[] stW = new int[70], stH = new int[70], ovW = new int[70], ovH = new int[70], icW = new int[70], icH = new int[70];
    private static int stoneW = 46;

    private MobileLayout() {}

    public static void apply() {
        if (!enabled || InterfaceList.topLevelInterface != 746) {
            return;
        }
        Component[][] all = InterfaceList.components;
        if (all == null || all.length <= 746 || all[746] == null || all[746].length < 111) {
            return;
        }
        Component[] c = all[746];
        if (c[24] == null || c[25] == null || c[40] == null || c[55] == null || c[23] == null || c[70] == null || c[73] == null) {
            return;
        }
        final int w = GameShell.canvasWidth;
        final int h = GameShell.canvasHeight;
        if (w <= 0 || h <= 0) {
            return;
        }

        if (!captured) {
            for (int s = 26; s <= 39; s++) {
                Component st = c[s], ov = c[s + 15], ic = c[s + 30];
                if (st == null || ov == null || ic == null) {
                    return;
                }
                ovDx[s] = ov.x - st.x;
                ovDy[s] = ov.y - st.y;
                icDx[s] = ic.x - st.x;
                icDy[s] = ic.y - st.y;
                stW[s] = st.width; stH[s] = st.height;
                ovW[s] = ov.width; ovH[s] = ov.height;
                icW[s] = ic.width; icH[s] = ic.height;
            }
            captured = true;
        }

        captureStone(c);

        // chat: tab buttons on top, chat box below, overlay under that
        set(c[23], 0, 0);
        set(c[70], 0, 23);
        if (c[71] != null) set(c[71], 9, 165);
        if (c[72] != null) set(c[72], 9, 165);

        // tab containers become full-screen so children can use screen coordinates
        for (int id : new int[] {24, 25, 40, 55}) {
            c[id].x = 0;
            c[id].y = 0;
            c[id].width = w;
            c[id].height = h;
            c[id].noClickThrough = false; // full-screen now, so it must not swallow world clicks
        }

        // 2x7 block of touching icons in the bottom-right, like OSRS mobile
        int top = 190;
        float f = Math.max(1f, Math.min(1.6f, (h - top - 6) / (8f * 36f)));
        int cellH = Math.round(36 * f);
        stoneW = Math.round(33 * f);
        gridX = w - 2 * stoneW - 4;
        gridY = h - 8 * cellH - 4;
        // cell 1 (top right) is the logout button, drawn natively by the app; stones fill cells 2..15
        logoutX = gridX + stoneW;
        logoutY = gridY;
        logoutW = stoneW;
        logoutH = cellH;
        canvasW = w;
        for (int i = 0; i < GRID.length; i++) {
            int cell = i + 2;
            placeOne(c, GRID[i], gridX + (cell % 2) * stoneW, gridY + (cell / 2) * cellH, f);
        }

        // the last slot is the logout tab; the stock script leaves it blank in this layout, so show it
        for (int id : new int[] {33, 48, 63}) {
            if (c[id] != null) {
                c[id].hidden = false;
            }
        }

        // opened tab panel sits to the left of the right column
        c[73].x = Math.max(0, gridX - 4 - c[73].width);
        c[73].y = Math.max(0, h - 4 - c[73].height);
        panelX = c[73].x;
        panelY = c[73].y;
        panelW = c[73].width;
        panelH = c[73].height;
        panelOpen = !c[73].hidden && c[77] != null && !c[77].hidden && c[75] != null && !c[75].hidden;
        try { studioFullscreen(w, h); } catch (RuntimeException e) { studioOpen = false; keepTop = -1; }
        try { bankLayout(c, w, h); } catch (RuntimeException e) { bankOpen = false; }
        try { fitWindows(w, h); } catch (RuntimeException e) { }
        sceneTop = -1;
        for (Component k2 : c) if (k2 != null && k2.clientCode == 1337) { sceneTop = topOf(k2); break; }
        HairPicker.tick();
        Tour.tick();
        Events.tick();
        Rewards.tick();
        WorldBoss.tick();
        Mastery.tick();
        RsFont.tick();
    }

    // ------------------------------------------------------------------ full-screen Character Studio
    /** colour of the studio's backdrop rectangle (component 1); it marks the window as a full-screen one */
    public static final int FS_MAGIC = 0x010203;
    private static final int FS_BG = 0x141826;
    private static Component[] fsGroup;
    private static int[] fsZoom, fsAlpha;
    public static volatile boolean studioOpen;
    /** the full-screen window open is not the Character Studio (e.g. Daily Rewards): no hair pickers for it */
    public static volatile boolean fsGeneric;
    /** the real Character Studio is open */
    public static boolean studioReal() { return studioOpen && !fsGeneric; }
    private static int keepTop = -1;
    private static final Component[] fsChain = new Component[16];
    private static final int[][] fsSaved = new int[16][4];
    private static int fsN;

    private static void studioFullscreen(int w, int h) {
        Component[] cs = null;
        Component container = null;
        Component[][] all = InterfaceList.components;
        for (ComponentPointer cp = (ComponentPointer) InterfaceList.openInterfaces.head(); cp != null; cp = (ComponentPointer) InterfaceList.openInterfaces.next()) {
            if (all == null || cp.interfaceId < 0 || cp.interfaceId >= all.length) continue;
            Component[] g = all[cp.interfaceId];
            if (g != null && g.length > 2 && g[0] != null && g[1] != null && g[2] != null && g[1].type == 3 && (g[1].color == FS_MAGIC || g[1].color == FS_BG) && g[2].type == 0) {
                cs = g;
                container = InterfaceList.getComponent((int) cp.key);
                break;
            }
        }
        if (cs == null || container == null) {
            exitFullscreen();
            return;
        }
        if (!studioOpen) {
            fsN = 0;
            keepTop = -1;
            for (Component k = container; k != null && fsN < fsChain.length; ) {
                fsChain[fsN] = k;
                fsSaved[fsN][0] = k.x; fsSaved[fsN][1] = k.y; fsSaved[fsN][2] = k.width; fsSaved[fsN][3] = k.height;
                fsN++;
                if (k.overlayer == -1) { keepTop = k.id; break; }
                k = InterfaceList.getComponent(k.overlayer);
            }
            StudioView.yaw = 0;
            studioOpen = true;
        }
        for (int i = 0; i < fsN; i++) {
            Component k = fsChain[i];
            k.x = 0; k.y = 0; k.width = w; k.height = h;
        }
        Component root = cs[0], back = cs[1], main = cs[2];
        fsGeneric = main.clientCode == 1610;
        root.x = 0; root.y = 0; root.width = w; root.height = h;
        back.x = 0; back.y = 0; back.width = w; back.height = h; back.color = FS_BG;
        // stretch the whole window to the screen: every part keeps its place, just scaled to fill
        if (fsGroup != cs) {
            fsGroup = cs;
            fsZoom = new int[cs.length];
            for (int i = 0; i < cs.length; i++) if (cs[i] != null) fsZoom[i] = cs[i].modelZoom;
            fsAlpha = new int[cs.length];
            for (int i = 0; i < cs.length; i++) if (cs[i] != null) fsAlpha[i] = cs[i].alpha;
        }
        int bw = Math.max(1, main.baseWidth), bh = Math.max(1, main.baseHeight);
        float sx = w / (float) bw, sy = h / (float) bh;
        main.x = 0; main.y = 0; main.width = w; main.height = h;
        for (int i = 3; i < cs.length; i++) {
            Component k = cs[i];
            if (k == null || k.if3) continue;
            int x0 = Math.round(k.baseX * sx), y0 = Math.round(k.baseY * sy);
            k.x = x0; k.y = y0;
            k.width = Math.max(1, Math.round((k.baseX + k.baseWidth) * sx) - x0);
            k.height = Math.max(1, Math.round((k.baseY + k.baseHeight) * sy) - y0);
            if (k.type == 6 && fsZoom[i] > 0) k.modelZoom = Math.max(50, Math.round(fsZoom[i] / Math.min(sx, sy)));
            if (k.type == 3 && (k.clientCode == 1620 || k.clientCode == 1621)) {
                // 1620 stars twinkle, 1621 glows breathe (alpha: 0 solid .. 255 invisible)
                double t = System.currentTimeMillis() / 1000.0;
                double wv = k.clientCode == 1620 ? Math.sin(t * (2.2 + (i % 7) * 0.45) + i * 1.7) : Math.sin(t * 2.4);
                int base = fsAlpha[i];
                int a = k.clientCode == 1620 ? (int) (base + (255 - base) * (0.5 - 0.5 * wv) * 0.85) : (int) (base + (255 - base) * (0.45 - 0.45 * wv));
                k.alpha = Math.max(0, Math.min(255, a));
                InterfaceList.redraw(k);
            }
            if (k.type == 6 && k.clientCode == 1600 && k.modelType != 4) {   // showcase models turn slowly (items keep their inventory pose)
                k.modelYAngle = (int) ((System.currentTimeMillis() / 7L + i * 97L) & 0x7FF);
                InterfaceList.redraw(k);
            }
        }
        CasinoFx.frame(cs, sx, sy);   // casino reels, roulette ball, dealt cards, dice
    }

    private static void exitFullscreen() {
        if (!studioOpen) return;
        for (int i = 0; i < fsN; i++) {
            Component k = fsChain[i];
            k.x = fsSaved[i][0]; k.y = fsSaved[i][1]; k.width = fsSaved[i][2]; k.height = fsSaved[i][3];
            InterfaceList.redraw(k);
            fsChain[i] = null;
        }
        fsN = 0;
        keepTop = -1;
        studioOpen = false;
        fsGeneric = false;
    }

    /** While the studio is full screen, every other top-level piece of the game screen (chat, minimap, tabs, orbs) is skipped.
     *  While the big bank is open, the chat and the minimap are skipped (the world, the bank, the tabs stay). */
    public static boolean skipTop(Component c) {
        if (c == null || (c.id >>> 16) != 746) return false;
        if (Tour.playing) return c.overlayer == -1 && c.id != sceneTop;     // cutscene: just the world
        if (studioOpen) return c.overlayer == -1 && c.id != keepTop;
        if (bankOpen) {
            int i = c.id & 0xFFFF;
            if (i == 23 || (i >= 70 && i <= 72)) return true;
            if (invPanelChild != -1 && c.overlayer == panelId && c.id != invPanelChild) return true;   // the panel's own frame
            return c.overlayer == -1 && c.id != bankTop && c.id != invTop && !keepTops.contains(c.id);
        }
        return false;
    }

    // ------------------------------------------------------------------ Rainbow Scape names
    private static final java.util.HashMap<String, JagString> retitled = new java.util.HashMap<String, JagString>();

    /** "Bank of RuneScape" -> "Bank of Rainbow Scape" with the flowing rainbow on the name */
    static JagString retitle(Component c, JagString t) {
        if (t == null || (c.id >>> 16) != 762) return t;
        String s = t.toString();
        if (!s.contains("RuneScape")) return t;
        JagString r = retitled.get(s);
        if (r == null) {
            byte[] b = s.replace("RuneScape", "<rbw>Rainbow Scape</rbw>").getBytes(java.nio.charset.StandardCharsets.ISO_8859_1);
            r = new Buffer(java.util.Arrays.copyOf(b, b.length + 1)).gjstr();
            retitled.put(s, r);
        }
        return r;
    }

    // ------------------------------------------------------------------ big bank (GPU only)
    /** the bank (762) and the bank inventory (763) side by side in the middle, both enlarged to fill the screen */
    public static volatile boolean bankOpen;
    private static float bankK = 1f;
    /** enlarging point (top-left of each window as drawn) and unscaled size, for the bank [0] and the inventory [1] */
    private static final int[] zX = new int[2], zY = new int[2], zW = new int[2], zH = new int[2];
    /** offset of each window's visible box inside its container */
    private static final int[] rX = new int[2], rY = new int[2];
    private static final boolean[] zValid = new boolean[2];
    private static int bankTop = -1, invTop = -1;
    private static final java.util.HashSet<Integer> keepTops = new java.util.HashSet<Integer>();

    public static int[] absOf(Component k) { return absPos(k); }

    private static int[] absPos(Component k) {
        int x = 0, y = 0;
        for (int i = 0; k != null && i < 40; i++) {
            x += k.x; y += k.y;
            if (k.overlayer == -1) return new int[] {x, y};
            Component p = InterfaceList.getComponent(k.overlayer);
            if (p == null) return new int[] {x, y};
            x -= p.scrollX; y -= p.scrollY;
            k = p;
        }
        return new int[] {x, y};
    }

    private static int topOf(Component k) {
        for (int i = 0; k != null && i < 40; i++) {
            if (k.overlayer == -1) return k.id;
            k = InterfaceList.getComponent(k.overlayer);
        }
        return -1;
    }

    /** the box the window's own top-level parts cover, relative to its container: {x, y, w, h} */
    private static int[] boxOf(int iface, Component container) {
        Component[] g = InterfaceList.components == null || iface >= InterfaceList.components.length ? null : InterfaceList.components[iface];
        if (g == null) return null;
        int x0 = Integer.MAX_VALUE, y0 = Integer.MAX_VALUE, x1 = Integer.MIN_VALUE, y1 = Integer.MIN_VALUE;
        for (Component k : g) {
            if (k == null || k.overlayer != -1 || k.hidden || k.width <= 0 || k.height <= 0) continue;
            x0 = Math.min(x0, k.x); y0 = Math.min(y0, k.y);
            x1 = Math.max(x1, k.x + k.width); y1 = Math.max(y1, k.y + k.height);
        }
        if (x0 == Integer.MAX_VALUE) return new int[] {0, 0, container.width, container.height};
        return new int[] {x0, y0, x1 - x0, y1 - y0};
    }

    private static boolean dimDone;
    private static Component bankCont;
    private static int bankSavedX, bankSavedY;

    /** the bank closed: put the window holder back where it was, for the next window that uses it */
    private static void restoreBank() {
        if (bankCont == null) return;
        bankCont.x = bankSavedX;
        bankCont.y = bankSavedY;
        InterfaceList.redraw(bankCont);
        bankCont = null;
    }

    private static void closeBank() {
        bankOpen = false;
        zValid[0] = zValid[1] = false;
        invPanelChild = -1;
        restoreBank();
    }

    /** the tab panel's own frame is drawn at normal size; while the big bank is open only the inventory inside it is shown */
    private static int invPanelChild = -1, panelId = -1;

    private static void bankLayout(Component[] c, int w, int h) {
        dimDone = false;
        if (studioOpen || !GlRenderer.enabled) { closeBank(); return; }   // enlarging needs the GPU renderer
        Component bank = null, inv = null;
        for (ComponentPointer cp = (ComponentPointer) InterfaceList.openInterfaces.head(); cp != null; cp = (ComponentPointer) InterfaceList.openInterfaces.next()) {
            if (cp.interfaceId == 762) bank = InterfaceList.getComponent((int) cp.key);
            else if (cp.interfaceId == 763) inv = InterfaceList.getComponent((int) cp.key);
        }
        if (bank == null) { closeBank(); return; }
        if (bankCont != bank) {
            restoreBank();
            bankCont = bank;
            bankSavedX = bank.x; bankSavedY = bank.y;
        }
        int[] bb = boxOf(762, bank);
        int[] ib = inv == null ? null : boxOf(763, inv);
        if (bb == null || bb[2] <= 0 || bb[3] <= 0) return;
        int iw = ib == null ? 0 : ib[2], ih = ib == null ? 0 : ib[3];
        int m = 8, gap = ib == null ? 0 : 10;
        int right = gridX - stoneW - 8;            // keep the icon column and the app's clock / keyboard / logout buttons free
        int availW = right - 2 * m, availH = h - 2 * m;
        float k = Math.min(availW / (float) (bb[2] + gap + iw), availH / (float) Math.max(bb[3], ih));
        k = Math.max(1f, Math.min(2.4f, k));
        int totalW = Math.round(k * (bb[2] + gap + iw));
        int left = m + Math.max(0, (availW - totalW) / 2);
        // bank: put its visible box's top-left at (left, top)
        int bx = left, by = Math.round((h - k * bb[3]) / 2f);
        int[] a = absPos(bank);
        bank.x += bx - (a[0] + bb[0]);
        bank.y += by - (a[1] + bb[1]);
        rX[0] = bb[0]; rY[0] = bb[1]; zW[0] = bb[2]; zH[0] = bb[3];
        bankTop = topOf(bank);
        invTop = -1;
        if (inv == null || ib == null || ib[2] <= 0) { zValid[1] = false; invPanelChild = -1; }
        if (inv != null && ib != null && ib[2] > 0) {
            int ix = left + Math.round(k * (bb[2] + gap)), iy = Math.round((h - k * ib[3]) / 2f);
            int[] ia = absPos(inv);
            // move the tab panel the inventory sits in
            c[73].x += ix - (ia[0] + ib[0]);
            c[73].y += iy - (ia[1] + ib[1]);
            rX[1] = ib[0]; rY[1] = ib[1]; zW[1] = ib[2]; zH[1] = ib[3];
            invTop = topOf(inv);
            panelId = c[73].id;
            invPanelChild = -1;
            for (Component k3 = inv; k3 != null; k3 = InterfaceList.getComponent(k3.overlayer)) {
                if (k3.overlayer == panelId) { invPanelChild = k3.id; break; }
                if (k3.overlayer == -1) break;
            }
        }
        keepTops.clear();
        for (int id : new int[] {24, 25, 40, 55, 73}) if (c[id] != null) keepTops.add(topOf(c[id]));
        // keep the 3D world
        for (Component k2 : c) if (k2 != null && k2.clientCode == 1337) keepTops.add(topOf(k2));
        bankK = k;
        bankOpen = true;
    }

    // ------------------------------------------------------------------ windows that would hang off the screen
    /** holders we moved, with their original position (put back when the window closes) */
    private static final java.util.HashMap<Component, int[]> fitMoved = new java.util.HashMap<Component, int[]>();

    /**
     * A window made for the old fixed-size screen (e.g. Daily Rewards) can sit partly off a narrow phone screen.
     * If its visible box goes past an edge, slide it fully on screen (centred left of the icon column when it fits).
     * Windows that already fit are never touched.
     */
    private static void fitWindows(int w, int h) {
        java.util.HashSet<Component> seen = new java.util.HashSet<Component>();
        if (!studioOpen && !Tour.playing) {
            for (ComponentPointer cp = (ComponentPointer) InterfaceList.openInterfaces.head(); cp != null; cp = (ComponentPointer) InterfaceList.openInterfaces.next()) {
                int iface = cp.interfaceId;
                if (iface == 762 || iface == 763) continue;          // the big bank has its own layout
                Component holder = InterfaceList.getComponent((int) cp.key);
                if (holder == null) continue;
                int[] b = boxOf(iface, holder);
                if (b == null || b[2] <= 0 || b[3] <= 0) continue;
                int[] a = absPos(holder);
                int left = a[0] + b[0], top = a[1] + b[1];
                boolean off = left < 0 || left + b[2] > w || top < 0 || top + b[3] > h;
                boolean was = fitMoved.containsKey(holder);
                if (!off && !was) continue;
                if (!was) fitMoved.put(holder, new int[] {holder.x, holder.y});
                seen.add(holder);
                int avail = gridX > 0 ? gridX - 4 : w;
                int nx = b[2] <= avail ? (avail - b[2]) / 2 : Math.max(0, (w - b[2]) / 2);
                int ny = Math.max(0, Math.min(h - b[3], top));
                if (nx != left || ny != top) {
                    holder.x += nx - left;
                    holder.y += ny - top;
                    InterfaceList.redraw(holder);
                }
            }
        }
        java.util.Iterator<java.util.Map.Entry<Component, int[]>> it = fitMoved.entrySet().iterator();
        while (it.hasNext()) {
            java.util.Map.Entry<Component, int[]> e = it.next();
            if (seen.contains(e.getKey())) continue;
            e.getKey().x = e.getValue()[0];
            e.getKey().y = e.getValue()[1];
            InterfaceList.redraw(e.getKey());
            it.remove();
        }
    }

    /** called around drawing an interface: enlarges the bank and its inventory (GPU renderer) */
    static boolean zoomBegin(int iface, int parentX, int parentY) {
        if (!bankOpen || !GlRenderer.enabled || (iface != 762 && iface != 763)) return false;
        int i = iface == 762 ? 0 : 1;
        com.jogamp.opengl.GL2 gl = GlRenderer.gl;
        if (!dimDone) {
            // dim the world once per frame, before whichever of the two windows is drawn first
            dimDone = true;
            GlRaster.setClip(0, 0, GameShell.canvasWidth, GameShell.canvasHeight);
            GlRaster.fillRectAlpha(0, 0, GameShell.canvasWidth, GameShell.canvasHeight, 0, 110);
        }
        int ox = parentX + rX[i], oy = parentY + rY[i];
        zX[i] = ox; zY[i] = oy; zValid[i] = true;
        float k = bankK;
        float H = GlRenderer.canvasHeight;
        gl.glMatrixMode(com.jogamp.opengl.GL2.GL_PROJECTION);
        gl.glPushMatrix();
        gl.glTranslatef(ox, H - oy, 0f);
        gl.glScalef(k, k, 1f);
        gl.glTranslatef(-ox, -(H - oy), 0f);
        gl.glMatrixMode(com.jogamp.opengl.GL2.GL_MODELVIEW);
        GlRaster.zoomOn = true; GlRaster.zoomK = k; GlRaster.zoomX = ox; GlRaster.zoomY = oy;
        if (i == 1) {
            // the inventory has no background of its own here: give it the bank's
            GlRaster.setClip(0, 0, GameShell.canvasWidth, GameShell.canvasHeight);
            int fx = ox - 6, fy = oy - 6, fw = zW[1] + 12, fh = zH[1] + 12;
            GlRaster.fillRect(fx, fy, fw, fh, 0x2A241D);            // dark outer edge
            GlRaster.fillRect(fx + 1, fy + 1, fw - 2, fh - 2, 0x5C5243);   // stone rim
            GlRaster.fillRect(fx + 3, fy + 3, fw - 6, fh - 6, 0x3E3529);   // the bank's background
        }
        return true;
    }

    /** enlarge again around the same point as the window (for the item being dragged out of it) */
    static boolean zoomAgain(int iface) {
        if (!bankOpen || !GlRenderer.enabled || (iface != 762 && iface != 763)) return false;
        int i = iface == 762 ? 0 : 1;
        if (!zValid[i]) return false;
        int ox = zX[i], oy = zY[i];
        float k = bankK, H = GlRenderer.canvasHeight;
        com.jogamp.opengl.GL2 gl = GlRenderer.gl;
        gl.glMatrixMode(com.jogamp.opengl.GL2.GL_PROJECTION);
        gl.glPushMatrix();
        gl.glTranslatef(ox, H - oy, 0f);
        gl.glScalef(k, k, 1f);
        gl.glTranslatef(-ox, -(H - oy), 0f);
        gl.glMatrixMode(com.jogamp.opengl.GL2.GL_MODELVIEW);
        GlRaster.zoomOn = true; GlRaster.zoomK = k; GlRaster.zoomX = ox; GlRaster.zoomY = oy;
        return true;
    }

    static void zoomEnd() {
        GlRaster.zoomOn = false;
        com.jogamp.opengl.GL2 gl = GlRenderer.gl;
        gl.glMatrixMode(com.jogamp.opengl.GL2.GL_PROJECTION);
        gl.glPopMatrix();
        gl.glMatrixMode(com.jogamp.opengl.GL2.GL_MODELVIEW);
    }

    /** which enlarged window a screen point is over (0 bank, 1 inventory, -1 none) */
    private static int zoomAt(int x, int y) {
        for (int i = 0; i < 2; i++) {
            if (!zValid[i]) continue;
            float k = bankK;
            if (x >= zX[i] && y >= zY[i] && x < zX[i] + zW[i] * k && y < zY[i] + zH[i] * k) return i;
        }
        return -1;
    }

    /** touch position (screen) -> where the game should think it is (the window's normal-size spot) */
    public static int mapX(int x, int y) {
        if (!bankOpen || Cs1ScriptRunner.isMenuOpen) return x;
        int i = zoomAt(x, y);
        return i < 0 ? x : zX[i] + Math.round((x - zX[i]) / bankK);
    }

    public static int mapY(int x, int y) {
        if (!bankOpen || Cs1ScriptRunner.isMenuOpen) return y;
        int i = zoomAt(x, y);
        return i < 0 ? y : zY[i] + Math.round((y - zY[i]) / bankK);
    }

    /** the reverse: a game position inside a window's normal-size spot -> where it is drawn on screen */
    private static int unzoomAt(int x, int y) {
        for (int i = 0; i < 2; i++) {
            if (zValid[i] && x >= zX[i] && y >= zY[i] && x < zX[i] + zW[i] && y < zY[i] + zH[i]) return i;
        }
        return -1;
    }

    public static int screenX(int x, int y) {
        int i = unzoomAt(x, y);
        return i < 0 ? x : zX[i] + Math.round((x - zX[i]) * bankK);
    }

    public static int screenY(int x, int y) {
        int i = unzoomAt(x, y);
        return i < 0 ? y : zY[i] + Math.round((y - zY[i]) * bankK);
    }

    /** Hide the native button when a full-screen interface would be covered by it (never, for now). */
    /** true while the full-screen welcome scroll (interface 378) is open; set on the game thread each frame */
    public static volatile boolean welcomeOpen = false;
    public static boolean logoutHidden() { return welcomeOpen || studioOpen || Tour.playing; }
    private static int sceneTop = -1;

    /** The game's own stone-tab background, copied once so the app can reuse it (ARGB, stoneWpx x stoneHpx). */
    public static volatile int[] stonePx;
    public static volatile int stoneWpx, stoneHpx;

    private static void captureStone(Component[] c) {
        if (stonePx != null) {
            return;
        }
        try {
            Sprite sp = c[26].getSprite(false);
            if (!(sp instanceof SoftwareSprite)) {
                return;
            }
            SoftwareSprite ss = (SoftwareSprite) sp;
            int iw = ss.innerWidth, ih = ss.innerHeight;
            if (ss.pixels == null || iw <= 0 || ih <= 0 || iw > 256 || ih > 256) {
                return;
            }
            int[] out = new int[iw * ih];
            for (int y = 0; y < ss.height; y++) {
                for (int x = 0; x < ss.width; x++) {
                    int dx = x + ss.xOffset, dy = y + ss.yOffset;
                    if (dx < 0 || dy < 0 || dx >= iw || dy >= ih) continue;
                    int px = ss.pixels[y * ss.width + x];
                    out[dy * iw + dx] = px == 0 ? 0 : (0xFF000000 | px);
                }
            }
            stoneWpx = iw;
            stoneHpx = ih;
            stonePx = out;
        } catch (Throwable ignored) {
        }
    }

    public static volatile int logoutX, logoutY, logoutW, logoutH, canvasW;
    private static volatile boolean panelOpen;
    private static volatile int panelX, panelY, panelW, panelH;

    /** True when logical point (x, y) is over the 3D world rather than a button, panel, chat or minimap. */
    public static boolean touchIsWorld(int x, int y) {
        int w = GameShell.canvasWidth;
        if (studioOpen || Tour.playing) return false;
        if (bankOpen && zoomAt(x, y) >= 0) return false;     // the big bank and its inventory
        if (x >= gridX && y >= gridY) return false;          // icon block
        if (!bankOpen && x < 520 && y < 170) return false;   // chat (hidden while the big bank is open)
        if (!bankOpen && x >= w - 225 && y < 190) return false;   // minimap and orbs (hidden with the big bank)
        if (panelOpen && x >= panelX && x < panelX + panelW && y >= panelY && y < panelY + panelH) return false;
        return true;
    }

    /** True when logical point (x, y) is over the chat message box (below the filter buttons). */
    public static boolean isChat(int x, int y) {
        return enabled && !studioOpen && !bankOpen && !Tour.playing && x >= 0 && x < 519 && y >= 23 && y < 165;
    }

    private static void set(Component comp, int x, int y) {
        comp.x = x;
        comp.y = y;
    }

    private static void placeOne(Component[] c, int s, int x, int y, float f) {
        c[s].x = x;
        c[s].y = y;
        c[s].width = Math.round(stW[s] * f);
        c[s].height = Math.round(stH[s] * f);
        c[s + 15].x = x + Math.round(ovDx[s] * f);
        c[s + 15].y = y + Math.round(ovDy[s] * f);
        c[s + 15].width = Math.round(ovW[s] * f);
        c[s + 15].height = Math.round(ovH[s] * f);
        c[s + 30].x = x + Math.round(icDx[s] * f);
        c[s + 30].y = y + Math.round(icDy[s] * f);
        c[s + 30].width = Math.round(icW[s] * f);
        c[s + 30].height = Math.round(icH[s] * f);
    }
}
