package rt4;

/** Server time sent by the game server at login as a hidden chat line "~srvtime~<epoch ms>|<utc offset minutes>|<zone label>". */
public final class ServerClock {
    private ServerClock() {}
    public static final String TAG = "~srvtime~";
    public static volatile boolean known = false;
    public static volatile long skewMs = 0;          // server clock minus phone clock
    public static volatile int offsetMin = 0;        // server time zone offset from UTC
    public static volatile String label = "";

    /** returns true if the message was a server clock line (and must not be shown in chat) */
    public static boolean handle(JagString msg) {
        if (msg == null) return false;
        String s = msg.toString();
        int i = s.indexOf(TAG);
        if (i < 0) return false;
        try {
            String[] p = s.substring(i + TAG.length()).split("\\|");
            long server = Long.parseLong(p[0].trim());
            skewMs = server - System.currentTimeMillis();
            offsetMin = p.length > 1 ? Integer.parseInt(p[1].trim()) : 0;
            label = p.length > 2 ? p[2].trim() : "";
            known = true;
        } catch (Exception ignored) { }
        return true;
    }

    /** server local time as {hour, minute, second}; null until the server has sent its clock */
    public static int[] now() {
        if (!known) return null;
        long t = System.currentTimeMillis() + skewMs + offsetMin * 60000L;
        long secs = Math.floorMod(t / 1000L, 86400L);
        return new int[] {(int) (secs / 3600), (int) (secs / 60 % 60), (int) (secs % 60)};
    }
}
