package app.rsps2009;

/** JNI side of the experimental GPU mode (gl4es). Everything here may be missing; callers must check {@link #loaded}. */
final class Gl4esNative {
    static volatile boolean loaded;
    static volatile String loadError = "";

    static {
        try {
            System.loadLibrary("gl4esbridge");
            loaded = true;
        } catch (Throwable t) {
            loaded = false;
            loadError = String.valueOf(t);
        }
    }

    static native String nInit(String gl4esPath);
    static native String nString(int name);
    static native int nDraw(int w, int h, float t);

    private Gl4esNative() { }
}
