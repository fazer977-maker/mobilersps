package rt4;

/**
 * Rainbow Scape particle system.
 * Players wearing the Rainbow cape shed sparks from the cape that fall under gravity and stay in the world
 * (so a trail is left behind when walking). The Halo gives a slow rising shimmer around the head.
 * Drawn as small alpha-blended squares right after the 3D scene each frame.
 */
public final class RainbowFx {

	/** item ids (must match the server) */
	public static final int CAPE_ID = 14670;
	public static final int HALO_ID = 14671;

	private static final int MAX = 900;
	private static final float[] px = new float[MAX], py = new float[MAX], ph = new float[MAX];
	private static final float[] vx = new float[MAX], vy = new float[MAX], vh = new float[MAX];
	private static final float[] age = new float[MAX], life = new float[MAX], hue = new float[MAX], grav = new float[MAX];
	private static final byte[] size = new byte[MAX];
	private static int count = 0;
	private static long last = 0L;
	private static float clock = 0.0F;
	private static final java.util.Random rnd = new java.util.Random();

	private static void spawn(float x, float y, float h, float dx, float dy, float dh, float g, float lifeSec, float hu, int sz) {
		if (count >= MAX) {
			return;
		}
		int i = count++;
		px[i] = x; py[i] = y; ph[i] = h;
		vx[i] = dx; vy[i] = dy; vh[i] = dh;
		grav[i] = g; age[i] = 0.0F; life[i] = lifeSec; hue[i] = hu; size[i] = (byte) sz;
	}

	private static void emit(Player p, float dt) {
		if (p.fxCape == CAPE_ID) {
			p.fxAcc += 52.0F * dt;
			int a = p.currentAngle & 0x7FF;
			float sin = MathUtils.sin[a] / 65536.0F, cos = MathUtils.cos[a] / 65536.0F;
			while (p.fxAcc >= 1.0F) {
				p.fxAcc -= 1.0F;
				// a point on the cape surface: across the shoulders, anywhere down the back, a little behind the body
				float lx = (rnd.nextFloat() * 2.0F - 1.0F) * (6.0F + 18.0F * rnd.nextFloat());
				float h = 14.0F + rnd.nextFloat() * 150.0F;
				float lz = 12.0F + (1.0F - h / 170.0F) * 14.0F;
				float wx = p.xFine + lx * cos + lz * sin;
				float wy = p.yFine + lz * cos - lx * sin;
				float hu = (h / 190.0F) * 0.85F + clock * 0.25F;
				// drifts out gently, then falls
				float dx = (rnd.nextFloat() - 0.5F) * 14.0F + sin * 10.0F;
				float dy = (rnd.nextFloat() - 0.5F) * 14.0F + cos * 10.0F;
				spawn(wx, wy, h, dx, dy, 6.0F + rnd.nextFloat() * 14.0F, 190.0F + rnd.nextFloat() * 90.0F,
					0.9F + rnd.nextFloat() * 0.9F, hu, rnd.nextInt(4) == 0 ? 2 : 1);
			}
		}
		if (p.fxHat == HALO_ID) {
			p.fxAcc += 16.0F * dt;
			while (p.fxAcc >= 1.0F) {
				p.fxAcc -= 1.0F;
				float ang = rnd.nextFloat() * 6.2831855F;
				float wx = p.xFine + 14.0F * (float) Math.cos(ang);
				float wy = p.yFine + 14.0F * (float) Math.sin(ang);
				spawn(wx, wy, 204.0F + rnd.nextFloat() * 8.0F, 0.0F, 0.0F, 10.0F + rnd.nextFloat() * 14.0F, -2.0F,
					0.8F + rnd.nextFloat() * 0.8F, ang / 6.2831855F + clock * 0.3F, 1);
			}
		}
	}

	private static int rgb(float hu) {
		hu -= (float) Math.floor(hu);
		float h6 = hu * 6.0F;
		int i = (int) h6;
		float f = h6 - i;
		float s = 0.55F, v = 1.0F;
		float p = v * (1.0F - s), q = v * (1.0F - s * f), t = v * (1.0F - s * (1.0F - f));
		float r, g, b;
		switch (i % 6) {
			case 0: r = v; g = t; b = p; break;
			case 1: r = q; g = v; b = p; break;
			case 2: r = p; g = v; b = t; break;
			case 3: r = p; g = q; b = v; break;
			case 4: r = t; g = p; b = v; break;
			default: r = v; g = p; b = q; break;
		}
		return ((int) (r * 255.0F) << 16) | ((int) (g * 255.0F) << 8) | (int) (b * 255.0F);
	}

	private static void rect(int x, int y, int w, int h, int color, int alpha) {
		if (alpha <= 0) {
			return;
		}
		if (alpha > 255) {
			alpha = 255;
		}
		if (GlRenderer.enabled) {
			GlRaster.fillRectAlpha(x, y, w, h, color, alpha);
		} else {
			SoftwareRaster.fillRectAlpha(x, y, w, h, color, alpha);
		}
	}

	public static void draw(int top, int width, int left, int zoomH, int height, int zoomV) {
		long now = System.nanoTime();
		float dt = last == 0L ? 0.0F : (now - last) / 1.0E9F;
		last = now;
		if (dt > 0.1F) {
			dt = 0.1F;
		}
		clock += dt;
		// emit from everyone wearing an effect item
		try {
			Player self = PlayerList.self;
			if (self != null && self.isVisible()) {
				emit(self, dt);
			}
			for (int i = 0; i < PlayerList.size; i++) {
				Player p = PlayerList.players[PlayerList.ids[i]];
				if (p != null && p != self && p.isVisible()) {
					emit(p, dt);
				}
			}
		} catch (RuntimeException e) {
			// never let the effect break the game
		}
		int unit = Math.max(1, width / 240);
		for (int i = 0; i < count; ) {
			age[i] += dt;
			vh[i] -= grav[i] * dt;
			ph[i] += vh[i] * dt;
			px[i] += vx[i] * dt;
			py[i] += vy[i] * dt;
			if (age[i] >= life[i] || ph[i] < 0.0F) {
				count--;
				px[i] = px[count]; py[i] = py[count]; ph[i] = ph[count];
				vx[i] = vx[count]; vy[i] = vy[count]; vh[i] = vh[count];
				age[i] = age[count]; life[i] = life[count]; hue[i] = hue[count]; grav[i] = grav[count]; size[i] = size[count];
				continue;
			}
			float t = age[i] / life[i];
			int alpha = (int) (235.0F * Math.min(1.0F, age[i] * 12.0F) * (1.0F - t) * (1.0F - t * 0.4F));
			ScriptRunner.projectToScreen(width >> 1, zoomH, (int) py[i], (int) ph[i], height >> 1, (int) px[i], zoomV);
			int sx = ScriptRunner.screenX, sy = ScriptRunner.screenY;
			if (sx != -1 || sy != -1) {
				int color = rgb(hue[i] + t * 0.15F);
				int s = unit * size[i];
				// soft halo, bright core
				rect(left + sx - s, top + sy - s, s * 2 + 1, s * 2 + 1, color, alpha / 4);
				rect(left + sx - (s >> 1), top + sy - (s >> 1), s + 1, s + 1, 0xFFFFFF, alpha / 2);
				rect(left + sx - (s >> 1), top + sy - (s >> 1), s, s, color, alpha);
			}
			i++;
		}
	}
}
