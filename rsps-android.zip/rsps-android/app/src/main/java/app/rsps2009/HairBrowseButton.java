package app.rsps2009;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

/** The "HAIR · Browse" button the app lays over the Studio's hair row; opens the hair picker. */
final class HairBrowseButton extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Typeface bold = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD);
    private final float d;

    HairBrowseButton(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        float pad = Math.max(1f, h * 0.06f);
        r.set(pad, pad, w - pad, h - pad);
        float rad = r.height() / 2f;
        double t = System.currentTimeMillis() / 600.0;
        float glow = 0.5f + 0.5f * (float) Math.sin(t);
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom, 0xFF4A3F8C, 0xFF2C2560, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1.5f, h * 0.05f));
        p.setColor(android.graphics.Color.argb(150 + Math.round(105 * glow), 255, 201, 74));
        c.drawRoundRect(r, rad, rad, p);
        p.setStyle(Paint.Style.FILL);

        // 2 x 2 grid icon
        float u = r.height() * 0.16f, ix = r.left + rad * 0.8f, iy = r.centerY() - u - u * 0.15f;
        p.setColor(0xFFFFC94A);
        for (int k = 0; k < 4; k++) {
            float x = ix + (k % 2) * (u * 1.3f), y = iy + (k / 2) * (u * 1.3f);
            c.drawRoundRect(new RectF(x, y, x + u, y + u), u * 0.25f, u * 0.25f, p);
        }
        float tx = ix + u * 2.3f + r.height() * 0.18f;
        float avail = r.right - rad * 0.5f - tx;
        p.setTypeface(bold);
        float big = Math.min(r.height() * 0.34f, 15 * d);
        p.setTextSize(big);
        p.setColor(0xFFFFC94A);
        c.drawText("HAIR", tx, r.centerY() - big * 0.08f, p);
        p.setTextSize(big * 0.78f);
        p.setColor(0xFFF2F3F8);
        String s = avail > p.measureText("Browse all") ? "Browse all" : "Browse";
        c.drawText(s, tx, r.centerY() + big * 0.92f, p);
        if (getVisibility() == VISIBLE) postInvalidateDelayed(50);
    }
}
