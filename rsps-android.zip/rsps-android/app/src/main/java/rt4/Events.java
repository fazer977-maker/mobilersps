package rt4;

/**
 * Rainbow Scape world events: the server's event messages end with a [Teleport] button (drawn in rainbow).
 * Tapping that chat line sends ::eventtp (the server checks there is an event to go to).
 */
public final class Events {
    private Events() {}

    public static final String BUTTON = "[Teleport]";
    private static volatile boolean tpWanted;

    /** UI thread: a tap on the chat box at game position (x, y). True if it hit an event's [Teleport] line. */
    public static boolean chatTap(int x, int y) {
        try {
            Component[][] all = InterfaceList.components;
            if (all == null) return false;
            for (ComponentPointer cp = (ComponentPointer) InterfaceList.openInterfaces.head(); cp != null; cp = (ComponentPointer) InterfaceList.openInterfaces.next()) {
                if (hit(all, cp.interfaceId, x, y)) return true;
            }
            return hit(all, InterfaceList.topLevelInterface, x, y);
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean hit(Component[][] all, int iface, int x, int y) {
        if (iface < 0 || iface >= all.length || all[iface] == null) return false;
        for (Component c : all[iface]) {
            if (c == null || c.type != 4 || c.text == null || c.hidden) continue;
            if (!c.text.toString().contains(BUTTON)) continue;
            int[] a = MobileLayout.absOf(c);
            // the whole line is the button: easier to hit with a finger
            if (x >= a[0] && x < a[0] + c.width && y >= a[1] - 2 && y < a[1] + Math.max(c.height, 14) + 2) {
                tpWanted = true;
                return true;
            }
        }
        return false;
    }

    public static void tick() {
        try {
            if (tpWanted && client.gameState == 30) {
                tpWanted = false;
                JagString line = JagString.parse("::eventtp");
                Protocol.outboundBuffer.p1isaac(ClientProt.CLIENT_CHEAT);
                Protocol.outboundBuffer.p1(line.length() - 1);
                Protocol.outboundBuffer.pjstr(line.substring(2));
            }
        } catch (Throwable ignored) {
        }
    }
}
