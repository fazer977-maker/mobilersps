package shim.awt;

import shim.platform.Platforms;

public class Frame extends Window {
    public Frame() {}
    public Frame(String title) { setTitle(title); }
    public void setTitle(String t) { title = t == null ? "" : t; Platforms.current.setTitle(title); }
    public String getTitle() { return title; }
    public void setResizable(boolean b) {}
    public void setUndecorated(boolean b) {}
    public void setExtendedState(int s) {}
    @Override public void setSize(int w, int h) {}
    @Override public Dimension getSize() { return new Dimension(getWidth(), getHeight()); }
    @Override public int getWidth() { return Platforms.current.viewWidth(); }
    @Override public int getHeight() { return Platforms.current.viewHeight(); }
    @Override public Insets getInsets() { return new Insets(0, 0, 0, 0); }
}
