package app.rsps2009;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Zips the downloaded game cache into the public Download folder so it can be uploaded from a file picker. */
final class CacheExport {
    private CacheExport() { }

    /** Finds every directory under root that holds a main_file_cache.dat2. */
    static List<File> findCacheDirs(File root) {
        List<File> out = new ArrayList<>();
        walk(root, out, 0);
        return out;
    }

    private static void walk(File dir, List<File> out, int depth) {
        if (depth > 6) return;
        File[] kids = dir.listFiles();
        if (kids == null) return;
        boolean here = false;
        for (File k : kids) if (k.isFile() && k.getName().equals("main_file_cache.dat2")) here = true;
        if (here) out.add(dir);
        for (File k : kids) if (k.isDirectory()) walk(k, out, depth + 1);
    }

    /** Returns a short human-readable result. Run off the UI thread. */
    static String export(Context c) {
        try {
            File home = c.getFilesDir();
            List<File> dirs = findCacheDirs(home);
            if (dirs.isEmpty()) return "No cache found yet. Press Play once and let it finish downloading, then try again.";
            File best = dirs.get(0);
            for (File d : dirs) if (new File(d, "main_file_cache.dat2").length() > new File(best, "main_file_cache.dat2").length()) best = d;

            String name = "2009scape_cache.zip";
            OutputStream raw;
            String where;
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                ContentResolver cr = c.getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, "application/zip");
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) return "Could not create a file in Download.";
                raw = cr.openOutputStream(u);
                where = "Download/" + name;
            } else {
                File dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                dl.mkdirs();
                File f = new File(dl, name);
                raw = new java.io.FileOutputStream(f);
                where = f.getAbsolutePath();
            }
            long total = 0; int n = 0;
            try (ZipOutputStream z = new ZipOutputStream(new java.io.BufferedOutputStream(raw))) {
                z.setLevel(1);
                File[] files = best.listFiles();
                if (files != null) for (File f : files) {
                    if (!f.isFile() || !f.getName().startsWith("main_file_cache")) continue;
                    z.putNextEntry(new ZipEntry(f.getName()));
                    try (FileInputStream in = new FileInputStream(f)) {
                        byte[] buf = new byte[1 << 16]; int r;
                        while ((r = in.read(buf)) > 0) { z.write(buf, 0, r); total += r; }
                    }
                    z.closeEntry(); n++;
                }
            }
            return "Exported " + n + " files (" + (total / 1048576) + " MB) to " + where + "\nFrom: " + best.getAbsolutePath().replace(home.getAbsolutePath(), "<app files>");
        } catch (Throwable t) {
            return "Export failed: " + t;
        }
    }
}
