package app.rsps2009;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

import rt4.Tour;

/** The intro cutscene's black bars, captions and Next / Skip buttons. The game moves the camera (rt4.Tour). */
final class TourView extends View {
    private static final int GOLD = 0xFFFFC94A, TXT = 0xFFF2F3F8, TXT2 = 0xFFA3A9C2;
    private static final int[] RAINBOW = {0xFFFF3030, 0xFFFF8A1E, 0xFFFFE62E, 0xFF4CFF4C, 0xFF2EE6FF, 0xFF4C7DFF, 0xFFC04CFF};

    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Typeface bold = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD);
    private final Typeface reg = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL);
    private final RectF r = new RectF(), card = new RectF(), nextR = new RectF(), skipR = new RectF();

    private int shownVersion = -1, shownIndex = -1;
    private long openedAt, sceneAt;
    private boolean typingDone;

    TourView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        setVisibility(GONE);
    }

    /** called by the activity's poller (UI thread) */
    void sync() {
        boolean on = Tour.playing;
        if (on && getVisibility() != VISIBLE) {
            setVisibility(VISIBLE);
            openedAt = System.currentTimeMillis();
            shownVersion = Tour.version;
            shownIndex = -1;
            postInvalidateOnAnimation();
        } else if (!on && getVisibility() == VISIBLE) {
            setVisibility(GONE);
        }
    }

    @Override protected void onDraw(Canvas c) {
        if (!Tour.playing) { setVisibility(GONE); return; }
        Tour.Scene[] ss = Tour.scenes;
        int i = Math.max(0, Math.min(ss.length - 1, Tour.index));
        long now = System.currentTimeMillis();
        if (i != shownIndex) { shownIndex = i; sceneAt = now; typingDone = false; }
        Tour.Scene s = ss[i];
        float w = getWidth(), h = getHeight();

        // black bars slide in
        float in = Math.min(1f, (now - openedAt) / 600f);
        in = in * in * (3 - 2 * in);
        float bar = h * 0.11f * in;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF000000);
        c.drawRect(0, 0, w, bar, p);
        c.drawRect(0, h - bar, w, h, p);

        // Skip, top right
        p.setTypeface(bold);
        p.setTextSize(14 * d);
        String skip = "Skip  ››";
        float sw = p.measureText(skip);
        skipR.set(w - sw - 36 * d, 8 * d, w - 12 * d, 8 * d + 34 * d);
        p.setColor(0x33FFFFFF);
        c.drawRoundRect(skipR, skipR.height() / 2, skipR.height() / 2, p);
        p.setColor(TXT);
        c.drawText(skip, skipR.centerX() - sw / 2, skipR.centerY() + 5 * d, p);

        // caption card
        float cw = Math.min(w - 32 * d, 720 * d);
        float pad = 18 * d;
        p.setTypeface(reg);
        p.setTextSize(15.5f * d);
        ArrayList<String> lines = wrap(s.text, cw - 2 * pad);
        float lineH = 21 * d;
        float ch = pad + 26 * d + 8 * d + lines.size() * lineH + 14 * d + 40 * d + pad * 0.6f;
        float cx = (w - cw) / 2, cy = h - 14 * d - ch;
        float rise = (1 - Math.min(1f, (now - sceneAt) / 350f)) * 18 * d;
        card.set(cx, cy + rise, cx + cw, cy + ch + rise);
        p.setColor(0x66000000);
        r.set(card.left, card.top + 5 * d, card.right, card.bottom + 7 * d);
        c.drawRoundRect(r, 20 * d, 20 * d, p);
        p.setShader(new LinearGradient(0, card.top, 0, card.bottom, 0xF0242A44, 0xF0161A2B, Shader.TileMode.CLAMP));
        c.drawRoundRect(card, 20 * d, 20 * d, p);
        p.setShader(null);
        // rainbow edge on top
        float segW = (card.width() - 40 * d) / RAINBOW.length;
        for (int k = 0; k < RAINBOW.length; k++) {
            p.setColor(RAINBOW[(int) ((k + now / 160) % RAINBOW.length)]);
            c.drawRect(card.left + 20 * d + k * segW, card.top, card.left + 20 * d + (k + 1) * segW, card.top + 3 * d, p);
        }

        // title
        p.setTypeface(bold);
        p.setTextSize(21 * d);
        p.setColor(GOLD);
        float y = card.top + pad + 20 * d;
        drawTitle(c, s.title, card.left + pad, y, now);
        // text, typed out
        p.setTypeface(reg);
        p.setTextSize(15.5f * d);
        p.setColor(TXT);
        int total = 0;
        for (String l : lines) total += l.length();
        int shown = typingDone ? total : (int) ((now - sceneAt - 250) / 22);
        if (shown >= total) typingDone = true;
        y += 12 * d;
        int left = Math.max(0, shown);
        for (String l : lines) {
            y += lineH;
            if (left <= 0) break;
            String part = l.length() <= left ? l : l.substring(0, left);
            left -= l.length();
            c.drawText(part, card.left + pad, y, p);
        }

        // progress dots + Next
        float by = card.bottom - pad * 0.6f - 20 * d;
        for (int k = 0; k < ss.length; k++) {
            p.setColor(k == i ? GOLD : 0x55FFFFFF);
            c.drawCircle(card.left + pad + 5 * d + k * 16 * d, by, k == i ? 5 * d : 4 * d, p);
        }
        boolean last = i >= ss.length - 1;
        String nx = last ? "Let's go!" : "Next  ›";
        p.setTypeface(bold);
        p.setTextSize(15 * d);
        float nw = p.measureText(nx) + 36 * d;
        nextR.set(card.right - pad - nw, by - 19 * d, card.right - pad, by + 19 * d);
        float pulse = typingDone ? 0.5f + 0.5f * (float) Math.sin(now / 300.0) : 0f;
        p.setColor(GOLD);
        c.drawRoundRect(nextR, nextR.height() / 2, nextR.height() / 2, p);
        if (pulse > 0) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2 * d);
            p.setColor(android.graphics.Color.argb(Math.round(140 * pulse), 255, 201, 74));
            r.set(nextR.left - 4 * d, nextR.top - 4 * d, nextR.right + 4 * d, nextR.bottom + 4 * d);
            c.drawRoundRect(r, r.height() / 2, r.height() / 2, p);
            p.setStyle(Paint.Style.FILL);
        }
        p.setColor(0xFF1A1405);
        c.drawText(nx, nextR.centerX() - p.measureText(nx) / 2, nextR.centerY() + 5.5f * d, p);
        p.setTypeface(reg);
        p.setTextSize(12 * d);
        p.setColor(TXT2);
        String hint = (i + 1) + " / " + ss.length;
        c.drawText(hint, card.left + pad + ss.length * 16 * d + 8 * d, by + 4 * d, p);

        postInvalidateOnAnimation();
    }

    /** gold title; the words "Rainbow Scape" get a letter-by-letter flowing rainbow */
    private void drawTitle(Canvas c, String t, float x, float y, long now) {
        int at = t.indexOf("Rainbow Scape");
        if (at < 0) { c.drawText(t, x, y, p); return; }
        String a = t.substring(0, at), name = "Rainbow Scape", b = t.substring(at + name.length());
        c.drawText(a, x, y, p);
        x += p.measureText(a);
        int shift = (int) ((now / 140L) % RAINBOW.length);
        int ci = 0;
        for (int i = 0; i < name.length(); i++) {
            String ch = name.substring(i, i + 1);
            if (!ch.equals(" ")) { p.setColor(RAINBOW[(ci + shift) % RAINBOW.length]); ci++; }
            c.drawText(ch, x, y, p);
            x += p.measureText(ch);
        }
        p.setColor(GOLD);
        c.drawText(b, x, y, p);
    }

    private ArrayList<String> wrap(String text, float max) {
        ArrayList<String> out = new ArrayList<String>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            if (word.isEmpty()) continue;
            String tryL = line.length() == 0 ? word : line + " " + word;
            if (p.measureText(tryL) > max && line.length() > 0) {
                out.add(line.toString());
                line.setLength(0);
                line.append(word);
            } else {
                line.setLength(0);
                line.append(tryL);
            }
        }
        if (line.length() > 0) out.add(line.toString());
        if (out.isEmpty()) out.add("");
        return out;
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (!Tour.playing) return false;
        if (e.getActionMasked() != MotionEvent.ACTION_UP) return true;
        float x = e.getX(), y = e.getY();
        r.set(skipR);
        r.inset(-8 * d, -8 * d);
        if (r.contains(x, y)) { Tour.stop(); return true; }
        if (!typingDone) { typingDone = true; return true; }   // first tap shows all the text
        Tour.next();
        return true;
    }
}
