package app.rsps2009;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/** Second app icon: opens the settings screen (UI size, anti-aliasing, shading, GPU test). The main icon still goes straight into the game. */
public class SettingsEntryActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Intent i = new Intent(this, LauncherActivity.class);
        i.putExtra("settings", true);
        startActivity(i);
        finish();
    }
}
