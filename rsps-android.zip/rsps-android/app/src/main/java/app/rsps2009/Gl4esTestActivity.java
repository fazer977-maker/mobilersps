package app.rsps2009;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.graphics.Color;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileWriter;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** Experimental: loads gl4es, draws a spinning triangle with OLD OpenGL calls, and reports what happened. Changes nothing. */
public class Gl4esTestActivity extends Activity {
    private GLSurfaceView gl;
    private TextView out;
    private volatile String head = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(2);
        gl.setRenderer(new R());
        root.addView(gl, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        ScrollView sv = new ScrollView(this);
        out = new TextView(this);
        out.setTextColor(Color.WHITE);
        out.setBackgroundColor(0xAA000000);
        out.setTextSize(12);
        out.setPadding(24, 48, 24, 24);
        sv.addView(out);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        root.addView(sv, lp);
        setContentView(root);
        out.setText("GL4ES TEST\nstarting...");
    }

    @Override protected void onPause() { super.onPause(); gl.onPause(); }
    @Override protected void onResume() { super.onResume(); gl.onResume(); }

    private void show(final String s) {
        runOnUiThread(new Runnable() { @Override public void run() { out.setText(s); } });
        try { FileWriter w = new FileWriter(new File(getFilesDir(), "gl4estest.txt")); w.write(s); w.close(); } catch (Throwable ignored) { }
    }

    private final class R implements GLSurfaceView.Renderer {
        boolean ok;
        long start, last;
        int frames, w = 1, h = 1, err;

        @Override public void onSurfaceCreated(GL10 g, EGLConfig c) {
            StringBuilder sb = new StringBuilder("GL4ES TEST\n\n");
            if (!Gl4esNative.loaded) {
                sb.append("Bridge library NOT loaded: ").append(Gl4esNative.loadError).append("\n\nThe GitHub build could not compile the GPU parts. Send the Actions log (the 'native build' section).\n");
                show(sb.toString());
                return;
            }
            ApplicationInfo ai = getApplicationInfo();
            String path = ai.nativeLibraryDir + "/libgl4es.so";
            sb.append("Bridge loaded.\nlib path: ").append(path).append(new File(path).exists() ? " (exists)" : " (MISSING)").append("\n\n");
            sb.append(Gl4esNative.nInit(path));
            sb.append("\nGL_VENDOR:   ").append(Gl4esNative.nString(0x1F00)).append('\n');
            sb.append("GL_RENDERER: ").append(Gl4esNative.nString(0x1F01)).append('\n');
            sb.append("GL_VERSION:  ").append(Gl4esNative.nString(0x1F02)).append('\n');
            head = sb.toString();
            ok = true;
            show(head + "\ndrawing...");
        }

        @Override public void onSurfaceChanged(GL10 g, int width, int height) { w = width; h = height; }

        @Override public void onDrawFrame(GL10 g) {
            if (!ok) return;
            long now = System.nanoTime();
            if (start == 0) { start = now; last = now; }
            err = Gl4esNative.nDraw(w, h, (now - start) / 1e9f);
            frames++;
            if (now - last > 1_500_000_000L) {
                show(head + "\nglGetError after drawing: 0x" + Integer.toHexString(err) + (err == 0 ? " (no error)" : err == -1 ? " (draw functions missing)" : "") + "\nframes: " + frames
                        + "\n\nIf you see a spinning red/green/blue triangle behind this text, old-style OpenGL works on your phone through gl4es.\n");
                last = now;
            }
        }
    }
}
