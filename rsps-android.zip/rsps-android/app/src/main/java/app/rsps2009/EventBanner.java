package app.rsps2009;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

import rt4.Events;

/**
 * World event countdown at the top of the screen: "Goblin Raid starts in 4:32 [GO]", "LIVE Rainbow Rain 6:12 left [GO]",
 * plus shooting stars and crop circles from the game's news. GO sends ::eventtp.
 */
final class EventBanner extends View {
    private static final int GOLD = 0xFFFFC94A, TXT = 0xFFF2F3F8, TXT2 = 0xFFB9BED6, LIVE = 0xFFFF4D6A;
    private static final int[] RAINBOW = {0xFFFF3030, 0xFFFF8A1E, 0xFFFFE62E, 0xFF4CFF4C, 0xFF2EE6FF, 0xFF4C7DFF, 0xFFC04CFF};

    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Typeface bold = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD);
    private final Typeface reg = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL);
    private final RectF r = new RectF(), goR = new RectF();
    private boolean hasGo;
    private float goBottom;
    private long goFlash;

    /** how much room the banner needs (px); the activity sizes it */
    float wantW, wantH;

    EventBanner(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        setVisibility(GONE);
    }

    private static class Row { String icon, title, sub; int accent; boolean go, live; }

    private static String mmss(long ms) {
        long s = Math.max(0, (ms + 999) / 1000);
        return (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60);
    }

    private static String icon(String name) {
        String n = name.toLowerCase();
        if (n.contains("rain")) return "🌈";      // rainbow
        if (n.contains("raid")) return "⚔️";      // swords
        if (n.contains("treasure")) return "💰";  // money bag
        return "✨";
    }

    private ArrayList<Row> rows() {
        ArrayList<Row> out = new ArrayList<Row>();
        long now = System.currentTimeMillis();
        char st = Events.state;
        if (st == 'W' || st == 'L') {
            Row a = new Row();
            a.icon = icon(Events.name);
            a.live = st == 'L';
            a.title = a.live ? Events.name : Events.name + " starts in " + mmss(Events.endsAt - now);
            a.sub = a.live ? mmss(Events.endsAt - now) + " left · " + Events.where : "at " + Events.where;
            a.accent = a.live ? LIVE : GOLD;
            a.go = true;
            out.add(a);
        }
        if (Events.starUntil > now) {
            Row a = new Row(); a.icon = "⭐"; a.title = "Shooting star"; a.sub = "near " + Events.starWhere; a.accent = 0xFF7FD8FF; out.add(a);
        }
        if (Events.cropUntil > now) {
            Row a = new Row(); a.icon = "🌾"; a.title = "Crop circle"; a.sub = "near " + Events.cropWhere; a.accent = 0xFF9BE07A; out.add(a);
        }
        if (out.isEmpty() && st == 'N') {
            Row a = new Row(); a.icon = "🌈"; a.title = "Next event in " + mmss(Events.endsAt - now); a.sub = null; a.accent = TXT2; out.add(a);
        }
        return out;
    }

    /** UI thread poller: show / hide and measure */
    void sync(boolean allowed) {
        ArrayList<Row> rs = allowed ? rows() : new ArrayList<Row>();
        boolean show = !rs.isEmpty();
        if (show) {
            float w = 0;
            for (Row a : rs) w = Math.max(w, measure(a));
            wantW = w;
            wantH = rs.size() * 46 * d + (rs.size() - 1) * 6 * d;
            if (rs.size() == 1 && rs.get(0).sub == null) wantH = 34 * d;
        }
        int v = show ? VISIBLE : GONE;
        if (getVisibility() != v) setVisibility(v);
        if (show) invalidate();
    }

    private float measure(Row a) {
        p.setTypeface(bold);
        p.setTextSize(14 * d);
        float t = p.measureText(a.title);
        float s = 0;
        if (a.sub != null) { p.setTypeface(reg); p.setTextSize(12 * d); s = p.measureText(a.sub); }
        float w = 14 * d + 24 * d + 8 * d + Math.max(t + (a.live ? 52 * d : 0), s) + 14 * d;
        if (a.go) w += 58 * d;
        return Math.min(w, 460 * d);
    }

    @Override protected void onDraw(Canvas c) {
        ArrayList<Row> rs = rows();
        long now = System.currentTimeMillis();
        float y = 0;
        hasGo = false;
        for (Row a : rs) {
            float h = a.sub == null ? 34 * d : 46 * d;
            float w = Math.min(getWidth(), measure(a));
            float x = (getWidth() - w) / 2f;
            r.set(x, y, x + w, y + h);
            // card
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0, r.top, 0, r.bottom, 0xEE242A44, 0xEE151827, Shader.TileMode.CLAMP));
            c.drawRoundRect(r, h / 2, h / 2, p);
            p.setShader(null);
            // animated rainbow border for our own events, accent for the others
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2 * d);
            if (a.go) {
                int k = (int) ((now / 120L) % RAINBOW.length);
                p.setShader(new LinearGradient(r.left, 0, r.right, 0,
                        new int[] {RAINBOW[k], RAINBOW[(k + 2) % 7], RAINBOW[(k + 4) % 7], RAINBOW[(k + 6) % 7]}, null, Shader.TileMode.CLAMP));
            } else {
                p.setColor(a.accent & 0x99FFFFFF);
            }
            c.drawRoundRect(r, h / 2, h / 2, p);
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            // icon
            p.setTypeface(reg);
            p.setTextSize(18 * d);
            p.setColor(0xFFFFFFFF);
            c.drawText(a.icon, r.left + 13 * d, r.centerY() + 6.5f * d, p);
            float tx = r.left + 13 * d + 26 * d;
            // LIVE tag
            p.setTypeface(bold);
            if (a.live) {
                float pulse = 0.55f + 0.45f * (float) Math.sin(now / 260.0);
                p.setTextSize(10.5f * d);
                float lw = p.measureText("LIVE") + 12 * d;
                RectF lr = new RectF(tx, (a.sub == null ? r.centerY() : r.top + 15 * d) - 8 * d, tx + lw, (a.sub == null ? r.centerY() : r.top + 15 * d) + 8 * d);
                p.setColor(android.graphics.Color.argb(Math.round(255 * pulse), 255, 77, 106));
                c.drawRoundRect(lr, 8 * d, 8 * d, p);
                p.setColor(0xFFFFFFFF);
                c.drawText("LIVE", lr.left + 6 * d, lr.centerY() + 3.8f * d, p);
                tx = lr.right + 7 * d;
            }
            p.setTextSize(14 * d);
            p.setColor(a.go ? TXT : a.accent);
            float titleY = a.sub == null ? r.centerY() + 5 * d : r.top + 20 * d;
            c.drawText(a.title, tx, titleY, p);
            if (a.sub != null) {
                p.setTypeface(reg);
                p.setTextSize(12 * d);
                p.setColor(TXT2);
                c.drawText(a.sub, r.left + 13 * d + 26 * d, r.top + 37 * d, p);
            }
            // GO button
            if (a.go) {
                float gw = 48 * d, gh = h - 12 * d;
                goR.set(r.right - 6 * d - gw, r.centerY() - gh / 2, r.right - 6 * d, r.centerY() + gh / 2);
                boolean flash = now - goFlash < 400;
                p.setColor(flash ? 0xFFFFFFFF : (a.live ? LIVE : GOLD));
                c.drawRoundRect(goR, gh / 2, gh / 2, p);
                p.setTypeface(bold);
                p.setTextSize(13 * d);
                p.setColor(a.live ? 0xFFFFFFFF : 0xFF1A1405);
                if (flash) p.setColor(0xFF1A1405);
                c.drawText("GO", goR.centerX() - p.measureText("GO") / 2, goR.centerY() + 4.5f * d, p);
                if (!hasGo) goBottom = r.bottom + 3 * d;
                hasGo = true;
            }
            y += h + 6 * d;
        }
        if (getVisibility() == VISIBLE) postInvalidateDelayed(100);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (!hasGo || e.getY() > goBottom) return false;   // star / crop rows: let the touch through to the game
        if (e.getActionMasked() == MotionEvent.ACTION_UP) {
            // the whole first row is the button; a bigger target is easier on a phone
            goFlash = System.currentTimeMillis();
            Events.teleport();
            invalidate();
        }
        return true;
    }
}
