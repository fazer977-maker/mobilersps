package com.jogamp.opengl;

public class GLDrawable {
    final EglBackend backend;
    int samples;
    GLDrawable(EglBackend b, int samples) { backend = b; this.samples = samples; }
    public void setRealized(boolean realized) {
        if (realized) {
            if (!backend.create(samples)) throw new RuntimeException("EGL surface/context could not be created");
        } else {
            backend.destroy();
        }
    }
    public GLContext createContext(GLContext share) { return new GLContext(backend); }
    public void swapBuffers() { backend.swap(); }
}
