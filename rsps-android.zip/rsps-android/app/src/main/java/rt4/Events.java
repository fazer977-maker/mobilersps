package rt4;

/**
 * Rainbow Scape world events: the server's event messages end with a [Teleport] button (drawn in rainbow).
 * Tapping that chat line sends ::eventtp (the server checks there is an event to go to).
 */
public final class Events {
    private Events() {}

    public static final String BUTTON = "[Teleport]";
    private static volatile boolean tpWanted;

    /** the app's button was tapped */
    public static void teleport() { tpWanted = true; }

    /** UI thread: a tap on the chat box at game position (x, y). True if it hit an event's [Teleport] line. */
    public static boolean chatTap(int x, int y) {
        try {
            Component[][] all = InterfaceList.components;
            if (all == null) return false;
            for (ComponentPointer cp = (ComponentPointer) InterfaceList.openInterfaces.head(); cp != null; cp = (ComponentPointer) InterfaceList.openInterfaces.next()) {
                int[] o = holderPos(cp);
                if (hit(all, cp.interfaceId, x - o[0], y - o[1])) return true;
            }
            return hit(all, InterfaceList.topLevelInterface, x, y);
        } catch (Throwable t) {
            return false;
        }
    }

    /** a window opened inside another sits at its holder's position: that is where its own (0, 0) is on screen */
    private static int[] holderPos(ComponentPointer cp) {
        Component h = InterfaceList.getComponent((int) cp.key);
        return h == null ? new int[] {0, 0} : MobileLayout.absOf(h);
    }

    private static boolean hit(Component[][] all, int iface, int x, int y) {
        if (iface < 0 || iface >= all.length || all[iface] == null) return false;
        for (Component c : all[iface]) {
            if (c == null || c.type != 4 || c.text == null || c.hidden) continue;
            if (!c.text.toString().contains(BUTTON)) continue;
            int[] a = MobileLayout.absOf(c);
            // the whole line is the button: easier to hit with a finger
            if (x >= a[0] && x < a[0] + c.width && y >= a[1] - 2 && y < a[1] + Math.max(c.height, 14) + 2) {
                tpWanted = true;
                return true;
            }
        }
        return false;
    }

    // ---- where the [Teleport] words are drawn in the chat box (game pixels); the app puts a real button there
    public static final int MAX = 4;
    public static final int[] btnX = new int[MAX], btnY = new int[MAX], btnW = new int[MAX], btnH = new int[MAX];
    public static volatile int btnCount;

    private static JagString js(String s) {
        byte[] b = s.getBytes(java.nio.charset.StandardCharsets.ISO_8859_1);
        return new Buffer(java.util.Arrays.copyOf(b, b.length + 1)).gjstr();
    }

    private static boolean shown(Component c) {
        for (int i = 0; c != null && i < 40; i++) {
            if (c.hidden) return false;
            if (c.overlayer == -1) return true;
            c = InterfaceList.getComponent(c.overlayer);
        }
        return true;
    }

    /** game thread, every frame: find the visible chat lines that carry the button */
    private static void place() {
        int n = 0;
        if (!MobileLayout.studioOpen && !MobileLayout.bankOpen && !Tour.playing && InterfaceList.components != null) {
            for (ComponentPointer cp = (ComponentPointer) InterfaceList.openInterfaces.head(); cp != null && n < MAX; cp = (ComponentPointer) InterfaceList.openInterfaces.next()) {
                int iface = cp.interfaceId;
                if (iface < 0 || iface >= InterfaceList.components.length || InterfaceList.components[iface] == null) continue;
                int[] o = holderPos(cp);
                for (Component c : InterfaceList.components[iface]) {
                    if (n >= MAX) break;
                    if (c == null || c.type != 4 || c.text == null || !shown(c)) continue;
                    String t = c.text.toString();
                    int at = t.indexOf(BUTTON);
                    if (at < 0) continue;
                    Font f = c.getFont(Sprites.nameIcons);
                    if (f == null) continue;
                    int[] a = MobileLayout.absOf(c);
                    a[0] += o[0]; a[1] += o[1];
                    // only lines inside the chat box (scrolled-away lines are outside it)
                    if (!MobileLayout.isChat(a[0] + 4, a[1] + c.height / 2)) continue;
                    String pre = t.substring(0, at);
                    if (pre.endsWith("<rbw>")) pre = pre.substring(0, pre.length() - 5);
                    int x = a[0] + f.getStringWidth(js(pre));
                    int w = f.getStringWidth(js(BUTTON));
                    btnX[n] = x; btnY[n] = a[1]; btnW[n] = w; btnH[n] = Math.max(12, c.height);
                    n++;
                }
            }
        }
        btnCount = n;
    }

    public static void tick() {
        try { place(); } catch (Throwable t) { btnCount = 0; }
        try {
            if (tpWanted && client.gameState == 30) {
                tpWanted = false;
                JagString line = JagString.parse("::eventtp");
                Protocol.outboundBuffer.p1isaac(ClientProt.CLIENT_CHEAT);
                Protocol.outboundBuffer.p1(line.length() - 1);
                Protocol.outboundBuffer.pjstr(line.substring(2));
            }
        } catch (Throwable ignored) {
        }
    }
}
