package shim.awt.image;

import shim.awt.Image;

public interface ImageObserver {
    boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height);
}
