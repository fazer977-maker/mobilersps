package shim.sound.sampled;

import shim.platform.Platform;
import shim.platform.Platforms;

/** Output line backed by the host platform's audio. */
public class SourceDataLine implements DataLine {
    private final AudioFormat format;
    private final int bufferSize;
    private Platform.AudioOut out;
    SourceDataLine(AudioFormat format, int bufferSize) { this.format = format; this.bufferSize = bufferSize; }
    public void open() throws LineUnavailableException {
        out = Platforms.current.openAudio((int) format.getSampleRate(), format.getChannels(), Math.max(bufferSize, 1024));
        if (out == null) throw new LineUnavailableException();
    }
    public void start() {}
    public int write(byte[] b, int off, int len) { return out == null ? 0 : out.write(b, off, len); }
    public int available() { return out == null ? 0 : out.available(); }
    public void flush() { if (out != null) out.flush(); }
    public void close() { if (out != null) { out.close(); out = null; } }
}
