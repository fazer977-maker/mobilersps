package rt4;

import com.jogamp.opengl.GL2;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Random;

/**
 * Sky for the GPU renderer, drawn right after the screen clear and before the scene. Every object is placed at a fixed
 * direction and drawn with the camera's rotation only (no translation), so the sky turns with the camera but never moves
 * when the player walks: it behaves like it is infinitely far away.
 *
 * Each time of day has its own gradient dome, sun or moon, clouds and stars. Night adds a Milky Way, six constellations
 * with faint connecting lines, twinkling stars and random shooting stars. The auto cycle blends smoothly between them.
 * All textures are generated here on the CPU, so no cache or asset changes are needed. Any GL trouble switches it off.
 */
public final class SkyBox {
	private static boolean inited, broken;
	private static int texGlow, texMoon, texCloud, texSun;
	private static float builtR = -1;
	private static long t0 = System.nanoTime(), lastNs = t0;
	private static int frame, lastKey = -1;
	private static boolean starsDirty = true;

	// morning, midday, evening, night
	private static final float[][] PH = {{1.00F, 0.74F, 0.56F}, {0.80F, 0.90F, 1.00F}, {1.00F, 0.52F, 0.25F}, {0.12F, 0.16F, 0.34F}};
	private static final float[][] PM = {{0.78F, 0.66F, 0.78F}, {0.50F, 0.72F, 1.00F}, {0.80F, 0.38F, 0.50F}, {0.05F, 0.07F, 0.20F}};
	private static final float[][] PZ = {{0.30F, 0.48F, 0.82F}, {0.20F, 0.45F, 0.90F}, {0.18F, 0.20F, 0.50F}, {0.01F, 0.02F, 0.07F}};
	private static final float[] HMIX = {0.5F, 0.3F, 0.6F, 0.85F};
	private static final float[][] SUNC = {{1, 0.75F, 0.5F}, {1, 0.97F, 0.85F}, {1, 0.5F, 0.2F}, {1, 0.8F, 0.5F}};
	private static final float[][] CLOUDC = {{1, 0.82F, 0.75F, 0.80F}, {1, 1, 1, 0.85F}, {1, 0.62F, 0.42F, 0.85F}, {0.30F, 0.36F, 0.60F, 0.40F}};
	/** sun angle in degrees along its arc (0 = east horizon, 90 = overhead, 180 = west horizon, 270 = below) */
	private static final float[] SUNA = {12, 80, 168, 270};
	private static final float[] STARV = {0.12F, 0, 0.2F, 1};
	private static final float[] MOONV = {0.5F, 0, 0, 1};

	// ---- gradient dome ----
	private static final int RINGS = 14, SEGS = 32, DV = (RINGS + 1) * (SEGS + 1);
	private static final float[] dvT = new float[DV], dvCx = new float[DV], dvCz = new float[DV], dvX = new float[DV], dvY = new float[DV], dvZ = new float[DV];
	private static final FloatBuffer domeV = fb(DV * 3), domeC = fb(DV * 4);
	private static final ByteBuffer domeI = ByteBuffer.allocateDirect(RINGS * SEGS * 6 * 4).order(ByteOrder.nativeOrder());

	// ---- static star batch (stars, nebula puffs, constellation lines) ----
	private static final int MAXE = 1500;
	private static int E;
	private static final float[] ex = new float[MAXE], ey = new float[MAXE], ez = new float[MAXE];
	private static final float[] ex2 = new float[MAXE], ey2 = new float[MAXE], ez2 = new float[MAXE];
	private static final float[] esz = new float[MAXE], ebr = new float[MAXE], ecr = new float[MAXE], ecg = new float[MAXE], ecb = new float[MAXE];
	private static final float[] eph = new float[MAXE], esp = new float[MAXE];
	private static final byte[] etype = new byte[MAXE]; // 0 star, 1 puff, 2 line
	private static final FloatBuffer sV = fb(MAXE * 12), sT = fb(MAXE * 8), sC = fb(MAXE * 16);
	private static final ByteBuffer sI = ByteBuffer.allocateDirect(MAXE * 6 * 4).order(ByteOrder.nativeOrder());

	// ---- dynamic batches ----
	private static final Batch db = new Batch(48); // sun, moon, streaks
	private static final Batch cb = new Batch(32); // clouds

	// ---- clouds ----
	private static final int NC = 22;
	private static final float[] cAz = new float[NC], cEl = new float[NC], cSize = new float[NC], cSpd = new float[NC], cAlpha = new float[NC];
	private static final boolean[] cFlip = new boolean[NC];

	// ---- shooting stars ----
	private static final int MAXS = 4;
	private static final float[][] stP = new float[MAXS][3], stT = new float[MAXS][3];
	private static final float[] stAge = new float[MAXS], stDur = new float[MAXS], stSpd = new float[MAXS];
	private static final boolean[] stOn = new boolean[MAXS];
	private static float nextStreak = 3;
	private static final Random rnd = new Random();

	private static final float[] tmpA = new float[3], tmpB = new float[3], tmpR = new float[3], tmpU = new float[3];

	private SkyBox() {
	}

	private static FloatBuffer fb(int n) {
		return ByteBuffer.allocateDirect(n * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
	}

	public static boolean active() {
		return !broken && FxConfig.skybox && FxConfig.tod > 0;
	}

	/** Called by GlRenderer right after the clear, with the modelview holding only the camera rotation. */
	public static void draw(GL2 gl) {
		if (!active()) {
			return;
		}
		try {
			run(gl);
		} catch (Throwable t) {
			broken = true;
			shim.platform.Platforms.error("SKYBOX failed: " + t, t);
		}
	}

	// ======================================================================================== helpers

	private static float ss(float a, float b, float x) {
		float t = Math.max(0.0F, Math.min(1.0F, (x - a) / (b - a)));
		return t * t * (3.0F - 2.0F * t);
	}

	private static float mix(float[] k, int k0, int k1, float f) {
		return k[k0] + (k[k1] - k[k0]) * f;
	}

	private static float mix(float[][] k, int c, int k0, int k1, float f) {
		return k[k0][c] + (k[k1][c] - k[k0][c]) * f;
	}

	/** Right and up vectors (in render space) for a billboard facing the sky direction d (render space: up is -y). */
	private static void basis(float dx, float dy, float dz, float[] right, float[] up) {
		float rx = -dz, rz = dx;
		float len = (float) Math.sqrt(rx * rx + rz * rz);
		if (len < 1.0e-4F) {
			rx = 1.0F;
			rz = 0.0F;
			len = 1.0F;
		}
		rx /= len;
		rz /= len;
		right[0] = rx;
		right[1] = 0.0F;
		right[2] = rz;
		up[0] = dy * rz - dz * 0.0F;
		up[1] = dz * rx - dx * rz;
		up[2] = dx * 0.0F - dy * rx;
	}

	private static final class Batch {
		final FloatBuffer v, t, c;
		final ByteBuffer ix;
		int n;

		Batch(int quads) {
			v = fb(quads * 12);
			t = fb(quads * 8);
			c = fb(quads * 16);
			ix = ByteBuffer.allocateDirect(quads * 6 * 4).order(ByteOrder.nativeOrder());
		}

		void clear() {
			v.clear();
			t.clear();
			c.clear();
			ix.clear();
			n = 0;
		}

		void vert(float x, float y, float z, float u, float w, float r, float g, float b, float a) {
			v.put(x).put(y).put(z);
			t.put(u).put(w);
			c.put(r).put(g).put(b).put(a);
		}

		void quadIdx() {
			int b = n * 4;
			ix.putInt(b).putInt(b + 1).putInt(b + 2).putInt(b).putInt(b + 2).putInt(b + 3);
			n++;
		}

		/** Billboard at sky direction (dx,dy,dz) (render space, unit length) with half sizes in radians. */
		void bb(float dx, float dy, float dz, float sx, float sy, float r, float g, float b, float a, float u0, float v0, float u1, float v1, float R) {
			if (n >= v.capacity() / 12) {
				return;
			}
			basis(dx, dy, dz, tmpR, tmpU);
			float px = dx * R, py = dy * R, pz = dz * R;
			float wx = tmpR[0] * sx * R, wy = tmpR[1] * sx * R, wz = tmpR[2] * sx * R;
			float hx = tmpU[0] * sy * R, hy = tmpU[1] * sy * R, hz = tmpU[2] * sy * R;
			vert(px - wx - hx, py - wy - hy, pz - wz - hz, u0, v0, r, g, b, a);
			vert(px + wx - hx, py + wy - hy, pz + wz - hz, u1, v0, r, g, b, a);
			vert(px + wx + hx, py + wy + hy, pz + wz + hz, u1, v1, r, g, b, a);
			vert(px - wx + hx, py - wy + hy, pz - wz + hz, u0, v1, r, g, b, a);
			quadIdx();
		}

		void flush(GL2 gl) {
			if (n == 0) {
				return;
			}
			v.flip();
			t.flip();
			c.flip();
			ix.flip();
			gl.glVertexPointer(3, GL2.GL_FLOAT, 0, v);
			gl.glTexCoordPointer(2, GL2.GL_FLOAT, 0, t);
			gl.glColorPointer(4, GL2.GL_FLOAT, 0, c);
			gl.glDrawElements(GL2.GL_TRIANGLES, n * 6, GL2.GL_UNSIGNED_INT, ix);
		}
	}

	// ======================================================================================== textures

	private static float hash(int x, int y, int s) {
		int h = x * 374761393 + y * 668265263 + s * 1442695041;
		h = (h ^ (h >>> 13)) * 1274126177;
		h ^= h >>> 16;
		return (h & 0xFFFF) / 65535.0F;
	}

	private static float vnoise(float x, float y, int s) {
		int xi = (int) Math.floor(x), yi = (int) Math.floor(y);
		float fx = x - xi, fy = y - yi;
		fx = fx * fx * (3.0F - 2.0F * fx);
		fy = fy * fy * (3.0F - 2.0F * fy);
		float a = hash(xi, yi, s), b = hash(xi + 1, yi, s), c = hash(xi, yi + 1, s), d = hash(xi + 1, yi + 1, s);
		return (a + (b - a) * fx) + ((c + (d - c) * fx) - (a + (b - a) * fx)) * fy;
	}

	private static float fbm(float x, float y, int s) {
		float a = 0.5F, sum = 0, f = 1;
		for (int i = 0; i < 4; i++) {
			sum += a * vnoise(x * f, y * f, s + i);
			f *= 2.0F;
			a *= 0.5F;
		}
		return sum / 0.9375F;
	}

	private static void put(byte[] px, int i, float r, float g, float b, float a) {
		px[i] = (byte) Math.max(0, Math.min(255, (int) (r * 255.0F)));
		px[i + 1] = (byte) Math.max(0, Math.min(255, (int) (g * 255.0F)));
		px[i + 2] = (byte) Math.max(0, Math.min(255, (int) (b * 255.0F)));
		px[i + 3] = (byte) Math.max(0, Math.min(255, (int) (a * 255.0F)));
	}

	private static int upload(GL2 gl, int w, int h, byte[] px) {
		int[] t = new int[1];
		gl.glGenTextures(1, t, 0);
		GlRenderer.setTextureId(t[0]);
		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_MIN_FILTER, GL2.GL_LINEAR);
		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_MAG_FILTER, GL2.GL_LINEAR);
		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_WRAP_S, GL2.GL_CLAMP_TO_EDGE);
		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_WRAP_T, GL2.GL_CLAMP_TO_EDGE);
		ByteBuffer b = ByteBuffer.allocateDirect(px.length).order(ByteOrder.nativeOrder());
		b.put(px);
		b.flip();
		gl.glTexImage2D(GL2.GL_TEXTURE_2D, 0, 6408, w, h, 0, 6408, GL2.GL_UNSIGNED_BYTE, b);
		return t[0];
	}

	/** Soft round glow, white with alpha falling off to the edge. The centre texel is fully opaque white (also used as a solid colour). */
	private static byte[] makeGlow(int n) {
		byte[] px = new byte[n * n * 4];
		for (int y = 0; y < n; y++) {
			for (int x = 0; x < n; x++) {
				float nx = (x + 0.5F) / n * 2.0F - 1.0F, ny = (y + 0.5F) / n * 2.0F - 1.0F;
				float r = (float) Math.sqrt(nx * nx + ny * ny);
				float a = Math.max(0.0F, 1.0F - r);
				a = a * a;
				put(px, (y * n + x) * 4, 1, 1, 1, a);
			}
		}
		return px;
	}

	/** Sun: hot white core, corona and a few faint rays. */
	private static byte[] makeSun(int n) {
		byte[] px = new byte[n * n * 4];
		for (int y = 0; y < n; y++) {
			for (int x = 0; x < n; x++) {
				float nx = (x + 0.5F) / n * 2.0F - 1.0F, ny = (y + 0.5F) / n * 2.0F - 1.0F;
				float r = (float) Math.sqrt(nx * nx + ny * ny);
				float core = 1.0F - ss(0.24F, 0.30F, r);
				float d = Math.max(0.0F, r - 0.18F) / 0.26F;
				float glow = (float) Math.exp(-d * d) * 0.85F;
				float ang = (float) Math.atan2(ny, nx);
				float ray = 0.22F * (float) Math.exp(-r * 2.6F) * (float) Math.pow(Math.abs(Math.cos(ang * 6.0F + 0.4F)), 8.0);
				float a = Math.min(1.0F, Math.max(core, glow) + ray) * (1.0F - ss(0.80F, 1.0F, r));
				put(px, (y * n + x) * 4, 1, 1, 1, a);
			}
		}
		return px;
	}

	/** Full moon with maria, craters and a soft shaded side. */
	private static byte[] makeMoon(int n) {
		byte[] px = new byte[n * n * 4];
		Random r = new Random(77);
		int nc = 52;
		float[] cx = new float[nc], cy = new float[nc], cr = new float[nc];
		for (int i = 0; i < nc; i++) {
			double ang = r.nextDouble() * Math.PI * 2.0;
			double dist = Math.sqrt(r.nextDouble()) * 0.85;
			cx[i] = (float) (Math.cos(ang) * dist);
			cy[i] = (float) (Math.sin(ang) * dist);
			cr[i] = 0.03F + (float) Math.pow(r.nextDouble(), 2.5) * 0.17F;
		}
		float lx = -0.55F, ly = -0.40F;
		for (int y = 0; y < n; y++) {
			for (int x = 0; x < n; x++) {
				float nx = (x + 0.5F) / n * 2.0F - 1.0F, ny = (y + 0.5F) / n * 2.0F - 1.0F;
				float r2 = nx * nx + ny * ny;
				float rr = (float) Math.sqrt(r2);
				float a = Math.max(0.0F, Math.min(1.0F, (0.96F - rr) / 0.03F));
				if (a <= 0.0F) {
					continue;
				}
				float nz = (float) Math.sqrt(Math.max(0.0F, 1.0F - r2 / 0.92F));
				float base = 0.90F;
				float m = fbm(nx * 2.2F + 5.0F, ny * 2.2F + 3.0F, 5);
				if (m > 0.52F) {
					base -= (m - 0.52F) * 1.1F;
				}
				base += (fbm(nx * 9.0F, ny * 9.0F, 9) - 0.5F) * 0.14F;
				for (int i = 0; i < nc; i++) {
					float dx = nx - cx[i], dy = ny - cy[i];
					float d = (float) Math.sqrt(dx * dx + dy * dy);
					if (d < cr[i] * 1.25F) {
						if (d < cr[i]) {
							base -= 0.07F * (1.0F - d / cr[i]);
						}
						float rim = 1.0F - Math.abs(d - cr[i]) / (cr[i] * 0.2F);
						if (rim > 0.0F && d > 0.0001F) {
							float side = (dx * lx + dy * ly) / d;
							base += rim * 0.12F * (side > 0 ? -1.0F : 1.0F);
						}
					}
				}
				float lam = Math.max(0.0F, nx * -0.35F + ny * -0.25F + nz * 0.9F);
				float shade = 0.30F + 0.70F * (float) Math.pow(lam, 0.55);
				float v = base * shade;
				put(px, (y * n + x) * 4, v, v * 0.985F, v * 0.93F, a);
			}
		}
		return px;
	}

	/** Puffy cloud with a flat darker underside (row 0 is the bottom). */
	private static byte[] makeCloud(int w, int h) {
		byte[] px = new byte[w * h * 4];
		for (int y = 0; y < h; y++) {
			for (int x = 0; x < w; x++) {
				float nx = (x + 0.5F) / w * 2.0F - 1.0F, ny = (y + 0.5F) / h * 2.0F - 1.0F;
				float e = nx * nx * 0.8F + (ny > 0 ? ny * ny * 1.6F : ny * ny * 3.5F);
				float d = fbm(x * 0.045F + 3.0F, y * 0.07F + 9.0F, 11) * 1.25F - e * 0.9F + 0.05F;
				float a = Math.max(0.0F, Math.min(1.0F, d * 3.2F));
				float shade = 0.70F + 0.30F * ss(0.0F, 1.0F, (ny + 1.0F) / 2.0F);
				put(px, (y * w + x) * 4, shade, shade, shade, a);
			}
		}
		return px;
	}

	// ======================================================================================== init

	private static void init(GL2 gl) {
		texGlow = upload(gl, 64, 64, makeGlow(64));
		texSun = upload(gl, 128, 128, makeSun(128));
		texMoon = upload(gl, 128, 128, makeMoon(128));
		texCloud = upload(gl, 128, 64, makeCloud(128, 64));
		Random r = new Random(20091);
		// dome geometry that does not depend on the radius
		for (int ri = 0; ri <= RINGS; ri++) {
			float e = (float) Math.toRadians(-12.0 + 102.0 * ri / RINGS);
			float ce = (float) Math.cos(e), se = (float) Math.sin(e);
			for (int s = 0; s <= SEGS; s++) {
				float a = (float) (Math.PI * 2.0 * s / SEGS);
				int v = ri * (SEGS + 1) + s;
				dvT[v] = Math.max(0.0F, se);
				dvCx[v] = (float) Math.cos(a);
				dvCz[v] = (float) Math.sin(a);
				dvX[v] = ce * dvCx[v];
				dvY[v] = -se; // render space: up is -y
				dvZ[v] = ce * dvCz[v];
			}
		}
		domeI.clear();
		for (int ri = 0; ri < RINGS; ri++) {
			for (int s = 0; s < SEGS; s++) {
				int a = ri * (SEGS + 1) + s;
				domeI.putInt(a).putInt(a + 1).putInt(a + SEGS + 1).putInt(a + 1).putInt(a + SEGS + 2).putInt(a + SEGS + 1);
			}
		}
		domeI.flip();
		// field stars
		E = 0;
		for (int i = 0; i < 480; i++) {
			float[] d = randomUpperDir(r);
			float b = (float) Math.pow(r.nextDouble(), 3.0) * 0.8F + 0.15F;
			float[] c = starColor(r);
			addStar(d[0], d[1], d[2], 0.0022F + b * 0.0040F, b, c[0], c[1], c[2], 0, r);
		}
		// Milky Way: a faint dense band of small stars plus soft nebula puffs
		float[] pole = norm(0.35F, 0.55F, 0.76F);
		float[] u = norm(-pole[1], pole[0], 0.0F);
		float[] v = {pole[1] * u[2] - pole[2] * u[1], pole[2] * u[0] - pole[0] * u[2], pole[0] * u[1] - pole[1] * u[0]};
		int made = 0, guard = 0;
		while (made < 340 && guard++ < 20000) {
			float[] d = randomUpperDir(r);
			float dist = d[0] * pole[0] + d[1] * pole[1] + d[2] * pole[2];
			if (r.nextFloat() < Math.exp(-dist * dist / 0.02)) {
				float b = 0.10F + r.nextFloat() * 0.25F;
				float[] c = starColor(r);
				addStar(d[0], d[1], d[2], 0.0018F + b * 0.003F, b, c[0], c[1], c[2], 0, r);
				made++;
			}
		}
		for (int i = 0; i < 18; i++) {
			double phi = r.nextDouble() * Math.PI * 2.0;
			float off = (float) (r.nextGaussian() * 0.05);
			float x = (float) (Math.cos(phi) * u[0] + Math.sin(phi) * v[0]) + pole[0] * off;
			float y = (float) (Math.cos(phi) * u[1] + Math.sin(phi) * v[1]) + pole[1] * off;
			float z = (float) (Math.cos(phi) * u[2] + Math.sin(phi) * v[2]) + pole[2] * off;
			float[] d = norm(x, y, z);
			if (d[1] < -0.05F) {
				continue;
			}
			boolean warm = r.nextBoolean();
			addStar(d[0], d[1], d[2], 0.10F + r.nextFloat() * 0.12F, 0.05F + r.nextFloat() * 0.05F, warm ? 0.75F : 0.45F, warm ? 0.55F : 0.55F, warm ? 0.9F : 1.0F, 1, r);
		}
		// constellations
		constellation(20, 45, new float[][]{{-15, 3}, {-10, 1}, {-5, 0.5F}, {0, 0}, {1, -5}, {8, -5.5F}, {9, 0.5F}},
				new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 4}, {4, 5}, {5, 6}, {6, 3}}, r);
		constellation(160, 40, new float[][]{{-3.5F, 6.5F}, {3.5F, 6.5F}, {-1.3F, 0}, {0, 0}, {1.3F, 0}, {-3.5F, -6.5F}, {3.5F, -6}, {0, 8.5F}},
				new int[][]{{0, 2}, {1, 4}, {2, 3}, {3, 4}, {2, 5}, {4, 6}, {0, 7}, {1, 7}}, r);
		constellation(250, 62, new float[][]{{-8, 0}, {-4, 3.5F}, {0, 0}, {4, 3.5F}, {8, 0}},
				new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 4}}, r);
		constellation(300, 28, new float[][]{{0, 6}, {0, -6}, {-4, 0.5F}, {4, -0.5F}, {1.5F, -2.5F}},
				new int[][]{{0, 1}, {2, 3}}, r);
		constellation(100, 35, new float[][]{{-12, 6}, {-9, 4}, {-6.5F, 1.5F}, {-4.5F, -1}, {-3, -4}, {-0.5F, -6.5F}, {3, -7}, {6.5F, -5.5F}, {8, -2.5F}, {-13, 9.5F}, {-14.5F, 5}},
				new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 4}, {4, 5}, {5, 6}, {6, 7}, {7, 8}, {0, 9}, {0, 10}}, r);
		constellation(205, 58, new float[][]{{-6, 4}, {-5, 7.5F}, {-2, 9}, {1, 7.5F}, {1, 4.5F}, {4, 5}, {9, 3}, {8, -1}},
				new int[][]{{0, 1}, {1, 2}, {2, 3}, {3, 4}, {4, 5}, {5, 6}, {6, 7}, {5, 7}}, r);
		// clouds
		for (int i = 0; i < NC; i++) {
			cAz[i] = r.nextFloat() * 6.2832F;
			cEl[i] = (float) Math.toRadians(5.0 + r.nextDouble() * 52.0);
			cSize[i] = 0.17F + r.nextFloat() * 0.20F;
			cSpd[i] = 0.0025F + r.nextFloat() * 0.0035F;
			cAlpha[i] = 0.55F + r.nextFloat() * 0.45F;
			cFlip[i] = r.nextBoolean();
		}
		inited = true;
	}

	private static float[] norm(float x, float y, float z) {
		float l = (float) Math.sqrt(x * x + y * y + z * z);
		if (l < 1.0e-6F) {
			return new float[]{0, 1, 0};
		}
		return new float[]{x / l, y / l, z / l};
	}

	/** Random direction on the upper sky (sky coordinates: y is up). */
	private static float[] randomUpperDir(Random r) {
		while (true) {
			float x = r.nextFloat() * 2 - 1, y = r.nextFloat() * 2 - 1, z = r.nextFloat() * 2 - 1;
			float l = x * x + y * y + z * z;
			if (l > 0.01F && l <= 1.0F && y / (float) Math.sqrt(l) > -0.05F) {
				return norm(x, y, z);
			}
		}
	}

	private static float[] starColor(Random r) {
		float p = r.nextFloat();
		if (p < 0.55F) {
			return new float[]{0.95F, 0.97F, 1.0F};
		}
		if (p < 0.75F) {
			return new float[]{0.70F, 0.80F, 1.0F};
		}
		if (p < 0.90F) {
			return new float[]{1.0F, 0.93F, 0.70F};
		}
		return new float[]{1.0F, 0.70F, 0.50F};
	}

	/** Adds a star, glow puff or line end (sky coordinates are converted to render space: y flipped). */
	private static void addStar(float x, float y, float z, float size, float bright, float r, float g, float b, int type, Random rr) {
		if (E >= MAXE) {
			return;
		}
		ex[E] = x;
		ey[E] = -y;
		ez[E] = z;
		esz[E] = size;
		ebr[E] = bright;
		ecr[E] = r;
		ecg[E] = g;
		ecb[E] = b;
		etype[E] = (byte) type;
		eph[E] = rr.nextFloat() * 6.2832F;
		esp[E] = 1.5F + rr.nextFloat() * 3.5F;
		E++;
	}

	private static void addLine(float[] a, float[] b, float width, float bright, Random rr) {
		if (E >= MAXE) {
			return;
		}
		ex[E] = a[0];
		ey[E] = -a[1];
		ez[E] = a[2];
		ex2[E] = b[0];
		ey2[E] = -b[1];
		ez2[E] = b[2];
		esz[E] = width;
		ebr[E] = bright;
		ecr[E] = 0.65F;
		ecg[E] = 0.78F;
		ecb[E] = 1.0F;
		etype[E] = 2;
		E++;
	}

	private static void constellation(float azDeg, float elDeg, float[][] pts, int[][] links, Random r) {
		float az = (float) Math.toRadians(azDeg), el = (float) Math.toRadians(elDeg);
		float cx = (float) (Math.cos(el) * Math.cos(az)), cy = (float) Math.sin(el), cz = (float) (Math.cos(el) * Math.sin(az));
		float rx = (float) -Math.sin(az), rz = (float) Math.cos(az);
		float ux = (float) (-Math.sin(el) * Math.cos(az)), uy = (float) Math.cos(el), uz = (float) (-Math.sin(el) * Math.sin(az));
		float[][] p = new float[pts.length][];
		for (int i = 0; i < pts.length; i++) {
			float dx = (float) Math.toRadians(pts[i][0] * 1.5F), dy = (float) Math.toRadians(pts[i][1] * 1.5F);
			p[i] = norm(cx + rx * dx + ux * dy, cy + uy * dy, cz + rz * dx + uz * dy);
		}
		for (int[] l : links) {
			addLine(p[l[0]], p[l[1]], 0.0012F, 0.22F, r);
		}
		for (int i = 0; i < p.length; i++) {
			float[] c = starColor(r);
			addStar(p[i][0], p[i][1], p[i][2], 0.009F + r.nextFloat() * 0.004F, 0.85F + r.nextFloat() * 0.15F, c[0], c[1], c[2], 0, r);
		}
	}

	// ======================================================================================== geometry (depends on the radius)

	private static void buildGeometry() {
		float R = builtR;
		domeV.clear();
		for (int v = 0; v < DV; v++) {
			domeV.put(dvX[v] * R).put(dvY[v] * R).put(dvZ[v] * R);
		}
		domeV.flip();
		sV.clear();
		sT.clear();
		sI.clear();
		for (int i = 0; i < E; i++) {
			if (etype[i] == 2) {
				float ax = ex[i], ay = ey[i], az = ez[i], bx = ex2[i], by = ey2[i], bz = ez2[i];
				float px = ay * bz - az * by, py = az * bx - ax * bz, pz = ax * by - ay * bx;
				float l = (float) Math.sqrt(px * px + py * py + pz * pz);
				if (l < 1.0e-6F) {
					l = 1.0F;
				}
				float w = esz[i] * R / l;
				px *= w;
				py *= w;
				pz *= w;
				sV.put(ax * R - px).put(ay * R - py).put(az * R - pz);
				sV.put(ax * R + px).put(ay * R + py).put(az * R + pz);
				sV.put(bx * R + px).put(by * R + py).put(bz * R + pz);
				sV.put(bx * R - px).put(by * R - py).put(bz * R - pz);
				for (int k = 0; k < 4; k++) {
					sT.put(0.5F).put(0.5F);
				}
			} else {
				basis(ex[i], ey[i], ez[i], tmpR, tmpU);
				float s = esz[i] * R;
				float cx = ex[i] * R, cy = ey[i] * R, cz = ez[i] * R;
				sV.put(cx - tmpR[0] * s - tmpU[0] * s).put(cy - tmpR[1] * s - tmpU[1] * s).put(cz - tmpR[2] * s - tmpU[2] * s);
				sV.put(cx + tmpR[0] * s - tmpU[0] * s).put(cy + tmpR[1] * s - tmpU[1] * s).put(cz + tmpR[2] * s - tmpU[2] * s);
				sV.put(cx + tmpR[0] * s + tmpU[0] * s).put(cy + tmpR[1] * s + tmpU[1] * s).put(cz + tmpR[2] * s + tmpU[2] * s);
				sV.put(cx - tmpR[0] * s + tmpU[0] * s).put(cy - tmpR[1] * s + tmpU[1] * s).put(cz - tmpR[2] * s + tmpU[2] * s);
				sT.put(0).put(0).put(1).put(0).put(1).put(1).put(0).put(1);
			}
			int b = i * 4;
			sI.putInt(b).putInt(b + 1).putInt(b + 2).putInt(b).putInt(b + 2).putInt(b + 3);
		}
		sV.flip();
		sT.flip();
		sI.flip();
		lastKey = -1;
		starsDirty = true;
	}

	private static void updateDome(int k0, int k1, float f, float sunY, float sx, float sz, float sunVis) {
		float hm = mix(HMIX, k0, k1, f);
		float[] fog = FogManager.fogColor;
		float[] H = new float[3], M = new float[3], Z = new float[3], SC = new float[3];
		for (int c = 0; c < 3; c++) {
			H[c] = fog[c] * (1.0F - hm) + mix(PH, c, k0, k1, f) * hm;
			M[c] = mix(PM, c, k0, k1, f);
			Z[c] = mix(PZ, c, k0, k1, f);
			SC[c] = mix(SUNC, c, k0, k1, f);
		}
		float low = Math.max(0.0F, Math.min(1.0F, 1.0F - Math.abs(sunY) * 2.2F));
		float warmAmt = low * ss(-0.15F, 0.05F, sunY) * 0.55F;
		float hl = (float) Math.sqrt(sx * sx + sz * sz);
		float shx = hl > 1.0e-4F ? sx / hl : 1.0F, shz = hl > 1.0e-4F ? sz / hl : 0.0F;
		domeC.clear();
		for (int v = 0; v < DV; v++) {
			float t = dvT[v];
			float w = Math.max(0.0F, dvCx[v] * shx + dvCz[v] * shz);
			w = w * w * w * warmAmt * (1.0F - t) * (1.0F - t);
			for (int c = 0; c < 3; c++) {
				float col;
				if (t < 0.3F) {
					col = H[c] + (M[c] - H[c]) * ss(0.0F, 1.0F, t / 0.3F);
				} else {
					col = M[c] + (Z[c] - M[c]) * (float) Math.pow((t - 0.3F) / 0.7F, 0.7);
				}
				domeC.put(Math.min(1.0F, col + SC[c] * w));
			}
			domeC.put(1.0F);
		}
		domeC.flip();
	}

	private static void updateStars(float vis, float t) {
		sC.clear();
		float lineVis = ss(0.35F, 1.0F, vis);
		for (int i = 0; i < E; i++) {
			float a;
			if (etype[i] == 2) {
				a = ebr[i] * lineVis;
			} else if (etype[i] == 1) {
				a = ebr[i] * vis;
			} else {
				float tw = 0.78F + 0.22F * (float) Math.sin(t * esp[i] + eph[i]);
				a = ebr[i] * vis * tw;
			}
			for (int k = 0; k < 4; k++) {
				sC.put(ecr[i]).put(ecg[i]).put(ecb[i]).put(a);
			}
		}
		sC.flip();
	}

	private static void updateStreaks(float dt, float vis) {
		if (vis > 0.5F) {
			nextStreak -= dt;
			if (nextStreak <= 0.0F) {
				int slot = -1;
				for (int i = 0; i < MAXS; i++) {
					if (!stOn[i]) {
						slot = i;
						break;
					}
				}
				if (slot >= 0) {
					float az = rnd.nextFloat() * 6.2832F, el = (float) Math.toRadians(20.0 + rnd.nextDouble() * 50.0);
					float[] p = norm((float) (Math.cos(el) * Math.cos(az)), (float) Math.sin(el), (float) (Math.cos(el) * Math.sin(az)));
					float[] q = norm(rnd.nextFloat() - 0.5F, rnd.nextFloat() - 0.5F, rnd.nextFloat() - 0.5F);
					float dot = q[0] * p[0] + q[1] * p[1] + q[2] * p[2];
					float[] tg = norm(q[0] - p[0] * dot, q[1] - p[1] * dot, q[2] - p[2] * dot);
					stP[slot] = p;
					stT[slot] = tg;
					stAge[slot] = 0.0F;
					stDur[slot] = 0.7F + rnd.nextFloat() * 0.5F;
					stSpd[slot] = 0.7F + rnd.nextFloat() * 0.6F;
					stOn[slot] = true;
				}
				nextStreak = rnd.nextFloat() < 0.15F ? 0.25F : 2.5F + rnd.nextFloat() * 5.0F;
			}
		}
		for (int i = 0; i < MAXS; i++) {
			if (stOn[i]) {
				stAge[i] += dt;
				if (stAge[i] >= stDur[i]) {
					stOn[i] = false;
				}
			}
		}
	}

	private static void streakPos(int i, float s, float[] out) {
		float ang = stSpd[i] * s;
		float c = (float) Math.cos(ang), sn = (float) Math.sin(ang);
		float x = stP[i][0] * c + stT[i][0] * sn, y = stP[i][1] * c + stT[i][1] * sn, z = stP[i][2] * c + stT[i][2] * sn;
		out[0] = x;
		out[1] = -y; // render space
		out[2] = z;
	}

	// ======================================================================================== frame

	private static void run(GL2 gl) {
		float pos = ColorGrade.todPos();
		if (pos < 0.0F) {
			return;
		}
		if (!inited) {
			init(gl);
		}
		float R = GlobalConfig.VIEW_DISTANCE * 0.6F;
		if (Math.abs(R - builtR) > 1.0F) {
			builtR = R;
			buildGeometry();
		}
		int k0 = ((int) Math.floor(pos)) & 3, k1 = (k0 + 1) & 3;
		float f = pos - (float) Math.floor(pos);
		f = f * f * (3.0F - 2.0F * f);
		long now = System.nanoTime();
		float t = (now - t0) / 1.0e9F;
		float dt = Math.min(0.1F, Math.max(0.0F, (now - lastNs) / 1.0e9F));
		lastNs = now;
		frame++;

		// sun and moon directions (sky coordinates: x east, y up, z north)
		float aS = (float) Math.toRadians(SUNA[k0] + ((k0 == 3 ? 372.0F : SUNA[k1]) - SUNA[k0]) * f);
		float c20 = 0.9397F, s20 = 0.3420F, c30 = 0.8660F, s30 = 0.5F;
		float sx = (float) Math.cos(aS), sy = (float) Math.sin(aS) * c20, sz = (float) Math.sin(aS) * s20;
		float aM = aS + (float) Math.toRadians(150.0);
		float mx = (float) Math.cos(aM), my = (float) Math.sin(aM) * c30, mz = (float) -Math.sin(aM) * s30;
		float sunVis = ss(-0.12F, 0.04F, sy);
		float starVis = mix(STARV, k0, k1, f);
		float moonVis = mix(MOONV, k0, k1, f) * ss(-0.05F, 0.12F, my);

		gl.glClientActiveTexture(GL2.GL_TEXTURE0);
		boolean pColor = GL2.clientOn(GL2.GL_COLOR_ARRAY), pTex = GL2.clientOn(GL2.GL_TEXTURE_COORD_ARRAY), pNormal = GL2.clientOn(GL2.GL_NORMAL_ARRAY);
		MaterialManager.setMaterial(0, 0);
		GlRenderer.setLightingEnabled(false);
		GlRenderer.setDepthTestEnabled(false);
		GlRenderer.setFogEnabled(false);
		GlRenderer.disableDepthMask();
		GlRenderer.setTextureCombineRgbMode(0);
		GlRenderer.setTextureCombineAlphaMode(0);
		gl.glDisable(GL2.GL_CULL_FACE);
		gl.glDisableClientState(GL2.GL_NORMAL_ARRAY);
		GlRenderer.normalArrayEnabled = false;
		gl.glEnableClientState(GL2.GL_VERTEX_ARRAY);
		if (GlRenderer.arbVboSupported) {
			gl.glBindBuffer(GL2.GL_ARRAY_BUFFER, 0);
			gl.glBindBuffer(GL2.GL_ELEMENT_ARRAY_BUFFER, 0);
		}

		// 1. gradient dome
		float[] fog = FogManager.fogColor;
		int key = FxConfig.tod * 16777259 + ((int) (fog[0] * 255) << 16) + ((int) (fog[1] * 255) << 8) + (int) (fog[2] * 255);
		boolean auto = FxConfig.tod >= 5;
		if (auto ? (frame % 3 == 0 || lastKey == -1) : key != lastKey) {
			updateDome(k0, k1, f, sy, sx, sz, sunVis);
			lastKey = key;
		}
		GlRenderer.setTextureId(-1);
		gl.glDisable(GL2.GL_BLEND);
		gl.glDisableClientState(GL2.GL_TEXTURE_COORD_ARRAY);
		gl.glEnableClientState(GL2.GL_COLOR_ARRAY);
		gl.glVertexPointer(3, GL2.GL_FLOAT, 0, domeV);
		gl.glColorPointer(4, GL2.GL_FLOAT, 0, domeC);
		gl.glDrawElements(GL2.GL_TRIANGLES, RINGS * SEGS * 6, GL2.GL_UNSIGNED_INT, domeI);

		// everything below is textured with per-vertex colour
		gl.glEnable(GL2.GL_BLEND);
		gl.glEnableClientState(GL2.GL_TEXTURE_COORD_ARRAY);
		gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE);

		// 2. stars, Milky Way, constellations
		if (starVis > 0.01F) {
			if (frame % 2 == 0 || starsDirty) {
				starsDirty = false;
				updateStars(starVis, t);
			}
			GlRenderer.setTextureId(texGlow);
			gl.glVertexPointer(3, GL2.GL_FLOAT, 0, sV);
			gl.glTexCoordPointer(2, GL2.GL_FLOAT, 0, sT);
			gl.glColorPointer(4, GL2.GL_FLOAT, 0, sC);
			gl.glDrawElements(GL2.GL_TRIANGLES, E * 6, GL2.GL_UNSIGNED_INT, sI);
			// 3. shooting stars
			updateStreaks(dt, starVis);
			db.clear();
			for (int i = 0; i < MAXS; i++) {
				if (!stOn[i]) {
					continue;
				}
				float env = (float) Math.sin(Math.PI * stAge[i] / stDur[i]);
				float s0 = Math.max(0.0F, stAge[i] - 0.25F / stSpd[i]);
				streakPos(i, stAge[i], tmpA);
				streakPos(i, s0, tmpB);
				float px = tmpA[1] * tmpB[2] - tmpA[2] * tmpB[1], py = tmpA[2] * tmpB[0] - tmpA[0] * tmpB[2], pz = tmpA[0] * tmpB[1] - tmpA[1] * tmpB[0];
				float pl = (float) Math.sqrt(px * px + py * py + pz * pz);
				if (pl > 1.0e-5F) {
					float wh = 0.0022F * R / pl, wt = 0.0003F * R / pl;
					float a = env * starVis;
					db.vert(tmpB[0] * R - px * wt, tmpB[1] * R - py * wt, tmpB[2] * R - pz * wt, 0.5F, 0.5F, 0.8F, 0.9F, 1.0F, 0.0F);
					db.vert(tmpB[0] * R + px * wt, tmpB[1] * R + py * wt, tmpB[2] * R + pz * wt, 0.5F, 0.5F, 0.8F, 0.9F, 1.0F, 0.0F);
					db.vert(tmpA[0] * R + px * wh, tmpA[1] * R + py * wh, tmpA[2] * R + pz * wh, 0.5F, 0.5F, 0.9F, 0.95F, 1.0F, a);
					db.vert(tmpA[0] * R - px * wh, tmpA[1] * R - py * wh, tmpA[2] * R - pz * wh, 0.5F, 0.5F, 0.9F, 0.95F, 1.0F, a);
					db.quadIdx();
					db.bb(tmpA[0], tmpA[1], tmpA[2], 0.012F, 0.012F, 0.9F, 0.95F, 1.0F, a * 0.8F, 0, 0, 1, 1, R);
				}
			}
			db.flush(gl);
		}

		// 4. sun
		if (sunVis > 0.01F) {
			float[] sc = {mix(SUNC, 0, k0, k1, f), mix(SUNC, 1, k0, k1, f), mix(SUNC, 2, k0, k1, f)};
			db.clear();
			db.bb(sx, -sy, sz, 0.75F, 0.75F, sc[0], sc[1], sc[2], 0.30F * sunVis, 0, 0, 1, 1, R);
			GlRenderer.setTextureId(texGlow);
			db.flush(gl);
			db.clear();
			db.bb(sx, -sy, sz, 0.17F, 0.17F, sc[0], sc[1], sc[2], sunVis, 0, 0, 1, 1, R);
			GlRenderer.setTextureId(texSun);
			db.flush(gl);
		}

		// 5. moon
		if (moonVis > 0.01F) {
			db.clear();
			db.bb(mx, -my, mz, 0.38F, 0.38F, 0.65F, 0.78F, 1.0F, 0.26F * moonVis, 0, 0, 1, 1, R);
			GlRenderer.setTextureId(texGlow);
			db.flush(gl);
			gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
			db.clear();
			db.bb(mx, -my, mz, 0.075F, 0.075F, 1, 1, 1, moonVis, 0, 0, 1, 1, R);
			GlRenderer.setTextureId(texMoon);
			db.flush(gl);
		}

		// 6. clouds (drift slowly; everything else is fixed)
		gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
		float cr = mix(CLOUDC, 0, k0, k1, f), cg = mix(CLOUDC, 1, k0, k1, f), cbl = mix(CLOUDC, 2, k0, k1, f), ca = mix(CLOUDC, 3, k0, k1, f);
		cb.clear();
		for (int i = 0; i < NC; i++) {
			cAz[i] += cSpd[i] * dt;
			float el = cEl[i];
			float x = (float) (Math.cos(el) * Math.cos(cAz[i])), y = (float) Math.sin(el), z = (float) (Math.cos(el) * Math.sin(cAz[i]));
			float flat = 0.35F + 0.65F * y;
			cb.bb(x, -y, z, cSize[i], cSize[i] * 0.5F * flat + 0.02F, cr, cg, cbl, ca * cAlpha[i], cFlip[i] ? 1 : 0, 0, cFlip[i] ? 0 : 1, 1, R);
		}
		GlRenderer.setTextureId(texCloud);
		cb.flush(gl);

		// put everything back the way the scene setup expects it
		gl.glEnable(GL2.GL_CULL_FACE);
		gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
		gl.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		if (pColor) { gl.glEnableClientState(GL2.GL_COLOR_ARRAY); } else { gl.glDisableClientState(GL2.GL_COLOR_ARRAY); }
		if (pTex) { gl.glEnableClientState(GL2.GL_TEXTURE_COORD_ARRAY); } else { gl.glDisableClientState(GL2.GL_TEXTURE_COORD_ARRAY); }
		if (pNormal) { gl.glEnableClientState(GL2.GL_NORMAL_ARRAY); } else { gl.glDisableClientState(GL2.GL_NORMAL_ARRAY); }
		GlRenderer.normalArrayEnabled = pNormal;
		GlRenderer.setTextureId(-1);
		GlRenderer.enableDepthMask();
		GlRenderer.setDepthTestEnabled(true);
		GlRenderer.setFogEnabled(true);
		GlRenderer.restoreLighting();
	}
}
