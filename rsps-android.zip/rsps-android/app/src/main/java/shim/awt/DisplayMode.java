package shim.awt;

public class DisplayMode {
    public static final int REFRESH_RATE_UNKNOWN = 0;
    public static final int BIT_DEPTH_MULTI = -1;
    private final int w, h, depth, refresh;
    public DisplayMode(int w, int h, int depth, int refresh) { this.w = w; this.h = h; this.depth = depth; this.refresh = refresh; }
    public int getWidth() { return w; }
    public int getHeight() { return h; }
    public int getBitDepth() { return depth; }
    public int getRefreshRate() { return refresh; }
    @Override public boolean equals(Object o) {
        return o instanceof DisplayMode && ((DisplayMode) o).w == w && ((DisplayMode) o).h == h && ((DisplayMode) o).depth == depth && ((DisplayMode) o).refresh == refresh;
    }
    @Override public int hashCode() { return w * 31 + h; }
}
