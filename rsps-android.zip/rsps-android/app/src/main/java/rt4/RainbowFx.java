package rt4;

/**
 * Rainbow Scape particle system.
 * Players wearing the Rainbow cape shed sparks from the cape that fall under gravity and stay in the world
 * (so a trail is left behind when walking). The Halo gives a slow rising shimmer around the head.
 * Each particle is a small real 3D block added to the scene graph every frame, so walls, roofs and
 * characters hide it with true depth, like the RS3 cape effects.
 */
public final class RainbowFx {

	/** item ids (must match the server) */
	public static final int CAPE_ID = 14670;
	public static final int HALO_ID = 14671;
	/** shop colour styles: capes 14673-14677 and halos 14678-14682 (fire, frost, toxic, galaxy, golden); 0 = rainbow */
	private static final float[] ST_BASE = {0.0F, 0.0F, 0.48F, 0.24F, 0.68F, 0.11F};
	private static final float[] ST_SPAN = {0.0F, 0.09F, 0.12F, 0.13F, 0.25F, 0.05F};
	private static int curStyle = 0;
	private static int capeStyle(int id) {
		if (id == CAPE_ID) return 0;
		if (id >= 14673 && id <= 14677) return id - 14672;
		return -1;
	}
	private static int haloStyle(int id) {
		if (id == HALO_ID) return 0;
		if (id >= 14678 && id <= 14682) return id - 14677;
		return -1;
	}

	private static final int MAX = 900;
	private static final float[] px = new float[MAX], py = new float[MAX], ph = new float[MAX];
	private static final float[] vx = new float[MAX], vy = new float[MAX], vh = new float[MAX];
	private static final float[] age = new float[MAX], life = new float[MAX], hue = new float[MAX], grav = new float[MAX];
	private static final byte[] size = new byte[MAX];
	private static final byte[] sty = new byte[MAX];
	private static int count = 0;
	private static long last = 0L;
	private static float clock = 0.0F;
	private static final java.util.Random rnd = new java.util.Random();

	private static void spawn(float x, float y, float h, float dx, float dy, float dh, float g, float lifeSec, float hu, int sz) {
		if (count >= MAX) {
			return;
		}
		int i = count++;
		px[i] = x; py[i] = y; ph[i] = h;
		vx[i] = dx; vy[i] = dy; vh[i] = dh;
		sty[i] = (byte) curStyle; grav[i] = g; age[i] = 0.0F; life[i] = lifeSec; hue[i] = hu; size[i] = (byte) sz;
	}

	/** hem vertices of the Rainbow cape model: lateral x, height above ground, depth behind the body (emitters sit on these) */
	private static final int[][] HEM = {{-28, 56, 30}, {-23, 44, 31}, {-20, 56, 32}, {-9, 61, 32}, {-4, 35, 34}, {3, 9, 34}, {5, 3, 34}, {15, 68, 27}, {20, 44, 32}, {23, 32, 31}, {28, 50, 30}};

	private static void emit(Player p, float dt) {
		int cs = capeStyle(p.fxCape);
		if (cs >= 0) {
			curStyle = cs;
			p.fxAcc += 70.0F * dt;
			int a = p.currentAngle & 0x7FF;
			float sin = MathUtils.sin[a] / 65536.0F, cos = MathUtils.cos[a] / 65536.0F;
			while (p.fxAcc >= 1.0F) {
				p.fxAcc -= 1.0F;
				// attached to the bottom hem of the cape (like the RS3 120 capes): along the hem edge, just above the ground
				int v = rnd.nextInt(HEM.length);
				float across = HEM[v][0] / 30.0F;
				float sw = (float) Math.sin(clock * 3.0F + v * 1.7F);
				float lx = HEM[v][0] + sw * 2.0F + (rnd.nextFloat() - 0.5F) * 3.0F;
				float h = HEM[v][1] + (rnd.nextFloat() - 0.5F) * 4.0F;
				float lz = HEM[v][2] + 2.0F + sw * 3.0F;
				float wx = p.xFine + lx * cos + lz * sin;
				float wy = p.yFine + lz * cos - lx * sin;
				float hu = across * 0.42F + 0.5F + clock * 0.3F;      // the rainbow runs along the hem and slowly rotates
				float dx = (rnd.nextFloat() - 0.5F) * 10.0F + sin * 8.0F;
				float dy = (rnd.nextFloat() - 0.5F) * 10.0F + cos * 8.0F;
				if (rnd.nextInt(100) < 55) {
					// soft glowing puff that hangs at the hem and fades
					spawn(wx, wy, h, dx, dy, 8.0F + rnd.nextFloat() * 18.0F, 45.0F, 0.6F + rnd.nextFloat() * 0.6F, hu, 3);
				} else {
					// bright spark that lifts off the hem, then falls
					spawn(wx, wy, h, dx, dy, 14.0F + rnd.nextFloat() * 36.0F, 190.0F + rnd.nextFloat() * 90.0F,
						0.8F + rnd.nextFloat() * 0.8F, hu, rnd.nextInt(4) == 0 ? 2 : 1);
				}
			}
		}
		int hs = haloStyle(p.fxHat);
		if (hs >= 0) {
			curStyle = hs;
			p.fxAcc += 16.0F * dt;
			while (p.fxAcc >= 1.0F) {
				p.fxAcc -= 1.0F;
				float ang = rnd.nextFloat() * 6.2831855F;
				float wx = p.xFine + 14.0F * (float) Math.cos(ang);
				float wy = p.yFine + 14.0F * (float) Math.sin(ang);
				spawn(wx, wy, 204.0F + rnd.nextFloat() * 8.0F, 0.0F, 0.0F, 10.0F + rnd.nextFloat() * 14.0F, -2.0F,
					0.8F + rnd.nextFloat() * 0.8F, ang / 6.2831855F + clock * 0.3F, 1);
			}
		}
	}


	// ---- soft additive glow sprites, merged per tile into GlowCluster scene entities
	private static final int MAXC = 48;
	private static final GlowCluster[] clusters = new GlowCluster[MAXC];
	private static final int[] cTile = new int[MAXC];
	private static int cCount = 0;
	private static final int[] wX = new int[32], wY = new int[32];
	private static int wCount = 0;

	private static int rgb(float hu, int st) {
		hu -= (float) Math.floor(hu);
		if (st > 0) {
			float tri = hu < 0.5F ? hu * 2.0F : 2.0F - hu * 2.0F;
			hu = ST_BASE[st] + ST_SPAN[st] * tri;
			hu -= (float) Math.floor(hu);
		}
		float h6 = hu * 6.0F;
		int i = (int) h6;
		float f = h6 - i;
		float s = 0.8F, v = 1.0F;
		float p = v * (1.0F - s), q = v * (1.0F - s * f), t = v * (1.0F - s * (1.0F - f));
		float r, g, b;
		switch (i % 6) {
			case 0: r = v; g = t; b = p; break;
			case 1: r = q; g = v; b = p; break;
			case 2: r = p; g = v; b = t; break;
			case 3: r = p; g = q; b = v; break;
			case 4: r = t; g = p; b = v; break;
			default: r = v; g = p; b = q; break;
		}
		return ((int) (r * 255.0F) << 16) | ((int) (g * 255.0F) << 8) | (int) (b * 255.0F);
	}

	private static void render(int i) {
		float t = age[i] / life[i];
		int x = (int) px[i], y = (int) py[i];
		if (x < 128 || y < 128 || x > 103 * 128 || y > 103 * 128) {
			return;
		}
		int tx = x >> 7, ty = y >> 7;
		// near a wearer: anchor the cluster one tile behind / in front of the body so the scene paints it in the right order
		int side = 0;
		for (int w = 0; w < wCount; w++) {
			int ddx = x - wX[w], ddy = y - wY[w];
			if (ddx * ddx + ddy * ddy < 140 * 140) {
				int cdx = wX[w] - Camera.renderX, cdy = wY[w] - Camera.renderY;
				side = ddx * cdx + ddy * cdy > 0 ? 1 : -1;
				break;
			}
		}
		int ax = tx, ay = ty;
		if (side != 0) {
			int sgx = Integer.signum((tx << 7) + 64 - Camera.renderX), sgy = Integer.signum((ty << 7) + 64 - Camera.renderY);
			ax = Math.max(1, Math.min(102, tx + side * sgx));
			ay = Math.max(1, Math.min(102, ty + side * sgy));
		}
		int tile = ax << 8 | ay;
		int c = -1;
		for (int k = 0; k < cCount; k++) {
			if (cTile[k] == tile) {
				c = k;
				break;
			}
		}
		int ox = (ax << 7) + 64, oy = (ay << 7) + 64;
		int oz = SceneGraph.getTileHeight(Player.plane, ox, oy);
		if (c < 0) {
			if (cCount >= MAXC) {
				return;
			}
			c = cCount++;
			if (clusters[c] == null) {
				clusters[c] = new GlowCluster();
			}
			clusters[c].n = 0;
			cTile[c] = tile;
		}
		int z = SceneGraph.getTileHeight(Player.plane, x, y) - (int) ph[i];
		float base = size[i] >= 3 ? 20.0F : (size[i] == 2 ? 11.0F : 8.0F);
		float rad = base * (1.0F - t * 0.55F);
		float fadeIn = Math.min(1.0F, age[i] * 10.0F);
		int inten = (int) (255.0F * fadeIn * (1.0F - t) * (size[i] >= 3 ? 0.55F : 0.95F));
		clusters[c].add(x - ox, y - oy, z - oz, rad, rgb(hue[i] + t * 0.15F, sty[i]), inten);
	}

	private static void noteWearer(Player p) {
		if ((capeStyle(p.fxCape) >= 0 || haloStyle(p.fxHat) >= 0) && wCount < 32) {
			wX[wCount] = p.xFine;
			wY[wCount] = p.yFine;
			wCount++;
		}
	}

	/** called once per frame while the scene is being built */
	public static void update() {
		long now = System.nanoTime();
		float dt = last == 0L ? 0.0F : (now - last) / 1.0E9F;
		last = now;
		if (dt > 0.1F) {
			dt = 0.1F;
		}
		clock += dt;
		wCount = 0;
		try {
			Player self = PlayerList.self;
			if (self != null && self.isVisible()) {
				noteWearer(self);
				emit(self, dt);
			}
			for (int i = 0; i < PlayerList.size; i++) {
				Player p = PlayerList.players[PlayerList.ids[i]];
				if (p != null && p != self && p.isVisible()) {
					noteWearer(p);
					emit(p, dt);
				}
			}
		} catch (RuntimeException e) {
		}
		cCount = 0;
		for (int i = 0; i < count; ) {
			age[i] += dt;
			vh[i] -= grav[i] * dt;
			ph[i] += vh[i] * dt;
			px[i] += vx[i] * dt;
			py[i] += vy[i] * dt;
			if (age[i] >= life[i] || ph[i] < 0.0F) {
				count--;
				px[i] = px[count]; py[i] = py[count]; ph[i] = ph[count];
				vx[i] = vx[count]; vy[i] = vy[count]; vh[i] = vh[count];
				age[i] = age[count]; life[i] = life[count]; hue[i] = hue[count]; grav[i] = grav[count]; size[i] = size[count]; sty[i] = sty[count];
				continue;
			}
			try {
				render(i);
			} catch (RuntimeException e) {
			}
			i++;
		}
		for (int k = 0; k < cCount; k++) {
			int tx = cTile[k] >> 8, ty = cTile[k] & 0xFF;
			int ox = (tx << 7) + 64, oy = (ty << 7) + 64;
			SceneGraph.add(Player.plane, ox, oy, SceneGraph.getTileHeight(Player.plane, ox, oy), 60, clusters[k], 0, -1L, false);
		}
	}
}
