package rt4;

/**
 * Rearranges the stock resizable top-level interface (746) into a phone layout:
 * chat at the top-left, tab icons in a column down each edge, tab panel beside the right column.
 * Runs every frame after layout, so script-driven re-layouts are simply overridden again.
 */
public final class MobileLayout {
    public static boolean enabled = true;

    // stone component indexes (layer 25). overlay = +15 (layer 40), icon = +30 (layer 55)
    // 2 columns x 7 rows, filled row by row (stone component indexes)
    private static final int[] GRID = {29, 27, 30, 26, 31, 32, 28, 34, 35, 36, 37, 38, 39, 33};
    private static int gridX, gridY;

    private static boolean captured;
    private static final int[] ovDx = new int[70], ovDy = new int[70], icDx = new int[70], icDy = new int[70];
    private static final int[] stW = new int[70], stH = new int[70], ovW = new int[70], ovH = new int[70], icW = new int[70], icH = new int[70];
    private static int stoneW = 46;

    private MobileLayout() {}

    public static void apply() {
        if (!enabled || InterfaceList.topLevelInterface != 746) {
            return;
        }
        Component[][] all = InterfaceList.components;
        if (all == null || all.length <= 746 || all[746] == null || all[746].length < 111) {
            return;
        }
        Component[] c = all[746];
        if (c[24] == null || c[25] == null || c[40] == null || c[55] == null || c[23] == null || c[70] == null || c[73] == null) {
            return;
        }
        final int w = GameShell.canvasWidth;
        final int h = GameShell.canvasHeight;
        if (w <= 0 || h <= 0) {
            return;
        }

        if (!captured) {
            for (int s = 26; s <= 39; s++) {
                Component st = c[s], ov = c[s + 15], ic = c[s + 30];
                if (st == null || ov == null || ic == null) {
                    return;
                }
                ovDx[s] = ov.x - st.x;
                ovDy[s] = ov.y - st.y;
                icDx[s] = ic.x - st.x;
                icDy[s] = ic.y - st.y;
                stW[s] = st.width; stH[s] = st.height;
                ovW[s] = ov.width; ovH[s] = ov.height;
                icW[s] = ic.width; icH[s] = ic.height;
            }
            captured = true;
        }

        captureStone(c);

        // chat: tab buttons on top, chat box below, overlay under that
        set(c[23], 0, 0);
        set(c[70], 0, 23);
        if (c[71] != null) set(c[71], 9, 165);
        if (c[72] != null) set(c[72], 9, 165);

        // tab containers become full-screen so children can use screen coordinates
        for (int id : new int[] {24, 25, 40, 55}) {
            c[id].x = 0;
            c[id].y = 0;
            c[id].width = w;
            c[id].height = h;
            c[id].noClickThrough = false; // full-screen now, so it must not swallow world clicks
        }

        // 2x7 block of touching icons in the bottom-right, like OSRS mobile
        int top = 190;
        float f = Math.max(1f, Math.min(1.6f, (h - top - 6) / (8f * 36f)));
        int cellH = Math.round(36 * f);
        stoneW = Math.round(33 * f);
        gridX = w - 2 * stoneW - 4;
        gridY = h - 8 * cellH - 4;
        // cell 1 (top right) is the logout button, drawn natively by the app; stones fill cells 2..15
        logoutX = gridX + stoneW;
        logoutY = gridY;
        logoutW = stoneW;
        logoutH = cellH;
        canvasW = w;
        for (int i = 0; i < GRID.length; i++) {
            int cell = i + 2;
            placeOne(c, GRID[i], gridX + (cell % 2) * stoneW, gridY + (cell / 2) * cellH, f);
        }

        // the last slot is the logout tab; the stock script leaves it blank in this layout, so show it
        for (int id : new int[] {33, 48, 63}) {
            if (c[id] != null) {
                c[id].hidden = false;
            }
        }

        // opened tab panel sits to the left of the right column
        c[73].x = Math.max(0, gridX - 4 - c[73].width);
        c[73].y = Math.max(0, h - 4 - c[73].height);
        panelX = c[73].x;
        panelY = c[73].y;
        panelW = c[73].width;
        panelH = c[73].height;
        panelOpen = !c[73].hidden && c[77] != null && !c[77].hidden && c[75] != null && !c[75].hidden;
        try { studioFullscreen(w, h); } catch (RuntimeException e) { studioOpen = false; keepTop = -1; }
    }

    // ------------------------------------------------------------------ full-screen Character Studio
    /** colour of the studio's backdrop rectangle (component 1); it marks the window as a full-screen one */
    public static final int FS_MAGIC = 0x010203;
    private static final int FS_BG = 0x141826;
    private static Component[] fsGroup;
    private static int[] fsZoom;
    public static volatile boolean studioOpen;
    private static int keepTop = -1;
    private static final Component[] fsChain = new Component[16];
    private static final int[][] fsSaved = new int[16][4];
    private static int fsN;

    private static void studioFullscreen(int w, int h) {
        Component[] cs = null;
        Component container = null;
        Component[][] all = InterfaceList.components;
        for (ComponentPointer cp = (ComponentPointer) InterfaceList.openInterfaces.head(); cp != null; cp = (ComponentPointer) InterfaceList.openInterfaces.next()) {
            if (all == null || cp.interfaceId < 0 || cp.interfaceId >= all.length) continue;
            Component[] g = all[cp.interfaceId];
            if (g != null && g.length > 2 && g[0] != null && g[1] != null && g[2] != null && g[1].type == 3 && (g[1].color == FS_MAGIC || g[1].color == FS_BG) && g[2].type == 0) {
                cs = g;
                container = InterfaceList.getComponent((int) cp.key);
                break;
            }
        }
        if (cs == null || container == null) {
            exitFullscreen();
            return;
        }
        if (!studioOpen) {
            fsN = 0;
            keepTop = -1;
            for (Component k = container; k != null && fsN < fsChain.length; ) {
                fsChain[fsN] = k;
                fsSaved[fsN][0] = k.x; fsSaved[fsN][1] = k.y; fsSaved[fsN][2] = k.width; fsSaved[fsN][3] = k.height;
                fsN++;
                if (k.overlayer == -1) { keepTop = k.id; break; }
                k = InterfaceList.getComponent(k.overlayer);
            }
            StudioView.yaw = 0;
            studioOpen = true;
        }
        for (int i = 0; i < fsN; i++) {
            Component k = fsChain[i];
            k.x = 0; k.y = 0; k.width = w; k.height = h;
        }
        Component root = cs[0], back = cs[1], main = cs[2];
        root.x = 0; root.y = 0; root.width = w; root.height = h;
        back.x = 0; back.y = 0; back.width = w; back.height = h; back.color = FS_BG;
        // stretch the whole window to the screen: every part keeps its place, just scaled to fill
        if (fsGroup != cs) {
            fsGroup = cs;
            fsZoom = new int[cs.length];
            for (int i = 0; i < cs.length; i++) if (cs[i] != null) fsZoom[i] = cs[i].modelZoom;
        }
        int bw = Math.max(1, main.baseWidth), bh = Math.max(1, main.baseHeight);
        float sx = w / (float) bw, sy = h / (float) bh;
        main.x = 0; main.y = 0; main.width = w; main.height = h;
        for (int i = 3; i < cs.length; i++) {
            Component k = cs[i];
            if (k == null || k.if3) continue;
            int x0 = Math.round(k.baseX * sx), y0 = Math.round(k.baseY * sy);
            k.x = x0; k.y = y0;
            k.width = Math.max(1, Math.round((k.baseX + k.baseWidth) * sx) - x0);
            k.height = Math.max(1, Math.round((k.baseY + k.baseHeight) * sy) - y0);
            if (k.type == 6 && fsZoom[i] > 0) k.modelZoom = Math.max(50, Math.round(fsZoom[i] / Math.min(sx, sy)));
        }
    }

    private static void exitFullscreen() {
        if (!studioOpen) return;
        for (int i = 0; i < fsN; i++) {
            Component k = fsChain[i];
            k.x = fsSaved[i][0]; k.y = fsSaved[i][1]; k.width = fsSaved[i][2]; k.height = fsSaved[i][3];
            InterfaceList.redraw(k);
            fsChain[i] = null;
        }
        fsN = 0;
        keepTop = -1;
        studioOpen = false;
    }

    /** While the studio is full screen, every other top-level piece of the game screen (chat, minimap, tabs, orbs) is skipped. */
    public static boolean skipTop(Component c) {
        return studioOpen && c != null && c.overlayer == -1 && (c.id >>> 16) == 746 && c.id != keepTop;
    }

    /** Hide the native button when a full-screen interface would be covered by it (never, for now). */
    /** true while the full-screen welcome scroll (interface 378) is open; set on the game thread each frame */
    public static volatile boolean welcomeOpen = false;
    public static boolean logoutHidden() { return welcomeOpen || studioOpen; }

    /** The game's own stone-tab background, copied once so the app can reuse it (ARGB, stoneWpx x stoneHpx). */
    public static volatile int[] stonePx;
    public static volatile int stoneWpx, stoneHpx;

    private static void captureStone(Component[] c) {
        if (stonePx != null) {
            return;
        }
        try {
            Sprite sp = c[26].getSprite(false);
            if (!(sp instanceof SoftwareSprite)) {
                return;
            }
            SoftwareSprite ss = (SoftwareSprite) sp;
            int iw = ss.innerWidth, ih = ss.innerHeight;
            if (ss.pixels == null || iw <= 0 || ih <= 0 || iw > 256 || ih > 256) {
                return;
            }
            int[] out = new int[iw * ih];
            for (int y = 0; y < ss.height; y++) {
                for (int x = 0; x < ss.width; x++) {
                    int dx = x + ss.xOffset, dy = y + ss.yOffset;
                    if (dx < 0 || dy < 0 || dx >= iw || dy >= ih) continue;
                    int px = ss.pixels[y * ss.width + x];
                    out[dy * iw + dx] = px == 0 ? 0 : (0xFF000000 | px);
                }
            }
            stoneWpx = iw;
            stoneHpx = ih;
            stonePx = out;
        } catch (Throwable ignored) {
        }
    }

    public static volatile int logoutX, logoutY, logoutW, logoutH, canvasW;
    private static volatile boolean panelOpen;
    private static volatile int panelX, panelY, panelW, panelH;

    /** True when logical point (x, y) is over the 3D world rather than a button, panel, chat or minimap. */
    public static boolean touchIsWorld(int x, int y) {
        int w = GameShell.canvasWidth;
        if (studioOpen) return false;
        if (x >= gridX && y >= gridY) return false;          // icon block
        if (x < 520 && y < 170) return false;                // chat
        if (x >= w - 225 && y < 190) return false;           // minimap and orbs
        if (panelOpen && x >= panelX && x < panelX + panelW && y >= panelY && y < panelY + panelH) return false;
        return true;
    }

    /** True when logical point (x, y) is over the chat message box (below the filter buttons). */
    public static boolean isChat(int x, int y) {
        return enabled && !studioOpen && x >= 0 && x < 519 && y >= 23 && y < 165;
    }

    private static void set(Component comp, int x, int y) {
        comp.x = x;
        comp.y = y;
    }

    private static void placeOne(Component[] c, int s, int x, int y, float f) {
        c[s].x = x;
        c[s].y = y;
        c[s].width = Math.round(stW[s] * f);
        c[s].height = Math.round(stH[s] * f);
        c[s + 15].x = x + Math.round(ovDx[s] * f);
        c[s + 15].y = y + Math.round(ovDy[s] * f);
        c[s + 15].width = Math.round(ovW[s] * f);
        c[s + 15].height = Math.round(ovH[s] * f);
        c[s + 30].x = x + Math.round(icDx[s] * f);
        c[s + 30].y = y + Math.round(icDy[s] * f);
        c[s + 30].width = Math.round(icW[s] * f);
        c[s + 30].height = Math.round(icH[s] * f);
    }
}
