package shim.awt;

import shim.platform.Platforms;

public class GraphicsDevice {
    private DisplayMode mode;
    public boolean isFullScreenSupported() { return false; }
    public DisplayMode getDisplayMode() { return mode != null ? mode : new DisplayMode(Platforms.current.viewWidth(), Platforms.current.viewHeight(), 32, 60); }
    public DisplayMode[] getDisplayModes() { return new DisplayMode[] { getDisplayMode() }; }
    public void setDisplayMode(DisplayMode m) { mode = m; }
    public void setFullScreenWindow(Window w) {}
    public GraphicsConfiguration getDefaultConfiguration() { return new GraphicsConfiguration(this); }
}
