// Tiny JNI bridge to gl4es. Everything is looked up with dlsym at run time, so this compiles without gl4es headers.
#include <jni.h>
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>

static void *lib = 0;
static char report[4096];

typedef void (*f_v)(void);
typedef const unsigned char *(*f_gets)(unsigned int);
typedef void (*f_vp)(int, int, int, int);
typedef void (*f_cc)(float, float, float, float);
typedef void (*f_u)(unsigned int);
typedef void (*f_rot)(float, float, float, float);
typedef void (*f_3f)(float, float, float);
typedef unsigned int (*f_err)(void);

static f_gets p_gets; static f_vp p_viewport; static f_cc p_clearcolor; static f_u p_clear, p_matrixmode, p_begin;
static f_v p_loadid, p_end; static f_rot p_rotate; static f_3f p_color3f, p_vertex3f; static f_err p_err;

static void *sym(const char *n) {
    void *p = lib ? dlsym(lib, n) : 0;
    if (!p && lib) { char b[128]; snprintf(b, sizeof b, "gl4es_%s", n); p = dlsym(lib, b); }
    return p;
}
static void rep(const char *fmt, const char *a) { size_t l = strlen(report); snprintf(report + l, sizeof(report) - l, fmt, a); }

JNIEXPORT jstring JNICALL Java_app_rsps2009_Gl4esNative_nInit(JNIEnv *env, jclass c, jstring path) {
    report[0] = 0;
    const char *p = (*env)->GetStringUTFChars(env, path, 0);
    lib = dlopen(p, RTLD_LAZY | RTLD_GLOBAL);
    if (!lib) { rep("dlopen by path failed: %s\n", dlerror()); lib = dlopen("libgl4es.so", RTLD_LAZY | RTLD_GLOBAL); }
    if (!lib) { rep("dlopen FAILED: %s\n", dlerror()); (*env)->ReleaseStringUTFChars(env, path, p); return (*env)->NewStringUTF(env, report); }
    rep("dlopen OK: %s\n", p);
    (*env)->ReleaseStringUTFChars(env, path, p);
    const char *initNames[] = {"initialize_gl4es", "gl4es_init", "init_gl4es", "gl4es_initialize", 0};
    for (int i = 0; initNames[i]; i++) { f_v f = (f_v)dlsym(lib, initNames[i]); if (f) { f(); rep("called init: %s\n", initNames[i]); break; } }
    const char *probe[] = {"glXMakeCurrent", "glXCreateContext", "eglGetProcAddress", "gl4es_getprocaddress", "glGetString", "glBegin", "glMatrixMode", "glLightfv", "glProgramStringARB", "glNewList", 0};
    for (int i = 0; probe[i]; i++) { rep(sym(probe[i]) ? "  have %s\n" : "  MISSING %s\n", probe[i]); }
    p_gets = (f_gets)sym("glGetString"); p_viewport = (f_vp)sym("glViewport"); p_clearcolor = (f_cc)sym("glClearColor");
    p_clear = (f_u)sym("glClear"); p_matrixmode = (f_u)sym("glMatrixMode"); p_begin = (f_u)sym("glBegin");
    p_loadid = (f_v)sym("glLoadIdentity"); p_end = (f_v)sym("glEnd"); p_rotate = (f_rot)sym("glRotatef");
    p_color3f = (f_3f)sym("glColor3f"); p_vertex3f = (f_3f)sym("glVertex3f"); p_err = (f_err)sym("glGetError");
    return (*env)->NewStringUTF(env, report);
}

JNIEXPORT jstring JNICALL Java_app_rsps2009_Gl4esNative_nString(JNIEnv *env, jclass c, jint name) {
    if (!p_gets) return (*env)->NewStringUTF(env, "(glGetString missing)");
    const char *s = (const char *)p_gets((unsigned int)name);
    return (*env)->NewStringUTF(env, s ? s : "(null)");
}

// Draws a spinning rainbow triangle with old fixed-function calls. Returns glGetError().
JNIEXPORT jint JNICALL Java_app_rsps2009_Gl4esNative_nDraw(JNIEnv *env, jclass c, jint w, jint h, jfloat t) {
    if (!p_viewport || !p_clear || !p_begin || !p_end || !p_vertex3f) return -1;
    p_viewport(0, 0, w, h);
    p_clearcolor(0.05f, 0.05f, 0.1f, 1.0f);
    p_clear(0x4000 | 0x100);
    if (p_matrixmode && p_loadid) { p_matrixmode(0x1701); p_loadid(); p_matrixmode(0x1700); p_loadid(); }
    if (p_rotate) p_rotate(t * 90.0f, 0, 0, 1);
    p_begin(0x0004);
    p_color3f(1, 0, 0); p_vertex3f(-0.6f, -0.5f, 0);
    p_color3f(0, 1, 0); p_vertex3f(0.6f, -0.5f, 0);
    p_color3f(0, 0, 1); p_vertex3f(0.0f, 0.7f, 0);
    p_end();
    return p_err ? (jint)p_err() : 0;
}

// ---------------------------------------------------------------------------------------------
// Full OpenGL entry points for the game's GPU renderer (generated list), resolved from gl4es.
// ---------------------------------------------------------------------------------------------
#include "gl_generated.inc"

JNIEXPORT jstring JNICALL Java_com_jogamp_opengl_GlNative_nLoad(JNIEnv *env, jclass c, jstring path) {
    char msg[512]; msg[0] = 0;
    if (!lib) {
        const char *p = (*env)->GetStringUTFChars(env, path, 0);
        lib = dlopen(p, RTLD_LAZY | RTLD_GLOBAL);
        if (!lib) { lib = dlopen("libgl4es.so", RTLD_LAZY | RTLD_GLOBAL); }
        if (!lib) { snprintf(msg, sizeof msg, "dlopen failed: %s", dlerror()); }
        (*env)->ReleaseStringUTFChars(env, path, p);
        if (lib) { f_v f = (f_v)dlsym(lib, "initialize_gl4es"); if (f) f(); }
    }
    if (lib) load_all();
    return (*env)->NewStringUTF(env, msg);
}

JNIEXPORT jlong JNICALL Java_com_jogamp_opengl_GlNative_address(JNIEnv *env, jclass c, jobject buf) {
    return (jlong)(intptr_t)(*env)->GetDirectBufferAddress(env, buf);
}

JNIEXPORT jstring JNICALL Java_com_jogamp_opengl_GlNative_glGetString(JNIEnv *env, jclass c, jint name) {
    if (!p_gets) p_gets = (f_gets)sym("glGetString");
    if (!p_gets) return 0;
    const char *s = (const char *)p_gets((unsigned int)name);
    return s ? (*env)->NewStringUTF(env, s) : 0;
}
