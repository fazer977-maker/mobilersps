package com.jogamp.opengl;

/** Android supplies the real EGL work; the desktop-style classes below just forward to it. */
public interface EglBackend {
    /** Creates the window surface + context for the GPU view. Returns false if it cannot. */
    boolean create(int sampleCount);
    /** Makes the context current on the calling thread. */
    boolean makeCurrent();
    void release();
    void swap();
    void destroy();
}
