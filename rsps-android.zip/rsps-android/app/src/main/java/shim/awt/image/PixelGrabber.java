package shim.awt.image;

import shim.awt.Image;

public class PixelGrabber {
    private final BufferedImage img;
    private final int x, y, w, h, off, scan;
    private final int[] pixels;
    public PixelGrabber(Image img, int x, int y, int w, int h, int[] pixels, int off, int scan) {
        this.img = img instanceof BufferedImage ? (BufferedImage) img : null;
        this.x = x; this.y = y; this.w = w; this.h = h; this.pixels = pixels; this.off = off; this.scan = scan;
    }
    public boolean grabPixels() throws InterruptedException {
        if (img == null) return false;
        img.getRGB(x, y, w, h, pixels, off, scan);
        return true;
    }
}
