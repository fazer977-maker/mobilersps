#!/bin/bash
# Best-effort native build for the experimental GPU mode: gl4es (old OpenGL -> OpenGL ES) plus a tiny JNI bridge.
# Never fails the app build: if anything goes wrong the APK is still produced, just without GPU mode.
cd "$(dirname "$0")/.." || exit 0
APP=$(pwd); OUT=$APP/src/main/jniLibs/arm64-v8a; B=$APP/build/native
mkdir -p "$OUT" "$B"
echo "=== native build (GPU mode) ==="
NDK=""
for c in "$ANDROID_NDK_HOME" "$ANDROID_NDK_ROOT" "$ANDROID_NDK_LATEST_HOME"; do [ -n "$c" ] && [ -d "$c" ] && NDK=$c && break; done
if [ -z "$NDK" ] && [ -d "$ANDROID_HOME/ndk" ]; then NDK=$(ls -d "$ANDROID_HOME"/ndk/* 2>/dev/null | sort -V | tail -1); fi
if [ -z "$NDK" ] && [ -d "$ANDROID_SDK_ROOT/ndk" ]; then NDK=$(ls -d "$ANDROID_SDK_ROOT"/ndk/* 2>/dev/null | sort -V | tail -1); fi
echo "NDK: ${NDK:-NOT FOUND}"
[ -n "$NDK" ] || { echo "GPU mode skipped: no NDK"; exit 0; }
TC=$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin
CC=$TC/aarch64-linux-android26-clang
[ -x "$CC" ] || { echo "GPU mode skipped: compiler not found at $CC"; ls "$TC" | head; exit 0; }

# 1) gl4es
if [ ! -d "$B/gl4es" ]; then
  git clone --depth 1 https://github.com/ptitSeb/gl4es.git "$B/gl4es" || { echo "GPU mode skipped: could not download gl4es"; exit 0; }
fi
G=$B/gl4es
echo "gl4es commit: $(git -C "$G" rev-parse --short HEAD 2>/dev/null)"
ls "$G" | head -30
rm -f "$OUT/libgl4es.so"
built=0
if [ -f "$G/Android.mk" ]; then
  echo "--- trying ndk-build with gl4es's own Android.mk"
  ( cd "$G" && "$NDK/ndk-build" NDK_PROJECT_PATH="$G" APP_BUILD_SCRIPT="$G/Android.mk" APP_ABI=arm64-v8a APP_PLATFORM=android-26 NDK_OUT="$B/ndkout" NDK_LIBS_OUT="$B/ndklibs" -j4 ) 2>&1 | tail -40
  f=$(find "$B/ndklibs" -name '*.so' 2>/dev/null | grep -i -E 'gl' | head -1)
  [ -n "$f" ] && cp "$f" "$OUT/libgl4es.so" && built=1 && echo "built via ndk-build: $f"
fi
if [ $built = 0 ]; then
  echo "--- trying direct compile of gl4es sources"
  SRCS=$(cd "$G/src" && find . -name '*.c' | grep -v -i -E 'gbm|rpi|x11|/glx/streaming|bcm' | sed 's|^\./||')
  mkdir -p "$B/obj"; : > "$B/objs.txt"; fail=0
  for s in $SRCS; do
    o="$B/obj/$(echo "$s" | tr '/' '_').o"
    "$CC" -c -O2 -fPIC -std=gnu99 -w -fvisibility=hidden -DNOX11 -DNO_GBM -DNO_INIT_CONSTRUCTOR=0 -DANDROID -I"$G/src" -I"$G/include" -I"$G/src/glx" -o "$o" "$G/src/$s" 2> "$B/err.txt" || { fail=$((fail+1)); echo "compile failed: $s"; head -3 "$B/err.txt"; continue; }
    echo "$o" >> "$B/objs.txt"
  done
  echo "compile failures: $fail"
  "$CC" -shared -o "$OUT/libgl4es.so" $(cat "$B/objs.txt") -llog -ldl -lGLESv2 -lEGL -lm 2>&1 | tail -20
  [ -f "$OUT/libgl4es.so" ] && built=1
fi
[ $built = 1 ] && echo "gl4es library: OK ($(du -k "$OUT/libgl4es.so" | cut -f1) KB)" || echo "gl4es library: FAILED (GPU mode will be unavailable)"

# 2) JNI bridge
"$CC" -shared -fPIC -O2 -o "$OUT/libgl4esbridge.so" "$APP/src/main/cpp/bridge.c" -llog -ldl 2>&1 | tail -20
[ -f "$OUT/libgl4esbridge.so" ] && echo "bridge: OK" || echo "bridge: FAILED"
exit 0
