package app.rsps2009;

import android.graphics.*;

/** Draws the game's own stone-tab background (copied from the running game) for native buttons. */
final class StoneIcon {
    private static Bitmap bmp;
    private static int[] src;

    private StoneIcon() {}

    static void drawStone(Canvas c, Paint p, float w, float h) {
        int[] sp = rt4.MobileLayout.stonePx;
        if (sp != null) {
            if (bmp == null || src != sp) {
                src = sp;
                bmp = Bitmap.createBitmap(sp, rt4.MobileLayout.stoneWpx, rt4.MobileLayout.stoneHpx, Bitmap.Config.ARGB_8888);
            }
            p.setFilterBitmap(false);
            c.drawBitmap(bmp, null, new RectF(0, 0, w, h), p);
            return;
        }
        float u = Math.min(w, h);
        p.setStyle(Paint.Style.FILL);
        p.setShader(null);
        p.setColor(Color.rgb(26, 22, 18));
        c.drawRoundRect(new RectF(0, 0, w, h), u * 0.2f, u * 0.2f, p);
        p.setShader(new LinearGradient(0, 0, w, h, Color.rgb(120, 112, 100), Color.rgb(66, 60, 52), Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(u * 0.06f, u * 0.06f, w - u * 0.06f, h - u * 0.06f), u * 0.17f, u * 0.17f, p);
        p.setShader(null);
    }

    /** Round clock face (gold rim, cream dial, hands showing the given time). */
    static void drawClock(Canvas c, Paint p, float w, float h, int hour, int min, int sec) {
        float cx = w / 2f, cy = h / 2f, r = Math.min(w, h) * 0.34f;
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setAntiAlias(true);
        p.setColor(Color.argb(120, 0, 0, 0)); c.drawCircle(cx + r * 0.08f, cy + r * 0.1f, r * 1.08f, p);
        p.setColor(Color.rgb(176, 132, 40)); c.drawCircle(cx, cy, r * 1.08f, p);
        p.setColor(Color.rgb(236, 196, 92)); c.drawCircle(cx, cy, r * 0.98f, p);
        p.setColor(Color.rgb(246, 238, 214)); c.drawCircle(cx, cy, r * 0.84f, p);
        p.setColor(Color.rgb(70, 56, 40));
        for (int i = 0; i < 12; i++) {
            double a = Math.PI * 2 * i / 12; float rr = i % 3 == 0 ? r * 0.10f : r * 0.055f;
            c.drawCircle(cx + (float) Math.sin(a) * r * 0.68f, cy - (float) Math.cos(a) * r * 0.68f, rr, p);
        }
        p.setStrokeCap(Paint.Cap.ROUND); p.setStyle(Paint.Style.STROKE);
        double ha = Math.PI * 2 * ((hour % 12) + min / 60.0) / 12, ma = Math.PI * 2 * (min + sec / 60.0) / 60, sa = Math.PI * 2 * sec / 60;
        p.setColor(Color.rgb(40, 32, 26)); p.setStrokeWidth(r * 0.13f);
        c.drawLine(cx, cy, cx + (float) Math.sin(ha) * r * 0.42f, cy - (float) Math.cos(ha) * r * 0.42f, p);
        p.setStrokeWidth(r * 0.08f);
        c.drawLine(cx, cy, cx + (float) Math.sin(ma) * r * 0.64f, cy - (float) Math.cos(ma) * r * 0.64f, p);
        p.setColor(Color.rgb(196, 40, 32)); p.setStrokeWidth(r * 0.04f);
        c.drawLine(cx, cy, cx + (float) Math.sin(sa) * r * 0.70f, cy - (float) Math.cos(sa) * r * 0.70f, p);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(176, 132, 40)); c.drawCircle(cx, cy, r * 0.09f, p);
    }

    /** A little pixel-style keyboard on top of the stone. */
    static void drawKeyboard(Canvas c, Paint p, float w, float h) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(null);
        p.setAntiAlias(false);
        float bx0 = w * 0.12f, bx1 = w * 0.88f, by0 = h * 0.32f, by1 = h * 0.70f;
        p.setColor(Color.rgb(18, 16, 20));
        c.drawRect(bx0 - w * 0.03f, by0 - h * 0.03f, bx1 + w * 0.03f, by1 + h * 0.04f, p);
        p.setColor(Color.rgb(78, 76, 84));
        c.drawRect(bx0, by0, bx1, by1, p);
        p.setColor(Color.rgb(104, 102, 112));
        c.drawRect(bx0, by0, bx1, by0 + h * 0.03f, p);
        float kw = (bx1 - bx0) / 9f;
        float rowH = (by1 - by0) / 4f;
        for (int r = 0; r < 3; r++) {
            int n = r == 1 ? 8 : 9;
            float off = r == 1 ? kw * 0.5f : 0f;
            for (int i = 0; i < n; i++) {
                float kx = bx0 + off + i * kw;
                p.setColor(Color.rgb(214, 214, 222));
                c.drawRect(kx + kw * 0.14f, by0 + r * rowH + rowH * 0.2f, kx + kw * 0.86f, by0 + r * rowH + rowH * 0.8f, p);
            }
        }
        p.setColor(Color.rgb(214, 214, 222));
        c.drawRect(bx0 + kw * 1.6f, by0 + 3 * rowH + rowH * 0.2f, bx1 - kw * 1.6f, by0 + 3 * rowH + rowH * 0.8f, p);
        p.setAntiAlias(true);
    }
}
