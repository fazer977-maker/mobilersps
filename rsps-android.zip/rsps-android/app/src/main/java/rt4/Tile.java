package rt4;

import org.openrs2.deob.annotation.OriginalArg;
import org.openrs2.deob.annotation.OriginalClass;
import org.openrs2.deob.annotation.OriginalMember;

@OriginalClass("client!bj")
public final class Tile extends Node {

	@OriginalMember(owner = "client!bj", name = "x", descriptor = "Z")
	public boolean visible;

	@OriginalMember(owner = "client!bj", name = "y", descriptor = "I")
	public int sceneryLen;

	@OriginalMember(owner = "client!bj", name = "A", descriptor = "Z")
	public boolean checkedBelowLevel;

	@OriginalMember(owner = "client!bj", name = "B", descriptor = "Lclient!fg;")
	public ShapedTile shapedTile;

	@OriginalMember(owner = "client!bj", name = "C", descriptor = "I")
	public int sceneryDrawFlags;

	@OriginalMember(owner = "client!bj", name = "E", descriptor = "I")
	public int sceneryDrawnDirFlags;

	@OriginalMember(owner = "client!bj", name = "G", descriptor = "Lclient!bm;")
	public GroundDecor groundDecor;

	@OriginalMember(owner = "client!bj", name = "I", descriptor = "I")
	public int scenerySkipDirFlags;

	@OriginalMember(owner = "client!bj", name = "J", descriptor = "Lclient!df;")
	public WallDecor wallDecor;

	@OriginalMember(owner = "client!bj", name = "K", descriptor = "Lclient!jh;")
	public Wall wall;

	@OriginalMember(owner = "client!bj", name = "M", descriptor = "Lclient!bj;")
	public Tile linkedTile;

	@OriginalMember(owner = "client!bj", name = "N", descriptor = "Z")
	public boolean hasUpdated;

	@OriginalMember(owner = "client!bj", name = "S", descriptor = "Lclient!rh;")
	public PlainTile plainTile;

	@OriginalMember(owner = "client!bj", name = "T", descriptor = "I")
	public int wallDrawFlags;

	@OriginalMember(owner = "client!bj", name = "X", descriptor = "Lclient!jj;")
	public ObjStackEntity objStack;

	@OriginalMember(owner = "client!bj", name = "D", descriptor = "I")
	public int allInteriorFlags = 0;

	@OriginalMember(owner = "client!bj", name = "w", descriptor = "[Lclient!ec;")
	public final Scenery[] scenery = new Scenery[5];

	@OriginalMember(owner = "client!bj", name = "P", descriptor = "[I")
	public final int[] interiorFlags = new int[5];

	@OriginalMember(owner = "client!bj", name = "H", descriptor = "I")
	public final int y;

	@OriginalMember(owner = "client!bj", name = "W", descriptor = "I")
	public int drawLevel;

	@OriginalMember(owner = "client!bj", name = "Q", descriptor = "I")
	public final int level;

	@OriginalMember(owner = "client!bj", name = "R", descriptor = "I")
	public final int x;

	@OriginalMember(owner = "client!bj", name = "<init>", descriptor = "(III)V")
	public Tile(@OriginalArg(0) int level, @OriginalArg(1) int x, @OriginalArg(2) int y) {
		this.y = y;
		this.level = this.drawLevel = level;
		this.x = x;
	}
}
