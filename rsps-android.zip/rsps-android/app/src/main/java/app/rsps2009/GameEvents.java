package app.rsps2009;

import rt4.GameShell;
import shim.awt.Canvas;
import shim.awt.event.FocusEvent;
import shim.awt.event.KeyEvent;
import shim.awt.event.MouseEvent;
import shim.awt.event.MouseWheelEvent;

/** Translates Android input into the AWT-style events the client's listeners expect. */
final class GameEvents {

    private static volatile float scale = 1f;
    static volatile Runnable onEnter;
    static volatile Runnable onChatTap;

    private GameEvents() {}

    static void setScale(float s) { scale = s <= 0 ? 1f : s; }

    private static Canvas canvas() { return GameShell.canvas; }

    private static int lx(Canvas c, float px) { return Math.round(px / scale) - c.getX(); }
    private static int ly(Canvas c, float py) { return Math.round(py / scale) - c.getY(); }

    // ---------------------------------------------------------------- pointer

    static void move(float px, float py) {
        Canvas c = canvas();
        if (c == null) return;
        c.processMouseMotionEvent(new MouseEvent(c, MouseEvent.MOUSE_MOVED, System.currentTimeMillis(), 0, lx(c, px), ly(c, py), 0, false));
    }

    static void drag(float px, float py) {
        Canvas c = canvas();
        if (c == null) return;
        c.processMouseMotionEvent(new MouseEvent(c, MouseEvent.MOUSE_DRAGGED, System.currentTimeMillis(),
                MouseEvent.BUTTON1_DOWN_MASK, lx(c, px), ly(c, py), 0, false));
    }

    private static int mods(int button) {
        if (button == MouseEvent.BUTTON3) return MouseEvent.BUTTON3_DOWN_MASK | MouseEvent.BUTTON3_MASK;
        return MouseEvent.BUTTON1_DOWN_MASK | MouseEvent.BUTTON1_MASK;
    }

    static void press(float px, float py, int button) {
        Canvas c = canvas();
        if (c == null) return;
        c.processMouseEvent(new MouseEvent(c, MouseEvent.MOUSE_PRESSED, System.currentTimeMillis(), mods(button), lx(c, px), ly(c, py), 1, false, button));
    }

    static void release(float px, float py, int button) {
        Canvas c = canvas();
        if (c == null) return;
        c.processMouseEvent(new MouseEvent(c, MouseEvent.MOUSE_RELEASED, System.currentTimeMillis(), 0, lx(c, px), ly(c, py), 1, false, button));
    }

    static void wheel(float px, float py, int rotation) {
        Canvas c = canvas();
        if (c == null || rotation == 0) return;
        c.processMouseWheelEvent(new MouseWheelEvent(c, System.currentTimeMillis(), 0, lx(c, px), ly(c, py), rotation));
    }

    static void focus(boolean gained) {
        Canvas c = canvas();
        if (c == null) return;
        c.processFocusEvent(new FocusEvent(c, gained ? FocusEvent.FOCUS_GAINED : FocusEvent.FOCUS_LOST));
    }

    // ------------------------------------------------------------------- keys

    private static void key(int id, int vk, char ch) {
        Canvas c = canvas();
        if (c == null) return;
        c.processKeyEvent(new KeyEvent(c, id, System.currentTimeMillis(), 0, vk, ch));
    }

    /** A control/navigation key (arrows, page up/down...): pressed + released only. */
    static void navKey(int vk) {
        key(KeyEvent.KEY_PRESSED, vk, KeyEvent.CHAR_UNDEFINED);
        key(KeyEvent.KEY_RELEASED, vk, KeyEvent.CHAR_UNDEFINED);
    }

    /** A key that also produces a character in AWT (enter, backspace, tab, escape, delete). */
    static void controlKey(int vk, char ch) {
        if (vk == KeyEvent.VK_ENTER && onEnter != null) {
            final Runnable r = onEnter;
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(r, 120);
        }
        key(KeyEvent.KEY_PRESSED, vk, ch);
        key(KeyEvent.KEY_TYPED, 0, ch);
        key(KeyEvent.KEY_RELEASED, vk, ch);
    }

    /** A printable character, as typed on a soft or hardware keyboard. */
    static void typeChar(char ch) {
        if (ch == '\n' || ch == '\r') { controlKey(KeyEvent.VK_ENTER, '\n'); return; }
        if (ch == '\b') { controlKey(KeyEvent.VK_BACK_SPACE, '\b'); return; }
        if (ch == '\t') { controlKey(KeyEvent.VK_TAB, '\t'); return; }
        int vk = KeyEvent.VK_UNDEFINED;
        if (ch >= 'a' && ch <= 'z') vk = KeyEvent.VK_A + (ch - 'a');
        else if (ch >= 'A' && ch <= 'Z') vk = KeyEvent.VK_A + (ch - 'A');
        else if (ch >= '0' && ch <= '9') vk = KeyEvent.VK_0 + (ch - '0');
        else if (ch == ' ') vk = KeyEvent.VK_SPACE;
        key(KeyEvent.KEY_PRESSED, vk, ch);
        key(KeyEvent.KEY_TYPED, 0, ch);
        key(KeyEvent.KEY_RELEASED, vk, ch);
    }

    static void typeText(CharSequence text) {
        for (int i = 0; i < text.length(); i++) typeChar(text.charAt(i));
    }

    /** Maps an Android key code from a hardware keyboard / IME key event. Returns true if handled. */
    static boolean androidKey(int keyCode, int unicode, boolean down) {
        // Only act on key-down; the helper sends press+release itself.
        if (!down) return true;
        switch (keyCode) {
            case android.view.KeyEvent.KEYCODE_ENTER:
            case android.view.KeyEvent.KEYCODE_NUMPAD_ENTER: controlKey(KeyEvent.VK_ENTER, '\n'); return true;
            case android.view.KeyEvent.KEYCODE_DEL: controlKey(KeyEvent.VK_BACK_SPACE, '\b'); return true;
            case android.view.KeyEvent.KEYCODE_FORWARD_DEL: controlKey(KeyEvent.VK_DELETE, (char) 127); return true;
            case android.view.KeyEvent.KEYCODE_TAB: controlKey(KeyEvent.VK_TAB, '\t'); return true;
            case android.view.KeyEvent.KEYCODE_ESCAPE: controlKey(KeyEvent.VK_ESCAPE, (char) 27); return true;
            case android.view.KeyEvent.KEYCODE_DPAD_LEFT: navKey(KeyEvent.VK_LEFT); return true;
            case android.view.KeyEvent.KEYCODE_DPAD_RIGHT: navKey(KeyEvent.VK_RIGHT); return true;
            case android.view.KeyEvent.KEYCODE_DPAD_UP: navKey(KeyEvent.VK_UP); return true;
            case android.view.KeyEvent.KEYCODE_DPAD_DOWN: navKey(KeyEvent.VK_DOWN); return true;
            case android.view.KeyEvent.KEYCODE_PAGE_UP: navKey(KeyEvent.VK_PAGE_UP); return true;
            case android.view.KeyEvent.KEYCODE_PAGE_DOWN: navKey(KeyEvent.VK_PAGE_DOWN); return true;
            case android.view.KeyEvent.KEYCODE_MOVE_HOME: navKey(KeyEvent.VK_HOME); return true;
            case android.view.KeyEvent.KEYCODE_MOVE_END: navKey(KeyEvent.VK_END); return true;
            default:
                if (unicode > 0 && unicode < 0xFFFF) { typeChar((char) unicode); return true; }
                return false;
        }
    }
}
