package shim.awt;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import shim.awt.event.FocusEvent;
import shim.awt.event.FocusListener;
import shim.awt.event.KeyEvent;
import shim.awt.event.KeyListener;
import shim.awt.event.MouseEvent;
import shim.awt.event.MouseListener;
import shim.awt.event.MouseMotionListener;
import shim.awt.event.MouseWheelEvent;
import shim.awt.event.MouseWheelListener;
import shim.awt.image.BufferedImage;
import shim.awt.image.ImageObserver;
import shim.awt.image.ImageProducer;

public class Component {
    protected int x, y, width, height;
    protected boolean visible = true;
    protected Container parent;
    protected Color background = Color.white;
    protected Font font;
    protected Cursor cursor;

    private final List<MouseListener> mouseListeners = new CopyOnWriteArrayList<>();
    private final List<MouseMotionListener> motionListeners = new CopyOnWriteArrayList<>();
    private final List<MouseWheelListener> wheelListeners = new CopyOnWriteArrayList<>();
    private final List<KeyListener> keyListeners = new CopyOnWriteArrayList<>();
    private final List<FocusListener> focusListeners = new CopyOnWriteArrayList<>();

    public void addMouseListener(MouseListener l) { if (l != null) mouseListeners.add(l); }
    public void removeMouseListener(MouseListener l) { mouseListeners.remove(l); }
    public void addMouseMotionListener(MouseMotionListener l) { if (l != null) motionListeners.add(l); }
    public void removeMouseMotionListener(MouseMotionListener l) { motionListeners.remove(l); }
    public void addMouseWheelListener(MouseWheelListener l) { if (l != null) wheelListeners.add(l); }
    public void removeMouseWheelListener(MouseWheelListener l) { wheelListeners.remove(l); }
    public void addKeyListener(KeyListener l) { if (l != null) keyListeners.add(l); }
    public void removeKeyListener(KeyListener l) { keyListeners.remove(l); }
    public void addFocusListener(FocusListener l) { if (l != null) focusListeners.add(l); }
    public void removeFocusListener(FocusListener l) { focusListeners.remove(l); }

    // ---- event injection (called by the host) ----
    public void processMouseEvent(MouseEvent e) {
        for (MouseListener l : mouseListeners) {
            switch (e.getID()) {
                case MouseEvent.MOUSE_PRESSED: l.mousePressed(e); break;
                case MouseEvent.MOUSE_RELEASED: l.mouseReleased(e); break;
                case MouseEvent.MOUSE_CLICKED: l.mouseClicked(e); break;
                case MouseEvent.MOUSE_ENTERED: l.mouseEntered(e); break;
                case MouseEvent.MOUSE_EXITED: l.mouseExited(e); break;
                default: break;
            }
        }
    }
    public void processMouseMotionEvent(MouseEvent e) {
        for (MouseMotionListener l : motionListeners) {
            if (e.getID() == MouseEvent.MOUSE_DRAGGED) l.mouseDragged(e); else l.mouseMoved(e);
        }
    }
    public void processMouseWheelEvent(MouseWheelEvent e) {
        for (MouseWheelListener l : wheelListeners) l.mouseWheelMoved(e);
    }
    public void processKeyEvent(KeyEvent e) {
        for (KeyListener l : keyListeners) {
            switch (e.getID()) {
                case KeyEvent.KEY_PRESSED: l.keyPressed(e); break;
                case KeyEvent.KEY_RELEASED: l.keyReleased(e); break;
                case KeyEvent.KEY_TYPED: l.keyTyped(e); break;
                default: break;
            }
        }
    }
    public void processFocusEvent(FocusEvent e) {
        for (FocusListener l : focusListeners) {
            if (e.getID() == FocusEvent.FOCUS_GAINED) l.focusGained(e); else l.focusLost(e);
        }
    }

    // ---- geometry ----
    public void setSize(int w, int h) { width = w; height = h; }
    public void setSize(Dimension d) { setSize(d.width, d.height); }
    public Dimension getSize() { return new Dimension(width, height); }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public void setLocation(int x, int y) { this.x = x; this.y = y; }
    public Point getLocation() { return new Point(x, y); }
    public int getX() { return x; }
    public int getY() { return y; }
    public void setBounds(int x, int y, int w, int h) { setLocation(x, y); setSize(w, h); }
    public Point getLocationOnScreen() { return new Point(x, y); }

    public void setVisible(boolean v) { visible = v; }
    public boolean isVisible() { return visible; }
    public boolean isShowing() { return visible; }
    public Container getParent() { return parent; }
    public void requestFocus() {}
    public boolean requestFocusInWindow() { return true; }
    public void setFocusTraversalKeysEnabled(boolean b) {}
    public void enableInputMethods(boolean b) {}
    public void setBackground(Color c) { if (c != null) background = c; }
    public Color getBackground() { return background; }
    public void setFont(Font f) { font = f; }
    public Font getFont() { return font; }
    public void setCursor(Cursor c) { cursor = c; }
    public Cursor getCursor() { return cursor; }
    public Toolkit getToolkit() { return Toolkit.getDefaultToolkit(); }
    public GraphicsConfiguration getGraphicsConfiguration() {
        return GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration();
    }

    public Graphics getGraphics() { return null; }
    public FontMetrics getFontMetrics(Font f) { return new FontMetrics(f); }
    public Image createImage(ImageProducer p) { return null; }
    public Image createImage(int w, int h) { return new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB); }
    public boolean prepareImage(Image image, ImageObserver observer) { return true; }
    public void repaint() {
        Graphics g = getGraphics();
        if (g != null) {
            update(g);
            g.dispose();
        }
    }
    public void update(Graphics g) { paint(g); }
    public void paint(Graphics g) {}
    public void setIgnoreRepaint(boolean b) {}
    public boolean isDisplayable() { return false; }
    public void validate() {}
    public void invalidate() {}
}
