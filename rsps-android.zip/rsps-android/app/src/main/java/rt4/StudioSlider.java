package rt4;

/**
 * Character Studio sliders (old-style interface, client code 1502 = a slot of the track, 1503 = the knob for that slot).
 * Touch the track and drag: the knob follows your finger; let go and the chosen style is sent as a click on that slot.
 */
public final class StudioSlider {
    private static int activeLayer = -1;
    private static Component[] hits = new Component[0];
    private static Component[] knobs = new Component[0];
    private static int layerAbsX;
    private static int preview = -1;
    private static int lastLoop = -1;

    private StudioSlider() {}

    public static void input(Component c, int absX, int left, int top, int right, int bottom) {
        if (Mouse.clickButton == 1 && activeLayer == -1 && Mouse.clickX >= left && Mouse.clickX < right && Mouse.clickY >= top && Mouse.clickY < bottom) {
            begin(c, absX);
        }
        if (activeLayer != c.overlayer || client.loop == lastLoop) {
            return;
        }
        lastLoop = client.loop;
        layerAbsX = absX - c.x;
        boolean held = Mouse.pressedButton == 1;
        int mx = held ? Mouse.lastMouseX : (preview < 0 ? Mouse.clickX : Mouse.lastMouseX);
        int idx = indexAt(mx - layerAbsX);
        if (idx != preview && idx >= 0) {
            preview = idx;
            for (int k = 0; k < knobs.length; k++) {
                knobs[k].hidden = k != idx;
                InterfaceList.redraw(knobs[k]);
            }
        }
        if (!held) {
            if (preview >= 0 && preview < hits.length) {
                Protocol.outboundBuffer.p1isaac(10);
                Protocol.outboundBuffer.p4(hits[preview].id);
            }
            activeLayer = -1;
            preview = -1;
        }
    }

    private static void begin(Component c, int absX) {
        int group = c.id >>> 16;
        Component[] all = InterfaceList.components[group];
        if (all == null) return;
        int nh = 0, nk = 0;
        for (Component k : all) {
            if (k == null || k.overlayer != c.overlayer) continue;
            if (k.clientCode == 1502) nh++;
            else if (k.clientCode == 1503) nk++;
        }
        hits = new Component[nh];
        knobs = new Component[nk];
        nh = 0; nk = 0;
        for (Component k : all) {
            if (k == null || k.overlayer != c.overlayer) continue;
            if (k.clientCode == 1502) hits[nh++] = k;
            else if (k.clientCode == 1503) knobs[nk++] = k;
        }
        if (knobs.length != hits.length) knobs = new Component[0];
        activeLayer = c.overlayer;
        layerAbsX = absX - c.x;
        preview = -1;
        lastLoop = -1;
    }

    private static int indexAt(int rx) {
        if (hits.length == 0) return -1;
        if (rx < hits[0].x) return 0;
        for (int k = 0; k < hits.length; k++) {
            if (rx < hits[k].x + hits[k].width) return k;
        }
        return hits.length - 1;
    }
}
