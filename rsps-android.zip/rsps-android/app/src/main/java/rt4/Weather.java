package rt4;

import com.jogamp.opengl.GL2;

import java.util.Random;

/**
 * Weather for the GPU renderer: rain, snow and mist drawn over the finished 3D picture (before the time-of-day tint, so it
 * darkens and warms with the sky). While it is on, the skybox goes overcast. Modes: 0 clear, 1 rain, 2 snow, 3 mist, 4 auto
 * (changes by itself every few minutes). Any GL trouble switches it off.
 */
public final class Weather {
	private static boolean broken;
	private static int cur, autoWant;
	private static float amt;
	private static long autoAt, lastNs = System.nanoTime();
	private static final Random rnd = new Random();
	private static final int N = 170;
	private static final float[] px = new float[N], py = new float[N], ps = new float[N], pl = new float[N], pp = new float[N];
	private static boolean seeded;
	private static final SkyBox.Batch fill = new SkyBox.Batch(4), streak = new SkyBox.Batch(N + 8);

	private Weather() {
	}

	/** 0..1, how overcast the sky should be right now. */
	public static float overcast() {
		if (cur == 0 || broken) {
			return 0.0F;
		}
		return amt * (cur == 3 ? 0.55F : cur == 1 ? 1.0F : 0.8F);
	}

	private static void tick(float dt) {
		int want = FxConfig.weather;
		if (want == 4) {
			long now = System.currentTimeMillis();
			if (now >= autoAt) {
				float r = rnd.nextFloat();
				autoWant = r < 0.5F ? 0 : r < 0.75F ? 1 : r < 0.85F ? 3 : 2;
				autoAt = now + (long) ((120 + rnd.nextInt(180)) * 1000L);
			}
			want = autoWant;
		}
		if (want != cur) {
			amt -= dt / 3.0F;
			if (amt <= 0.0F) {
				amt = 0.0F;
				cur = want;
			}
		} else if (cur != 0) {
			amt = Math.min(1.0F, amt + dt / 4.0F);
		}
	}

	/** Called from the 2D setup right after the world scene is finished (see GlRenderer.finishWorldView). */
	public static void apply(GL2 gl) {
		if (!FxConfig.armWeather) {
			return;
		}
		FxConfig.armWeather = false;
		long now = System.nanoTime();
		float dt = Math.min(0.1F, Math.max(0.0F, (now - lastNs) / 1.0e9F));
		lastNs = now;
		tick(dt);
		if (broken || cur == 0 || amt <= 0.01F) {
			return;
		}
		try {
			SkyBox.ensureInit(gl);
			run(gl, dt);
		} catch (Throwable t) {
			broken = true;
			FxGl.recover(gl);
			shim.platform.Platforms.error("WEATHER failed: " + t, t);
		}
	}

	private static void run(GL2 gl, float dt) {
		float w = GlRenderer.canvasWidth, h = GlRenderer.canvasHeight;
		if (w < 64 || h < 64) {
			return;
		}
		SkyBox.ensureInit(gl);
		if (!seeded) {
			for (int i = 0; i < N; i++) {
				px[i] = rnd.nextFloat();
				py[i] = rnd.nextFloat();
				ps[i] = 0.6F + rnd.nextFloat() * 0.8F;
				pl[i] = 0.6F + rnd.nextFloat() * 0.8F;
				pp[i] = rnd.nextFloat() * 6.2832F;
			}
			seeded = true;
		}
		float scale = Math.max(1.0F, h / 540.0F);
		gl.glClientActiveTexture(GL2.GL_TEXTURE0);
		boolean pColor = GL2.clientOn(GL2.GL_COLOR_ARRAY), pTex = GL2.clientOn(GL2.GL_TEXTURE_COORD_ARRAY), pNormal = GL2.clientOn(GL2.GL_NORMAL_ARRAY);
		MaterialManager.setMaterial(0, 0);
		GlRenderer.setLightingEnabled(false);
		GlRenderer.setDepthTestEnabled(false);
		GlRenderer.setFogEnabled(false);
		GlRenderer.disableDepthMask();
		GlRenderer.setTextureCombineRgbMode(0);
		GlRenderer.setTextureCombineAlphaMode(0);
		gl.glDisableClientState(GL2.GL_NORMAL_ARRAY);
		GlRenderer.normalArrayEnabled = false;
		gl.glEnableClientState(GL2.GL_VERTEX_ARRAY);
		gl.glEnableClientState(GL2.GL_COLOR_ARRAY);
		gl.glEnableClientState(GL2.GL_TEXTURE_COORD_ARRAY);
		if (GlRenderer.arbVboSupported) {
			gl.glBindBuffer(GL2.GL_ARRAY_BUFFER, 0);
			gl.glBindBuffer(GL2.GL_ELEMENT_ARRAY_BUFFER, 0);
		}
		GlRenderer.setTextureId(SkyBox.glowTex());
		gl.glEnable(GL2.GL_BLEND);
		// 1. a veil over the whole picture: grey for rain, white haze for mist and snow, thicker toward the bottom
		float vr, vg, vb, va0, va1;
		if (cur == 1) {
			vr = 0.10F; vg = 0.12F; vb = 0.16F; va0 = 0.16F; va1 = 0.30F;
		} else if (cur == 3) {
			vr = 0.80F; vg = 0.84F; vb = 0.90F; va0 = 0.22F; va1 = 0.55F;
		} else {
			vr = 0.80F; vg = 0.86F; vb = 0.95F; va0 = 0.08F; va1 = 0.18F;
		}
		fill.clear();
		fill.vert(0, 0, 0, 0.5F, 0.5F, vr, vg, vb, va1 * amt);
		fill.vert(w, 0, 0, 0.5F, 0.5F, vr, vg, vb, va1 * amt);
		fill.vert(w, h, 0, 0.5F, 0.5F, vr, vg, vb, va0 * amt);
		fill.vert(0, h, 0, 0.5F, 0.5F, vr, vg, vb, va0 * amt);
		fill.quadIdx();
		gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
		fill.flush(gl);
		// 2. falling drops or flakes
		streak.clear();
		int count = (int) (N * Math.min(1.0F, amt));
		float t = System.currentTimeMillis() / 1000.0F;
		if (cur == 1) {
			for (int i = 0; i < count; i++) {
				py[i] -= ps[i] * 1.3F * dt;
				px[i] -= 0.12F * ps[i] * dt;
				if (py[i] < -0.1F) {
					py[i] += 1.2F;
					px[i] = rnd.nextFloat() * 1.2F;
				}
				if (px[i] < -0.1F) {
					px[i] += 1.2F;
				}
				float x = px[i] * w, y = py[i] * h, len = (26.0F + 30.0F * pl[i]) * scale, wd = 1.1F * scale;
				float tx = x + len * 0.2F, ty = y + len;
				float a = 0.45F * amt * ps[i];
				streak.vert(x - wd, y, 0, 0.5F, 0.5F, 0.75F, 0.85F, 1.0F, a);
				streak.vert(x + wd, y, 0, 0.5F, 0.5F, 0.75F, 0.85F, 1.0F, a);
				streak.vert(tx + wd, ty, 0, 0.5F, 0.5F, 0.75F, 0.85F, 1.0F, 0.0F);
				streak.vert(tx - wd, ty, 0, 0.5F, 0.5F, 0.75F, 0.85F, 1.0F, 0.0F);
				streak.quadIdx();
			}
		} else if (cur == 2) {
			for (int i = 0; i < count; i++) {
				py[i] -= ps[i] * 0.16F * dt;
				if (py[i] < -0.05F) {
					py[i] += 1.1F;
					px[i] = rnd.nextFloat();
				}
				float x = (px[i] + 0.02F * (float) Math.sin(t * 0.8F + pp[i])) * w, y = py[i] * h, sz = (2.2F + 3.2F * pl[i]) * scale;
				float a = 0.85F * amt;
				streak.vert(x - sz, y - sz, 0, 0, 0, 1, 1, 1, a);
				streak.vert(x + sz, y - sz, 0, 1, 0, 1, 1, 1, a);
				streak.vert(x + sz, y + sz, 0, 1, 1, 1, 1, 1, a);
				streak.vert(x - sz, y + sz, 0, 0, 1, 1, 1, 1, a);
				streak.quadIdx();
			}
		}
		gl.glBlendFunc(GL2.GL_SRC_ALPHA, cur == 1 ? GL2.GL_ONE : GL2.GL_ONE_MINUS_SRC_ALPHA);
		streak.flush(gl);
		gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
		gl.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		if (pColor) { gl.glEnableClientState(GL2.GL_COLOR_ARRAY); } else { gl.glDisableClientState(GL2.GL_COLOR_ARRAY); }
		if (pTex) { gl.glEnableClientState(GL2.GL_TEXTURE_COORD_ARRAY); } else { gl.glDisableClientState(GL2.GL_TEXTURE_COORD_ARRAY); }
		if (pNormal) { gl.glEnableClientState(GL2.GL_NORMAL_ARRAY); } else { gl.glDisableClientState(GL2.GL_NORMAL_ARRAY); }
		GlRenderer.normalArrayEnabled = pNormal;
		GlRenderer.setTextureId(-1);
		GlRenderer.enableDepthMask();
	}
}
