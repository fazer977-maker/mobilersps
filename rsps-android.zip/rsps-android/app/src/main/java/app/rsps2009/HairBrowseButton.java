package app.rsps2009;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

/** The "HAIR · Browse" button the app lays over the Studio's hair row; opens the hair picker. */
final class HairBrowseButton extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Typeface bold = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD);
    private final float d;

    HairBrowseButton(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        float sw = Math.max(1.5f, 1.4f * d);
        r.set(sw, sw, w - sw, h - sw);
        float rad = Math.min(10 * d, r.height() * 0.22f);
        float glow = 0.5f + 0.5f * (float) Math.sin(System.currentTimeMillis() / 520.0);
        // card the same navy as the Studio rows, a touch lighter so it reads as a button
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom, 0xFF2E3556, 0xFF1F2540, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(sw);
        p.setColor(android.graphics.Color.argb(120 + Math.round(135 * glow), 255, 201, 74));
        c.drawRoundRect(r, rad, rad, p);
        p.setStyle(Paint.Style.FILL);

        // "HAIR" in gold, then a small grid icon and "BROWSE" under it, centred
        p.setTypeface(bold);
        float big = Math.min(r.height() * 0.30f, 16 * d);
        p.setTextSize(big);
        float hw = p.measureText("HAIR");
        float small = big * 0.62f;
        float gap = big * 0.40f;
        float block = big + gap + small;
        float top = r.centerY() - block / 2;
        p.setColor(0xFFFFC94A);
        c.drawText("HAIR", r.centerX() - hw / 2, top + big * 0.86f, p);

        p.setTextSize(small);
        String s = "BROWSE";
        float tw = p.measureText(s);
        float u = small * 0.38f, ig = u * 0.35f, iconW = u * 2 + ig;
        float rowW = iconW + small * 0.45f + tw;
        float x = r.centerX() - rowW / 2, by = top + big + gap + small * 0.86f;
        float iy = by - small * 0.80f;
        for (int k = 0; k < 4; k++) {
            float gx = x + (k % 2) * (u + ig), gy = iy + (k / 2) * (u + ig);
            c.drawRoundRect(new RectF(gx, gy, gx + u, gy + u), u * 0.3f, u * 0.3f, p);
        }
        p.setColor(0xFFE8EAF4);
        c.drawText(s, x + iconW + small * 0.45f, by, p);
        if (getVisibility() == VISIBLE) postInvalidateDelayed(50);
    }
}
