package app.rsps2009;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/** Custom RuneScape-styled loading + login screen drawn over the game surface. */
final class LoginOverlay extends FrameLayout {
    private static final int GOLD = Color.rgb(255, 176, 0);
    private static final int PARCH = Color.rgb(220, 205, 160);
    private static final int STONE = Color.rgb(62, 53, 41);

    private final Handler h = new Handler(Looper.getMainLooper());
    private final BarView bar;
    private final TextView status, error;
    private final LinearLayout form;
    private final EditText user, pass;
    private final CheckBox remember;
    private final Button login;
    private final File accFile;
    private final float d;

    private boolean attempting, sawBusy, wasInGame, autoDone, prefilled;
    private long attemptAt;

    LoginOverlay(Context c, File filesDir) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        accFile = new File(filesDir, "account.txt");
        setClickable(true);
        setFocusable(true);
        setFocusableInTouchMode(true);

        setBackground(new BgDrawable());

        ScrollView sv = new ScrollView(c);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        addView(sv, new LayoutParams(-1, -1));

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(16), dp(18), dp(16), dp(12));
        sv.addView(col, new ScrollView.LayoutParams(-1, -2));

        TextView title = new TextView(c);
        title.setText("2009Scape");
        title.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        title.setTextSize(38);
        title.setTextColor(GOLD);
        title.setShadowLayer(dp(2), dp(2), dp(2), Color.BLACK);
        title.setGravity(Gravity.CENTER);
        col.addView(title);

        TextView sub = new TextView(c);
        sub.setText("MOBILE");
        sub.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        sub.setTextSize(13);
        sub.setLetterSpacing(0.5f);
        sub.setTextColor(PARCH);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, dp(10));
        col.addView(sub);

        FrameLayout panel = new FrameLayout(c);
        panel.setBackground(panelBg());
        panel.setPadding(dp(14), dp(12), dp(14), dp(12));
        col.addView(panel, new LinearLayout.LayoutParams(dp(330), -2));

        LinearLayout in = new LinearLayout(c);
        in.setOrientation(LinearLayout.VERTICAL);
        in.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.addView(in, new LayoutParams(-1, -2));

        bar = new BarView(c);
        in.addView(bar, new LinearLayout.LayoutParams(-1, dp(30)));

        status = label(c, "Loading...", 13, PARCH);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(6), 0, 0);
        in.addView(status, new LinearLayout.LayoutParams(-1, -2));

        form = new LinearLayout(c);
        form.setOrientation(LinearLayout.VERTICAL);
        in.addView(form, new LinearLayout.LayoutParams(-1, -2));

        form.addView(label(c, "Login", 14, GOLD));
        user = field(c, "Username", false);
        form.addView(user, fieldLp());
        pass = field(c, "Password", true);
        form.addView(pass, fieldLp());

        remember = new CheckBox(c);
        remember.setText("Remember me");
        remember.setTextColor(PARCH);
        remember.setChecked(true);
        remember.setButtonTintList(android.content.res.ColorStateList.valueOf(GOLD));
        form.addView(remember);

        error = label(c, "", 13, Color.rgb(255, 90, 70));
        error.setGravity(Gravity.CENTER);
        form.addView(error);

        login = new Button(c);
        login.setText("Login");
        login.setAllCaps(false);
        login.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        login.setTextSize(17);
        login.setTextColor(GOLD);
        login.setBackground(btnBg());
        login.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) { submit(); }
        });
        form.addView(login, new LinearLayout.LayoutParams(-1, dp(46)));

        pass.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int a, android.view.KeyEvent e) {
                submit();
                return true;
            }
        });
        form.setVisibility(GONE);
        h.post(poll);
    }

    private int dp(int v) { return (int) (v * d + 0.5f); }

    private TextView label(Context c, String t, int sp, int color) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        return v;
    }

    private LinearLayout.LayoutParams fieldLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(44));
        lp.topMargin = dp(6);
        return lp;
    }

    private EditText field(Context c, String hint, boolean pw) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(130, 120, 95));
        e.setTextColor(Color.rgb(255, 240, 190));
        e.setSingleLine(true);
        e.setTextSize(16);
        e.setPadding(dp(10), 0, dp(10), 0);
        e.setInputType(pw ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD
                : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.setImeOptions(pw ? EditorInfo.IME_ACTION_GO : EditorInfo.IME_ACTION_NEXT);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.rgb(20, 16, 11));
        g.setStroke(dp(2), Color.rgb(105, 90, 62));
        g.setCornerRadius(dp(2));
        e.setBackground(g);
        return e;
    }

    private GradientDrawable panelBg() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(STONE);
        g.setStroke(dp(3), Color.rgb(20, 15, 9));
        g.setCornerRadius(dp(3));
        return g;
    }

    private android.graphics.drawable.Drawable btnBg() {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] {Color.rgb(95, 80, 56), Color.rgb(52, 42, 29)});
        g.setStroke(dp(2), Color.rgb(20, 15, 9));
        g.setCornerRadius(dp(3));
        return g;
    }

    private void submit() {
        if (attempting) return;
        String u = user.getText().toString().trim();
        String p = pass.getText().toString();
        if (u.isEmpty() || p.isEmpty()) {
            error.setText("Please enter your username and password.");
            return;
        }
        hideIme();
        error.setText("");
        attempting = true;
        sawBusy = false;
        attemptAt = System.currentTimeMillis();
        rt4.SavedAccount.request(u, p, remember.isChecked());
    }

    private void ime(boolean pan) {
        if (getContext() instanceof android.app.Activity) {
            ((android.app.Activity) getContext()).getWindow().setSoftInputMode(pan
                    ? android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
                    : android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        }
    }

    private void hideIme() {
        InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(getWindowToken(), 0);
    }

    private void prefill() {
        prefilled = true;
        try {
            if (accFile.exists()) {
                String[] p = new String(Files.readAllBytes(accFile.toPath()), StandardCharsets.ISO_8859_1).split("\n");
                if (p.length >= 2) {
                    user.setText(p[0]);
                    pass.setText(p[1]);
                    remember.setChecked(true);
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static String replyText(int r) {
        switch (r) {
            case 3: return "Invalid username or password.";
            case 4: return "Your account has been disabled.";
            case 5: return "Your account is already logged in. Try again in a minute.";
            case 6: case 14: return "The server is being updated. Try again in a minute.";
            case 7: return "This world is full.";
            case 9: case 16: return "Too many login attempts. Wait and try again.";
            case 12: return "This world needs a members account.";
            case 18: return "Your account is locked.";
            case 26: return "Your connection has been blocked.";
            case -4: case 8: case 10: case 11: case 20: case 23: case -5:
                return "Unable to connect to the server.";
            default: return "Login failed (code " + r + ").";
        }
    }

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            try {
                update();
            } catch (Throwable ignored) {
            }
            if (getVisibility() == VISIBLE || true) h.postDelayed(this, 120);
        }
    };

    private void update() {
        int gs = rt4.client.gameState;
        if (gs == 30) {
            wasInGame = true;
            attempting = false;
            if (getVisibility() != GONE) {
                hideIme();
                setVisibility(GONE);
                ime(false);
            }
            return;
        }
        if (getVisibility() != VISIBLE) {
            setVisibility(VISIBLE);
            ime(true);
        }
        if (gs < 10 || gs == 1000) {
            form.setVisibility(GONE);
            String t = rt4.client.mainLoadSecondaryText == null ? "Loading..." : rt4.client.mainLoadSecondaryText.toString();
            int pct = rt4.client.mainLoadPercentage;
            bar.set(pct, "Loading - please wait... " + pct + "%");
            status.setText(t);
            return;
        }
        if (gs == 10) {
            if (!prefilled) prefill();
            if (attempting) {
                int step = rt4.LoginManager.step;
                int hop = rt4.LoginManager.hopStep;
                if (step != 0 || hop != 0) sawBusy = true;
                if (sawBusy && step == 0 && hop == 0) {
                    attempting = false;
                    int r = rt4.LoginManager.reply;
                    if (r != 2) error.setText(replyText(r));
                } else if (!sawBusy && System.currentTimeMillis() - attemptAt > 6000) {
                    attempting = false;
                    error.setText("Unable to connect to the server.");
                }
            }
            if (attempting) {
                form.setVisibility(GONE);
                bar.set(-1, "Connecting to server...");
                status.setText("Logging in...");
            } else {
                form.setVisibility(VISIBLE);
                bar.set(100, "Welcome to 2009Scape");
                status.setText("");
                if (!autoDone && !wasInGame && accFile.exists() && user.length() > 0 && pass.length() > 0) {
                    autoDone = true;
                    submit();
                }
            }
            return;
        }
        // 20..29: logged in, loading the world
        form.setVisibility(GONE);
        bar.set(-1, "Loading world...");
        status.setText("Entering the world...");
    }

    /** RuneScape-style loading bar: red outline, dark red fill, white text. */
    private final class BarView extends View {
        private int pct = 0;
        private String text = "";
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final long t0 = System.currentTimeMillis();

        BarView(Context c) { super(c); }

        void set(int pct, String text) {
            if (pct != this.pct || !text.equals(this.text) || pct < 0) {
                this.pct = pct;
                this.text = text;
                invalidate();
            }
        }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), hh = getHeight(), b = dp(2);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(b);
            p.setColor(Color.rgb(140, 17, 17));
            c.drawRect(b / 2, b / 2, w - b / 2, hh - b / 2, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(140, 17, 17));
            float in = b * 2;
            if (pct >= 0) {
                c.drawRect(in, in, in + (w - 2 * in) * Math.min(100, pct) / 100f, hh - in, p);
            } else {
                float seg = (w - 2 * in) * 0.3f;
                float t = ((System.currentTimeMillis() - t0) % 1400) / 1400f;
                float x = in + (w - 2 * in - seg) * (t < 0.5f ? t * 2 : (1 - t) * 2);
                c.drawRect(x, in, x + seg, hh - in, p);
                postInvalidateDelayed(40);
            }
            p.setColor(Color.WHITE);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(dp(13));
            p.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
            p.setShadowLayer(2, 1, 1, Color.BLACK);
            c.drawText(text, w / 2, hh / 2 + dp(5), p);
            p.clearShadowLayer();
        }
    }

    /** Dark vignette background with a faint gold border pattern. */
    private final class BgDrawable extends android.graphics.drawable.Drawable {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        @Override public void draw(Canvas c) {
            Rect r = getBounds();
            p.setShader(new RadialGradient(r.exactCenterX(), r.exactCenterY(), Math.max(r.width(), r.height()) * 0.7f,
                    Color.rgb(48, 38, 26), Color.rgb(10, 7, 4), Shader.TileMode.CLAMP));
            c.drawRect(r, p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(3));
            p.setColor(Color.argb(150, 120, 90, 30));
            c.drawRect(dp(8), dp(8), r.width() - dp(8), r.height() - dp(8), p);
            p.setStrokeWidth(dp(1));
            p.setColor(Color.argb(110, 255, 176, 0));
            c.drawRect(dp(13), dp(13), r.width() - dp(13), r.height() - dp(13), p);
            p.setStyle(Paint.Style.FILL);
        }
        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.OPAQUE; }
    }
}
