package app.rsps2009;

import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import com.jogamp.opengl.EglBackend;
import shim.platform.Platforms;

/** EGL (ES2) context + window surface for gl4es, driven from the client thread. */
public class AndroidEglBackend implements EglBackend {
    private final GpuView view;
    private EGLDisplay dpy = EGL14.EGL_NO_DISPLAY;
    private EGLContext ctx = EGL14.EGL_NO_CONTEXT;
    private EGLSurface surf = EGL14.EGL_NO_SURFACE;
    private EGLConfig cfg;
    private android.view.Surface bound;
    private int rebinds;

    public AndroidEglBackend(GpuView v) { view = v; }

    private static void log(String s) { Platforms.error("EGL: " + s, null); }

    @Override public boolean create(int samples) {
        try {
            long end = System.currentTimeMillis() + 8000;
            while (view.surface == null || !view.surface.isValid()) {
                if (System.currentTimeMillis() > end) { log("no surface"); return false; }
                Thread.sleep(20);
            }
            dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
            int[] ver = new int[2];
            EGL14.eglInitialize(dpy, ver, 0, ver, 1);
            EGLConfig[] cfgs = new EGLConfig[1];
            int[] n = new int[1];
            int[] attr = {
                EGL14.EGL_RENDERABLE_TYPE, 4 /*ES2*/, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT,
                EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_DEPTH_SIZE, 24, EGL14.EGL_STENCIL_SIZE, 8,
                EGL14.EGL_SAMPLE_BUFFERS, samples > 1 ? 1 : 0, EGL14.EGL_SAMPLES, samples > 1 ? samples : 0,
                EGL14.EGL_NONE };
            if (!EGL14.eglChooseConfig(dpy, attr, 0, cfgs, 0, 1, n, 0) || n[0] < 1) {
                attr[attr.length - 6] = 0; attr[attr.length - 4] = 0; attr[attr.length - 3] = 0; // retry without MSAA
                attr[attr.length - 5] = EGL14.EGL_SAMPLE_BUFFERS; attr[attr.length - 4] = 0;
                int[] a2 = {
                    EGL14.EGL_RENDERABLE_TYPE, 4, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT,
                    EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
                    EGL14.EGL_DEPTH_SIZE, 16, EGL14.EGL_NONE };
                if (!EGL14.eglChooseConfig(dpy, a2, 0, cfgs, 0, 1, n, 0) || n[0] < 1) { log("no config"); return false; }
            }
            cfg = cfgs[0];
            ctx = EGL14.eglCreateContext(dpy, cfg, EGL14.EGL_NO_CONTEXT, new int[] { EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE }, 0);
            bound = view.surface;
            surf = EGL14.eglCreateWindowSurface(dpy, cfg, bound, new int[] { EGL14.EGL_NONE }, 0);
            if (ctx == EGL14.EGL_NO_CONTEXT || surf == EGL14.EGL_NO_SURFACE) { log("create failed " + EGL14.eglGetError()); return false; }
            log("created ok");
            return true;
        } catch (Throwable t) { Platforms.error("EGL create", t); return false; }
    }
    @Override public boolean makeCurrent() {
        boolean ok = EGL14.eglMakeCurrent(dpy, surf, surf, ctx);
        if (!ok) log("makeCurrent failed " + EGL14.eglGetError());
        return ok;
    }
    @Override public void release() { EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT); }
    private int frame, inGame;
    private String px(com.jogamp.opengl.GL2 gl, int w, int h) {
        java.nio.ByteBuffer bb = java.nio.ByteBuffer.allocateDirect(4).order(java.nio.ByteOrder.nativeOrder());
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= 3; i++) {
            bb.clear();
            gl.glReadPixels(w * i / 4, h / 2, 1, 1, 0x1908, 0x1401, bb);
            sb.append(String.format(" %02x%02x%02x%02x", bb.get(0) & 255, bb.get(1) & 255, bb.get(2) & 255, bb.get(3) & 255));
        }
        return sb.toString();
    }
    private void diag() {
        try {
            com.jogamp.opengl.GL2 gl = (com.jogamp.opengl.GL2) com.jogamp.opengl.GLContext.getCurrentGL();
            int[] wh = new int[2];
            EGL14.eglQuerySurface(dpy, surf, EGL14.EGL_WIDTH, wh, 0);
            EGL14.eglQuerySurface(dpy, surf, EGL14.EGL_HEIGHT, wh, 1);
            String before = px(gl, wh[0], wh[1]);
            gl.glDisable(0x0B90); gl.glDisable(0x0C11); gl.glDisable(0x0BE2); gl.glDisable(0x0B71);
            gl.glClearColor(1f, 0f, 1f, 1f);
            gl.glClear(0x4000);
            String after = px(gl, wh[0], wh[1]);
            log("GPU diag frame " + frame + " surface " + wh[0] + "x" + wh[1] + " game:" + before + " | after magenta clear (want ff00ffff):" + after
                + " | surfaceValid=" + view.surface.isValid() + " viewVis=" + view.getVisibility() + " viewSize=" + view.getWidth() + "x" + view.getHeight());
        } catch (Throwable t) { Platforms.error("diag failed", t); }
    }
    /** Re-attach to the view's current surface (it gets rebuilt when the size changes). */
    private boolean rebind() {
        try {
            EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
            if (surf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, surf);
            surf = EGL14.EGL_NO_SURFACE;
            long end = System.currentTimeMillis() + 3000;
            while (view.surface == null || !view.surface.isValid()) {
                if (System.currentTimeMillis() > end) return false;
                Thread.sleep(10);
            }
            bound = view.surface;
            surf = EGL14.eglCreateWindowSurface(dpy, cfg, bound, new int[] { EGL14.EGL_NONE }, 0);
            if (surf == EGL14.EGL_NO_SURFACE) { log("rebind create failed " + EGL14.eglGetError()); return false; }
            boolean ok = EGL14.eglMakeCurrent(dpy, surf, surf, ctx);
            if (rebinds++ < 6) log("rebound surface #" + rebinds + " ok=" + ok);
            return ok;
        } catch (Throwable t) { Platforms.error("rebind", t); return false; }
    }
    @Override public void swap() {
        frame++;
        if (frame == 120) diag();
        if (rt4.client.gameState == 30) inGame++;
        if (inGame == 250) com.jogamp.opengl.GlNative.dbg = true;
        if (inGame == 254) { com.jogamp.opengl.GlNative.dbg = false; log("GLCALLS in-game(4 frames) " + com.jogamp.opengl.GlNative.report()); }
        if (false) {
            try {
                com.jogamp.opengl.GL2 gl = (com.jogamp.opengl.GL2) com.jogamp.opengl.GLContext.getCurrentGL();
                gl.glClearColor(1f, 0f, 1f, 1f);
                gl.glClear(0x4000);
            } catch (Throwable t) { }
        }
        if (view.surface != bound && view.surface != null) rebind();
        boolean ok = EGL14.eglSwapBuffers(dpy, surf);
        if (!ok) {
            int err = EGL14.eglGetError();
            if (rebinds < 6) log("swap failed frame " + frame + " err " + err);
            if (rebind()) EGL14.eglSwapBuffers(dpy, surf);
        }
    }
    @Override public void destroy() {
        try {
            release();
            if (surf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, surf);
            if (ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ctx);
        } catch (Throwable ignored) { }
        surf = EGL14.EGL_NO_SURFACE; ctx = EGL14.EGL_NO_CONTEXT;
    }
}
