package rt4;

/**
 * Rainbow Scape Mastery (levels 100 to 1000 after 99), game-thread side. Hidden chat lines from the server:
 *   ~ms~A|m0:p0,m1:p1,...   every skill: m = Mastery level (0 = not 99, 99 = 99 with no Mastery yet), p = progress 0..999
 *   ~ms~L|slot|level         Mastery level-up (the app celebrates)
 *   ~ms~O|slot               open the Mastery window on that skill (-1 = overview)
 * The stats tab shows a gold Mastery level in place of the "99" base level once a skill passes 99.
 * We say hello (::mscheck) a few seconds after login so the server knows this app understands the lines.
 */
public final class Mastery {
    private Mastery() {}
    public static final String TAG = "~ms~";

    public static final int[] level = new int[24];
    public static final int[] progress = new int[24];
    public static volatile boolean known;
    public static volatile int version, openVersion, openSkill = -1, upVersion, upSkill, upLevel;

    private static final java.util.concurrent.ConcurrentLinkedQueue<String> out = new java.util.concurrent.ConcurrentLinkedQueue<>();
    private static long loginAt, lastHello;
    private static int lastState;

    /** app (UI thread): queue a command, e.g. "msguide 14" */
    public static void want(String cmd) { out.add(cmd); }

    public static boolean handle(JagString msg) {
        if (msg == null) return false;
        String s = msg.toString();
        if (!s.startsWith(TAG)) return false;
        try {
            char t = s.charAt(TAG.length());
            String rest = s.length() > TAG.length() + 2 ? s.substring(TAG.length() + 2) : "";
            if (t == 'A') {
                String[] e = rest.split(",");
                for (int i = 0; i < e.length && i < 24; i++) {
                    int c = e[i].indexOf(':');
                    level[i] = Integer.parseInt(e[i].substring(0, c).trim());
                    progress[i] = Integer.parseInt(e[i].substring(c + 1).trim());
                }
                known = true; version++;
                InterfaceList.redrawActiveInterfaces();
            } else if (t == 'L') {
                String[] p = rest.split("\\|");
                upSkill = Integer.parseInt(p[0].trim()); upLevel = Integer.parseInt(p[1].trim());
                if (upSkill >= 0 && upSkill < 24) level[upSkill] = upLevel;
                upVersion++;
            } else if (t == 'O') {
                openSkill = Integer.parseInt(rest.trim());
                openVersion++;
            }
        } catch (Throwable ignored) { }
        return true;
    }

    // ------------------------------------------------------------------ the stats tab
    private static final JagString[] gold = new JagString[1001];

    /** stats tab (320): the base-level number of a skill past 99 becomes its gold Mastery level */
    public static JagString tabText(Component c, JagString text) {
        try {
            if (!known || (c.id >>> 16) != 320) return text;
            int[][] sc = c.cs1Scripts;
            if (sc == null || sc.length == 0 || sc[0] == null || sc[0].length < 2 || sc[0][0] != 2) return text;
            int skill = sc[0][1];
            if (skill < 0 || skill >= 24) return text;
            int m = level[skill];
            if (m < 100 || m > 1000) return text;
            JagString g = gold[m];
            if (g == null) { g = JagString.parse("<col=ffb000>" + m); gold[m] = g; }
            return g;
        } catch (Throwable t) { return text; }
    }

    // ------------------------------------------------------------------ game thread, every frame
    public static void tick() {
        try {
            int st = client.gameState;
            long now = System.currentTimeMillis();
            if (st == 30 && lastState != 30) { loginAt = now; lastHello = 0; known = false; }
            lastState = st;
            if (st != 30) { out.clear(); return; }
            if ((lastHello == 0 && now - loginAt > 9000) || (lastHello > 0 && now - lastHello > 300_000)) {
                if (!MobileLayout.studioOpen && !Tour.playing) { lastHello = now; send("mscheck"); }
            }
            String cmd; int n = 0;
            while (n++ < 3 && (cmd = out.poll()) != null) send(cmd);
        } catch (Throwable ignored) { }
    }

    private static void send(String cmd) {
        JagString line = JagString.parse("::" + cmd);
        Protocol.outboundBuffer.p1isaac(ClientProt.CLIENT_CHEAT);
        Protocol.outboundBuffer.p1(line.length() - 1);
        Protocol.outboundBuffer.pjstr(line.substring(2));
    }
}
