package rt4;

/**
 * Rainbow Scape daily rewards icon, game-thread side. The server answers ::dailycheck with a hidden chat line:
 *   ~dr~R|claimable|streak|nextDay|today|minutesToReset
 *   ~dr~O                  bring the icon back (::dailyicon)
 * The app draws the animated icon; tapping it sends ::daily (the server's Daily Rewards window).
 */
public final class Rewards {
    private Rewards() {}
    public static final String TAG = "~dr~";

    public static final String[] gifts = {"", "", "", "", "", "", ""};
    public static volatile boolean known, claimable;
    public static volatile int streak, nextDay, potState;
    public static volatile long today, resetAt;
    public static volatile int version, openVersion;
    public static volatile String message = "";
    public static volatile long messageAt;

    private static final java.util.concurrent.ConcurrentLinkedQueue<String> out = new java.util.concurrent.ConcurrentLinkedQueue<>();
    private static long loginAt, lastAsk;
    private static int lastState;

    /** app (UI thread): queue a command, e.g. "dailyclaim" */
    public static void want(String cmd) { out.add(cmd); }

    public static int badge() { return known && claimable ? 1 : 0; }
    private static volatile long recheckAt;
    /** ask again shortly (after the window was opened, or a reward was claimed) */
    public static void recheckSoon(long ms) { recheckAt = System.currentTimeMillis() + ms; }

    public static boolean handle(JagString msg) {
        if (msg == null) return false;
        String s = msg.toString();
        if (!s.startsWith(TAG)) {
            if (s.contains("Daily reward claimed")) recheckSoon(800);
            return false;
        }
        try {
            char t = s.charAt(TAG.length());
            String rest = s.length() > TAG.length() + 2 ? s.substring(TAG.length() + 2) : "";
            if (t == 'D') {
                int bar = rest.indexOf('|');
                int d = Integer.parseInt(rest.substring(0, bar).trim());
                if (d >= 1 && d <= 7) gifts[d - 1] = rest.substring(bar + 1);
            } else if (t == 'R') {
                String[] p = rest.split("\\|");
                claimable = p[0].trim().equals("1");
                streak = Integer.parseInt(p[1].trim());
                nextDay = Integer.parseInt(p[2].trim());
                today = Long.parseLong(p[3].trim());
                resetAt = System.currentTimeMillis() + Long.parseLong(p[4].trim()) * 60_000L;
                potState = p.length > 5 ? Integer.parseInt(p[5].trim()) : 0;
                known = true;
                version++;
            } else if (t == 'O') {
                openVersion++;
            } else if (t == 'M') {
                message = rest; messageAt = System.currentTimeMillis(); version++;
            }
        } catch (Throwable ignored) { }
        return true;
    }

    public static void tick() {
        try {
            int state = client.gameState;
            long now = System.currentTimeMillis();
            if (state == 30 && lastState != 30) { loginAt = now; lastAsk = 0; known = false; }
            lastState = state;
            if (state != 30) { out.clear(); return; }
            // ask a few seconds after login, every 2 minutes, and right after midnight
            boolean due = (lastAsk == 0 && now - loginAt > 7000) || (lastAsk > 0 && now - lastAsk > 120_000)
                    || (known && resetAt > 0 && now > resetAt && now - lastAsk > 15_000)
                    || (recheckAt > 0 && now > recheckAt);
            if (due) recheckAt = 0;
            if (due && !MobileLayout.studioOpen && !Tour.playing) { lastAsk = now; send("dailycheck"); }
            String c;
            int n = 0;
            while (n++ < 3 && (c = out.poll()) != null) { send(c); if (c.equals("dailycheck")) lastAsk = now; }
        } catch (Throwable ignored) { }
    }

    private static void send(String cmd) {
        JagString line = JagString.parse("::" + cmd);
        Protocol.outboundBuffer.p1isaac(ClientProt.CLIENT_CHEAT);
        Protocol.outboundBuffer.p1(line.length() - 1);
        Protocol.outboundBuffer.pjstr(line.substring(2));
    }
}
