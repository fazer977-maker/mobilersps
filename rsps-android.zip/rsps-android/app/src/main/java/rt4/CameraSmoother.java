package rt4;

/**
 * Eases touch camera movement: drags are applied gradually over a few frames (so bursts of touch
 * events don't look steppy) and a flick keeps the camera gliding for a moment.
 */
public final class CameraSmoother {
    private static final Object LOCK = new Object();
    private static double pendingYaw, pendingPitch;   // not yet applied
    private static double velYaw, velPitch;            // units per millisecond, after release
    private static long lastTick;

    private CameraSmoother() {}

    public static void add(double yaw, double pitch) {
        synchronized (LOCK) {
            pendingYaw += yaw;
            pendingPitch += pitch;
            velYaw = 0;
            velPitch = 0;
        }
    }

    public static void fling(double yawPerMs, double pitchPerMs) {
        synchronized (LOCK) {
            velYaw = yawPerMs;
            velPitch = pitchPerMs;
        }
    }

    public static void stop() {
        synchronized (LOCK) {
            pendingYaw = pendingPitch = velYaw = velPitch = 0;
        }
    }

    /** Called once per rendered frame. */
    public static void tick() {
        long now = System.nanoTime();
        double dt = lastTick == 0 ? 16 : Math.min(50, (now - lastTick) / 1e6);
        lastTick = now;
        double dy, dp;
        synchronized (LOCK) {
            // ease pending drag: about 60 ms time constant
            double k = 1 - Math.exp(-dt / 60.0);
            double sy = pendingYaw * k, sp = pendingPitch * k;
            pendingYaw -= sy;
            pendingPitch -= sp;
            if (Math.abs(pendingYaw) < 0.05) { sy += pendingYaw; pendingYaw = 0; }
            if (Math.abs(pendingPitch) < 0.05) { sp += pendingPitch; pendingPitch = 0; }
            // glide after a flick, slowing down
            double decay = Math.exp(-dt / 220.0);
            sy += velYaw * dt;
            sp += velPitch * dt;
            velYaw *= decay;
            velPitch *= decay;
            if (Math.abs(velYaw) < 0.002) velYaw = 0;
            if (Math.abs(velPitch) < 0.002) velPitch = 0;
            dy = sy;
            dp = sp;
        }
        if (dy != 0 || dp != 0) {
            Camera.yawTarget += dy;
            Camera.pitchTarget += dp;
            Camera.clampCameraAngle();
        }
    }
}
