package rt4;

/**
 * Rainbow Casino animations, driven by hidden chat lines from the server (the server has already decided the result;
 * these only show it nicely). They run inside full-screen windows (see MobileLayout.studioFullscreen).
 *
 *   ~ca~R|iface|layer|symbols|cellH|target|ms          slot reel: scroll a strip of symbols, land on target
 *   ~ca~B|iface|ball|cx|cy|rOut|rIn|targetDeg|ms        roulette ball: spin round the wheel, drop into the pocket
 *   ~ca~C|iface|card|back|faceA|faceB|fromX|fromY|delay|flip   deal a card from the shoe, then turn it over
 *   ~ca~D|iface|ms|f1,f2,f3,f4,f5,f6                    dice tumble through faces, then show the real one
 *   ~ca~X|iface                                          stop everything in this window
 * Celebrations:
 *   ~ce~W|tier|text      big win banner + confetti for me (tier 1 win, 2 big, 3 mega, 4 jackpot)
 *   ~ce~P|name|tier|secs a light beam over a player who just won big
 */
public final class CasinoFx {
    private CasinoFx() {}

    static final class Anim {
        char kind; int iface; long start; int ms;
        int comp, symbols, cellH, target; float fromPos;            // reel
        int cx, cy, rOut, rIn; float targetDeg;                      // ball
        int back, faceA, faceB, fromX, fromY, delay, flip;           // card
        int[] faces; boolean[] saved; boolean captured; int last = -1;   // card / dice
        boolean done;
    }

    private static final java.util.ArrayList<Anim> anims = new java.util.ArrayList<Anim>();
    /** where each reel stopped last (layer id -> position in cells), so the next spin starts there */
    private static final java.util.HashMap<Long, Float> reelPos = new java.util.HashMap<Long, Float>();

    // celebration state, read by the app's CelebrateView
    public static volatile int winVersion, winTier;
    public static volatile String winText = "";

    public static boolean handle(JagString msg) {
        if (msg == null) return false;
        String s = msg.toString();
        boolean ca = s.startsWith("~ca~"), ce = s.startsWith("~ce~");
        if (!ca && !ce) return false;
        try {
            String[] p = s.substring(4).split("\\|");
            long now = System.currentTimeMillis();
            if (ce) {
                if (p[0].equals("W")) { winTier = Integer.parseInt(p[1].trim()); winText = p.length > 2 ? p[2] : ""; winVersion++; }
                else if (p[0].equals("P")) LootBeams.playerBeam(p[1], Integer.parseInt(p[2].trim()), Integer.parseInt(p[3].trim()));
                return true;
            }
            Anim a = new Anim();
            a.kind = p[0].charAt(0); a.iface = Integer.parseInt(p[1].trim()); a.start = now;
            switch (a.kind) {
                case 'R':
                    a.comp = i(p[2]); a.symbols = i(p[3]); a.cellH = i(p[4]); a.target = i(p[5]); a.ms = i(p[6]);
                    Float f = reelPos.get(key(a.iface, a.comp));
                    a.fromPos = f == null ? 0f : f;
                    break;
                case 'B':
                    a.comp = i(p[2]); a.cx = i(p[3]); a.cy = i(p[4]); a.rOut = i(p[5]); a.rIn = i(p[6]); a.targetDeg = Float.parseFloat(p[7].trim()); a.ms = i(p[8]);
                    break;
                case 'C':
                    a.comp = i(p[2]); a.back = i(p[3]); a.faceA = i(p[4]); a.faceB = i(p[5]); a.fromX = i(p[6]); a.fromY = i(p[7]); a.delay = i(p[8]); a.flip = i(p[9]);
                    a.ms = Math.max(a.flip, a.delay + 300) + 50;
                    break;
                case 'D': {
                    a.ms = i(p[2]); String[] f6 = p[3].split(",");
                    a.faces = new int[f6.length]; for (int k = 0; k < f6.length; k++) a.faces[k] = i(f6[k]);
                    break;
                }
                case 'X':
                    synchronized (anims) { for (Anim o : anims) if (o.iface == a.iface) o.done = true; }
                    return true;
                default: return true;
            }
            synchronized (anims) {
                // a new reel/ball animation replaces the old one on the same part
                if (a.kind == 'R' || a.kind == 'B') for (Anim o : anims) if (o.iface == a.iface && o.comp == a.comp && o.kind == a.kind) o.done = true;
                anims.add(a);
            }
        } catch (Throwable ignored) { }
        return true;
    }

    private static int i(String s) { return Integer.parseInt(s.trim()); }
    private static long key(int iface, int comp) { return ((long) iface << 20) | comp; }
    private static float easeOutBack(float u) { float c1 = 1.1f, c3 = c1 + 1; float v = u - 1; return 1 + c3 * v * v * v + c1 * v * v; }
    private static float easeOutCubic(float u) { float v = 1 - u; return 1 - v * v * v; }

    /** called every frame by the full-screen layout, after it has placed every part of the window */
    static void frame(Component[] cs, float sx, float sy) {
        if (anims.isEmpty()) return;
        long now = System.currentTimeMillis();
        synchronized (anims) {
            java.util.Iterator<Anim> it = anims.iterator();
            while (it.hasNext()) {
                Anim a = it.next();
                Component[][] all = InterfaceList.components;
                if (all == null || a.iface < 0 || a.iface >= all.length || all[a.iface] == null) { it.remove(); continue; }
                if (all[a.iface] != cs) {
                    // window not on screen: finish card/dice overrides so nothing stays hidden, drop the rest
                    if (a.kind == 'C' || a.kind == 'D') release(all[a.iface], a);
                    if (a.kind != 'R' && a.kind != 'B') it.remove();
                    continue;
                }
                float u = Math.min(1f, (now - a.start) / (float) Math.max(1, a.ms));
                try {
                    switch (a.kind) {
                        case 'R': reel(cs, a, u, sy); break;
                        case 'B': ball(cs, a, u, sx, sy); break;
                        case 'C': card(cs, a, now - a.start, sx, sy); break;
                        case 'D': dice(cs, a, now - a.start); break;
                    }
                } catch (Throwable t) { a.done = true; }
                if (a.done || (u >= 1f && (a.kind == 'C' || a.kind == 'D'))) {
                    if (a.kind == 'C' || a.kind == 'D') release(cs, a);
                    if (a.kind == 'R') reelPos.put(key(a.iface, a.comp), (float) a.target);
                    if (a.done || a.kind == 'C' || a.kind == 'D') it.remove();
                }
            }
        }
    }

    private static Component at(Component[] cs, int i) { return i >= 0 && i < cs.length ? cs[i] : null; }

    private static void reel(Component[] cs, Anim a, float u, float sy) {
        Component k = at(cs, a.comp);
        if (k == null) return;
        int n = Math.max(1, a.symbols), ch = Math.max(1, a.cellH);
        // travel forward through the strip: at least 3 full turns, then ease onto the target with a little bounce
        float from = a.fromPos, to = a.target;
        float dist = ((to - from) % n + n) % n + 3 * n;
        float pos = from + dist * (u >= 1f ? 1f : easeOutBack(u));
        float wrapped = ((pos % n) + n) % n;
        int lh = k.baseHeight;
        float scrollBase = n * ch + wrapped * ch - (lh - ch) / 2f;     // middle copy of the strip, symbol centred
        k.scrollY = Math.round(scrollBase * sy);
        InterfaceList.redraw(k);
    }

    private static void ball(Component[] cs, Anim a, float u, float sx, float sy) {
        Component k = at(cs, a.comp);
        if (k == null) return;
        float spin = (1 - easeOutCubic(u)) * 360f * 5f;             // goes round 5 times, slowing down
        float ang = (float) Math.toRadians(a.targetDeg - spin);
        float r;
        if (u < 0.6f) r = a.rOut;
        else if (u < 0.85f) { float v = (u - 0.6f) / 0.25f; r = a.rOut + (a.rIn - a.rOut) * v + (float) Math.abs(Math.sin(v * Math.PI * 3)) * 6 * (1 - v); }
        else r = a.rIn;
        float bx = a.cx + r * (float) Math.sin(ang), by = a.cy - r * (float) Math.cos(ang);
        k.x = Math.round(bx * sx) - k.width / 2;
        k.y = Math.round(by * sy) - k.height / 2;
        InterfaceList.redraw(k);
    }

    private static void capture(Component[] cs, Anim a, int[] ids) {
        if (a.captured) return;
        a.saved = new boolean[ids.length];
        for (int j = 0; j < ids.length; j++) { Component c = at(cs, ids[j]); a.saved[j] = c != null && c.hidden; }
        a.captured = true;
    }

    private static int[] cardIds(Anim a) { return new int[] {a.comp, a.back, a.faceA, a.faceB}; }

    private static void card(Component[] cs, Anim a, long t, float sx, float sy) {
        int[] ids = cardIds(a);
        capture(cs, a, ids);
        Component c = at(cs, a.comp), back = at(cs, a.back), fa = at(cs, a.faceA), fb = at(cs, a.faceB);
        if (c == null) return;
        if (t < a.delay) { c.hidden = true; InterfaceList.redraw(c); return; }
        c.hidden = a.saved[0];
        if (a.fromX > -9000) {
            float v = Math.min(1f, (t - a.delay) / 300f), e = easeOutCubic(v);
            float bx = a.fromX + (c.baseX - a.fromX) * e, by = a.fromY + (c.baseY - a.fromY) * e;
            c.x = Math.round(bx * sx); c.y = Math.round(by * sy);
        }
        boolean showBack = t < a.flip;
        // turning over: squeeze the card thin just before and just after the flip
        long d = Math.abs(t - a.flip);
        if (d < 90) {
            int w = c.width, nw = Math.max(1, (int) (w * d / 90f));
            c.x += (w - nw) / 2; c.width = nw;
        }
        if (back != null) back.hidden = !showBack ? a.saved[1] : false;
        if (fa != null) fa.hidden = showBack ? true : a.saved[2];
        if (fb != null) fb.hidden = showBack ? true : a.saved[3];
        InterfaceList.redraw(c);
    }

    private static void dice(Component[] cs, Anim a, long t) {
        capture(cs, a, a.faces);
        int step = (int) (t / 85);
        if (step == a.last) return;
        a.last = step;
        int show = (int) ((step * 7L + a.faces.length * 3L + (a.start & 7)) % a.faces.length);
        for (int j = 0; j < a.faces.length; j++) {
            Component c = at(cs, a.faces[j]);
            if (c != null) { c.hidden = j != show; InterfaceList.redraw(c); }
        }
    }

    private static void release(Component[] cs, Anim a) {
        if (!a.captured || cs == null) return;
        int[] ids = a.kind == 'C' ? cardIds(a) : a.faces;
        for (int j = 0; j < ids.length; j++) {
            Component c = at(cs, ids[j]);
            if (c != null) { c.hidden = a.saved[j]; InterfaceList.redraw(c); }
        }
        a.captured = false;
    }
}
