package rt4;

/**
 * Writes the live progressive jackpot on the casino's jackpot board, in big glowing digits, from a hidden chat line:
 *   ~jp~|worldX|worldY|plane|value[|height]     (worldX/Y = south-west tile of the 3x3 board; height of the screen centre, default 245)
 * Drawn as a 2D overlay after the 3D scene (same place as the loot beams).
 */
public final class JackpotSign {
    private JackpotSign() {}
    private static volatile int wx = -1, wy, plane, ht = 245;
    private static volatile long value, updated;
    private static final String[] DIG = {
        "111101101101111", "010110010010111", "111001111100111", "111001111001111", "101101111001001",
        "111100111001111", "111100111101111", "111001010010010", "111101111101111", "111101111001111"};
    private static final int[] RB = {0xff3b3b, 0xff9a1e, 0xffe62e, 0x4cff6a, 0x2ee6ff, 0x4c7dff, 0xc04cff};

    public static boolean handle(JagString msg) {
        if (msg == null) return false;
        String s = msg.toString();
        if (!s.startsWith("~jp~")) return false;
        try {
            String[] p = s.substring(5).split("\\|");
            wx = Integer.parseInt(p[0].trim()); wy = Integer.parseInt(p[1].trim()); plane = Integer.parseInt(p[2].trim());
            value = Long.parseLong(p[3].trim()); updated = System.currentTimeMillis();
            ht = p.length > 4 ? Math.max(20, Math.min(900, Integer.parseInt(p[4].trim()))) : 245;
        } catch (Throwable ignored) { }
        return true;
    }

    private static void rect(int x, int y, int w, int h, int col, int alpha) {
        if (w <= 0 || h <= 0 || alpha <= 0) return;
        if (GlRenderer.enabled) GlRaster.fillRectAlpha(x, y, w, h, col, Math.min(255, alpha));
        else SoftwareRaster.fillRectAlpha(x, y, w, h, col, Math.min(255, alpha));
    }

    static void draw(int top, int width, int left, int zoomH, int height, int zoomV) {
        if (wx < 0 || Player.plane != plane || System.currentTimeMillis() - updated > 120_000) return;
        try {
            int lx = wx - Camera.originX, ly = wy - Camera.originY;
            if (lx < 1 || ly < 1 || lx > 100 || ly > 100) return;
            int xf = lx * 128 + 192, yf = ly * 128 + 192;
            ScriptRunner.projectToScreen(width >> 1, zoomH, yf, ht, height >> 1, xf, zoomV);
            int cx = ScriptRunner.screenX, cy = ScriptRunner.screenY;
            if (cx < 0) return;
            ScriptRunner.projectToScreen(width >> 1, zoomH, yf, ht + 100, height >> 1, xf, zoomV);
            if (ScriptRunner.screenX < 0) return;
            float ppu = Math.max(0.05f, (cy - ScriptRunner.screenY) / 100f);   // pixels per world unit here
            String txt = String.format("%,d", value);
            int px = Math.max(1, Math.round(9 * ppu));                           // size of one digit pixel
            int cw = px * 4, n = txt.length();
            int total = n * cw;
            int x0 = left + cx - total / 2, y0 = top + cy - px * 5 / 2;
            long now = System.currentTimeMillis();
            // dark plate behind the number so it always reads
            rect(x0 - px * 2, y0 - px * 2, total + px * 3, px * 9, 0x000000, 150);
            for (int i = 0; i < n; i++) {
                char ch = txt.charAt(i);
                int col = RB[(int) ((i + now / 180) % RB.length)];
                int bx = x0 + i * cw;
                if (ch == ',') { rect(bx + px, y0 + px * 4, px, px * 2, col, 255); continue; }
                if (ch < '0' || ch > '9') continue;
                String g = DIG[ch - '0'];
                for (int r = 0; r < 5; r++) for (int c = 0; c < 3; c++)
                    if (g.charAt(r * 3 + c) == '1') {
                        rect(bx + c * px - 1, y0 + r * px - 1, px + 2, px + 2, col, 70);     // glow
                        rect(bx + c * px, y0 + r * px, px, px, col, 255);
                    }
            }
        } catch (Throwable ignored) { }
    }
}
