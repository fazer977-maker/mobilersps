package app.rsps2009;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import rt4.Rewards;

/**
 * Daily rewards: an animated gift icon, shown only while today's daily reward is unclaimed. Tap it to open the
 * server's Daily Rewards window (::daily). Drag it anywhere; drag it onto the "hide" circle to hide it until
 * tomorrow's reward. ::dailyicon brings it back.
 */
final class RewardsView extends View {
    private static final int[] RAINBOW = {0xFFFF3B3B, 0xFFFF9A1E, 0xFFFFE62E, 0xFF4CFF6A, 0xFF2EE6FF, 0xFF4C7DFF, 0xFFC04CFF, 0xFFFF3B3B};
    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Typeface bold = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD);
    private Typeface pixel;
    private final SharedPreferences prefs;

    private boolean allowed;
    private float fx, fy;              // icon centre as a fraction of the view
    private long hiddenDay;
    private int seenOpen;

    // touch
    private boolean down, dragging, onHide;
    private float downX, downY, grabDX, grabDY;
    private long tappedAt;

    RewardsView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        prefs = c.getSharedPreferences("rewards", Context.MODE_PRIVATE);
        fx = prefs.getFloat("fx", 0.06f);
        fy = prefs.getFloat("fy", 0.30f);
        hiddenDay = prefs.getLong("hiddenDay", -1);
        try { pixel = Typeface.createFromAsset(c.getAssets(), "silkscreen.ttf"); } catch (Throwable t) { pixel = bold; }
        setVisibility(GONE);
    }

    private boolean iconShown() {
        return allowed && Rewards.known && Rewards.badge() > 0 && hiddenDay != Rewards.today;
    }

    /** UI poller */
    void sync(boolean ok) {
        allowed = ok;
        if (Rewards.openVersion != seenOpen) {
            seenOpen = Rewards.openVersion;
            if (hiddenDay != -1) { hiddenDay = -1; prefs.edit().putLong("hiddenDay", -1).apply(); }
        }
        int vis = (iconShown() || dragging) ? VISIBLE : GONE;
        if (getVisibility() != vis) setVisibility(vis);
        if (vis == VISIBLE) invalidate();
    }

    private float iconSize() { return 58 * d; }
    private float ix() { return fx * getWidth(); }
    private float iy() { return fy * getHeight(); }
    private float hx() { return getWidth() / 2f; }
    private float hy() { return getHeight() - 70 * d; }

    // ------------------------------------------------------------------ drawing
    @Override protected void onDraw(Canvas c) {
        long now = System.currentTimeMillis();
        if (dragging) drawHideTarget(c, now);
        if (iconShown() || dragging) {
            float press = now - tappedAt < 220 ? 0.86f : 1f;   // squish when tapped
            drawIcon(c, ix(), iy(), iconSize() * press, now);
        }
        postInvalidateDelayed(33);
    }

    private void drawHideTarget(Canvas c, long now) {
        float r = (onHide ? 40 : 34) * d;
        p.setShader(null); p.setStyle(Paint.Style.FILL);
        p.setColor(onHide ? 0xCCB02020 : 0x99000000);
        c.drawCircle(hx(), hy(), r, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2 * d); p.setColor(0xFFFFFFFF);
        c.drawCircle(hx(), hy(), r, p);
        float k = 10 * d;
        c.drawLine(hx() - k, hy() - k - 6 * d, hx() + k, hy() + k - 6 * d, p);
        c.drawLine(hx() + k, hy() - k - 6 * d, hx() - k, hy() + k - 6 * d, p);
        p.setStyle(Paint.Style.FILL); p.setTypeface(bold); p.setTextSize(10 * d); p.setTextAlign(Paint.Align.CENTER);
        c.drawText("HIDE", hx(), hy() + 20 * d, p);
        p.setTextAlign(Paint.Align.LEFT);
    }

    private void drawIcon(Canvas c, float cx, float cy, float s, long now) {
        float t = (now % 100000L) / 1000f;
        float bob = (float) Math.sin(t * 3.2) * s * 0.04f;
        // rotating rainbow glow ring
        c.save();
        c.rotate((t * 60f) % 360f, cx, cy);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(s * 0.07f);
        p.setShader(new SweepGradient(cx, cy, RAINBOW, null));
        c.drawCircle(cx, cy, s * 0.48f, p);
        c.restore();
        p.setShader(new RadialGradient(cx, cy, s * 0.46f, new int[] {0xEE3A2A6A, 0xEE1A1430}, null, Shader.TileMode.CLAMP));
        p.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy, s * 0.445f, p);
        // soft pulsing light behind the gift
        float pulse = 0.5f + 0.5f * (float) Math.sin(t * 4);
        p.setShader(new RadialGradient(cx, cy + bob, s * 0.42f, new int[] {(int) (90 + 80 * pulse) << 24 | 0xFFE680, 0x00FFE680}, null, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy + bob, s * 0.42f, p);
        p.setShader(null);
        // the gift: box, ribbon, lid that hops now and then
        float bw = s * 0.46f, bh = s * 0.30f, bx = cx - bw / 2, by = cy - bh * 0.15f + bob;
        float phase = (t % 2.6f);
        float lidUp = phase < 0.35f ? (float) Math.sin(phase / 0.35f * Math.PI) * s * 0.10f : 0f;
        float wig = phase < 0.35f ? (float) Math.sin(phase * 40) * 6f : 0f;
        p.setShader(new LinearGradient(0, by, 0, by + bh, 0xFFFF4FA0, 0xFFC0206A, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(bx, by, bx + bw, by + bh), s * 0.03f, s * 0.03f, p);
        p.setShader(null); p.setColor(0xFFFFD84A);
        c.drawRect(cx - s * 0.04f, by, cx + s * 0.04f, by + bh, p);
        c.save();
        c.rotate(wig, cx, by - lidUp);
        float lw = bw * 1.12f, lh = s * 0.09f, ly = by - lh - lidUp;
        p.setShader(new LinearGradient(0, ly, 0, ly + lh, 0xFFFF7AC0, 0xFFE0307E, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(cx - lw / 2, ly, cx + lw / 2, ly + lh), s * 0.025f, s * 0.025f, p);
        p.setShader(null); p.setColor(0xFFFFD84A);
        c.drawRect(cx - s * 0.04f, ly, cx + s * 0.04f, ly + lh, p);
        // bow
        Path bow = new Path();
        float bt = ly;
        bow.moveTo(cx, bt); bow.cubicTo(cx - s * 0.16f, bt - s * 0.16f, cx - s * 0.20f, bt + s * 0.02f, cx, bt);
        bow.moveTo(cx, bt); bow.cubicTo(cx + s * 0.16f, bt - s * 0.16f, cx + s * 0.20f, bt + s * 0.02f, cx, bt);
        p.setColor(0xFFFFE066); c.drawPath(bow, p);
        p.setColor(0xFFFFB000); c.drawCircle(cx, bt, s * 0.035f, p);
        c.restore();
        // sparkles orbiting
        for (int i = 0; i < 4; i++) {
            double a = t * 1.6 + i * Math.PI / 2;
            float sx = cx + (float) Math.cos(a) * s * 0.33f, sy = cy + (float) Math.sin(a) * s * 0.30f + bob;
            float tw = 0.5f + 0.5f * (float) Math.sin(t * 7 + i * 1.7);
            drawSpark(c, sx, sy, s * 0.05f * (0.4f + tw), RAINBOW[(i * 2 + (int) (t * 2)) % 7]);
        }
        // badge
        int b = Rewards.badge();
        if (b > 0) {
            float br = s * 0.15f, bxx = cx + s * 0.34f, byy = cy - s * 0.34f;
            p.setColor(0xFFE02424); c.drawCircle(bxx, byy, br, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f * d); p.setColor(0xFFFFFFFF); c.drawCircle(bxx, byy, br, p);
            p.setStyle(Paint.Style.FILL); p.setTypeface(bold); p.setTextSize(br * 1.3f); p.setTextAlign(Paint.Align.CENTER);
            c.drawText(String.valueOf(b), bxx, byy + br * 0.45f, p);
            p.setTextAlign(Paint.Align.LEFT);
        }
    }

    private void drawSpark(Canvas c, float x, float y, float r, int col) {
        Path s = new Path();
        s.moveTo(x, y - r * 2); s.lineTo(x + r * 0.5f, y - r * 0.5f); s.lineTo(x + r * 2, y); s.lineTo(x + r * 0.5f, y + r * 0.5f);
        s.lineTo(x, y + r * 2); s.lineTo(x - r * 0.5f, y + r * 0.5f); s.lineTo(x - r * 2, y); s.lineTo(x - r * 0.5f, y - r * 0.5f); s.close();
        p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(col);
        c.drawPath(s, p);
        p.setColor(0xFFFFFFFF); c.drawCircle(x, y, r * 0.4f, p);
    }

    // ------------------------------------------------------------------ touch
    @Override public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        int a = e.getActionMasked();
        if (!iconShown() && !dragging) return false;
        float s = iconSize();
        switch (a) {
            case MotionEvent.ACTION_DOWN:
                if (Math.hypot(x - ix(), y - iy()) > s * 0.6f) return false;   // not on the icon: the game gets it
                down = true; dragging = false; downX = x; downY = y; grabDX = x - ix(); grabDY = y - iy();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (!down) return false;
                if (!dragging && Math.hypot(x - downX, y - downY) > 10 * d) dragging = true;
                if (dragging) {
                    float w = Math.max(1, getWidth()), h = Math.max(1, getHeight());
                    fx = Math.max(s / 2 / w, Math.min(1 - s / 2 / w, (x - grabDX) / w));
                    fy = Math.max(s / 2 / h, Math.min(1 - s / 2 / h, (y - grabDY) / h));
                    onHide = Math.hypot(ix() - hx(), iy() - hy()) < 48 * d;
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (!down) return false;
                down = false;
                if (dragging) {
                    dragging = false;
                    if (onHide) {
                        onHide = false;
                        hiddenDay = Rewards.today;
                        fx = prefs.getFloat("fx", 0.06f); fy = prefs.getFloat("fy", 0.30f);   // snap back for next time
                        prefs.edit().putLong("hiddenDay", hiddenDay).apply();
                    } else prefs.edit().putFloat("fx", fx).putFloat("fy", fy).apply();
                } else if (a == MotionEvent.ACTION_UP) {
                    tappedAt = System.currentTimeMillis();
                    Rewards.want("daily");            // the server's Daily Rewards window
                    Rewards.recheckSoon(30_000);
                }
                invalidate();
                return true;
        }
        return down;
    }
}
