package com.jogamp.opengl;

import com.jogamp.nativewindow.awt.JAWTWindow;

public class GLContext {
    private static volatile GLContext current;
    private static volatile GL2 currentGl;
    private final EglBackend backend;
    GLContext(EglBackend b) { backend = b; }
    public static GLContext getCurrent() { return current; }
    public static GL getCurrentGL() { return currentGl; }
    /** 0 = failed, 1 = ok. */
    public int makeCurrent() {
        if (!backend.makeCurrent()) return 0;
        if (!GlNative.init(JAWTWindow.libPath)) throw new RuntimeException("gl4es: " + GlNative.error);
        current = this;
        if (currentGl == null) currentGl = new GL2();
        return 1;
    }
    public void release() { backend.release(); if (current == this) current = null; }
    public void destroy() { backend.destroy(); }
}
