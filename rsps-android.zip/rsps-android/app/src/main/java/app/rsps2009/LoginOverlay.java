package app.rsps2009;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/** Custom RuneScape-styled loading + login screen drawn over the game surface. */
final class LoginOverlay extends FrameLayout {
    private static final int GOLD = Color.rgb(255, 213, 74);
    private static final int PARCH = Color.rgb(205, 198, 255);
    private static final int STONE = Color.rgb(22, 17, 40);

    private final Handler h = new Handler(Looper.getMainLooper());
    private Typeface pxFace;
    /** the pixel arcade font (Silkscreen, SIL Open Font License) shipped in the app's assets */
    private Typeface pixel() {
        if (pxFace == null) {
            try { pxFace = Typeface.createFromAsset(getContext().getAssets(), "silkscreen.ttf"); }
            catch (Throwable t) { pxFace = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); }
        }
        return pxFace;
    }
    private final BarView bar;
    private final TextView status, error;
    private TextView backLink;
    private final LinearLayout form;
    private final EditText user, pass;
    private final LinearLayout accountsBox, manualBox;
    private final View panelView;
    private boolean manual, fadingOut, formShown;
    private java.util.List<String[]> accounts = new java.util.ArrayList<String[]>();
    private final CheckBox remember;
    private final Button login;
    private final File dir;
    private final float d;

    private boolean inWorld, attempting, sawBusy, wasInGame, autoDone, prefilled;
    private final TransitionView tv;
    private boolean loggingOut, enterWait;
    private long logoutAt, enterAt, g30At;
    private int g30Frames = -1;
    private long attemptAt, lastLoadChange;
    private String lastLoadKey = "";

    LoginOverlay(Context c, File filesDir) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        dir = filesDir;
        setClickable(true);
        setFocusable(true);
        setFocusableInTouchMode(true);

        setBackground(new BgDrawable());

        ScrollView sv = new ScrollView(c);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        addView(sv, new LayoutParams(-1, -1));

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(16), dp(18), dp(16), dp(12));
        sv.addView(col, new ScrollView.LayoutParams(-1, -2));

        TextView title = new ShimmerTitle(c);
        title.setText("RAINBOW SCAPE");
        title.setLetterSpacing(0.04f);
        title.setTypeface(pixel());
        title.setTextSize(30);
        title.setTextColor(GOLD);
        title.setShadowLayer(dp(9), 0, 0, Color.argb(210, 255, 70, 200));
        title.setGravity(Gravity.CENTER);
        col.addView(title);

        TextView sub = new TextView(c);
        sub.setText("INSERT COIN");
        sub.setTypeface(pixel());
        sub.setTextSize(14);
        sub.setLetterSpacing(0.25f);
        sub.setTextColor(Color.rgb(90, 255, 130));
        sub.setShadowLayer(dp(7), 0, 0, Color.argb(210, 40, 255, 100));
        android.animation.ObjectAnimator blink = android.animation.ObjectAnimator.ofFloat(sub, "alpha", 1f, 0.2f);
        blink.setDuration(700L); blink.setRepeatCount(android.animation.ValueAnimator.INFINITE); blink.setRepeatMode(android.animation.ValueAnimator.REVERSE); blink.start();
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, dp(10));
        sub.setVisibility(GONE);
        col.addView(sub);
        title.setPadding(0, 0, 0, dp(14));

        FrameLayout panel = new FrameLayout(c);
        panel.setBackground(panelBg());
        panel.setPadding(dp(14), dp(12), dp(14), dp(12));
        col.addView(panel, new LinearLayout.LayoutParams(dp(330), -2));
        panelView = panel;

        LinearLayout in = new LinearLayout(c);
        in.setOrientation(LinearLayout.VERTICAL);
        in.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.addView(in, new LayoutParams(-1, -2));

        bar = new BarView(c);
        in.addView(bar, new LinearLayout.LayoutParams(-1, dp(210)));

        status = label(c, "Loading...", 13, PARCH);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(6), 0, 0);
        in.addView(status, new LinearLayout.LayoutParams(-1, -2));

        form = new LinearLayout(c);
        form.setOrientation(LinearLayout.VERTICAL);
        in.addView(form, new LinearLayout.LayoutParams(-1, -2));

        accountsBox = new LinearLayout(c);
        accountsBox.setOrientation(LinearLayout.VERTICAL);

        manualBox = new LinearLayout(c);
        manualBox.setOrientation(LinearLayout.VERTICAL);
        manualBox.addView(label(c, "Login", 14, GOLD));
        user = field(c, "Username", false);
        manualBox.addView(user, fieldLp());
        pass = field(c, "Password", true);
        manualBox.addView(pass, fieldLp());

        remember = new CheckBox(c);
        remember.setText("Remember me (up to 3 accounts)");
        remember.setTextColor(PARCH);
        remember.setChecked(true);
        remember.setButtonTintList(android.content.res.ColorStateList.valueOf(GOLD));
        manualBox.addView(remember);

        login = new Button(c);
        login.setText("Login");
        login.setAllCaps(false);
        login.setTypeface(pixel());
        login.setTextSize(17);
        login.setTextColor(Color.rgb(34, 18, 62));
        login.setBackground(pressable(btnBg()));
        login.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) { submit(); }
        });
        pressScale(login);
        manualBox.addView(login, new LinearLayout.LayoutParams(-1, dp(46)));

        final TextView back = label(c, "< Back to saved accounts", 13, PARCH);
        back.setGravity(Gravity.CENTER);
        back.setPadding(0, dp(10), 0, dp(4));
        back.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) {
                manual = false;
                error.setText("");
                hideIme();
                refreshAccounts();
                animateIn();
            }
        });
        backLink = back;
        manualBox.addView(back);

        form.addView(accountsBox, new LinearLayout.LayoutParams(-1, -2));
        form.addView(manualBox, new LinearLayout.LayoutParams(-1, -2));

        error = label(c, "", 13, Color.rgb(255, 90, 70));
        error.setGravity(Gravity.CENTER);
        error.setPadding(0, dp(6), 0, 0);
        form.addView(error);

        pass.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int a, android.view.KeyEvent e) {
                submit();
                return true;
            }
        });
        tv = new TransitionView(c);
        addView(tv, new LayoutParams(-1, -1));
        tv.setVisibility(GONE);
        form.setVisibility(GONE);
        h.post(poll);
        h.post(animTick);
    }

    // ---------------------------------------------------------------- accounts

    private void refreshAccounts() {
        accounts = rt4.SavedAccount.load(dir);
        accountsBox.removeAllViews();
        boolean showList = !accounts.isEmpty() && !manual;
        if (showList) {
            Context c = getContext();
            accountsBox.addView(label(c, "Choose an account", 14, GOLD));
            int i = 0;
            for (final String[] a : accounts) {
                View card = accountCard(c, a);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(58));
                lp.topMargin = dp(8);
                accountsBox.addView(card, lp);
                card.setAlpha(0f);
                card.setTranslationY(dp(18));
                card.animate().alpha(1f).translationY(0f).setStartDelay(90L * i).setDuration(280L).start();
                i++;
            }
            if (accounts.size() < rt4.SavedAccount.MAX_ACCOUNTS) {
                TextView add = label(c, "+  ADD ACCOUNT", 14, Color.rgb(10, 46, 26));
                add.setGravity(Gravity.CENTER);
                add.setBackground(pressable(addBg()));
                add.setOnClickListener(new OnClickListener() {
                    @Override public void onClick(View v) {
                        manual = true;
                        user.setText("");
                        pass.setText("");
                        error.setText("");
                        refreshAccounts();
                        animateIn();
                    }
                });
                pressScale(add);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(46));
                lp.topMargin = dp(10);
                accountsBox.addView(add, lp);
                add.setAlpha(0f);
                add.animate().alpha(1f).setStartDelay(90L * i).setDuration(280L).start();
            }
        }
        accountsBox.setVisibility(showList ? VISIBLE : GONE);
        manualBox.setVisibility(showList ? GONE : VISIBLE);
        backLink.setVisibility(accounts.isEmpty() ? GONE : VISIBLE);
    }

    private View accountCard(final Context c, final String[] a) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10), 0, dp(6), 0);
        row.setBackground(pressable(cardBg()));

        final String name = a[0];
        View avatar = new View(c) {
            private final Paint ap = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas cv) {
                float r = Math.min(getWidth(), getHeight()) / 2f;
                ap.setStyle(Paint.Style.FILL);
                ap.setColor(Color.rgb(24, 18, 11));
                cv.drawCircle(getWidth() / 2f, getHeight() / 2f, r, ap);
                ap.setShader(new LinearGradient(0, 0, 0, getHeight(), Color.rgb(255, 200, 70), Color.rgb(200, 120, 0), Shader.TileMode.CLAMP));
                cv.drawCircle(getWidth() / 2f, getHeight() / 2f, r * 0.88f, ap);
                ap.setShader(null);
                ap.setColor(Color.rgb(50, 30, 5));
                ap.setTextAlign(Paint.Align.CENTER);
                ap.setTypeface(pixel());
                ap.setTextSize(r * 1.1f);
                cv.drawText(name.substring(0, 1).toUpperCase(), getWidth() / 2f, getHeight() / 2f + r * 0.38f, ap);
            }
        };
        row.addView(avatar, new LinearLayout.LayoutParams(dp(38), dp(38)));

        LinearLayout mid = new LinearLayout(c);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setPadding(dp(10), 0, 0, 0);
        TextView n = label(c, name, 17, Color.rgb(255, 232, 160));
        n.setSingleLine(true);
        mid.addView(n);
        TextView sub = new TextView(c);
        sub.setText("Saved  -  " + ago(a[2]));
        sub.setTextSize(12);
        sub.setTextColor(Color.rgb(170, 155, 120));
        mid.addView(sub);
        row.addView(mid, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView x = new TextView(c);
        x.setText("\u2715");
        x.setTextSize(16);
        x.setTextColor(Color.rgb(180, 120, 100));
        x.setGravity(Gravity.CENTER);
        x.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) {
                new android.app.AlertDialog.Builder(c)
                        .setMessage("Forget " + name + "?")
                        .setPositiveButton("Forget", new android.content.DialogInterface.OnClickListener() {
                            @Override public void onClick(android.content.DialogInterface dd, int w) {
                                rt4.SavedAccount.remove(dir, name);
                                refreshAccounts();
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        });
        row.addView(x, new LinearLayout.LayoutParams(dp(40), dp(40)));

        row.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) {
                user.setText(a[0]);
                pass.setText(a[1]);
                remember.setChecked(true);
                submit();
            }
        });
        pressScale(row);
        return row;
    }

    private static String ago(String ts) {
        try {
            long t = Long.parseLong(ts);
            if (t <= 0) return "not played yet";
            long m = (System.currentTimeMillis() - t) / 60000L;
            if (m < 1) return "played just now";
            if (m < 60) return "played " + m + " min ago";
            if (m < 60 * 24) return "played " + (m / 60) + " h ago";
            return "played " + (m / (60 * 24)) + " d ago";
        } catch (Throwable e) {
            return "";
        }
    }

    private android.graphics.drawable.Drawable cardBg() {
        if (true) return new ChunkyBg(Color.rgb(44, 32, 88), Color.rgb(16, 10, 36), Color.rgb(120, 90, 220));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] {Color.rgb(54, 38, 100), Color.rgb(28, 20, 58)});
        g.setStroke(dp(2), Color.rgb(150, 100, 255));
        g.setCornerRadius(dp(8));
        return g;
    }

    private android.graphics.drawable.Drawable addBg() {
        if (true) return new ChunkyBg(Color.rgb(70, 235, 130), Color.rgb(18, 120, 62), Color.rgb(180, 255, 210));
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.argb(50, 90, 240, 255));
        g.setStroke(dp(2), Color.argb(190, 90, 240, 255), dp(6), dp(4));
        g.setCornerRadius(dp(8));
        return g;
    }

    private android.graphics.drawable.Drawable pressable(android.graphics.drawable.Drawable base) {
        return new android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(Color.argb(90, 140, 220, 255)), base, null);
    }

    private void pressScale(View v) {
        v.setOnTouchListener(new OnTouchListener() {
            @Override public boolean onTouch(View view, android.view.MotionEvent e) {
                int a = e.getActionMasked();
                if (a == android.view.MotionEvent.ACTION_DOWN) {
                    view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80L).start();
                } else if (a == android.view.MotionEvent.ACTION_UP || a == android.view.MotionEvent.ACTION_CANCEL) {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(140L).start();
                }
                return false;
            }
        });
    }

    /** Fade and slide the form in. */
    private void animateIn() {
        form.setAlpha(0f);
        form.setTranslationY(dp(14));
        form.animate().alpha(1f).translationY(0f).setStartDelay(0L).setDuration(260L).start();
    }

    /** Short horizontal shake of the panel (wrong password, can't connect...). */
    private void shake() {
        android.animation.ValueAnimator va = android.animation.ValueAnimator.ofFloat(0f, 1f);
        va.setDuration(420L);
        va.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(android.animation.ValueAnimator an) {
                float t = (Float) an.getAnimatedValue();
                panelView.setTranslationX((float) (Math.sin(t * Math.PI * 6) * (1f - t) * dp(12)));
            }
        });
        va.start();
    }

    /** Gold shimmer sweeping across the title. */
    private final class ShimmerTitle extends TextView {
        private final int[] cols = {0xFFFF4D4D, 0xFFFF9F43, 0xFFFFD93D, 0xFF6BD968, 0xFF4DABF7, 0xFF9775FA, 0xFFE64980};
        ShimmerTitle(Context c) { super(c); }
        @Override protected void onDraw(Canvas cv) {
            String t = getText().toString();
            Paint pt = new Paint(getPaint());
            pt.setColor(Color.WHITE);
            float gap = dp(2);
            float total = 0f;
            for (int i = 0; i < t.length(); i++) total += pt.measureText(t, i, i + 1) + gap;
            float x = (getWidth() - total) / 2f + gap / 2f;
            float y = getBaseline();
            long now = System.currentTimeMillis();
            int shift = (int) (now / 320L);
            int ci = 0;
            for (int i = 0; i < t.length(); i++) {
                String ch = t.substring(i, i + 1);
                float cw = pt.measureText(ch);
                if (!ch.equals(" ")) {
                    int col = cols[(ci + shift) % cols.length];
                    ci++;
                    pt.setShadowLayer(0, 0, 0, 0);
                    pt.setColor(Color.rgb(24, 8, 50));
                    float bob = (float) Math.sin(now / 260.0 + i * 0.55) * dp(3);   // letters ripple in a wave
                    cv.drawText(ch, x + dp(3), y + dp(3) + bob, pt);          // hard arcade drop shadow
                    pt.setShadowLayer(dp(10), 0, 0, (col & 0x00FFFFFF) | 0xD0000000);
                    pt.setColor(col);
                    cv.drawText(ch, x, y + bob, pt);
                }
                x += cw + gap;
            }
            postInvalidateOnAnimation();
        }
    }

    /** Full-screen animated cover shown while logging in, entering the world and logging out (hides the stock title screen). */
    private final class TransitionView extends View {
        private final android.graphics.Paint ring = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Paint dot = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Paint txt = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Paint sub = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private String text = "";
        TransitionView(Context c) {
            super(c);
            setClickable(true);
            ring.setStyle(android.graphics.Paint.Style.STROKE);
            ring.setStrokeCap(android.graphics.Paint.Cap.ROUND);
            txt.setTextAlign(android.graphics.Paint.Align.CENTER);
            txt.setTypeface(pixel());
            sub.setTextAlign(android.graphics.Paint.Align.CENTER);
            sub.setTypeface(pixel());
        }
        void show(String t) {
            text = t;
            if (getVisibility() != VISIBLE) setVisibility(VISIBLE);
            invalidate();
        }
        void hide() { if (getVisibility() != GONE) setVisibility(GONE); }
        @Override protected void onDraw(Canvas cv) {
            int w = getWidth(), hh = getHeight();
            float cx = w / 2f, cy = hh * 0.44f;
            long now = System.currentTimeMillis();
            Shader bg = new android.graphics.RadialGradient(cx, cy, Math.max(w, hh) * 0.75f,
                    new int[] {Color.rgb(24, 20, 44), Color.rgb(8, 9, 16)}, new float[] {0f, 1f}, Shader.TileMode.CLAMP);
            android.graphics.Paint bp = new android.graphics.Paint();
            bp.setShader(bg);
            cv.drawRect(0, 0, w, hh, bp);
            float r = Math.min(w, hh) * 0.13f;
            float t = (now % 1700L) / 1700f;
            int[] cols = new int[8];
            for (int i = 0; i < 8; i++) {
                float hue = (i / 7f) * 300f;
                int a = Math.round(255f * (i / 7f));
                cols[i] = Color.HSVToColor(a, new float[] {hue, 0.75f, 1f});
            }
            ring.setStrokeWidth(r * 0.30f);
            ring.setShader(new android.graphics.SweepGradient(cx, cy, cols, null));
            cv.save();
            cv.rotate(t * 360f, cx, cy);
            cv.drawArc(new android.graphics.RectF(cx - r, cy - r, cx + r, cy + r), 0f, 300f, false, ring);
            cv.restore();
            ring.setShader(null);
            // three small glowing stars orbiting the other way
            for (int k = 0; k < 3; k++) {
                double ang = -(now % 3200L) / 3200.0 * Math.PI * 2 + k * Math.PI * 2 / 3;
                float ox = cx + (float) Math.cos(ang) * r * 1.65f, oy = cy + (float) Math.sin(ang) * r * 1.65f;
                int c1 = Color.HSVToColor(255, new float[] {(k * 120f + (now % 3600L) / 10f) % 360f, 0.6f, 1f});
                dot.setColor(c1);
                dot.setAlpha(70);
                cv.drawCircle(ox, oy, r * 0.16f, dot);
                dot.setAlpha(255);
                cv.drawCircle(ox, oy, r * 0.07f, dot);
            }
            float pulse = 0.65f + 0.35f * (float) Math.sin(now / 380.0);
            txt.setTextSize(Math.min(w, hh) * 0.055f);
            txt.setColor(Color.argb(Math.round(255 * pulse), 255, 214, 90));
            txt.setShadowLayer(dp(2), dp(1), dp(1), Color.BLACK);
            cv.drawText(text, cx, cy + r * 2.55f, txt);
            sub.setTextSize(Math.min(w, hh) * 0.034f);
            sub.setColor(Color.argb(190, 200, 190, 230));
            cv.drawText("Rainbow Scape", cx, cy + r * 3.5f, sub);
            postInvalidateOnAnimation();
        }
    }

    private final Runnable animTick = new Runnable() {
        @Override public void run() {
            if (getVisibility() == VISIBLE) {
                invalidate();
            }
            h.postDelayed(this, 33L);
        }
    };

    private int dp(int v) { return (int) (v * d + 0.5f); }

    private TextView label(Context c, String t, int sp, int color) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(pixel());
        return v;
    }

    private LinearLayout.LayoutParams fieldLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(44));
        lp.topMargin = dp(6);
        return lp;
    }

    private EditText field(Context c, String hint, boolean pw) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(125, 115, 170));
        e.setTextColor(Color.rgb(235, 230, 255));
        e.setSingleLine(true);
        e.setTextSize(16);
        e.setPadding(dp(10), 0, dp(10), 0);
        e.setInputType(pw ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD
                : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.setImeOptions(pw ? EditorInfo.IME_ACTION_GO : EditorInfo.IME_ACTION_NEXT);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.rgb(12, 9, 28));
        g.setStroke(dp(2), Color.rgb(100, 80, 190));
        g.setCornerRadius(dp(6));
        e.setBackground(g);
        return e;
    }

    private android.graphics.drawable.Drawable panelBg() {
        return new NeonBorder();
    }

    /** Arcade-cabinet panel: dark glass with a rainbow neon border that slowly rotates. */
    private final class NeonBorder extends android.graphics.drawable.Drawable {
        private final Paint np = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int[] cols = {0xFFFF4D4D, 0xFFFF9F43, 0xFFFFD93D, 0xFF6BD968, 0xFF4DABF7, 0xFF9775FA, 0xFFE64980, 0xFFFF4D4D};
        @Override public void draw(Canvas c) {
            Rect b = getBounds();
            float cx = b.exactCenterX(), cy = b.exactCenterY();
            RectF rf = new RectF(b.left + dp(3), b.top + dp(3), b.right - dp(10), b.bottom - dp(10));
            float rad = dp(2);
            np.setShader(null);
            np.setStyle(Paint.Style.FILL);
            np.setColor(Color.rgb(58, 20, 104));
            c.drawRect(rf.left + dp(7), rf.top + dp(7), rf.right + dp(7), rf.bottom + dp(7), np);   // hard offset shadow
            np.setColor(Color.rgb(20, 15, 38));
            c.drawRoundRect(rf, rad, rad, np);
            SweepGradient sg = new SweepGradient(cx, cy, cols, null);
            Matrix m = new Matrix();
            m.setRotate((System.currentTimeMillis() % 4200L) / 4200f * 360f, cx, cy);
            sg.setLocalMatrix(m);
            np.setShader(sg);
            np.setStyle(Paint.Style.STROKE);
            np.setStrokeWidth(dp(9));
            np.setAlpha(55);
            c.drawRoundRect(rf, rad, rad, np);
            np.setStrokeWidth(dp(3));
            np.setAlpha(255);
            c.drawRoundRect(rf, rad, rad, np);
            np.setShader(null);
            invalidateSelf();
        }
        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Flat arcade button: solid face with a hard darker slab underneath. */
    private final class ChunkyBg extends android.graphics.drawable.Drawable {
        private final Paint cp = new Paint();
        private final int face, slab, hi;
        ChunkyBg(int face, int slab, int hi) { this.face = face; this.slab = slab; this.hi = hi; }
        @Override public void draw(Canvas c) {
            Rect b = getBounds();
            float lift = dp(4);
            cp.setStyle(Paint.Style.FILL);
            cp.setColor(slab);
            c.drawRect(b.left, b.top + lift, b.right, b.bottom, cp);
            cp.setColor(face);
            c.drawRect(b.left, b.top, b.right, b.bottom - lift, cp);
            cp.setColor(hi);
            c.drawRect(b.left, b.top, b.right, b.top + dp(2), cp);
        }
        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.OPAQUE; }
    }

    private android.graphics.drawable.Drawable btnBg() {
        if (true) return new ChunkyBg(Color.rgb(255, 224, 66), Color.rgb(168, 120, 8), Color.rgb(255, 246, 170));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] {Color.rgb(140, 70, 230), Color.rgb(70, 28, 140)});
        g.setStroke(dp(2), Color.rgb(90, 240, 255));
        g.setCornerRadius(dp(8));
        return g;
    }

    private void submit() {
        if (attempting) return;
        String u = user.getText().toString().trim();
        String p = pass.getText().toString();
        if (u.isEmpty() || p.isEmpty()) {
            error.setText("Please enter your username and password.");
            return;
        }
        hideIme();
        error.setText("");
        attempting = true;
        sawBusy = false;
        attemptAt = System.currentTimeMillis();
        rt4.SavedAccount.request(u, p, remember.isChecked());
    }

    private void ime(boolean pan) {
        if (getContext() instanceof android.app.Activity) {
            ((android.app.Activity) getContext()).getWindow().setSoftInputMode(pan
                    ? android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
                    : android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        }
    }

    private void hideIme() {
        InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(getWindowToken(), 0);
    }

    private void prefill() {
        prefilled = true;
        manual = false;
        refreshAccounts();
    }

    private static String replyText(int r) {
        switch (r) {
            case 3: return "Invalid username or password.";
            case 4: return "Your account has been disabled.";
            case 5: return "Your account is already logged in. Try again in a minute.";
            case 6: case 14: return "The server is being updated. Try again in a minute.";
            case 7: return "This world is full.";
            case 9: case 16: return "Too many login attempts. Wait and try again.";
            case 12: return "This world needs a members account.";
            case 18: return "Your account is locked.";
            case 26: return "Your connection has been blocked.";
            case -4: case 8: case 10: case 11: case 20: case 23: case -5:
                return "Unable to connect to the server.";
            default: return "Login failed (code " + r + ").";
        }
    }

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            try {
                update();
            } catch (Throwable ignored) {
            }
            if (getVisibility() == VISIBLE || true) h.postDelayed(this, 120);
        }
    };

    private void ensureVisible() {
        if (getVisibility() != VISIBLE) {
            animate().cancel();
            fadingOut = false;
            setAlpha(1f);
            setVisibility(VISIBLE);
        }
    }

    private void update() {
        int gs = rt4.client.gameState;
        long nowT = System.currentTimeMillis();
        // logging out: cover the game at once, keep covering until the login form is ready
        if (gs == 30 && rt4.SavedAccount.intentionalLogout && !loggingOut) {
            loggingOut = true; logoutAt = nowT; enterWait = false;
        }
        if (loggingOut) {
            if (gs == 30 && nowT - logoutAt > 6000L) {
                loggingOut = false;          // logout did not happen (e.g. in combat): back to the game
                rt4.SavedAccount.intentionalLogout = false;
            } else if (gs != 30 || rt4.SavedAccount.intentionalLogout) {
                inWorld = false; wasInGame = false;
                if (gs == 10 && nowT - logoutAt > 1300L) {
                    loggingOut = false;
                    tv.hide();
                } else {
                    if (getVisibility() != VISIBLE) { animate().cancel(); setAlpha(0f); setVisibility(VISIBLE); animate().alpha(1f).setDuration(220L).start(); }
                    form.setVisibility(GONE); bar.setVisibility(GONE);
                    tv.show("Logging out...");
                    return;
                }
            }
        }
        if (gs != 30) g30Frames = -1;
        if (gs == 30) {
            wasInGame = true;
            inWorld = true;
            attempting = false;
            if (g30Frames < 0) { g30Frames = rt4.SavedAccount.frames; g30At = nowT; }
            if (getVisibility() != GONE && !fadingOut && rt4.SavedAccount.frames - g30Frames < 12) {
                return;      // keep the cover until the game has drawn its first frames (hides the stock login screen)
            }
            if (getVisibility() != GONE && !fadingOut && nowT - g30At < 500L) {
                return;
            }
            if (getVisibility() != GONE && !fadingOut) {
                hideIme();
                fadingOut = true;
                animate().alpha(0f).setDuration(380L).withEndAction(new Runnable() {
                    @Override public void run() {
                        setVisibility(GONE);
                        setAlpha(1f);
                        fadingOut = false;
                        enterWait = false;
                        tv.hide();
                        ime(false);
                    }
                }).start();
            }
            return;
        }
        if (gs == 40) {
            // connection lost: the game shows its own message and tries to reconnect
            if (getVisibility() != GONE) {
                setVisibility(GONE);
                ime(false);
            }
            return;
        }
        if (gs > 10 && gs < 30 && inWorld) {
            // moving between map regions while playing: never cover the game
            if (getVisibility() != GONE) {
                setVisibility(GONE);
                ime(false);
            }
            return;
        }
        if (gs <= 10) {
            inWorld = false;
        }
        if (getVisibility() != VISIBLE) {
            animate().cancel();
            fadingOut = false;
            setAlpha(1f);
            setVisibility(VISIBLE);
            ime(true);
        }
        if (gs < 10 || gs == 1000) {
            form.setVisibility(GONE);
            tv.hide();
            String t = rt4.client.mainLoadSecondaryText == null ? "Loading..." : rt4.client.mainLoadSecondaryText.toString();
            int pct = rt4.client.mainLoadPercentage;
            bar.setVisibility(VISIBLE);
            bar.set(pct, "");
            String key = pct + "|" + t + "|" + gs + "|" + rt4.client.mainLoadState;
            long nowMs = System.currentTimeMillis();
            if (!key.equals(lastLoadKey)) {
                lastLoadKey = key;
                lastLoadChange = nowMs;
            }
            if (nowMs - lastLoadChange > 15000L) {
                status.setText(t + "\nStill waiting for the server... check your connection.");
            } else {
                status.setText(t);
            }
            return;
        }
        if (gs == 10) {
            if (!prefilled) prefill();
            if (rt4.SavedAccount.reconnecting) {
                form.setVisibility(GONE);
                bar.setVisibility(VISIBLE);
                bar.set(-1, "");
                status.setText("Connection lost. Reconnecting...");
                return;
            }
            if (attempting) {
                int step = rt4.LoginManager.step;
                int hop = rt4.LoginManager.hopStep;
                if (step != 0 || hop != 0) sawBusy = true;
                if (sawBusy && step == 0 && hop == 0) {
                    attempting = false;
                    int r = rt4.LoginManager.reply;
                    if (r != 2) {
                        error.setText(replyText(r));
                        shake();
                    } else {
                        enterWait = true; enterAt = nowT;
                    }
                } else if (!sawBusy && System.currentTimeMillis() - attemptAt > 6000) {
                    attempting = false;
                    error.setText("Unable to connect to the server.");
                    shake();
                }
            }
            if (enterWait && nowT - enterAt < 25000L) {
                form.setVisibility(GONE); bar.setVisibility(GONE);
                tv.show("Entering Rainbow Scape...");
                return;
            }
            enterWait = false;
            if (attempting) {
                form.setVisibility(GONE);
                bar.setVisibility(VISIBLE);
                bar.set(-1, "");
                status.setText("Logging in...");
            } else {
                tv.hide();
                if (form.getVisibility() != VISIBLE) {
                    form.setVisibility(VISIBLE);
                    if (!inWorld) refreshAccounts();
                    animateIn();
                }
                bar.setVisibility(GONE);
                status.setText("Welcome to Rainbow Scape");
            }
            return;
        }
        // 20..29: logged in, loading the world
        form.setVisibility(GONE);
        bar.setVisibility(GONE);
        tv.show("Entering Rainbow Scape...");
    }

    // RuneScape herbs in Herblore-level order (RuneScape Wiki: Herb), drawn here as simple leaf sprigs.
    // name, leaf colour, flower colour (0 = none), potion colour (approximate)
    private static final String[] HERB_NAME = {
        "Guam leaf", "Marrentill", "Tarromin", "Harralander", "Ranarr weed", "Toadflax", "Irit leaf",
        "Avantoe", "Kwuarm", "Snapdragon", "Cadantine", "Lantadyme", "Dwarf weed", "Torstol"
    };
    private static final int[] HERB_LEAF = {
        0xFF58AA46, 0xFF468C50, 0xFF3C7846, 0xFF82AA3C, 0xFF3C9646, 0xFF64A05A, 0xFF3C963C,
        0xFF6EAA46, 0xFF46729A, 0xFF5AA050, 0xFF3C6E46, 0xFF5A9678, 0xFF326432, 0xFF503C6E
    };
    private static final int[] HERB_FLOWER = {
        0, 0, 0, 0, 0xFFE65A82, 0xFFF0A040, 0, 0, 0xFF9BD0FF, 0xFFF06AA0, 0, 0, 0, 0xFFB070F0
    };
    private static final int[] HERB_POTION = {
        0xFF5AE646, 0xFF28DCAA, 0xFF1EAA5A, 0xFFE6E628, 0xFF28D2E6, 0xFFF09628, 0xFFFFDC32,
        0xFFFF6E1E, 0xFF3278FF, 0xFFFF46A0, 0xFF1EC878, 0xFF5AC8FF, 0xFFE63C32, 0xFFA03CFF
    };

    /** Potion flask: herbs drop in one by one, each tinting the potion, and it fills as loading progresses. */
    private final class BarView extends View {
        private int pct = 0;
        private float shown = 0;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path flask = new Path();
        private final Path star = new Path();
        private final long t0 = System.currentTimeMillis();
        // sparkle: x, y (flask units, flask is 90 x 120), size, phase
        private final float[][] sparks = {
            {-34, 18, 11, 0.0f}, {112, 34, 13, 1.7f}, {-26, 76, 9, 3.1f},
            {108, 92, 8, 4.4f}, {20, -2, 7, 2.2f}, {82, 8, 6, 5.3f}, {-8, 110, 6, 0.9f}, {96, 120, 7, 3.8f}
        };
        private int lastHerb = -1;
        private int dropHerb = -1;
        private long dropStart;
        private boolean landed;
        private long splashAt;
        private final int[] bandCol = new int[14];
        private final long[] bandStart = new long[14];
        private int nb = 0;
        private final float[] col = {110, 120, 130};
        private final float[] target = {110, 120, 130};

        BarView(Context c) {
            super(c);
            setLayerType(LAYER_TYPE_SOFTWARE, null);
        }

        void set(int pct, String ignored) {
            this.pct = pct;
        }

        private void drawStar(Canvas c, float cx, float cy, float r) {
            star.reset();
            float in = r * 0.26f;
            star.moveTo(cx, cy - r);
            star.lineTo(cx + in, cy - in);
            star.lineTo(cx + r, cy);
            star.lineTo(cx + in, cy + in);
            star.lineTo(cx, cy + r);
            star.lineTo(cx - in, cy + in);
            star.lineTo(cx - r, cy);
            star.lineTo(cx - in, cy - in);
            star.close();
            c.drawPath(star, p);
        }

        /** A little herb sprig: stem, five leaves and an optional flower. u = unit size in px. */
        private void drawHerb(Canvas c, int herb, float cx, float cy, float u, float rot, int alpha) {
            c.save();
            c.translate(cx, cy);
            c.rotate(rot);
            int leaf = HERB_LEAF[herb];
            int dark = Color.rgb((int) (Color.red(leaf) * 0.6f), (int) (Color.green(leaf) * 0.6f), (int) (Color.blue(leaf) * 0.6f));
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(u * 0.5f);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(Color.argb(alpha, Color.red(dark), Color.green(dark), Color.blue(dark)));
            c.drawLine(0, u * 5f, 0, -u * 1f, p);
            p.setStyle(Paint.Style.FILL);
            float[][] leaves = {{-1, 0.6f, -50}, {1, 0.6f, 50}, {-1, -1.6f, -28}, {1, -1.6f, 28}, {0, -3.4f, 0}};
            for (float[] l : leaves) {
                c.save();
                c.translate(l[0] * u * 1.4f, l[1] * u * 1.3f);
                c.rotate(l[2]);
                p.setColor(Color.argb(alpha, Color.red(leaf), Color.green(leaf), Color.blue(leaf)));
                c.drawOval(new RectF(-u * 1.2f, -u * 2.6f, u * 1.2f, u * 1.2f), p);
                p.setColor(Color.argb(alpha, Color.red(dark), Color.green(dark), Color.blue(dark)));
                c.drawRect(-u * 0.12f, -u * 2.2f, u * 0.12f, u * 1.0f, p);
                c.restore();
            }
            if (HERB_FLOWER[herb] != 0) {
                int f = HERB_FLOWER[herb];
                p.setColor(Color.argb(alpha, Color.red(f), Color.green(f), Color.blue(f)));
                c.drawCircle(0, -u * 4.4f, u * 1.0f, p);
                c.drawCircle(-u * 1.2f, -u * 3.4f, u * 0.7f, p);
                c.drawCircle(u * 1.2f, -u * 3.4f, u * 0.7f, p);
            }
            c.restore();
        }

        /** Layered potion: one colour band per herb added, newest on top, each growing in as it lands. */
        private Shader bandShader(float yTop, float yBot, long now, int waterTop, int waterBot) {
            if (nb == 0) {
                return new LinearGradient(0, yTop, 0, yBot, Color.rgb(170, 200, 225), Color.rgb(90, 120, 150), Shader.TileMode.CLAMP);
            }
            float[] w = new float[nb];
            float sum = 0;
            for (int j = 0; j < nb; j++) {
                float k = Math.min(1f, (now - bandStart[j]) / 900f);
                w[j] = 0.05f + 0.95f * (k * k * (3f - 2f * k));
                sum += w[j];
            }
            int[] cols = new int[nb * 2];
            float[] pos = new float[nb * 2];
            float at = 0f;
            int i = 0;
            for (int j = nb - 1; j >= 0; j--) {
                float end = at + w[j] / sum;
                cols[i] = bandCol[j];
                pos[i++] = at;
                cols[i] = bandCol[j];
                pos[i++] = Math.min(1f, end);
                at = end;
            }
            pos[pos.length - 1] = 1f;
            return new LinearGradient(0, yTop, 0, yBot, cols, pos, Shader.TileMode.CLAMP);
        }

        @Override protected void onDraw(Canvas c) {
            float s = d * 1.0f;
            long now = System.currentTimeMillis();
            float t = (now - t0) / 1000f;
            float ox = getWidth() / 2f - 45 * s, oy = dp(26);
            float frac;
            int herbNow;
            if (pct >= 0) {
                shown += (Math.min(100, pct) / 100f - shown) * 0.12f;
                frac = 0.05f + 0.95f * shown;
                herbNow = Math.min(13, (int) (Math.min(100, pct) * 14 / 100f));
            } else {
                frac = 0.5f + 0.12f * (float) Math.sin(t * 2.2f);
                herbNow = ((int) (t / 1.6f)) % 14;
            }

            // herb drop state machine: one herb at a time
            if (dropHerb >= 0 && now - dropStart > 700) {
                dropHerb = -1;
            }
            if (dropHerb < 0) {
                if (pct < 0 && herbNow != lastHerb) {
                    lastHerb = herbNow;
                    dropHerb = herbNow;
                    dropStart = now;
                    landed = false;
                } else if (pct >= 0 && lastHerb < herbNow) {
                    lastHerb++;
                    dropHerb = lastHerb;
                    dropStart = now;
                    landed = false;
                }
            }
            float prog = dropHerb >= 0 ? (now - dropStart) / 700f : 1f;
            if (dropHerb >= 0 && !landed && prog > 0.62f) {
                landed = true;
                splashAt = now;
                if (nb >= 14) nb = 0;
                bandCol[nb] = HERB_POTION[dropHerb];
                bandStart[nb] = now;
                nb++;
                int pc = HERB_POTION[dropHerb];
                target[0] = Color.red(pc);
                target[1] = Color.green(pc);
                target[2] = Color.blue(pc);
            }
            for (int i = 0; i < 3; i++) {
                col[i] += (target[i] - col[i]) * 0.06f;
            }
            float splash = Math.max(0f, 1f - (now - splashAt) / 900f);

            // flask outline in absolute coordinates
            flask.reset();
            flask.moveTo(ox + 34 * s, oy + 14 * s);
            flask.lineTo(ox + 56 * s, oy + 14 * s);
            flask.lineTo(ox + 56 * s, oy + 46 * s);
            flask.lineTo(ox + 85 * s, oy + 100 * s);
            flask.quadTo(ox + 92 * s, oy + 118 * s, ox + 74 * s, oy + 118 * s);
            flask.lineTo(ox + 16 * s, oy + 118 * s);
            flask.quadTo(ox - 2 * s, oy + 118 * s, ox + 5 * s, oy + 100 * s);
            flask.lineTo(ox + 34 * s, oy + 46 * s);
            flask.close();

            // sparkles behind
            p.setStyle(Paint.Style.FILL);
            for (float[] k : sparks) {
                float tw = 0.5f + 0.5f * (float) Math.sin(t * 2.6f + k[3]);
                p.setColor(Color.argb((int) (60 + 195 * tw), 170, 205, 255));
                drawStar(c, ox + k[0] * s, oy + k[1] * s, k[2] * s * (0.55f + 0.6f * tw));
            }

            // glass body fill
            p.setColor(Color.argb(45, 200, 225, 255));
            c.drawPath(flask, p);

            // liquid, clipped to the flask
            int top1 = Color.rgb((int) col[0], (int) col[1], (int) col[2]);
            int bot1 = Color.rgb((int) (col[0] * 0.55f), (int) (col[1] * 0.55f), (int) (col[2] * 0.55f));
            float top = 118f - (118f - 48f) * Math.min(1f, frac);
            c.save();
            c.clipPath(flask);
            p.setShader(bandShader(oy + top * s, oy + 118 * s, now, top1, bot1));
            Path liquid = new Path();
            liquid.moveTo(ox - 5 * s, oy + 124 * s);
            float amp = 1.8f + 4.5f * splash;
            for (int x = -5; x <= 95; x += 4) {
                float y = top + amp * (float) Math.sin(t * (3f + 5f * splash) + x * 0.16f);
                liquid.lineTo(ox + x * s, oy + y * s);
            }
            liquid.lineTo(ox + 95 * s, oy + 124 * s);
            liquid.close();
            c.drawPath(liquid, p);
            // depth: darker toward the bottom
            p.setShader(new LinearGradient(0, oy + top * s, 0, oy + 118 * s, Color.argb(0, 0, 0, 0), Color.argb(110, 0, 0, 0), Shader.TileMode.CLAMP));
            c.drawPath(liquid, p);
            p.setShader(null);
            // bubbles
            p.setColor(Color.argb(150, 255, 255, 255));
            int nBub = 5 + (int) (6 * splash);
            for (int i = 0; i < nBub; i++) {
                float ph = (t * (0.35f + 0.07f * (i % 5)) + i * 0.37f) % 1f;
                float by = 116f - (116f - top) * ph;
                float bx = 26 + (i % 7) * 6 + 3 * (float) Math.sin(t * 2f + i);
                c.drawCircle(ox + bx * s, oy + by * s, (1.4f + (i % 3) * 0.7f) * s, p);
            }
            // surface shine
            p.setColor(Color.argb(110, 255, 255, 255));
            c.drawRect(ox, oy + (top - 0.5f) * s, ox + 90 * s, oy + (top + 1.2f) * s, p);
            c.restore();

            // glass highlight stripe
            p.setColor(Color.argb(95, 255, 255, 255));
            Path hl = new Path();
            hl.moveTo(ox + 30 * s, oy + 62 * s);
            hl.lineTo(ox + 36 * s, oy + 56 * s);
            hl.lineTo(ox + 18 * s, oy + 98 * s);
            hl.lineTo(ox + 13 * s, oy + 98 * s);
            hl.close();
            c.drawPath(hl, p);

            // outline
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.2f * s);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setColor(Color.argb(230, 225, 238, 255));
            c.drawPath(flask, p);
            p.setStyle(Paint.Style.FILL);

            // lip ring
            p.setColor(Color.rgb(228, 238, 255));
            c.drawRoundRect(new RectF(ox + 28 * s, oy + 11 * s, ox + 62 * s, oy + 20 * s), 2 * s, 2 * s, p);
            p.setColor(Color.rgb(150, 170, 205));
            c.drawRect(ox + 28 * s, oy + 18 * s, ox + 62 * s, oy + 20 * s, p);
            // cork, popped off and resting beside the flask
            c.save();
            c.translate(ox + 80 * s, oy + 4 * s);
            c.rotate(24);
            p.setColor(Color.rgb(176, 148, 62));
            c.drawRoundRect(new RectF(-13 * s, -7 * s, 13 * s, 8 * s), 2.5f * s, 2.5f * s, p);
            p.setColor(Color.rgb(120, 98, 38));
            c.drawRect(-13 * s, 4 * s, 13 * s, 8 * s, p);
            c.restore();

            // the falling herb
            if (dropHerb >= 0) {
                float k = Math.min(1f, prog / 0.62f);
                float hy = -34f + (24f + 34f) * k * k;
                float scale = prog > 0.62f ? Math.max(0.2f, 1f - (prog - 0.62f) / 0.38f * 0.8f) : 1f;
                int al = prog > 0.62f ? (int) (255 * (1f - (prog - 0.62f) / 0.38f)) : 255;
                drawHerb(c, dropHerb, ox + 45 * s, oy + hy * s, 3.3f * s * scale, 18f * (float) Math.sin(prog * 9f) + 200f * prog, Math.max(0, al));
            }

            // percentage and herb name under the flask
            p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(pixel());
            if (pct >= 0) {
                p.setColor(Color.WHITE);
                p.setTextSize(dp(20));
                p.setShadowLayer(3, 1, 1, Color.BLACK);
                c.drawText(Math.min(100, pct) + "%", getWidth() / 2f, oy + 144 * s, p);
                p.clearShadowLayer();
            }
            if (lastHerb >= 0 || pct < 0) {
                int hn = dropHerb >= 0 ? dropHerb : Math.max(0, lastHerb);
                p.setColor(Color.argb(220, 255, 214, 130));
                p.setTextSize(dp(12));
                c.drawText("Adding " + HERB_NAME[hn], getWidth() / 2f, oy + 164 * s, p);
            }
            postInvalidateOnAnimation();
        }
    }

    /** Dark vignette background with a faint gold border pattern. */
    /** Arcade scene: deep purple sky, drifting rainbow aurora, neon grid floor, rainbow sparkles, CRT scanlines. */
    private final class BgDrawable extends android.graphics.drawable.Drawable {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Bitmap bg;
        private boolean bgTried;
        @Override public void draw(Canvas c) {
            Rect r = getBounds();
            float w = r.width(), h = r.height();
            long now = System.currentTimeMillis();
            p.setStyle(Paint.Style.FILL);
            p.setXfermode(null);
            p.setShader(new LinearGradient(0, 0, 0, h, new int[] {Color.rgb(9, 5, 26), Color.rgb(34, 10, 62), Color.rgb(8, 4, 20)},
                    new float[] {0f, 0.62f, 1f}, Shader.TileMode.CLAMP));
            p.setAlpha(255);
            c.drawRect(r, p);
            p.setShader(null);
            if (bg == null && !bgTried) {
                bgTried = true;
                try {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inScaled = false;
                    bg = BitmapFactory.decodeResource(getResources(), R.drawable.login_bg, o);
                } catch (Throwable ignored) {
                }
            }
            if (bg != null) {
                // the old world map, faint, under the neon
                float sc = Math.max(w / bg.getWidth(), h / bg.getHeight());
                float sw = bg.getWidth() * sc, sh = bg.getHeight() * sc;
                float l = r.left + (w - sw) / 2f, t = r.top + (h - sh) / 2f;
                p.setColor(Color.WHITE);
                p.setAlpha(46);
                p.setFilterBitmap(true);
                c.drawBitmap(bg, null, new RectF(l, t, l + sw, t + sh), p);
            }
            p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
            // rainbow aurora bands drifting across the sky
            for (int i = 0; i < 6; i++) {
                float hue = ((now / 90f) + i * 60f) % 360f;
                float yy = h * (0.10f + 0.085f * i) + (float) Math.sin(now / 2300f + i * 1.3f) * h * 0.035f;
                float half = h * 0.085f;
                int col = Color.HSVToColor(64, new float[] {hue, 0.85f, 1f});
                p.setShader(new LinearGradient(0, yy - half, 0, yy + half, new int[] {0x00000000, col, 0x00000000}, null, Shader.TileMode.CLAMP));
                c.drawRect(0, yy - half, w, yy + half, p);
            }
            p.setShader(null);
            // neon perspective grid floor
            float y0 = h * 0.70f;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1f, d));
            float scroll = (now % 1400L) / 1400f;
            for (int j = 0; j < 9; j++) {
                float t = (j + scroll) / 9f;
                float y = y0 + (h - y0) * t * t;
                p.setColor(Color.argb((int) (150 * t), 255, 70, 210));
                c.drawLine(0, y, w, y, p);
            }
            for (int k = -12; k <= 12; k++) {
                float xb = w / 2f + k * w * 0.14f;
                p.setColor(Color.argb(120, 80, 230, 255));
                c.drawLine(w / 2f + k * w * 0.012f, y0, xb, h, p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setXfermode(null);
            // horizon glow
            p.setShader(new LinearGradient(0, y0 - h * 0.06f, 0, y0 + h * 0.02f, new int[] {0x00ff46d2, 0x66ff46d2, 0x00ff46d2}, null, Shader.TileMode.CLAMP));
            c.drawRect(0, y0 - h * 0.06f, w, y0 + h * 0.02f, p);
            p.setShader(null);
            // rainbow sparkles rising
            for (int i = 0; i < 38; i++) {
                float seed = i * 12.9898f;
                float speed = 0.03f + (i % 7) * 0.012f;
                float ph = ((now / 1000f) * speed + (i * 0.173f)) % 1f;
                float x = w * (0.5f + 0.5f * (float) Math.sin(seed)) + dp(14) * (float) Math.sin(now / 900f + i);
                float y = h * (1.05f - ph * 1.1f);
                float tw = 0.5f + 0.5f * (float) Math.sin(now / 350f + i * 2.1f);
                int a = (int) (200 * Math.sin(ph * Math.PI) * (0.4f + 0.6f * tw));
                p.setColor(Color.HSVToColor(Math.max(0, a), new float[] {(i * 37f + now / 25f) % 360f, 0.6f, 1f}));
                c.drawCircle(x, y, dp(1) + (i % 3) * 0.7f * d, p);
            }
            // CRT scanlines
            p.setColor(Color.argb(46, 0, 0, 0));
            float step = Math.max(3f, 3f * d);
            for (float y = 0; y < h; y += step) c.drawRect(0, y, w, y + Math.max(1f, d), p);
            // a bright scan line rolling down the screen, like a CRT refresh
            float sy = ((now % 5200L) / 5200f) * (h * 1.3f) - h * 0.15f;
            p.setShader(new LinearGradient(0, sy - h * 0.07f, 0, sy + h * 0.07f, new int[] {0x00ffffff, 0x2cffffff, 0x00ffffff}, null, Shader.TileMode.CLAMP));
            c.drawRect(0, sy - h * 0.07f, w, sy + h * 0.07f, p);
            p.setShader(null);
            // vignette
            p.setShader(new RadialGradient(r.exactCenterX(), r.exactCenterY(), Math.max(w, h) * 0.78f,
                    Color.argb(0, 0, 0, 0), Color.argb(200, 0, 0, 0), Shader.TileMode.CLAMP));
            c.drawRect(r, p);
            p.setShader(null);
        }
        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.OPAQUE; }
    }
}
