package shim.awt;

import shim.awt.image.ImageObserver;

public abstract class Graphics {
    public abstract void setColor(Color c);
    public abstract Color getColor();
    public abstract void setFont(Font f);
    public abstract Font getFont();
    public abstract FontMetrics getFontMetrics();
    public abstract FontMetrics getFontMetrics(Font f);
    public abstract void translate(int x, int y);
    public abstract void clipRect(int x, int y, int w, int h);
    public abstract Shape getClip();
    public abstract Rectangle getClipBounds();
    public abstract void setClip(Shape s);
    public abstract void setClip(int x, int y, int w, int h);
    public abstract void fillRect(int x, int y, int w, int h);
    public abstract void drawRect(int x, int y, int w, int h);
    public abstract void drawLine(int x1, int y1, int x2, int y2);
    public abstract boolean drawImage(Image img, int x, int y, ImageObserver obs);
    public abstract boolean drawImage(Image img, int x, int y, int w, int h, ImageObserver obs);
    public abstract void drawString(String s, int x, int y);
    public abstract void dispose();
}
