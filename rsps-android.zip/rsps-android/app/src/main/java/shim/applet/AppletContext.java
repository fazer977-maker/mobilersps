package shim.applet;

import java.net.URL;

public interface AppletContext {
    void showDocument(URL url, String target);
    void showDocument(URL url);
}
