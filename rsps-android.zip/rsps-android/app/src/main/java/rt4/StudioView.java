package rt4;

/** Drag-to-spin for the Character Studio's full-body preview (model components with client code 1501). */
public final class StudioView {
    public static volatile int yaw;
    private static int lastX = -1;
    private static int lastLoop = -1;

    private StudioView() {}

    public static void drag(boolean pressed, int mouseX) {
        if (client.loop == lastLoop) return;
        lastLoop = client.loop;
        if (pressed) {
            if (lastX >= 0) yaw = (yaw - (mouseX - lastX) * 5) & 0x7FF;
            lastX = mouseX;
        } else {
            lastX = -1;
        }
    }
}
