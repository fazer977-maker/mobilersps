package rt4;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/** Remembers the last successful login (app-private file) and signs in with it once per app start. */
public final class SavedAccount {
    private static String pendingUser, pendingPass;
    private static volatile String[] pendingRequest;
    private static volatile boolean rememberMe = true;

    private static File file() {
        String home = System.getProperty("clientHomeOverride");
        return home == null ? null : new File(home, "account.txt");
    }

    /** Called when a login attempt starts. */
    public static void attempt(JagString user, JagString pass) {
        pendingUser = user.toString();
        pendingPass = pass.toString();
    }

    /** Called when the server accepted the login. */
    public static void success() {
        File f = file();
        if (!rememberMe || f == null || pendingUser == null || pendingUser.isEmpty()) {
            return;
        }
        try {
            Files.write(f.toPath(), (pendingUser + "\n" + pendingPass + "\n").getBytes(StandardCharsets.ISO_8859_1));
        } catch (Throwable ignored) {
        }
    }

    /** Queue a login from the Android login screen; the client thread starts it. */
    public static void request(String user, String pass, boolean remember) {
        rememberMe = remember;
        if (!remember) {
            forget();
        }
        pendingRequest = new String[] {user, pass};
    }

    public static void forget() {
        File f = file();
        if (f != null) {
            f.delete();
        }
    }

    private static volatile boolean logoutRequested;

    /** Incremented once per rendered frame (lets the app wait for the client to see a new cursor position). */
    public static volatile int frames;

    // ---- automatic reconnect after an unexpected disconnect
    public static volatile boolean reconnecting;
    public static boolean intentionalLogout;
    private static boolean wasInWorld;
    private static long reconnectAt;
    private static int reconnectTries;
    private static boolean reconnectBusy;

    /** Called from LoginManager.processLogout (every way of ending up on the login screen). */
    public static void onLogout() {
        boolean fromWorld = wasInWorld;
        wasInWorld = false;
        boolean intended = intentionalLogout;
        intentionalLogout = false;
        if (fromWorld && !intended && pendingUser != null && !pendingUser.isEmpty() && pendingPass != null) {
            reconnecting = true;
            reconnectTries = 0;
            reconnectBusy = false;
            reconnectAt = System.currentTimeMillis() + 2500L;
        } else {
            reconnecting = false;
        }
    }


    /** Ask the client thread to log out (same packet the game sends on idle logout). */
    public static void requestLogout() {
        logoutRequested = true;
    }

    /** Called every frame on the client thread. */
    public static void tick() {
        frames++;
        if (client.gameState == 30) {
            wasInWorld = true;
            reconnecting = false;
            reconnectBusy = false;
        }
        if (reconnecting && client.gameState == 10 && pendingRequest == null) {
            boolean idle = LoginManager.hopStep == 0 && LoginManager.step == 0 && CreateManager.step == 0 && WorldList.step == 0;
            if (reconnectBusy && idle) {
                // the attempt we started has finished without reaching the world
                reconnectBusy = false;
                int r = LoginManager.reply;
                if (r == 3 || r == 4 || reconnectTries >= 8) {
                    reconnecting = false;
                } else {
                    reconnectAt = System.currentTimeMillis() + 4000L;
                }
            } else if (!reconnectBusy && idle && reconnecting && System.currentTimeMillis() >= reconnectAt) {
                reconnectTries++;
                reconnectBusy = true;
                LoginManager.startLogin(JagString.of(pendingUser), JagString.of(pendingPass), 0);
            }
        }
        if (logoutRequested) {
            intentionalLogout = true;
            logoutRequested = false;
            if (client.gameState == 30 && Protocol.socket != null) {
                Protocol.outboundBuffer.p1isaac(245);
                Protocol.logoutOnDisconnectTimer = 250;
            }
        }
        String[] r = pendingRequest;
        if (r == null || client.gameState != 10) {
            return;
        }
        if (LoginManager.hopStep != 0 || LoginManager.step != 0 || CreateManager.step != 0 || WorldList.step != 0) {
            return;
        }
        pendingRequest = null;
        LoginManager.startLogin(JagString.of(r[0]), JagString.of(r[1]), 0);
    }
}
