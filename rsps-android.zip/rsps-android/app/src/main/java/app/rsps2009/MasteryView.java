package app.rsps2009;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;

import rt4.Mastery;
import rt4.RsFont;

/**
 * The Mastery window (levels 100 to 1000 after 99) and each skill's talent tree, plus the level-up banner,
 * drawn like a real RuneScape interface: everything is laid out in game pixels on a small bitmap (stone window,
 * sunken panels, stone buttons, the game's own fonts and pixel icons) and scaled up with no smoothing.
 * Opens when the server says so (tapping a 99 skill in the stats tab, or ::mastery). Touches pass through when closed.
 */
final class MasteryView extends View {
    private static final String[] NAME = {"Attack", "Defence", "Strength", "Hitpoints", "Ranged", "Prayer", "Magic", "Cooking",
            "Woodcutting", "Fletching", "Fishing", "Firemaking", "Crafting", "Smithing", "Mining", "Herblore", "Agility", "Thieving",
            "Slayer", "Farming", "Runecrafting", "Hunter", "Construction", "Summoning"};
    /** stats tab order, 3 columns */
    private static final int[] ORDER = {0, 3, 14, 2, 16, 13, 1, 15, 10, 4, 17, 7, 5, 12, 11, 6, 9, 8, 20, 18, 19, 22, 21, 23};
    private static final int W0 = 488, H0 = 304;                 // window size in game pixels
    private static final int BW = 220, BH = 44;                  // banner size in game pixels
    private static final int P11 = RsFont.P11, P12 = RsFont.P12, B12 = RsFont.B12;

    private final RsUi ui = new RsUi();
    private final Paint blit = new Paint();
    private final Paint dim = new Paint();
    private Bitmap buf, bannerBuf;
    private Canvas bc, bannerC;
    private final Rect dstR = new Rect(), bannerR = new Rect();
    private int scale = 2;

    // hit boxes, in game pixels
    private final Rect guideBtn = new Rect(), closeBtn = new Rect(), talentBtn = new Rect(), xBtn = new Rect();
    private final Rect addBtn = new Rect(), resetBtn = new Rect(), backBtn = new Rect();
    private final Rect[] cells = new Rect[24], nodes = new Rect[6];
    private boolean open, talents;
    private int pressed = -1;                    // 0 guide 1 close 2 talents 3 learn 4 reset 5 back 6 X
    private int sel = -1, seenOpen, seenUp, tSkill = -1, node = 0;
    private long upAt, resetArmed;
    private int upSkill, upLevel;

    MasteryView(Context c) {
        super(c);
        blit.setFilterBitmap(false); blit.setAntiAlias(false); blit.setDither(false);
        dim.setColor(0x88000000);
        for (int i = 0; i < 24; i++) cells[i] = new Rect();
        for (int i = 0; i < 6; i++) nodes[i] = new Rect();
        seenOpen = Mastery.openVersion; seenUp = Mastery.upVersion;
        setVisibility(GONE);
    }

    /** UI poller (every 50 ms) */
    void sync(boolean ok) {
        long now = System.currentTimeMillis();
        if (Mastery.openVersion != seenOpen) {
            seenOpen = Mastery.openVersion;
            if (ok) { open = true; talents = false; int s = Mastery.openSkill; sel = s >= 0 && s < 24 ? s : firstMastered(); }
        }
        if (Mastery.upVersion != seenUp) { seenUp = Mastery.upVersion; upAt = now; upSkill = Mastery.upSkill; upLevel = Mastery.upLevel; }
        if (!ok) open = false;
        boolean banner = ok && upAt > 0 && now - upAt < 3800;
        boolean vis = open || banner;
        if ((getVisibility() == VISIBLE) != vis) setVisibility(vis ? VISIBLE : GONE);
        if (vis) invalidate();
    }

    private static int firstMastered() {
        int best = -1, bl = 0;
        for (int i = 0; i < 24; i++) if (Mastery.level[i] > bl) { bl = Mastery.level[i]; best = i; }
        return best;
    }

    private static String perk(int s, int over) {
        String f02 = num(over * 0.02), f03 = num(over * 0.03);
        switch (s) {
            case 0: return "+" + f02 + "% melee accuracy";
            case 2: return "+" + f02 + "% melee max hit";
            case 1: return "+" + f02 + "% defence";
            case 4: return "+" + f02 + "% ranged accuracy and damage";
            case 6: return "+" + f02 + "% magic accuracy";
            case 3: return "+" + f02 + "% healing";
            case 5: return "-" + f03 + "% prayer drain";
            case 14: case 8: case 10: return f03 + "% chance of double resources";
            default: return null;
        }
    }

    private static String num(double v) {
        String s = String.format(java.util.Locale.US, "%.2f", v);
        while (s.contains(".") && (s.endsWith("0") || s.endsWith("."))) s = s.substring(0, s.length() - 1);
        return s;
    }

    private static String fill(String tpl, double v) { return tpl == null ? "" : tpl.replace("{}", num(v)); }

    private static String cap1(String s) { return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1); }

    // ------------------------------------------------------------------ frame
    @Override protected void onDraw(Canvas c) {
        long now = System.currentTimeMillis();
        int W = getWidth(), H = getHeight();
        scale = Math.max(1, Math.min((int) (W * 0.96f / W0), (int) (H * 0.94f / H0)));
        if (open) {
            if (buf == null) { buf = Bitmap.createBitmap(W0, H0, Bitmap.Config.ARGB_8888); bc = new Canvas(buf); }
            buf.eraseColor(0);
            if (talents) drawTalents(bc, now); else drawOverview(bc);
            c.drawRect(0, 0, W, H, dim);
            int dw = W0 * scale, dh = H0 * scale;
            dstR.set((W - dw) / 2, (H - dh) / 2, (W - dw) / 2 + dw, (H - dh) / 2 + dh);
            c.drawBitmap(buf, null, dstR, blit);
        }
        if (upAt > 0 && now - upAt < 3800) {
            if (bannerBuf == null) { bannerBuf = Bitmap.createBitmap(BW, BH, Bitmap.Config.ARGB_8888); bannerC = new Canvas(bannerBuf); }
            bannerBuf.eraseColor(0);
            drawBanner(bannerC);
            long t = now - upAt;
            float a = t < 250 ? t / 250f : t > 3000 ? (3800 - t) / 800f : 1f;
            int bw = BW * scale, bh = BH * scale;
            int top = (int) (H * 0.14f - (1 - Math.min(1f, t / 250f)) * 6 * scale);
            bannerR.set((W - bw) / 2, top, (W - bw) / 2 + bw, top + bh);
            blit.setAlpha(Math.max(0, Math.min(255, (int) (255 * a))));
            c.drawBitmap(bannerBuf, null, bannerR, blit);
            blit.setAlpha(255);
        }
    }

    private void titleBar(Canvas c, String title) {
        ui.window(c, 0, 0, W0, H0);
        ui.text(c, B12, title, W0 / 2, 21, RsUi.ORANGE, 1, true);
        xBtn.set(W0 - 26, 7, W0 - 8, 25);
        ui.raised(c, xBtn.left, xBtn.top, 18, 18, pressed == 6, false);
        int o = pressed == 6 ? 1 : 0;
        for (int k = 0; k < 8; k++) {                       // the X
            ui.fill(c, xBtn.left + 5 + k + o, xBtn.top + 5 + k + o, 2, 1, 0xFFE0C9A6);
            ui.fill(c, xBtn.left + 12 - k + o, xBtn.top + 5 + k + o, 2, 1, 0xFFE0C9A6);
        }
    }

    // ------------------------------------------------------------------ overview
    private void drawOverview(Canvas c) {
        titleBar(c, "Mastery");
        int total = 0, at99 = 0;
        for (int i = 0; i < 24; i++) { if (Mastery.level[i] > 99) total += Mastery.level[i] - 99; if (Mastery.level[i] >= 99) at99++; }
        ui.text(c, P11, "Levels 100 to 1000, earned with XP after 99", 12, 40, RsUi.PARCH, 0, true);
        String tv = String.valueOf(total);
        int tw = ui.width(P11, tv);
        ui.text(c, P11, tv, W0 - 12, 40, RsUi.YELLOW, 2, true);
        ui.text(c, P11, "Total Mastery: ", W0 - 12 - tw, 40, RsUi.ORANGE, 2, true);

        // skill grid
        int gx = 8, gy = 46, gw = 282, gh = H0 - 8 - gy;
        ui.inset(c, gx, gy, gw, gh);
        int cw = (gw - 8) / 3, ch = (gh - 8) / 8;
        for (int k = 0; k < 24; k++) {
            int s = ORDER[k], col = k % 3, row = k / 3;
            int x = gx + 4 + col * cw, y = gy + 4 + row * ch;
            Rect r = cells[s]; r.set(x + 1, y + 1, x + cw - 1, y + ch - 1);
            int m = Mastery.level[s];
            ui.raised(c, r.left, r.top, r.width(), r.height(), false, s == sel);
            if (s == sel) ui.outline(c, r.left - 1, r.top - 1, r.width() + 2, r.height() + 2, RsUi.WHITE);
            ui.text(c, P11, NAME[s], r.left + 5, r.top + 14, m >= 99 ? RsUi.WHITE : RsUi.GREY, 0, true);
            ui.text(c, P12, m >= 100 ? String.valueOf(m) : m == 99 ? "99" : "-", r.right - 5, r.top + 14, m >= 100 ? RsUi.YELLOW : m == 99 ? RsUi.WHITE : RsUi.GREY, 2, true);
            if (m >= 99) ui.bar(c, r.left + 5, r.bottom - 9, r.width() - 10, 5, m >= 1000 ? 1f : Mastery.progress[s] / 1000f);
        }

        // details
        int px = 296, py = gy, pw = W0 - 8 - px, ph = gh;
        ui.inset(c, px, py, pw, ph);
        int lx = px + 8, w = pw - 16;
        talentBtn.setEmpty(); guideBtn.setEmpty();
        int bh = 22, rowY = py + ph - 8 - bh, half = (w - 6) / 2;
        if (sel < 0) {
            ui.text(c, B12, "Getting started", lx, py + 20, RsUi.ORANGE, 0, true);
            int y = ui.wrap(c, P11, "Reach level 99 in any skill to begin its Mastery. Every point of XP you earn after 99 counts toward Mastery levels 100 to 1000.", lx, py + 38, w, RsUi.WHITE);
            ui.wrap(c, P11, "Each level adds a small permanent perk, and talent points unlock as you climb.", lx, y + 6, w, RsUi.PARCH);
            closeBtn.set(lx, rowY, lx + w, rowY + bh);
            ui.button(c, closeBtn.left, closeBtn.top, closeBtn.width(), bh, "Close", RsUi.ORANGE, pressed == 1);
            return;
        }
        int m = Mastery.level[sel];
        ui.raised(c, lx, py + 8, 34, 34, false, m >= 100);
        String ic = Glyphs.forSkill(sel);
        if (ic != null) ui.icon(c, ic, lx + 17, py + 25, 22, m >= 100 ? RsUi.ORANGE : RsUi.PARCH);
        else ui.text(c, B12, NAME[sel].substring(0, 1), lx + 17, py + 31, m >= 100 ? RsUi.ORANGE : RsUi.PARCH, 1, true);
        ui.text(c, B12, NAME[sel], lx + 42, py + 22, RsUi.ORANGE, 0, true);
        if (m >= 100) {
            String lv = "Mastery " + m;
            ui.text(c, P12, lv, lx + 42, py + 38, RsUi.YELLOW, 0, true);
            ui.text(c, P11, " / 1000", lx + 42 + ui.width(P12, lv), py + 38, RsUi.GREY, 0, true);
        } else {
            ui.text(c, P11, m == 99 ? "Level 99 - Mastery begins now" : "Mastery begins at level 99", lx + 42, py + 38, RsUi.PARCH, 0, true);
        }
        int y = py + 52;
        if (m >= 99) {
            float f = m >= 1000 ? 1f : Mastery.progress[sel] / 1000f;
            ui.bar(c, lx, y, w, 15, f);
            String pct = m >= 1000 ? "Maxed" : (Mastery.progress[sel] / 10) + "." + (Mastery.progress[sel] % 10) + "% to " + (m + 1);
            ui.text(c, P11, pct, lx + w / 2, y + 12, RsUi.WHITE, 1, true);
            y += 34;
            ui.text(c, P11, "Mastery perk:", lx, y, RsUi.ORANGE, 0, true);
            String pk = perk(sel, Math.max(0, m - 99));
            if (pk != null) {
                y = ui.wrap(c, P11, cap1(pk), lx, y + 14, w, RsUi.WHITE);
                ui.wrap(c, P11, "At 1000: " + perk(sel, 901), lx, y + 2, w, RsUi.PARCH);
            } else {
                ui.wrap(c, P11, "Arrives with this skill's talents.", lx, y + 14, w, RsUi.PARCH);
            }
        }
        if (Mastery.hasTree(sel) && m >= 100) {
            talentBtn.set(lx, rowY - bh - 6, lx + w, rowY - 6);
            int free = Mastery.tKnown[sel] ? Mastery.tFree[sel] : -1;
            ui.button(c, talentBtn.left, talentBtn.top, w, bh, free > 0 ? "Talents (" + free + " to spend)" : "Talents", free > 0 ? RsUi.GREEN : RsUi.ORANGE, pressed == 2);
        }
        guideBtn.set(lx, rowY, lx + half, rowY + bh);
        closeBtn.set(lx + half + 6, rowY, lx + w, rowY + bh);
        ui.button(c, guideBtn.left, guideBtn.top, guideBtn.width(), bh, "Skill guide", RsUi.ORANGE, pressed == 0);
        ui.button(c, closeBtn.left, closeBtn.top, closeBtn.width(), bh, "Close", RsUi.ORANGE, pressed == 1);
    }

    // ------------------------------------------------------------------ talents
    private boolean locked(int i) { return i % 2 == 1 && Mastery.tRank[tSkill][i - 1] < 5; }

    private void drawTalents(Canvas c, long now) {
        int s = tSkill;
        boolean known = Mastery.tKnown[s];
        titleBar(c, NAME[s] + " Talents");
        int lvl = Mastery.level[s];
        ui.text(c, P11, (lvl >= 100 ? "Mastery " + lvl + " - " : "") + "1 talent point every 20 Mastery levels", 12, 40, RsUi.PARCH, 0, true);
        if (known) {
            String tot = " / " + Mastery.tTotal[s], fr = String.valueOf(Mastery.tFree[s]);
            int x = W0 - 12;
            ui.text(c, P11, tot, x, 40, RsUi.GREY, 2, true); x -= ui.width(P11, tot);
            ui.text(c, P11, fr, x, 40, Mastery.tFree[s] > 0 ? RsUi.GREEN : RsUi.WHITE, 2, true); x -= ui.width(P11, fr);
            ui.text(c, P11, "Points: ", x, 40, RsUi.ORANGE, 2, true);
        }

        // tree
        int gx = 8, gy = 46, gw = 282, gh = H0 - 8 - gy;
        ui.inset(c, gx, gy, gw, gh);
        int colW = (gw - 8) / 3, slot = 36;
        int y1 = gy + 30, y2 = gy + 142;
        for (int b = 0; b < 3; b++) {
            int cx = gx + 4 + colW * b + colW / 2;
            ui.text(c, P11, "Path " + (b == 0 ? "I" : b == 1 ? "II" : "III"), cx, gy + 18, RsUi.ORANGE, 1, true);
            int r0 = known ? Mastery.tRank[s][b * 2] : 0;
            int ya = y1 + slot + 32, yb = y2 - 6;
            ui.fill(c, cx - 2, ya, 4, yb - ya, 0xFF000000);
            ui.fill(c, cx - 1, ya + 1, 2, yb - ya - 2, 0xFF3A2F24);
            int fh = (int) ((yb - ya - 2) * Math.min(1f, r0 / 5f));
            if (fh > 0) ui.fill(c, cx - 1, ya + 1, 2, fh, RsUi.ORANGE);
            for (int tier = 0; tier < 2; tier++) {
                int i = b * 2 + tier;
                int ty = tier == 0 ? y1 : y2;
                boolean lock = known && locked(i);
                int rank = known ? Mastery.tRank[s][i] : 0, mx = Math.max(1, Mastery.tMax[s]);
                int sx = cx - slot / 2;
                nodes[i].set(cx - colW / 2 + 2, ty - 4, cx + colW / 2 - 2, ty + slot + 30);
                if (lock) ui.inset(c, sx, ty, slot, slot); else ui.raised(c, sx, ty, slot, slot, false, rank > 0);
                if (i == node) { ui.outline(c, sx - 2, ty - 2, slot + 4, slot + 4, RsUi.WHITE); }
                String ic = known ? Glyphs.forEffect(Mastery.tEff[s][i]) : "star";
                ui.icon(c, ic, cx, ty + slot / 2, 22, lock ? RsUi.DARK : rank > 0 ? RsUi.ORANGE : RsUi.PARCH);
                if (lock) ui.lock(c, sx + slot - 10, ty + slot - 11);
                if (rank >= mx) ui.outline(c, sx + 2, ty + 2, slot - 4, slot - 4, RsUi.YELLOW);
                String nm = known && Mastery.tName[s][i] != null ? Mastery.tName[s][i] : "...";
                ui.text(c, P11, nm, cx, ty + slot + 13, lock ? RsUi.GREY : RsUi.WHITE, 1, true);
                ui.text(c, P11, rank + "/" + mx, cx, ty + slot + 25, lock ? RsUi.GREY : rank > 0 ? RsUi.YELLOW : RsUi.PARCH, 1, true);
            }
        }

        // details
        int px = 296, py = gy, pw = W0 - 8 - px, ph = gh;
        ui.inset(c, px, py, pw, ph);
        int lx = px + 8, w = pw - 16;
        int bh = 22, rowY = py + ph - 8 - bh, half = (w - 6) / 2;
        if (!known) {
            ui.text(c, P12, "Loading talents...", lx, py + 22, RsUi.PARCH, 0, true);
        } else {
            int i = node, rank = Mastery.tRank[s][i], mx = Mastery.tMax[s];
            double per = Mastery.tPer[s][i];
            boolean lock = locked(i);
            ui.raised(c, lx, py + 8, 34, 34, false, rank > 0);
            ui.icon(c, Glyphs.forEffect(Mastery.tEff[s][i]), lx + 17, py + 25, 22, lock ? RsUi.DARK : rank > 0 ? RsUi.ORANGE : RsUi.PARCH);
            ui.text(c, B12, Mastery.tName[s][i], lx + 42, py + 22, RsUi.ORANGE, 0, true);
            ui.text(c, P11, (i % 2 == 0 ? "Tier 1" : "Tier 2") + " - Path " + (i / 2 == 0 ? "I" : i / 2 == 1 ? "II" : "III"), lx + 42, py + 37, RsUi.PARCH, 0, true);
            int y = py + 50;
            int pip = (w - (mx - 1) * 2) / mx;
            for (int k = 0; k < mx; k++) {
                int x = lx + k * (pip + 2);
                ui.fill(c, x, y, pip, 7, 0xFF000000);
                ui.fill(c, x + 1, y + 1, pip - 2, 5, k < rank ? 0xFF2E8B22 : 0xFF3A1010);
                if (k < rank) ui.fill(c, x + 1, y + 1, pip - 2, 1, 0xFF56C443);
            }
            ui.text(c, P11, "Rank " + rank + " of " + mx, lx, y + 20, RsUi.WHITE, 0, true);
            y += 38;
            ui.text(c, P11, "Current:", lx, y, RsUi.ORANGE, 0, true);
            y = ui.wrap(c, P11, rank > 0 ? cap1(fill(Mastery.tText[s][i], per * rank)) : "Not learned yet.", lx, y + 13, w, rank > 0 ? RsUi.WHITE : RsUi.PARCH);
            if (rank < mx) {
                ui.text(c, P11, "Next rank:", lx, y + 4, RsUi.ORANGE, 0, true);
                y = ui.wrap(c, P11, cap1(fill(Mastery.tText[s][i], per * (rank + 1))), lx, y + 17, w, RsUi.YELLOW);
            } else {
                ui.text(c, P11, "Fully learned!", lx, y + 4, RsUi.GREEN, 0, true);
                y += 17;
            }
            if (lock) ui.wrap(c, P11, "Requires 5 ranks in " + Mastery.tName[s][i - 1] + ".", lx, y + 4, w, RsUi.RED);
        }
        boolean canAdd = known && Mastery.tFree[s] > 0 && Mastery.tRank[s][node] < Mastery.tMax[s] && !locked(node);
        String addLabel = !known ? "Learn rank" : Mastery.tRank[s][node] >= Mastery.tMax[s] ? "Maxed" : locked(node) ? "Locked"
                : Mastery.tFree[s] <= 0 ? "No points to spend" : "Learn rank";
        addBtn.set(lx, rowY - bh - 6, lx + w, rowY - 6);
        ui.button(c, addBtn.left, addBtn.top, w, bh, addLabel, canAdd ? RsUi.GREEN : RsUi.GREY, pressed == 3 && canAdd);
        resetBtn.set(lx, rowY, lx + half, rowY + bh);
        backBtn.set(lx + half + 6, rowY, lx + w, rowY + bh);
        ui.button(c, resetBtn.left, resetBtn.top, resetBtn.width(), bh, now - resetArmed < 3000 ? "Confirm?" : "Reset (500k)", RsUi.RED, pressed == 4);
        ui.button(c, backBtn.left, backBtn.top, backBtn.width(), bh, "Back", RsUi.ORANGE, pressed == 5);
    }

    // ------------------------------------------------------------------ level-up banner
    private void drawBanner(Canvas c) {
        ui.window(c, 0, 0, BW, BH);
        String sk = upSkill >= 0 && upSkill < 24 ? NAME[upSkill] : "";
        String ic = Glyphs.forSkill(upSkill);
        ui.text(c, P11, "Mastery level up!", BW / 2, 17, RsUi.ORANGE, 1, true);
        String big = sk + " " + upLevel;
        int tw = ui.width(B12, big) + (ic != null ? 20 : 0);
        int x = BW / 2 - tw / 2;
        if (ic != null) { ui.icon(c, ic, x + 8, 30, 16, RsUi.ORANGE); x += 20; }
        ui.text(c, B12, big, x, 36, RsUi.YELLOW, 0, true);
    }

    // ------------------------------------------------------------------ touch
    @Override public boolean onTouchEvent(MotionEvent e) {
        if (!open) return false;
        int x = (int) Math.floor((e.getX() - dstR.left) / (float) scale), y = (int) Math.floor((e.getY() - dstR.top) / (float) scale);
        boolean inside = x >= 0 && y >= 0 && x < W0 && y < H0;
        int a = e.getActionMasked();
        Rect[] btns = {guideBtn, closeBtn, talentBtn, addBtn, resetBtn, backBtn, xBtn};
        if (a == MotionEvent.ACTION_DOWN) {
            pressed = -1;
            for (int i = 0; i < btns.length; i++) {
                if (i < 6 && ((talents && i < 3) || (!talents && i >= 3))) continue;
                if (btns[i].contains(x, y)) { pressed = i; break; }
            }
            invalidate();
        } else if (a == MotionEvent.ACTION_UP) {
            int b = pressed; pressed = -1;
            if (b >= 0 && !btns[b].contains(x, y)) b = -1;
            long now = System.currentTimeMillis();
            if (b == 6) { open = false; invalidate(); return true; }
            if (talents) {
                if (b == 3) {
                    if (Mastery.tKnown[tSkill] && Mastery.tFree[tSkill] > 0 && !locked(node) && Mastery.tRank[tSkill][node] < Mastery.tMax[tSkill])
                        Mastery.want("mstal " + tSkill + " " + node);
                } else if (b == 4) { if (now - resetArmed < 3000) { resetArmed = 0; Mastery.want("msreset " + tSkill); } else resetArmed = now; }
                else if (b == 5) talents = false;
                else if (b < 0 && !inside) open = false;
                else if (b < 0) { for (int i = 0; i < 6; i++) if (nodes[i].contains(x, y)) { node = i; break; } }
            } else {
                if (b == 2 && sel >= 0) { talents = true; tSkill = sel; node = 0; resetArmed = 0; Mastery.want("mstree " + sel); }
                else if (b == 0 && sel >= 0) { Mastery.want("msguide " + sel); open = false; }
                else if (b == 1 || (b < 0 && !inside)) open = false;
                else if (b < 0) { for (int s = 0; s < 24; s++) if (cells[s].contains(x, y)) { sel = s; break; } }
            }
            invalidate();
        } else if (a == MotionEvent.ACTION_CANCEL) { pressed = -1; invalidate(); }
        return true;
    }
}
