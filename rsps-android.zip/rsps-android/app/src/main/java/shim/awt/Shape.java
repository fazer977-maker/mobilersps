package shim.awt;

public interface Shape {
    Rectangle getBounds();
}
