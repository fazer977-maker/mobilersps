package shim.awt.event;

import shim.awt.AWTEvent;

public class ActionEvent extends AWTEvent {
    private final String command;
    public ActionEvent(Object source, int id, String command) { super(source, id); this.command = command; }
    public String getActionCommand() { return command; }
}
