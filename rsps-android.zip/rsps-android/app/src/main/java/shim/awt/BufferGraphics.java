package shim.awt;

import shim.awt.image.BufferedImage;
import shim.awt.image.ImageObserver;
import shim.platform.Platforms;

/** Pure-Java software Graphics that draws into a BufferedImage, optionally presenting to the screen. */
public class BufferGraphics extends Graphics {
    private final BufferedImage target;
    private final Canvas canvas; // non-null when this is the on-screen graphics
    private Color color = Color.black;
    private Font font = new Font("SansSerif", Font.PLAIN, 12);
    private Rectangle clip; // null = whole target
    private int tx, ty;

    public BufferGraphics(BufferedImage target, Canvas canvas) {
        this.target = target;
        this.canvas = canvas;
    }

    private Rectangle effectiveClip() {
        Rectangle all = new Rectangle(0, 0, target.getWidth(), target.getHeight());
        return clip == null ? all : all.intersection(clip);
    }

    @Override public void setColor(Color c) { if (c != null) color = c; }
    @Override public Color getColor() { return color; }
    @Override public void setFont(Font f) { if (f != null) font = f; }
    @Override public Font getFont() { return font; }
    @Override public FontMetrics getFontMetrics() { return new FontMetrics(font); }
    @Override public FontMetrics getFontMetrics(Font f) { return new FontMetrics(f); }
    @Override public void translate(int x, int y) { tx += x; ty += y; }

    @Override public void clipRect(int x, int y, int w, int h) {
        Rectangle r = new Rectangle(x + tx, y + ty, w, h);
        clip = clip == null ? r : clip.intersection(r);
    }
    @Override public Shape getClip() { return clip == null ? null : new Rectangle(clip.x - tx, clip.y - ty, clip.width, clip.height); }
    @Override public Rectangle getClipBounds() { return clip == null ? null : new Rectangle(clip.x - tx, clip.y - ty, clip.width, clip.height); }
    @Override public void setClip(Shape s) {
        if (s == null) { clip = null; return; }
        Rectangle b = s.getBounds();
        clip = new Rectangle(b.x + tx, b.y + ty, b.width, b.height);
    }
    @Override public void setClip(int x, int y, int w, int h) { clip = new Rectangle(x + tx, y + ty, w, h); }

    @Override public void fillRect(int x, int y, int w, int h) {
        Rectangle r = new Rectangle(x + tx, y + ty, w, h).intersection(effectiveClip());
        if (r.isEmpty()) return;
        int argb = color.getRGB();
        int tw = target.getWidth();
        for (int yy = r.y; yy < r.y + r.height; yy++) {
            java.util.Arrays.fill(target.data, yy * tw + r.x, yy * tw + r.x + r.width, argb);
        }
        dirty(r);
    }
    @Override public void drawRect(int x, int y, int w, int h) {
        if (w < 0 || h < 0) return;
        fillRect(x, y, w + 1, 1);
        fillRect(x, y + h, w + 1, 1);
        fillRect(x, y, 1, h + 1);
        fillRect(x + w, y, 1, h + 1);
    }
    @Override public void drawLine(int x1, int y1, int x2, int y2) {
        int dx = Math.abs(x2 - x1), dy = Math.abs(y2 - y1), sx = x1 < x2 ? 1 : -1, sy = y1 < y2 ? 1 : -1, err = dx - dy;
        while (true) {
            fillRect(x1, y1, 1, 1);
            if (x1 == x2 && y1 == y2) break;
            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x1 += sx; }
            if (e2 < dx) { err += dx; y1 += sy; }
        }
    }

    @Override public boolean drawImage(Image img, int x, int y, ImageObserver obs) {
        if (!(img instanceof BufferedImage)) return false;
        BufferedImage src = (BufferedImage) img;
        int sw = src.getWidth(), sh = src.getHeight();
        // fast path: full frame straight to the screen
        if (canvas != null && x + tx == 0 && y + ty == 0 && sw == target.getWidth() && sh == target.getHeight()
                && src.getType() != BufferedImage.TYPE_INT_ARGB) {
            Rectangle c = effectiveClip();
            if (!c.isEmpty()) {
                Platforms.current.present(src.data, sw, sh, c.x, c.y, c.width, c.height);
            }
            return true;
        }
        Rectangle r = new Rectangle(x + tx, y + ty, sw, sh).intersection(effectiveClip());
        if (r.isEmpty()) return true;
        int tw = target.getWidth();
        boolean alpha = src.getType() == BufferedImage.TYPE_INT_ARGB;
        for (int yy = r.y; yy < r.y + r.height; yy++) {
            int so = (yy - (y + ty)) * sw + (r.x - (x + tx));
            int to = yy * tw + r.x;
            if (!alpha) {
                System.arraycopy(src.data, so, target.data, to, r.width);
            } else {
                for (int i = 0; i < r.width; i++) {
                    int p = src.data[so + i];
                    int a = p >>> 24;
                    if (a == 255) target.data[to + i] = p;
                    else if (a != 0) {
                        int d = target.data[to + i];
                        int rr = ((p >> 16 & 255) * a + (d >> 16 & 255) * (255 - a)) / 255;
                        int gg = ((p >> 8 & 255) * a + (d >> 8 & 255) * (255 - a)) / 255;
                        int bb = ((p & 255) * a + (d & 255) * (255 - a)) / 255;
                        target.data[to + i] = 0xFF000000 | rr << 16 | gg << 8 | bb;
                    }
                }
            }
        }
        dirty(r);
        if (canvas != null) canvas.flushDirty();
        return true;
    }
    @Override public boolean drawImage(Image img, int x, int y, int w, int h, ImageObserver obs) {
        return drawImage(img, x, y, obs);
    }

    @Override public void drawString(String s, int x, int y) {
        if (s == null || s.isEmpty()) return;
        Platforms.current.drawText(target.data, target.getWidth(), target.getHeight(), s, x + tx, y + ty,
                font.getName(), font.getStyle(), font.getSize(), color.getRGB());
        dirty(new Rectangle(x + tx, y + ty - font.getSize(), font.getSize() * s.length(), font.getSize() * 2));
        if (canvas != null) canvas.flushDirty();
    }

    private void dirty(Rectangle r) {
        if (canvas != null) canvas.markDirty(r);
    }
    @Override public void dispose() {
        if (canvas != null) canvas.flushDirty();
    }
}
