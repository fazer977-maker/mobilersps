package rt4;

import shim.awt.Component;
import shim.awt.Graphics;
import shim.awt.Image;

/** Software frame buffer: an int[] the rasteriser draws into, shown on the canvas via the platform layer. */
public abstract class FrameBuffer {

	public int[] pixels;

	protected Image image;

	protected int height;

	protected int width;

	public static FrameBuffer create(int width, int height, Component component) {
		FrameBuffer frameBuffer = new BufferedImageFrameBuffer();
		frameBuffer.init(width, height, component);
		return frameBuffer;
	}

	public abstract void draw(Graphics graphics);

	public final void makeTarget() {
		SoftwareRaster.setSize(this.pixels, this.width, this.height);
	}

	public abstract void drawAt(int x, int y, int width, Graphics graphics, int height);

	public abstract void init(int width, int height, Component component);
}
