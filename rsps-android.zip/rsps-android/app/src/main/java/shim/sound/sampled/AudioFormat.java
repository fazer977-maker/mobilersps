package shim.sound.sampled;

public class AudioFormat {
    private final float sampleRate;
    private final int bits, channels;
    public AudioFormat(float sampleRate, int bits, int channels, boolean signed, boolean bigEndian) {
        this.sampleRate = sampleRate; this.bits = bits; this.channels = channels;
    }
    public float getSampleRate() { return sampleRate; }
    public int getSampleSizeInBits() { return bits; }
    public int getChannels() { return channels; }
}
