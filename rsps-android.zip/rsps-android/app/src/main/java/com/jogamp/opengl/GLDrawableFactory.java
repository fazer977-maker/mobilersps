package com.jogamp.opengl;

import com.jogamp.nativewindow.awt.JAWTWindow;

public class GLDrawableFactory {
    private static final GLDrawableFactory F = new GLDrawableFactory();
    public static GLDrawableFactory getFactory(GLProfile p) { return F; }
    public GLDrawable createGLDrawable(JAWTWindow w) { return new GLDrawable(JAWTWindow.backend, GLCapabilities.lastSamples); }
}
