package com.jogamp.opengl;

/** JNI entry points into gl4es (generated list) plus a few helpers. */
public final class GlNative {
    public static volatile boolean ready;
    public static volatile String error = "";
    static {
        try { System.loadLibrary("gl4esbridge"); } catch (Throwable t) { error = String.valueOf(t); }
    }
    /** Loads gl4es by path (or name) and resolves every function. Call with the GL context current. */
    public static synchronized boolean init(String path) {
        if (ready) return true;
        try {
            String r = nLoad(path);
            ready = r == null || r.isEmpty();
            if (!ready) error = r;
        } catch (Throwable t) { error = String.valueOf(t); }
        return ready;
    }
    public static volatile boolean dbg;
    /** GL calls since the last reset (read by the FPS overlay). */
    public static int calls;
    static native int nGetError();
    private static final java.util.HashMap<String,Integer> counts = new java.util.HashMap<>();
    private static final StringBuilder errs = new StringBuilder();
    private static int nerr;
    static void chk(String name) {
        Integer c = counts.get(name);
        counts.put(name, c == null ? 1 : c + 1);
        int e = nGetError();
        if (e != 0 && nerr < 60) { nerr++; errs.append(name).append(':').append(Integer.toHexString(e)).append(' '); }
    }
    public static String report() {
        StringBuilder b = new StringBuilder("calls: ");
        for (java.util.Map.Entry<String,Integer> en : counts.entrySet()) b.append(en.getKey()).append('=').append(en.getValue()).append(' ');
        b.append("\nERRORS: ").append(errs.length() == 0 ? "none" : errs.toString());
        counts.clear(); errs.setLength(0); nerr = 0;
        return b.toString();
    }
    static native String nLoad(String path);
    static native void nSetCrashFile(String path);
    public static void setCrashFile(String path) { try { nSetCrashFile(path); } catch (Throwable ignored) { } }
    static native long address(java.nio.Buffer b);
    static native String glGetString(int name);
    static native void glActiveTexture_0(int a0);
    static native void glAlphaFunc_0(int a0, float a1);
    static native void glBegin_0(int a0);
    static native void glBindBuffer_0(int a0, int a1);
    static native void glBindProgramARB_0(int a0, int a1);
    static native void glBindTexture_0(int a0, int a1);
    static native void glBlendFunc_0(int a0, int a1);
    static native void glBufferData_0(int a0, long a1, long a2, int a3);
    static native void glBufferSubData_0(int a0, long a1, long a2, long a3);
    static native void glCallList_0(int a0);
    static native void glClearColor_0(float a0, float a1, float a2, float a3);
    static native void glClearDepth_0(double a0);
    static native void glClear_0(int a0);
    static native void glClientActiveTexture_0(int a0);
    static native void glColor3ub_0(byte a0, byte a1, byte a2);
    static native void glColor4fv_0(float[] a0, int a1);
    static native void glColor4f_0(float a0, float a1, float a2, float a3);
    static native void glColor4ub_0(byte a0, byte a1, byte a2, byte a3);
    static native void glColorMaterial_0(int a0, int a1);
    static native void glColorPointer_0(int a0, int a1, int a2, long a3);
    static native void glColorPointer_1(int a0, int a1, int a2, long a3);
    static native void glCopyPixels_0(int a0, int a1, int a2, int a3, int a4);
    static native void glCullFace_0(int a0);
    static native void glDeleteBuffers_0(int a0, int[] a1, int a2);
    static native void glDeleteLists_0(int a0, int a1);
    static native void glDeleteTextures_0(int a0, int[] a1, int a2);
    static native void glDepthFunc_0(int a0);
    static native void glDepthMask_0(boolean a0);
    static native void glDisableClientState_0(int a0);
    static native void glDisable_0(int a0);
    static native void glDrawBuffer_0(int a0);
    static native void glDrawElements_0(int a0, int a1, int a2, long a3);
    static native void glDrawElements_1(int a0, int a1, int a2, long a3);
    static native void glDrawPixels_0(int a0, int a1, int a2, int a3, long a4);
    static native void glEnableClientState_0(int a0);
    static native void glEnable_0(int a0);
    static native void glEndList_0();
    static native void glEnd_0();
    static native void glFogfv_0(int a0, float[] a1, int a2);
    static native void glFogf_0(int a0, float a1);
    static native void glFogi_0(int a0, int a1);
    static native void glGenBuffers_0(int a0, int[] a1, int a2);
    static native int glGenLists_0(int a0);
    static native void glGenProgramsARB_0(int a0, int[] a1, int a2);
    static native void glGenTextures_0(int a0, int[] a1, int a2);
    static native void glGenerateMipmap_0(int a0);
    static native void glGetFloatv_0(int a0, long a1);
    static native void glGetFloatv_1(int a0, float[] a1, int a2);
    static native void glGetIntegerv_0(int a0, int[] a1, int a2);
    static native void glHint_0(int a0, int a1);
    static native void glInterleavedArrays_0(int a0, int a1, long a2);
    static native void glInterleavedArrays_1(int a0, int a1, long a2);
    static native void glLightModelfv_0(int a0, float[] a1, int a2);
    static native void glLightfv_0(int a0, int a1, float[] a2, int a3);
    static native void glLightf_0(int a0, int a1, float a2);
    static native void glLineWidth_0(float a0);
    static native void glLoadIdentity_0();
    static native void glLoadMatrixf_0(float[] a0, int a1);
    static native void glMatrixMode_0(int a0);
    static native void glMultiTexCoord2f_0(int a0, float a1, float a2);
    static native void glNewList_0(int a0, int a1);
    static native void glNormalPointer_0(int a0, int a1, long a2);
    static native void glNormalPointer_1(int a0, int a1, long a2);
    static native void glOrtho_0(double a0, double a1, double a2, double a3, double a4, double a5);
    static native void glPixelZoom_0(float a0, float a1);
    static native void glPointParameterfv_0(int a0, float[] a1, int a2);
    static native void glPointParameterf_0(int a0, float a1);
    static native void glPolygonMode_0(int a0, int a1);
    static native void glPopAttrib_0();
    static native void glPopMatrix_0();
    static native void glProgramLocalParameter4fARB_0(int a0, int a1, float a2, float a3, float a4, float a5);
    static native void glProgramLocalParameter4fvARB_0(int a0, int a1, long a2);
    static native void glProgramLocalParameter4fvARB_1(int a0, int a1, float[] a2, int a3);
    static native void glProgramStringARB_0(int a0, int a1, int a2, String a3);
    static native void glPushAttrib_0(int a0);
    static native void glPushMatrix_0();
    static native void glRasterPos2i_0(int a0, int a1);
    static native void glReadBuffer_0(int a0);
    static native void glReadPixels_0(int a0, int a1, int a2, int a3, int a4, int a5, long a6);
    static native void glRotatef_0(float a0, float a1, float a2, float a3);
    static native void glScalef_0(float a0, float a1, float a2);
    static native void glScissor_0(int a0, int a1, int a2, int a3);
    static native void glShadeModel_0(int a0);
    static native void glTexCoord2f_0(float a0, float a1);
    static native void glTexCoordPointer_0(int a0, int a1, int a2, long a3);
    static native void glTexCoordPointer_1(int a0, int a1, int a2, long a3);
    static native void glTexEnvfv_0(int a0, int a1, float[] a2, int a3);
    static native void glTexEnvf_0(int a0, int a1, float a2);
    static native void glTexEnvi_0(int a0, int a1, int a2);
    static native void glTexGenfv_0(int a0, int a1, float[] a2, int a3);
    static native void glTexGeni_0(int a0, int a1, int a2);
    static native void glTexImage1D_0(int a0, int a1, int a2, int a3, int a4, int a5, int a6, long a7);
    static native void glTexImage2D_0(int a0, int a1, int a2, int a3, int a4, int a5, int a6, int a7, long a8);
    static native void glTexImage3D_0(int a0, int a1, int a2, int a3, int a4, int a5, int a6, int a7, int a8, long a9);
    static native void glTexParameteri_0(int a0, int a1, int a2);
    static native void glTexStorage2D_0(int a0, int a1, int a2, int a3, int a4);
    static native void glTexSubImage2D_0(int a0, int a1, int a2, int a3, int a4, int a5, int a6, int a7, long a8);
    static native void glTranslatef_0(float a0, float a1, float a2);
    static native void glVertex2f_0(float a0, float a1);
    static native void glVertexPointer_0(int a0, int a1, int a2, long a3);
    static native void glVertexPointer_1(int a0, int a1, int a2, long a3);
    static native void glViewport_0(int a0, int a1, int a2, int a3);
}
