package shim.awt;

import shim.awt.event.WindowListener;

public class Window extends Container {
    protected String title = "";
    protected final java.util.List<WindowListener> windowListeners = new java.util.concurrent.CopyOnWriteArrayList<>();
    public void addWindowListener(WindowListener l) { if (l != null) windowListeners.add(l); }
    public void removeWindowListener(WindowListener l) { windowListeners.remove(l); }
    public void toFront() {}
    public void toBack() {}
    public void setLocationRelativeTo(Component c) {}
    public void setIconImage(Image image) {}
    public void dispose() {}
    public void setAlwaysOnTop(boolean b) {}
}
