package com.jogamp.opengl;

public class GLProfile {
    public static final String GL3bc = "GL3bc";
    public static final String GL2 = "GL2";
    private static final GLProfile P = new GLProfile();
    public static GLProfile get(String name) { return P; }
    public static GLProfile getDefault() { return P; }
    public static void shutdown() { }
}
