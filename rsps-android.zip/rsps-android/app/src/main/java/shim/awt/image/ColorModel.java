package shim.awt.image;

public abstract class ColorModel {
    public abstract int getRGB(int pixel);
}
