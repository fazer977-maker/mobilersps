# Rainbow Scape Mobile (Android)

Android port of the 2009Scape rt4 client. Software renderer, touch input, fullscreen portrait.

## Build
Push to GitHub; Actions builds `app/build/outputs/apk/debug/*.apk` (artifact `rsps2009-debug-apk` on the run page).

## Controls
- Tap = left click, long-press = right click, drag = drag
- Two-finger drag = rotate camera, pinch = zoom
- Keyboard button (top right) toggles the soft keyboard; Back = Esc

## Server
Launcher screen: host, ports, world, UI size. Defaults to test.2009scape.org.
