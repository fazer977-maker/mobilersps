package rt4;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Rainbow Scape Studio pickers (hair, beard, torso, arms, wrists, legs, feet), game-thread side.
 *
 * The app asks with ::hairpick2 while the Studio is open; the server answers with hidden chat lines:
 *   ~hp~S|iface|gender                                start
 *   ~hp~R|row|count|prevComp|rowComp|colourSlot       a body row (0 hair .. 6 feet)
 *   ~hp~E|idx,kit,hit,C:Name;...                      its options (C = S/M/L/U/A hair groups, - none)
 *   ~hp~C|slot|comp,colourIndex;...                   colour swatches for a colour slot (0 hair .. 4 skin)
 *   ~hp~D                                             end
 * The app draws the pickers; this class draws the previews with the game's own renderer (game thread)
 * and sends taps back as ordinary Studio button clicks.
 */
public final class HairPicker {
    private HairPicker() {}

    public static final String TAG = "~hp~";
    public static final int ROWS = 7;
    public static final String[] ROW_NAME = {"HAIR", "BEARD", "TORSO", "ARMS", "WRISTS", "LEGS", "FEET"};

    public static final class Entry {
        public final int idx, kit, hit;
        public final char cat;
        public final String name;
        public Entry(int idx, int kit, int hit, char cat, String name) { this.idx = idx; this.kit = kit; this.hit = hit; this.cat = cat; this.name = name; }
    }

    public static final class Row {
        public final int row, prevComp, rowComp, colourSlot;
        public final Entry[] entries;
        Row(int row, int prevComp, int rowComp, int colourSlot, Entry[] entries) { this.row = row; this.prevComp = prevComp; this.rowComp = rowComp; this.colourSlot = colourSlot; this.entries = entries; }
    }

    // ---- published to the app (read on the UI thread)
    public static volatile Row[] rows = new Row[ROWS];
    public static volatile int listGender = -1;          // 0 male, 1 female
    public static volatile int listVersion = 0;
    public static volatile int[][] colourHit = new int[5][0];
    public static volatile int[][] colourIdx = new int[5][0];
    public static volatile int[][] colourRgb = new int[5][0];
    public static final int[] curKit = new int[ROWS];    // what the character wears in each row right now (-1 = hidden by gear)
    public static final int[] curColour = new int[5];
    public static volatile int curGender = -1;
    /** where each row's "Browse" button goes, in game-canvas pixels; pillW[r] == 0 means hidden */
    public static final int[] pillX = new int[ROWS], pillY = new int[ROWS], pillW = new int[ROWS], pillH = new int[ROWS];
    /** set by the app while a picker is on screen, and for which row */
    public static volatile boolean pickerOpen;
    public static volatile int pickerRow = 0;

    // ---- previews: the app asks, the game thread draws
    public static final int THUMB = 224;                 // output size (drawn at 2x, then smoothed down)
    public static final ConcurrentHashMap<String, int[]> thumbs = new ConcurrentHashMap<String, int[]>();
    private static final ConcurrentLinkedQueue<Integer> wanted = new ConcurrentLinkedQueue<Integer>();
    private static final ConcurrentHashMap<Integer, Boolean> wantedSet = new ConcurrentHashMap<Integer, Boolean>();
    private static final ConcurrentLinkedQueue<Integer> clicks = new ConcurrentLinkedQueue<Integer>();

    // ---- big preview (spins)
    public static volatile int bigKit = -1, bigYaw = 0, bigW = 300, bigH = 360;
    public static volatile int[] bigPixels;
    public static volatile int bigPixW, bigPixH;
    public static volatile int bigSeq;
    private static String bigKey = "";

    // ---- framing per row: centre height, half size shown (model units), camera pitch, yaw
    private static final int[][] FRAME = {
        {-180, 25, 72, 210},   // hair: head
        {-170, 22, 40, 230},   // beard: face
        {-134, 46, 50, 200},   // torso
        {-122, 58, 50, 200},   // arms
        {-102, 44, 60, 230},   // wrists
        {-58, 64, 40, 200},    // legs
        {-12, 32, 100, 200},   // feet, from above
    };

    // ---- building a list
    private static int buildGender, buildIface;
    private static Row[] bRows = new Row[ROWS];
    private static int bRow = -1, bCount, bPrev, bRowComp, bSlot;
    private static final java.util.ArrayList<Entry> building = new java.util.ArrayList<Entry>();
    private static int[][] bHit = new int[5][0], bIdx = new int[5][0];
    private static int iface = -1;
    private static long lastAsk;
    private static int asks;
    private static boolean wasOpen;
    private static volatile String[] rowLooks = new String[ROWS];

    /** key for a preview of `kit` in row `row`, with everything else as the character looks now */
    public static String key(int row, int kit) {
        String[] rl = rowLooks;
        return row + ":" + kit + ":" + (rl[row] == null ? "" : rl[row]);
    }

    public static void want(int row, int kit) {
        int k = (row << 24) | (kit & 0xFFFFFF);
        if (wantedSet.putIfAbsent(k, Boolean.TRUE) == null) wanted.add(k);
    }

    public static void click(int componentId) { clicks.add(componentId); }

    public static Row row(int r) {
        Row[] rs = rows;
        return r >= 0 && r < rs.length ? rs[r] : null;
    }

    // ------------------------------------------------------------------ chat lines
    private static void finishRow() {
        if (bRow >= 0 && bRow < ROWS) bRows[bRow] = new Row(bRow, bPrev, bRowComp, bSlot, building.toArray(new Entry[0]));
        building.clear();
        bRow = -1;
    }

    /** true if the line was a picker line (never shown in chat). Game thread. */
    public static boolean handle(JagString msg) {
        if (msg == null) return false;
        String s = msg.toString();
        if (!s.startsWith(TAG)) return false;
        try {
            String body = s.substring(TAG.length());
            char t = body.charAt(0);
            String rest = body.length() > 2 ? body.substring(2) : "";
            if (t == 'S') {
                String[] p = rest.split("\\|");
                buildIface = Integer.parseInt(p[0].trim());
                buildGender = Integer.parseInt(p[1].trim());
                bRows = new Row[ROWS];
                building.clear();
                bRow = -1;
                bHit = new int[5][0]; bIdx = new int[5][0];
            } else if (t == 'R') {
                finishRow();
                String[] p = rest.split("\\|");
                bRow = Integer.parseInt(p[0].trim());
                bCount = Integer.parseInt(p[1].trim());
                bPrev = Integer.parseInt(p[2].trim());
                bRowComp = Integer.parseInt(p[3].trim());
                bSlot = Integer.parseInt(p[4].trim());
            } else if (t == 'E') {
                for (String e : rest.split(";")) {
                    String[] f = e.split(",", 4);
                    if (f.length < 4) continue;
                    String cn = f[3];
                    boolean hasCat = cn.length() > 1 && cn.charAt(1) == ':';
                    char cat = hasCat ? cn.charAt(0) : '-';
                    String name = hasCat ? cn.substring(2) : cn;
                    building.add(new Entry(Integer.parseInt(f[0].trim()), Integer.parseInt(f[1].trim()), (buildIface << 16) | Integer.parseInt(f[2].trim()), cat, name));
                }
            } else if (t == 'C') {
                finishRow();
                int bar = rest.indexOf('|');
                int slot = Integer.parseInt(rest.substring(0, bar).trim());
                if (slot < 0 || slot >= 5) return true;
                String[] parts = rest.substring(bar + 1).split(";");
                int[] h = new int[parts.length], ix = new int[parts.length];
                int n = 0;
                for (String e : parts) {
                    String[] f = e.split(",");
                    if (f.length < 2) continue;
                    h[n] = (buildIface << 16) | Integer.parseInt(f[0].trim());
                    ix[n] = Integer.parseInt(f[1].trim());
                    n++;
                }
                // a slot's colours may come over several lines: add to what we have
                int o = bHit[slot].length;
                int[] nh = java.util.Arrays.copyOf(bHit[slot], o + n), ni = java.util.Arrays.copyOf(bIdx[slot], o + n);
                System.arraycopy(h, 0, nh, o, n); System.arraycopy(ix, 0, ni, o, n);
                bHit[slot] = nh; bIdx[slot] = ni;
            } else if (t == 'D') {
                finishRow();
                int[][] rgb = new int[5][];
                for (int sl = 0; sl < 5; sl++) {
                    rgb[sl] = new int[bIdx[sl].length];
                    for (int i = 0; i < bIdx[sl].length; i++) rgb[sl][i] = colourRgb(sl, bIdx[sl][i]);
                }
                iface = buildIface;
                colourHit = bHit; colourIdx = bIdx; colourRgb = rgb;
                rows = bRows;
                listGender = buildGender;
                listVersion++;
            }
        } catch (RuntimeException ignored) {
        }
        return true;
    }

    private static int colourRgb(int slot, int idx) {
        try {
            short[] d = PlayerAppearance.destinationBodyColors[slot];
            if (idx < 0 || idx >= d.length) return 0x808080;
            return Rasteriser.palette[d[idx] & 0xFFFF] & 0xFFFFFF;
        } catch (RuntimeException e) {
            return 0x808080;
        }
    }

    // ------------------------------------------------------------------ every frame (game thread)
    public static void tick() {
        try {
            tick0();
        } catch (Throwable ignored) {
        }
    }

    private static int[] lastIdk;
    private static int[] lastCols;
    private static int[] lastExtras;

    private static void tick0() {
        boolean open = MobileLayout.studioOpen;
        if (!open) {
            if (wasOpen) {
                wasOpen = false;
                rows = new Row[ROWS];
                listGender = -1;
                listVersion++;
                for (int r = 0; r < ROWS; r++) pillW[r] = 0;
                asks = 0;
                clicks.clear();
            }
            return;
        }
        wasOpen = true;
        Player me = PlayerList.self;
        PlayerAppearance a = me == null ? null : me.appearance;
        if (a == null) return;
        int gender = a.gender ? 1 : 0;
        curGender = gender;
        int[] idk = a.studioIdentikit();
        int[] cols = a.studioColors();
        lastIdk = idk; lastCols = cols; lastExtras = a.extraKits;
        int base = gender == 1 ? 7 : 0;
        for (int r = 0; r < ROWS; r++) curKit[r] = -1;
        if (idk != null) {
            for (int slot : idk) {
                if ((slot & Integer.MIN_VALUE) == 0 || (slot & 0x40000000) != 0) continue;
                IdkType t = IdkTypeList.get(slot & 0x3FFFFFFF);
                if (t == null) continue;
                int r = t.feature - base;
                if (r >= 0 && r < ROWS) curKit[r] = slot & 0x3FFFFFFF;
            }
        }
        if (cols != null) for (int i = 0; i < 5 && i < cols.length; i++) curColour[i] = cols[i];

        // what each row's previews depend on: everything except that row's own choice
        String ex = extrasKey(a.extraKits), cs = cols == null ? "" : java.util.Arrays.toString(cols);
        String[] rl = new String[ROWS];
        boolean changed = false;
        String[] old = rowLooks;
        for (int r = 0; r < ROWS; r++) {
            StringBuilder b = new StringBuilder();
            b.append(gender).append(cs).append(ex);
            if (r == 0) b.append('b').append(curKit[1]);        // hair previews show the beard too
            else for (int q = 0; q < ROWS; q++) if (q != r) b.append('.').append(curKit[q]);
            rl[r] = b.toString();
            if (!rl[r].equals(old[r])) changed = true;
        }
        if (changed) {
            rowLooks = rl;
            wantedSet.clear();
            wanted.clear();
            // keep only previews that still match
            for (java.util.Iterator<String> it = thumbs.keySet().iterator(); it.hasNext(); ) {
                String k = it.next();
                int c1 = k.indexOf(':'), c2 = k.indexOf(':', c1 + 1);
                int r = Integer.parseInt(k.substring(0, c1));
                if (!k.substring(c2 + 1).equals(rl[r])) it.remove();
            }
        }

        // ask the server for the lists when they're missing or for the other gender
        long now = System.currentTimeMillis();
        if (listGender != gender && asks < 3 && now - lastAsk > 2500 && client.gameState == 30) {
            lastAsk = now;
            asks++;
            sendCommand("hairpick2");
        }

        // taps from the app
        Integer c;
        int sent = 0;
        while ((c = clicks.poll()) != null && sent < 4) {
            Protocol.outboundBuffer.p1isaac(10);
            Protocol.outboundBuffer.p4(c);
            sent++;
        }

        for (int r = 0; r < ROWS; r++) placePill(r);

        if (!pickerOpen) return;
        int pr = pickerRow;
        long t0 = System.nanoTime();
        if (bigKit >= 0) {
            String bk = pr + ":" + bigKit + ":" + bigYaw + ":" + bigW + "x" + bigH + ":" + rl[pr];
            if (!bk.equals(bigKey)) {
                int[] px = renderBig(pr, bigKit, bigYaw, bigW, bigH);
                if (px != null) {
                    bigKey = bk;
                    bigPixW = bigW; bigPixH = bigH;
                    bigPixels = px;
                    bigSeq++;
                }
            }
        }
        Integer k;
        int done = 0;
        java.util.ArrayList<Integer> later = null;
        while (done < 3 && System.nanoTime() - t0 < 9_000_000L && (k = wanted.poll()) != null) {
            int r = k >>> 24, kit = k & 0xFFFFFF;
            String key = key(r, kit);
            if (thumbs.containsKey(key)) continue;
            int[] px = renderThumb(r, kit);
            if (px == null) {
                if (later == null) later = new java.util.ArrayList<Integer>();
                later.add(k);   // models still downloading; try again next frame
                continue;
            }
            thumbs.put(key, px);
            done++;
        }
        if (later != null) wanted.addAll(later);
    }

    private static String extrasKey(int[] e) {
        if (e == null || e.length == 0) return "-";
        StringBuilder b = new StringBuilder();
        for (int x : e) b.append(x).append('.');
        return b.toString();
    }

    private static void sendCommand(String cmd) {
        JagString line = JagString.parse("::" + cmd);
        Protocol.outboundBuffer.p1isaac(ClientProt.CLIENT_CHEAT);
        Protocol.outboundBuffer.p1(line.length() - 1);
        Protocol.outboundBuffer.pjstr(line.substring(2));
    }

    /** a row's Browse button covers only its label box: from the left edge of the row's background
     *  stripe up to just before its "<" button (the row layer itself is as big as the window) */
    private static void placePill(int r) {
        Row row = row(r);
        if (iface < 0 || row == null || row.entries.length < 2) { pillW[r] = 0; return; }
        Component prev = InterfaceList.getComponent((iface << 16) | row.prevComp);
        Component rc = InterfaceList.getComponent((iface << 16) | row.rowComp);
        if (prev == null || rc == null || !shown(prev) || !shown(rc)) { pillW[r] = 0; return; }
        Component stripe = null;
        Component[] all = InterfaceList.components == null || iface >= InterfaceList.components.length ? null : InterfaceList.components[iface];
        if (all != null) {
            for (Component k : all) {
                if (k == null || k.overlayer != rc.id || k.type != 3 || !k.filled) continue;
                if (stripe == null || k.x < stripe.x) stripe = k;
            }
        }
        if (stripe == null) { pillW[r] = 0; return; }
        int[] pa = abs(prev), sa = abs(stripe);
        if (pa == null || sa == null) { pillW[r] = 0; return; }
        int pad = Math.max(2, prev.height / 8);
        int x0 = sa[0] + pad, x1 = pa[0] - pad;
        if (x1 - x0 < 20) { pillW[r] = 0; return; }
        pillX[r] = x0; pillY[r] = sa[1] + pad; pillH[r] = stripe.height - 2 * pad; pillW[r] = x1 - x0;
    }

    private static boolean shown(Component c) {
        for (int i = 0; c != null && i < 32; i++) {
            if (c.hidden) return false;
            if (c.overlayer == -1) return true;
            c = InterfaceList.getComponent(c.overlayer);
        }
        return c == null;
    }

    private static int[] abs(Component c) {
        int x = 0, y = 0;
        for (int i = 0; c != null && i < 32; i++) {
            x += c.x; y += c.y;
            if (c.overlayer == -1) return new int[] {x, y};
            Component p = InterfaceList.getComponent(c.overlayer);
            if (p == null) return new int[] {x, y};
            x -= p.scrollX; y -= p.scrollY;
            c = p;
        }
        return null;
    }

    // ------------------------------------------------------------------ rendering
    private static RawModel combine(int[] kits, int[] cols) {
        RawModel[] ms = new RawModel[kits.length];
        int n = 0;
        for (int id : kits) {
            if (id < 0) continue;
            IdkType t = IdkTypeList.get(id);
            if (t == null) continue;
            if (!t.isBodyModelReady()) return null;
            RawModel m = t.getBodyModel();
            if (m != null) ms[n++] = m;
        }
        if (n == 0) return null;
        RawModel combined = new RawModel(ms, n);
        if (cols != null) {
            for (int s = 0; s < 5 && s < cols.length; s++) {
                if (PlayerAppearance.destinationBodyColors[s].length > cols[s]) combined.recolor(PlayerAppearance.sourceBodyColors[s], PlayerAppearance.destinationBodyColors[s][cols[s]]);
                if (PlayerAppearance.destinationSkinColors[s].length > cols[s]) combined.recolor(PlayerAppearance.sourceSkinColors[s], PlayerAppearance.destinationSkinColors[s][cols[s]]);
            }
        }
        return combined;
    }

    private static int[] withExtras(int[] base, int[] extras) {
        if (extras == null || extras.length == 0) return base;
        int[] out = java.util.Arrays.copyOf(base, base.length + extras.length);
        int n = base.length;
        for (int e : extras) {
            IdkType t = IdkTypeList.get(e);
            if (t != null && t.feature != 98) out[n++] = e;   // rainbow extras cycle colour; leave them out of still pictures
        }
        return java.util.Arrays.copyOf(out, n);
    }

    /** the character's kits with row `row` swapped for `kit` (hair previews: just hair + beard) */
    private static int[] kitsWith(int row, int kit) {
        if (row == 0) return new int[] {kit, curKit[1]};
        int[] out = new int[ROWS];
        for (int r = 0; r < ROWS; r++) out[r] = r == row ? kit : curKit[r];
        return out;
    }

    private static int[] renderThumb(int row, int kit) {
        RawModel m = combine(withExtras(kitsWith(row, kit), lastExtras), lastCols);
        if (m == null) return null;
        int S = 2, W = THUMB * S, H = THUMB * S;
        int[] f = FRAME[row];
        int[] px = draw(m, W, H, f[3], f[2], 0, f[0], f[1]);
        return px == null ? null : down(px, W, H, S);
    }

    private static int[] renderBig(int row, int kit, int yaw, int w, int h) {
        int[] kits;
        if (row == 0) {
            kits = new int[] {kit, curKit[1], curKit[2], curKit[3]};   // head and shoulders
        } else {
            kits = kitsWith(row, kit);
        }
        RawModel m = combine(withExtras(kits, lastExtras), lastCols);
        if (m == null) return null;
        int S = 2, W = w * S, H = h * S;
        int[] px = row <= 1 ? draw(m, W, H, yaw & 0x7FF, 60, 0, -166, 54) : draw(m, W, H, yaw & 0x7FF, 40, 0, -100, 112);
        return px == null ? null : down(px, W, H, S);
    }

    /** renders with the game's software renderer into a private buffer, like inventory icons; half = units shown above/below the centre */
    public static int[] draw(RawModel raw, int W, int H, int yaw, int pitch, int cx, int cy, int half) {
        SoftwareModel model = new SoftwareModel(raw, 64, 850, -30, -50, -30);
        int[] savedPx = SoftwareRaster.pixels;
        int savedW = SoftwareRaster.width, savedH = SoftwareRaster.height;
        int[] clip = new int[4];
        SoftwareRaster.saveClip(clip);
        boolean jag = Rasteriser.jagged;
        int[] out = new int[W * H];
        try {
            SoftwareRaster.setSize(out, W, H);
            Rasteriser.prepare();
            Rasteriser.setBounds(W / 2, H / 2);
            Rasteriser.jagged = false;
            int zoom = Math.max(40, half * 512 / (H / 2));
            // the renderer cuts off anything very close to the camera, so for close-ups make the model
            // bigger and keep the camera back instead of moving it in
            if (zoom < 220) {
                int f = (220 + zoom - 1) / zoom;
                raw.resize(128 * f, 128 * f, 128 * f);
                zoom *= f; cx *= f; cy *= f;
                model = new SoftwareModel(raw, 64, 850, -30, -50, -30);
            }
            int s = MathUtils.sin[pitch] * zoom >> 16, c = MathUtils.cos[pitch] * zoom >> 16;
            model.setCamera(yaw, 0, pitch, -cx, s - cy, c, -1L);
        } catch (RuntimeException e) {
            out = null;
        } finally {
            SoftwareRaster.setSize(savedPx, savedW, savedH);
            SoftwareRaster.restoreClip(clip);
            Rasteriser.prepare();
            Rasteriser.jagged = jag;
        }
        return out;
    }

    /** S x S box filter down to the output size, with alpha (0 = empty) so edges are smooth */
    public static int[] down(int[] src, int W, int H, int S) {
        int w = W / S, h = H / S, n = S * S;
        int[] out = new int[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int r = 0, g = 0, b = 0, cnt = 0;
                for (int dy = 0; dy < S; dy++) {
                    int row = (y * S + dy) * W + x * S;
                    for (int dx = 0; dx < S; dx++) {
                        int p = src[row + dx];
                        if (p == 0) continue;
                        r += (p >> 16) & 0xFF; g += (p >> 8) & 0xFF; b += p & 0xFF; cnt++;
                    }
                }
                if (cnt == 0) continue;
                int al = cnt * 255 / n;
                out[y * w + x] = (al << 24) | ((r / cnt) << 16) | ((g / cnt) << 8) | (b / cnt);
            }
        }
        return out;
    }
}
