package com.jogamp.opengl;
public class GL2GL3 { public static final int GL_SRC1_ALPHA = 0x8589; }
