package app.rsps2009;

import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import com.jogamp.opengl.EglBackend;
import shim.platform.Platforms;

/** EGL (ES2) context + window surface for gl4es, driven from the client thread. */
public class AndroidEglBackend implements EglBackend {
    private final GpuView view;
    private EGLDisplay dpy = EGL14.EGL_NO_DISPLAY;
    private EGLContext ctx = EGL14.EGL_NO_CONTEXT;
    private EGLSurface surf = EGL14.EGL_NO_SURFACE;
    private EGLConfig cfg;

    public AndroidEglBackend(GpuView v) { view = v; }

    private static void log(String s) { Platforms.error("EGL: " + s, null); }

    @Override public boolean create(int samples) {
        try {
            long end = System.currentTimeMillis() + 8000;
            while (view.surface == null || !view.surface.isValid()) {
                if (System.currentTimeMillis() > end) { log("no surface"); return false; }
                Thread.sleep(20);
            }
            dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
            int[] ver = new int[2];
            EGL14.eglInitialize(dpy, ver, 0, ver, 1);
            EGLConfig[] cfgs = new EGLConfig[1];
            int[] n = new int[1];
            int[] attr = {
                EGL14.EGL_RENDERABLE_TYPE, 4 /*ES2*/, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT,
                EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_DEPTH_SIZE, 24, EGL14.EGL_STENCIL_SIZE, 8,
                EGL14.EGL_SAMPLE_BUFFERS, samples > 1 ? 1 : 0, EGL14.EGL_SAMPLES, samples > 1 ? samples : 0,
                EGL14.EGL_NONE };
            if (!EGL14.eglChooseConfig(dpy, attr, 0, cfgs, 0, 1, n, 0) || n[0] < 1) {
                attr[attr.length - 6] = 0; attr[attr.length - 4] = 0; attr[attr.length - 3] = 0; // retry without MSAA
                attr[attr.length - 5] = EGL14.EGL_SAMPLE_BUFFERS; attr[attr.length - 4] = 0;
                int[] a2 = {
                    EGL14.EGL_RENDERABLE_TYPE, 4, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT,
                    EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
                    EGL14.EGL_DEPTH_SIZE, 16, EGL14.EGL_NONE };
                if (!EGL14.eglChooseConfig(dpy, a2, 0, cfgs, 0, 1, n, 0) || n[0] < 1) { log("no config"); return false; }
            }
            cfg = cfgs[0];
            ctx = EGL14.eglCreateContext(dpy, cfg, EGL14.EGL_NO_CONTEXT, new int[] { EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE }, 0);
            surf = EGL14.eglCreateWindowSurface(dpy, cfg, view.surface, new int[] { EGL14.EGL_NONE }, 0);
            if (ctx == EGL14.EGL_NO_CONTEXT || surf == EGL14.EGL_NO_SURFACE) { log("create failed " + EGL14.eglGetError()); return false; }
            log("created ok");
            return true;
        } catch (Throwable t) { Platforms.error("EGL create", t); return false; }
    }
    @Override public boolean makeCurrent() {
        boolean ok = EGL14.eglMakeCurrent(dpy, surf, surf, ctx);
        if (!ok) log("makeCurrent failed " + EGL14.eglGetError());
        return ok;
    }
    @Override public void release() { EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT); }
    private int frame;
    private void diag() {
        try {
            com.jogamp.opengl.GL2 gl = (com.jogamp.opengl.GL2) com.jogamp.opengl.GLContext.getCurrentGL();
            int[] wh = new int[2];
            EGL14.eglQuerySurface(dpy, surf, EGL14.EGL_WIDTH, wh, 0);
            EGL14.eglQuerySurface(dpy, surf, EGL14.EGL_HEIGHT, wh, 1);
            java.nio.ByteBuffer bb = java.nio.ByteBuffer.allocateDirect(4).order(java.nio.ByteOrder.nativeOrder());
            StringBuilder sb = new StringBuilder("GPU diag frame " + frame + " surface " + wh[0] + "x" + wh[1] + " pixels:");
            for (int i = 1; i <= 5; i++) {
                bb.clear();
                gl.glReadPixels(wh[0] * i / 6, wh[1] / 2, 1, 1, 0x1908, 0x1401, bb);
                sb.append(String.format(" %02x%02x%02x%02x", bb.get(0) & 255, bb.get(1) & 255, bb.get(2) & 255, bb.get(3) & 255));
            }
            log(sb.toString());
        } catch (Throwable t) { Platforms.error("diag failed", t); }
    }
    @Override public void swap() {
        frame++;
        if (frame == 120 || frame == 600) diag();
        if (frame >= 300 && frame < 360) {
            try {
                com.jogamp.opengl.GL2 gl = (com.jogamp.opengl.GL2) com.jogamp.opengl.GLContext.getCurrentGL();
                gl.glClearColor(1f, 0f, 1f, 1f);
                gl.glClear(0x4000);
            } catch (Throwable t) { }
        }
        EGL14.eglSwapBuffers(dpy, surf);
    }
    @Override public void destroy() {
        try {
            release();
            if (surf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, surf);
            if (ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ctx);
        } catch (Throwable ignored) { }
        surf = EGL14.EGL_NO_SURFACE; ctx = EGL14.EGL_NO_CONTEXT;
    }
}
