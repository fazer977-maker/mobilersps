package rt4;

/** Visual extras set from the launcher settings (read by the GPU renderer). */
public final class FxConfig {
	/** 0 off, 1 warm, 2 cool, 3 sunset, 4 moonlight */
	public static volatile int look = 0;
	/** time of day: 0 off, 1 morning, 2 midday, 3 evening, 4 night, 5 auto cycle */
	public static volatile int tod = 0;
	public static volatile boolean skybox = true, nightGlow = true;
	public static volatile boolean softShadows = false;
	public static volatile boolean sway = false;
	public static volatile boolean bloom = false, dof = false, vignette = false;
	/** set when the big world 3D view starts; the screen effects then run once, right after it finishes */
	public static volatile boolean armGrade = false, armPost = false;
	private FxConfig() {
	}
}
