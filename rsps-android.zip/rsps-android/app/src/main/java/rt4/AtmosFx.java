package rt4;

import com.jogamp.opengl.GL2;

/**
 * World-space atmosphere for the GPU renderer, drawn inside the scene right after the map's own lights:
 *  - soft light pools on the ground under every map light (lamps, fires, lanterns) at night,
 *  - fireflies at night and slow drifting motes by day,
 * plus per-frame tints that follow the time of day:
 *  - water colour and glints reflect the sky,
 *  - shadow colour and strength change (cool and soft at night, warm in the evening).
 * Any GL trouble switches the drawing off.
 */
public final class AtmosFx {
	private static boolean broken, waterTouched;
	private static final float[] mv = new float[16];
	private static final SkyBox.Batch batch = new SkyBox.Batch(160);

	// morning, midday, evening, night
	private static final float[][] WATER = {{0.20F, 0.19F, 0.27F}, {0.06F, 0.22F, 0.36F}, {0.28F, 0.13F, 0.17F}, {0.015F, 0.035F, 0.09F}};
	private static final float[][] WSPEC = {{0.30F, 0.22F, 0.20F, 0.22F}, {0.28F, 0.28F, 0.28F, 0.22F}, {0.45F, 0.25F, 0.12F, 0.35F}, {0.14F, 0.16F, 0.28F, 0.25F}};
	private static final float[] WATER0 = {0.073F, 0.169F, 0.24F};
	private static final float[] WSPEC0 = {0.1F, 0.1F, 0.15F, 0.1F};
	private static final float[][] SHADOW = {{0.06F, 0.03F, 0.10F, 0.85F}, {0.0F, 0.0F, 0.04F, 1.0F}, {0.12F, 0.02F, 0.09F, 0.90F}, {0.0F, 0.02F, 0.10F, 0.55F}};

	private AtmosFx() {
	}

	private static float hash(int x, int y, int s) {
		int h = x * 374761393 + y * 668265263 + s * 1442695041;
		h = (h ^ (h >>> 13)) * 1274126177;
		h ^= h >>> 16;
		return (h & 0xFFFF) / 65535.0F;
	}

	private static float mixk(float[][] k, int c, int k0, int k1, float f) {
		return k[k0][c] + (k[k1][c] - k[k0][c]) * f;
	}

	/** Colour and alpha for shadows at the current time of day, or null when time of day is off. */
	public static float[] shadowTint() {
		float pos = ColorGrade.todPos();
		if (pos < 0.0F) {
			return null;
		}
		int k0 = ((int) Math.floor(pos)) & 3, k1 = (k0 + 1) & 3;
		float f = pos - (float) Math.floor(pos);
		f = f * f * (3.0F - 2.0F * f);
		float oc = Weather.overcast();
		return new float[]{mixk(SHADOW, 0, k0, k1, f), mixk(SHADOW, 1, k0, k1, f), mixk(SHADOW, 2, k0, k1, f), mixk(SHADOW, 3, k0, k1, f) * (1.0F - 0.45F * oc)};
	}

	/** Water takes the colour of the sky (and the glint colour of sun or moon). */
	private static void updateWater() {
		float pos = ColorGrade.todPos();
		if (pos < 0.0F) {
			if (waterTouched) {
				for (int c = 0; c < 3; c++) {
					WaterMaterialRenderer.waterColor[c] = WATER0[c];
				}
				for (int c = 0; c < 4; c++) {
					WaterMaterialRenderer.waterSpecularColor[c] = WSPEC0[c];
				}
				waterTouched = false;
			}
			return;
		}
		int k0 = ((int) Math.floor(pos)) & 3, k1 = (k0 + 1) & 3;
		float f = pos - (float) Math.floor(pos);
		f = f * f * (3.0F - 2.0F * f);
		float oc = Weather.overcast();
		float lum = 0.15F + 0.85F * (1.0F - ColorGrade.nightAmount());
		for (int c = 0; c < 3; c++) {
			float target = mixk(WATER, c, k0, k1, f);
			target += (0.30F * lum - target) * oc * 0.6F;
			WaterMaterialRenderer.waterColor[c] = WATER0[c] * 0.4F + target * 0.6F;
		}
		for (int c = 0; c < 4; c++) {
			WaterMaterialRenderer.waterSpecularColor[c] = mixk(WSPEC, c, k0, k1, f) * (c == 3 ? 1.0F : 1.0F - 0.4F * oc);
		}
		waterTouched = true;
	}

	/** Called inside the scene (world coordinates) right after the map lights have been drawn. */
	public static void drawWorld(GL2 gl) {
		if (!GlRenderer.enabled || broken) {
			return;
		}
		int us = -1;
		try {
			updateWater();
			float night = ColorGrade.nightAmount();
			float pos = ColorGrade.todPos();
			if (!FxConfig.ambient || pos < 0.0F) {
				return;
			}
			boolean pools = night > 0.03F && LightingManager.lights != null;
			us = FxGl.enter(gl);
			draw(gl, night, pools);
		} catch (Throwable t) {
			broken = true;
			FxGl.recover(gl);
			shim.platform.Platforms.error("ATMOS failed: " + t, t);
		} finally {
			FxGl.leave(gl, us);
		}
	}

	private static void quad(float cx, float cy, float cz, float rx, float ry, float rz, float ux, float uy, float uz, float r, float g, float b, float a) {
		batch.vert(cx - rx - ux, cy - ry - uy, cz - rz - uz, 0, 0, r, g, b, a);
		batch.vert(cx + rx - ux, cy + ry - uy, cz + rz - uz, 1, 0, r, g, b, a);
		batch.vert(cx + rx + ux, cy + ry + uy, cz + rz + uz, 1, 1, r, g, b, a);
		batch.vert(cx - rx + ux, cy - ry + uy, cz - rz + uz, 0, 1, r, g, b, a);
		batch.quadIdx();
	}

	private static void draw(GL2 gl, float night, boolean pools) {
		SkyBox.ensureInit(gl);
		int plane = Player.plane;
		int px = PlayerList.self.xFine, py = PlayerList.self.yFine;
		batch.clear();
		int maxQuads = 150;
		// --- light pools: a flat additive disc on the ground under each light
		if (pools) {
			int lim = 26 * 128;
			for (int i = 0; i < LightingManager.lightCount && batch.n < 60; i++) {
				Light l = LightingManager.lights[i];
				if (l == null || l.level != plane) {
					continue;
				}
				int dx = l.x - px, dy = l.y - py;
				if (dx > lim || dx < -lim || dy > lim || dy < -lim) {
					continue;
				}
				int tx = l.x >> 7, ty = l.y >> 7;
				if (tx < LightingManager.visibleMinX || tx >= LightingManager.visibleMaxX || ty < LightingManager.visibleMinY || ty >= LightingManager.visibleMaxY) {
					continue;
				}
				float gy = SceneGraph.getTileHeight(l.level, l.x, l.y) - 6.0F;
				int col = l.color;
				float cr = (col >> 16 & 0xFF) / 255.0F, cg = (col >> 8 & 0xFF) / 255.0F, cb = (col & 0xFF) / 255.0F;
				float m = Math.max(0.2F, Math.max(cr, Math.max(cg, cb)));
				cr = Math.min(1.0F, cr / m);
				cg = Math.min(1.0F, cg / m);
				cb = Math.min(1.0F, cb / m);
				float fl = Math.max(0.35F, Math.min(1.0F, l.alpha));
				float h = Math.max(1.5F, l.radius) * 128.0F * 0.85F;
				quad(l.x, gy, l.y, h, 0, 0, 0, 0, h, cr, cg, cb, 0.55F * night * fl);
			}
		}
		// --- fireflies at night, drifting motes by day
		float t = System.currentTimeMillis() / 1000.0F;
		gl.glGetFloatv(2982, mv, 0);
		float rx = mv[0], ry = mv[4], rz = mv[8], ux = mv[1], uy = mv[5], uz = mv[9];
		int cell = 384, cx0 = (px / cell) - 11, cy0 = (py / cell) - 11;
		float density = 0.035F + 0.045F * night;
		for (int cx = cx0; cx <= cx0 + 22 && batch.n < maxQuads; cx++) {
			for (int cy = cy0; cy <= cy0 + 22 && batch.n < maxQuads; cy++) {
				if (hash(cx, cy, 1) > density) {
					continue;
				}
				float ph = hash(cx, cy, 2) * 6.2832F;
				float wx = cx * cell + hash(cx, cy, 3) * cell + 70.0F * (float) Math.sin(t * 0.45F + ph);
				float wy = cy * cell + hash(cx, cy, 4) * cell + 70.0F * (float) Math.cos(t * 0.38F + ph * 1.3F);
				if (wx < 0 || wy < 0) {
					continue;
				}
				float ground = SceneGraph.getTileHeight(plane, (int) wx, (int) wy);
				float hgt = 50.0F + hash(cx, cy, 5) * 170.0F + 18.0F * (float) Math.sin(t * 0.9F + ph);
				float blink = (float) Math.sin(t * (1.1F + hash(cx, cy, 6)) + ph);
				blink = Math.max(0.0F, blink);
				blink *= blink;
				float s;
				float r, g, b, a;
				if (night > 0.25F) {
					s = 11.0F + 5.0F * hash(cx, cy, 7);
					r = 0.75F;
					g = 1.0F;
					b = 0.35F;
					a = (0.25F + 0.75F * blink) * Math.min(1.0F, night * 1.3F);
				} else {
					s = 6.0F + 3.0F * hash(cx, cy, 7);
					r = 1.0F;
					g = 0.98F;
					b = 0.85F;
					a = 0.30F * (0.4F + 0.6F * blink) * (1.0F - night * 3.0F);
				}
				if (a <= 0.02F) {
					continue;
				}
				quad(wx, ground - hgt, wy, rx * s, ry * s, rz * s, ux * s, uy * s, uz * s, r, g, b, a);
			}
		}
		if (batch.n == 0) {
			return;
		}
		// state for additive soft sprites that are depth-tested but do not write depth
		gl.glClientActiveTexture(GL2.GL_TEXTURE0);
		MaterialManager.setMaterial(0, 0);
		GlRenderer.setTextureCombineRgbMode(0);
		GlRenderer.setLightingEnabled(false);
		GlRenderer.disableDepthMask();
		GlRenderer.setDepthTestEnabled(true);
		GlRenderer.setDepthLayer(201.5F - (float) plane * 50.0F - 1.8F);
		GlRenderer.setTextureId(SkyBox.glowTex());
		gl.glDisable(GL2.GL_CULL_FACE);
		gl.glEnable(GL2.GL_BLEND);
		gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE);
		gl.glDisableClientState(GL2.GL_NORMAL_ARRAY);
		GlRenderer.normalArrayEnabled = false;
		gl.glEnableClientState(GL2.GL_VERTEX_ARRAY);
		gl.glEnableClientState(GL2.GL_COLOR_ARRAY);
		gl.glEnableClientState(GL2.GL_TEXTURE_COORD_ARRAY);
		if (GlRenderer.arbVboSupported) {
			gl.glBindBuffer(GL2.GL_ARRAY_BUFFER, 0);
			gl.glBindBuffer(GL2.GL_ELEMENT_ARRAY_BUFFER, 0);
		}
		batch.flush(gl);
		gl.glEnable(GL2.GL_CULL_FACE);
		gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
		gl.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		GlRenderer.enableDepthMask();
		GlRenderer.restoreLighting();
		GlRenderer.normalizeModelState();
	}

	// ======================================================================================== per-entity effects (called from Loc.render)

	private static boolean basisOk, fountainDrawn;
	private static float bRx, bRy, bRz, bUx, bUy, bUz;
	private static final SkyBox.Batch solid = new SkyBox.Batch(300), spark = new SkyBox.Batch(110);
	private static boolean loggedFountain;

	/** Called once at the start of each world frame. */
	public static void beginFrame() {
		basisOk = false;
		fountainDrawn = false;
	}

	private static void basis(GL2 gl) {
		if (!basisOk) {
			gl.glGetFloatv(2982, mv, 0);
			bRx = mv[0];
			bRy = mv[4];
			bRz = mv[8];
			bUx = mv[1];
			bUy = mv[5];
			bUz = mv[9];
			basisOk = true;
		}
	}

	private static void begin(GL2 gl, boolean additive) {
		SkyBox.ensureInit(gl);
		MaterialManager.setMaterial(0, 0);
		GlRenderer.setTextureCombineRgbMode(0);
		GlRenderer.setLightingEnabled(false);
		if (additive) {
			GlRenderer.disableDepthMask();
		} else {
			GlRenderer.enableDepthMask();
		}
		GlRenderer.setDepthTestEnabled(true);
		GlRenderer.setTextureId(SkyBox.glowTex());
		gl.glClientActiveTexture(GL2.GL_TEXTURE0);
		gl.glDisable(GL2.GL_CULL_FACE);
		if (additive) {
			gl.glEnable(GL2.GL_BLEND);
			gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE);
		} else {
			gl.glDisable(GL2.GL_BLEND);
		}
		gl.glDisableClientState(GL2.GL_NORMAL_ARRAY);
		GlRenderer.normalArrayEnabled = false;
		gl.glEnableClientState(GL2.GL_VERTEX_ARRAY);
		gl.glEnableClientState(GL2.GL_COLOR_ARRAY);
		gl.glEnableClientState(GL2.GL_TEXTURE_COORD_ARRAY);
		if (GlRenderer.arbVboSupported) {
			gl.glBindBuffer(GL2.GL_ARRAY_BUFFER, 0);
			gl.glBindBuffer(GL2.GL_ELEMENT_ARRAY_BUFFER, 0);
		}
	}

	private static void end(GL2 gl) {
		gl.glEnable(GL2.GL_CULL_FACE);
		gl.glEnable(GL2.GL_BLEND);
		gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
		gl.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		GlRenderer.enableDepthMask();
		GlRenderer.restoreLighting();
		GlRenderer.normalizeModelState();
	}

	/** A glowing lamp at night: warm halo at the lamp head and a pool of light on the ground. Coordinates are relative to the camera. */
	public static void lampGlow(int x, int h, int y) {
		if (broken || !FxConfig.ambient) {
			return;
		}
		float amt = ColorGrade.nightAmount();
		if (amt < 0.04F) {
			return;
		}
		int us = -1;
		try {
			float px = x, py = h - 175.0F, pz = y;
			float len = (float) Math.sqrt(px * px + py * py + pz * pz);
			if (len < 60.0F || len > 4500.0F) {
				return;
			}
			GL2 gl = GlRenderer.gl;
			us = FxGl.enter(gl);
			SkyBox.ensureInit(gl);
			basis(gl);
			float k = 110.0F / len; // pull the halo toward the camera so the lamp's own model does not hide half of it
			px -= px * k;
			py -= py * k;
			pz -= pz * k;
			float t = System.currentTimeMillis() / 1000.0F;
			float s = 175.0F * (0.88F + 0.12F * (float) Math.sin(t * 3.1F + x * 0.013F));
			batch.clear();
			quad(x, h - 10.0F, y, 320.0F, 0, 0, 0, 0, 320.0F, 1.0F, 0.78F, 0.40F, 0.38F * amt);
			quad(px, py, pz, bRx * s, bRy * s, bRz * s, bUx * s, bUy * s, bUz * s, 1.0F, 0.80F, 0.42F, 0.85F * amt);
			float c = s * 0.33F;
			quad(px, py, pz, bRx * c, bRy * c, bRz * c, bUx * c, bUy * c, bUz * c, 1.0F, 0.96F, 0.82F, 0.95F * amt);
			begin(gl, true);
			batch.flush(gl);
			end(gl);
		} catch (Throwable t) {
			broken = true;
			shim.platform.Platforms.error("LAMP failed: " + t, t);
		} finally {
			FxGl.leave(GlRenderer.gl, us);
		}
	}

	private static void rgbHue(float h, float[] out) {
		h = h - (float) Math.floor(h);
		float r = Math.max(0.0F, Math.min(1.0F, Math.abs(h * 6.0F - 3.0F) - 1.0F));
		float g = Math.max(0.0F, Math.min(1.0F, 2.0F - Math.abs(h * 6.0F - 2.0F)));
		float b = Math.max(0.0F, Math.min(1.0F, 2.0F - Math.abs(h * 6.0F - 4.0F)));
		out[0] = r;
		out[1] = g;
		out[2] = b;
	}

	private static void sq(SkyBox.Batch b, float x0, float y0, float z0, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3,
			float r0, float g0, float b0, float r1, float g1, float b1) {
		b.vert(x0, y0, z0, 0.5F, 0.5F, r0, g0, b0, 1.0F);
		b.vert(x1, y1, z1, 0.5F, 0.5F, r0, g0, b0, 1.0F);
		b.vert(x2, y2, z2, 0.5F, 0.5F, r1, g1, b1, 1.0F);
		b.vert(x3, y3, z3, 0.5F, 0.5F, r1, g1, b1, 1.0F);
		b.quadIdx();
	}

	// paw: x offset, z offset, half width, half depth (in K units), jet height, jet droplets
	private static final float[][] PAW = {{0.0F, 0.55F, 1.45F, 1.15F, 215.0F, 22}, {-2.05F, -0.95F, 0.62F, 0.78F, 130.0F, 10}, {-0.75F, -2.0F, 0.60F, 0.80F, 150.0F, 10},
			{0.75F, -2.0F, 0.60F, 0.80F, 150.0F, 10}, {2.05F, -0.95F, 0.62F, 0.78F, 130.0F, 10}};

	/** Replaces the fountain model with an animated paw-shaped fountain. Returns false if it could not draw (the normal model is then used). */
	public static boolean fountain(int x, int h, int y) {
		if (broken || !FxConfig.ambient) {
			return false;
		}
		if (fountainDrawn) {
			return true;
		}
		fountainDrawn = true;
		int us = -1;
		try {
			GL2 gl = GlRenderer.gl;
			us = FxGl.enter(gl);
			SkyBox.ensureInit(gl);
			basis(gl);
			float t = System.currentTimeMillis() / 1000.0F;
			float night = ColorGrade.nightAmount();
			float K = 112.0F, RH = 30.0F, WL = 22.0F;
			int SEG = 14;
			float[] hc = new float[3];
			solid.clear();
			spark.clear();
			for (int p = 0; p < PAW.length; p++) {
				float cx = x + PAW[p][0] * K, cz = y + PAW[p][1] * K, a = PAW[p][2] * K, b = PAW[p][3] * K;
				float yTop = h - RH, yWat = h - WL;
				for (int sg = 0; sg < SEG; sg++) {
					double a0 = Math.PI * 2.0 * sg / SEG, a1 = Math.PI * 2.0 * (sg + 1) / SEG;
					float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0), c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
					float ox0 = cx + a * c0, oz0 = cz + b * s0, ox1 = cx + a * c1, oz1 = cz + b * s1;
					float ix0 = cx + a * 0.80F * c0, iz0 = cz + b * 0.80F * s0, ix1 = cx + a * 0.80F * c1, iz1 = cz + b * 0.80F * s1;
					float shade = 0.72F + 0.28F * (float) Math.cos((a0 + a1) * 0.5 - 2.2);
					// outer wall, rim top, inner wall
					sq(solid, ox0, h, oz0, ox1, h, oz1, ox1, yTop, oz1, ox0, yTop, oz0, 0.50F * shade, 0.52F * shade, 0.62F * shade, 0.58F * shade, 0.60F * shade, 0.70F * shade);
					sq(solid, ox0, yTop, oz0, ox1, yTop, oz1, ix1, yTop, iz1, ix0, yTop, iz0, 0.74F, 0.76F, 0.86F, 0.74F, 0.76F, 0.86F);
					sq(solid, ix0, yTop, iz0, ix1, yTop, iz1, ix1, yWat, iz1, ix0, yWat, iz0, 0.30F, 0.33F, 0.44F, 0.22F, 0.26F, 0.38F);
					// water wedge: slow rainbow shimmer over blue, rippling toward the edge, glowing at night
					float ang = (float) ((a0 + a1) * 0.5);
					float rip = 0.5F + 0.5F * (float) Math.sin(t * 2.3F + ang * 3.0F + p * 1.7F);
					rgbHue(t * 0.05F + p * 0.11F + ang * 0.08F, hc);
					float gl2 = 1.0F + 0.9F * night;
					float er = Math.min(1.0F, (0.10F + 0.30F * hc[0] * 0.6F + 0.10F * rip) * gl2);
					float eg = Math.min(1.0F, (0.42F + 0.25F * hc[1] * 0.6F + 0.12F * rip) * gl2);
					float eb = Math.min(1.0F, (0.85F + 0.15F * hc[2] * 0.6F) * (0.9F + 0.1F * gl2));
					float cr = Math.min(1.0F, er + 0.25F), cg = Math.min(1.0F, eg + 0.25F), cb = Math.min(1.0F, eb + 0.1F);
					solid.vert(cx, yWat, cz, 0.5F, 0.5F, cr, cg, cb, 1.0F);
					solid.vert(ix0, yWat, iz0, 0.5F, 0.5F, er, eg, eb, 1.0F);
					solid.vert(ix1, yWat, iz1, 0.5F, 0.5F, er, eg, eb, 1.0F);
					solid.vert(ix1, yWat, iz1, 0.5F, 0.5F, er, eg, eb, 1.0F);
					solid.quadIdx();
				}
				// water jets: droplets thrown up in arcs
				int n = (int) PAW[p][5];
				float jh = PAW[p][4];
				for (int i = 0; i < n && spark.n < 100; i++) {
					float ph = t * 0.75F + i / (float) n + p * 0.137F;
					ph = ph - (float) Math.floor(ph);
					float ang = i * 2.39996F;
					float spread = a * 0.30F * (0.3F + (i % 3) * 0.35F) * ph * 2.0F;
					float hgt = jh * 4.0F * ph * (1.0F - ph);
					float sz = 9.0F + 7.0F * (1.0F - ph);
					float al = 0.45F + 0.4F * (float) Math.sin(Math.PI * ph);
					rgbHue(0.55F + 0.08F * (float) Math.sin(t * 0.3F + i), hc);
					float dx = cx + (float) Math.cos(ang) * spread, dz = cz + (float) Math.sin(ang) * spread * (b / a), dy = yWat - hgt;
					spark.vert(dx - bRx * sz - bUx * sz, dy - bRy * sz - bUy * sz, dz - bRz * sz - bUz * sz, 0, 0, 0.75F, 0.92F, 1.0F, al);
					spark.vert(dx + bRx * sz - bUx * sz, dy + bRy * sz - bUy * sz, dz + bRz * sz - bUz * sz, 1, 0, 0.75F, 0.92F, 1.0F, al);
					spark.vert(dx + bRx * sz + bUx * sz, dy + bRy * sz + bUy * sz, dz + bRz * sz + bUz * sz, 1, 1, 0.75F, 0.92F, 1.0F, al);
					spark.vert(dx - bRx * sz + bUx * sz, dy - bRy * sz + bUy * sz, dz - bRz * sz + bUz * sz, 0, 1, 0.75F, 0.92F, 1.0F, al);
					spark.quadIdx();
				}
				// ring of light on the water surface (soft glow disc)
				float rs = a * 1.05F;
				float ra = (0.10F + 0.35F * night) * (0.7F + 0.3F * (float) Math.sin(t * 1.6F + p));
				quadTo(spark, cx, yWat - 3.0F, cz, rs, 0, 0, 0, 0, rs * (b / a), 0.35F, 0.75F, 1.0F, ra);
			}
			// glow of the whole fountain at night
			if (night > 0.04F) {
				float s = 520.0F;
				quadTo(spark, x, h - 4.0F, y + 0.2F * K, s, 0, 0, 0, 0, s * 0.8F, 0.35F, 0.65F, 1.0F, 0.40F * night);
			}
			begin(gl, false);
			solid.flush(gl);
			begin(gl, true);
			spark.flush(gl);
			end(gl);
			if (!loggedFountain) {
				loggedFountain = true;
				shim.platform.Platforms.error("FOUNTAIN paw drawn at rel " + x + "," + h + "," + y, null);
			}
			return true;
		} catch (Throwable t) {
			broken = true;
			shim.platform.Platforms.error("FOUNTAIN failed: " + t, t);
			return false;
		} finally {
			FxGl.leave(GlRenderer.gl, us);
		}
	}

	private static void quadTo(SkyBox.Batch b, float cx, float cy, float cz, float rx, float ry, float rz, float ux, float uy, float uz, float r, float g, float bl, float a) {
		b.vert(cx - rx - ux, cy - ry - uy, cz - rz - uz, 0, 0, r, g, bl, a);
		b.vert(cx + rx - ux, cy + ry - uy, cz + rz - uz, 1, 0, r, g, bl, a);
		b.vert(cx + rx + ux, cy + ry + uy, cz + rz + uz, 1, 1, r, g, bl, a);
		b.vert(cx - rx + ux, cy - ry + uy, cz - rz + uz, 0, 1, r, g, bl, a);
		b.quadIdx();
	}
}
