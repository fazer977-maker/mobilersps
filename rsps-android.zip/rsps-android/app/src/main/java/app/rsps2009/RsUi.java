package app.rsps2009;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Typeface;

import rt4.RsFont;
import rt4.SoftwareFont;

/**
 * RuneScape-style interface drawing for native windows, in game pixels (drawn 1:1 into a small bitmap that is then
 * scaled up with no smoothing): the game's own fonts (p11, p12, b12 with their black shadow), stone textures, raised
 * and sunken bevels, stone buttons and pixel icons with a black outline.
 */
final class RsUi {
    // classic interface colours
    static final int ORANGE = 0xFFFF981F, YELLOW = 0xFFFFFF00, WHITE = 0xFFFFFFFF, GREEN = 0xFF00FF00, RED = 0xFFFF3030;
    static final int PARCH = 0xFFC8B9A0, GREY = 0xFF9A8D7A, DARK = 0xFF6B5D4B;

    private final Paint p = new Paint();               // no anti-aliasing: crisp game pixels
    private final Bitmap[] atlas = new Bitmap[3];
    private final int[] cellW = new int[3], cellH = new int[3];
    private int atlasVersion = -1;
    private final Rect src = new Rect(), dst = new Rect();
    private final Paint fallback = new Paint();
    private final Shader bgTex, panelTex, btnTex, btnHiTex;

    RsUi() {
        p.setAntiAlias(false); p.setFilterBitmap(false); p.setDither(false);
        fallback.setAntiAlias(false); fallback.setTypeface(Typeface.DEFAULT_BOLD);
        bgTex = tex(0x3E352A, 7, 11);
        panelTex = tex(0x2A231B, 5, 23);
        btnTex = tex(0x4D4236, 6, 37);
        btnHiTex = tex(0x5C4F40, 6, 41);
    }

    /** a 64 x 64 stone tile: base colour with grain and soft blotches */
    private static Shader tex(int base, int grain, int seed) {
        int n = 64;
        int[] px = new int[n * n];
        java.util.Random r = new java.util.Random(seed);
        float[] blot = new float[n * n];
        for (int k = 0; k < 14; k++) {
            int cx = r.nextInt(n), cy = r.nextInt(n), rad = 6 + r.nextInt(12);
            float amt = (r.nextFloat() - 0.5f) * 10f;
            for (int y = -rad; y <= rad; y++) for (int x = -rad; x <= rad; x++) {
                float dd = (float) Math.sqrt(x * x + y * y) / rad; if (dd > 1) continue;
                int xx = (cx + x + n) % n, yy = (cy + y + n) % n;
                blot[yy * n + xx] += amt * (1 - dd);
            }
        }
        int br = (base >> 16) & 255, bg = (base >> 8) & 255, bb = base & 255;
        for (int i = 0; i < n * n; i++) {
            int v = (int) (r.nextGaussian() * grain * 0.6f + blot[i]);
            px[i] = 0xFF000000 | (clamp(br + v) << 16) | (clamp(bg + v) << 8) | clamp(bb + v);
        }
        Bitmap b = Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888);
        return new BitmapShader(b, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
    }

    private static int clamp(int v) { return v < 0 ? 0 : v > 255 ? 255 : v; }

    // ------------------------------------------------------------------ fonts
    private boolean fontsReady() {
        if (!RsFont.ready) return false;
        if (atlasVersion == RsFont.version) return atlas[0] != null;
        atlasVersion = RsFont.version;
        try {
            for (int f = 0; f < 3; f++) {
                SoftwareFont sf = RsFont.fonts[f];
                int[] w = sf.exW(), h = sf.exH();
                byte[][] pix = sf.exPixels();
                int cw = 1, ch = 1;
                for (int i = 0; i < 256; i++) { cw = Math.max(cw, w[i]); ch = Math.max(ch, h[i]); }
                cellW[f] = cw; cellH[f] = ch;
                int[] a = new int[cw * 16 * ch * 16];
                for (int i = 0; i < 256; i++) {
                    if (pix[i] == null) continue;
                    int ox = (i % 16) * cw, oy = (i / 16) * ch;
                    for (int y = 0; y < h[i]; y++) for (int x = 0; x < w[i]; x++)
                        if (pix[i][y * w[i] + x] != 0) a[(oy + y) * cw * 16 + ox + x] = 0xFFFFFFFF;
                }
                atlas[f] = Bitmap.createBitmap(a, cw * 16, ch * 16, Bitmap.Config.ARGB_8888).extractAlpha();
            }
            return true;
        } catch (Throwable t) { atlas[0] = null; return false; }
    }

    private static int code(char ch) {
        if (ch < 256) return ch;
        return '?';
    }

    int width(int font, String s) {
        if (!fontsReady()) { fallback.setTextSize(font == RsFont.P11 ? 11 : 12); return (int) fallback.measureText(s); }
        SoftwareFont sf = RsFont.fonts[font];
        int[] adv = sf.exAdvance(); byte[] kern = sf.exKerning();
        int x = 0, prev = 0;
        for (int i = 0; i < s.length(); i++) {
            int ch = code(s.charAt(i));
            if (kern != null && prev != 0) x += kern[(prev << 8) + ch];
            x += adv[ch]; prev = ch;
        }
        return x;
    }

    int lineHeight(int font) { return font == RsFont.P11 ? 12 : 13; }

    /** text with its baseline at y; align 0 left, 1 centre, 2 right; shadow = black 1px down-right like the game */
    void text(Canvas c, int font, String s, int x, int y, int color, int align, boolean shadow) {
        if (align != 0) { int w = width(font, s); x -= align == 1 ? w / 2 : w; }
        if (!fontsReady()) {
            fallback.setTextSize(font == RsFont.P11 ? 11 : 12);
            fallback.setTypeface(font == RsFont.B12 ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            if (shadow) { fallback.setColor(0xFF000000); c.drawText(s, x + 1, y + 1, fallback); }
            fallback.setColor(color); c.drawText(s, x, y, fallback);
            return;
        }
        if (shadow) glyphs(c, font, s, x + 1, y + 1, 0xFF000000);
        glyphs(c, font, s, x, y, color);
    }

    private void glyphs(Canvas c, int font, String s, int x, int y, int color) {
        SoftwareFont sf = RsFont.fonts[font];
        int[] adv = sf.exAdvance(), xo = sf.exXOff(), yo = sf.exYOff(), w = sf.exW(), h = sf.exH();
        byte[] kern = sf.exKerning();
        int top = y - sf.lineHeight;
        p.setShader(null); p.setColor(color);
        int prev = 0;
        for (int i = 0; i < s.length(); i++) {
            int ch = code(s.charAt(i));
            if (kern != null && prev != 0) x += kern[(prev << 8) + ch];
            if (ch != 32 && w[ch] > 0) {
                int ox = (ch % 16) * cellW[font], oy = (ch / 16) * cellH[font];
                src.set(ox, oy, ox + w[ch], oy + h[ch]);
                dst.set(x + xo[ch], top + yo[ch], x + xo[ch] + w[ch], top + yo[ch] + h[ch]);
                c.drawBitmap(atlas[font], src, dst, p);
            }
            x += adv[ch]; prev = ch;
        }
    }

    /** word-wrapped text; returns the baseline after the last line */
    int wrap(Canvas c, int font, String s, int x, int y, int w, int color) {
        StringBuilder line = new StringBuilder();
        for (String wd : s.split(" ")) {
            String t = line.length() == 0 ? wd : line + " " + wd;
            if (width(font, t) > w && line.length() > 0) { text(c, font, line.toString(), x, y, color, 0, true); y += lineHeight(font); line = new StringBuilder(wd); }
            else line = new StringBuilder(t);
        }
        if (line.length() > 0) { text(c, font, line.toString(), x, y, color, 0, true); y += lineHeight(font); }
        return y;
    }

    // ------------------------------------------------------------------ shapes
    void fill(Canvas c, int x, int y, int w, int h, int color) { p.setShader(null); p.setColor(color); c.drawRect(x, y, x + w, y + h, p); }

    private void tex(Canvas c, Shader s, int x, int y, int w, int h) { p.setShader(s); p.setColor(0xFFFFFFFF); c.drawRect(x, y, x + w, y + h, p); p.setShader(null); }

    /** the window: black edge, light/dark bevel, stone inside */
    void window(Canvas c, int x, int y, int w, int h) {
        fill(c, x, y, w, h, 0xFF000000);
        fill(c, x + 1, y + 1, w - 2, h - 2, 0xFF5A4D3D);
        fill(c, x + 1, y + 1, w - 2, 1, 0xFF7A6A55); fill(c, x + 1, y + 1, 1, h - 2, 0xFF7A6A55);
        fill(c, x + 1, y + h - 2, w - 2, 1, 0xFF1E1912); fill(c, x + w - 2, y + 1, 1, h - 2, 0xFF1E1912);
        fill(c, x + 3, y + 3, w - 6, h - 6, 0xFF000000);
        tex(c, bgTex, x + 4, y + 4, w - 8, h - 8);
    }

    /** sunken panel */
    void inset(Canvas c, int x, int y, int w, int h) {
        tex(c, panelTex, x, y, w, h);
        fill(c, x, y, w, 1, 0xFF14100B); fill(c, x, y, 1, h, 0xFF14100B);
        fill(c, x, y + h - 1, w, 1, 0xFF5E5141); fill(c, x + w - 1, y, 1, h, 0xFF5E5141);
    }

    /** raised stone box (cells, slots, buttons) */
    void raised(Canvas c, int x, int y, int w, int h, boolean down, boolean bright) {
        fill(c, x, y, w, h, 0xFF000000);
        tex(c, bright ? btnHiTex : btnTex, x + 1, y + 1, w - 2, h - 2);
        int hi = down ? 0xFF231D16 : 0xFF7D6C57, lo = down ? 0xFF7D6C57 : 0xFF231D16;
        fill(c, x + 1, y + 1, w - 2, 1, hi); fill(c, x + 1, y + 1, 1, h - 2, hi);
        fill(c, x + 1, y + h - 2, w - 2, 1, lo); fill(c, x + w - 2, y + 1, 1, h - 2, lo);
    }

    void outline(Canvas c, int x, int y, int w, int h, int color) {
        fill(c, x, y, w, 1, color); fill(c, x, y + h - 1, w, 1, color); fill(c, x, y, 1, h, color); fill(c, x + w - 1, y, 1, h, color);
    }

    void button(Canvas c, int x, int y, int w, int h, String label, int color, boolean down) {
        raised(c, x, y, w, h, down, false);
        text(c, RsFont.P12, label, x + w / 2 + (down ? 1 : 0), y + h / 2 + 5 + (down ? 1 : 0), color, 1, true);
    }

    /** progress bar: black edge, dark track, green fill with a lighter top row */
    void bar(Canvas c, int x, int y, int w, int h, float f) {
        fill(c, x, y, w, h, 0xFF000000);
        fill(c, x + 1, y + 1, w - 2, h - 2, 0xFF3A1010);
        int fw = (int) ((w - 2) * Math.max(0f, Math.min(1f, f)));
        if (fw > 0) {
            fill(c, x + 1, y + 1, fw, h - 2, 0xFF2E8B22);
            fill(c, x + 1, y + 1, fw, 1, 0xFF56C443);
            fill(c, x + 1, y + h - 2, fw, 1, 0xFF1D5A15);
        }
    }

    /** pixel icon with a 1px black outline */
    void icon(Canvas c, String key, int cx, int cy, int size, int color) {
        if (key == null) return;
        p.setShader(null);
        Glyphs.draw(c, p, key, cx - 1, cy, size, 0xFF000000);
        Glyphs.draw(c, p, key, cx + 1, cy, size, 0xFF000000);
        Glyphs.draw(c, p, key, cx, cy - 1, size, 0xFF000000);
        Glyphs.draw(c, p, key, cx, cy + 1, size, 0xFF000000);
        Glyphs.draw(c, p, key, cx, cy, size, color);
    }

    /** tiny padlock, 7 x 8 */
    void lock(Canvas c, int x, int y) {
        fill(c, x, y + 3, 7, 5, 0xFF000000); fill(c, x + 1, y + 4, 5, 3, 0xFFB8A27E);
        fill(c, x + 1, y, 5, 1, 0xFF000000); fill(c, x + 1, y, 1, 4, 0xFF000000); fill(c, x + 5, y, 1, 4, 0xFF000000);
        fill(c, x + 2, y + 1, 3, 1, 0xFF8C7A5C);
    }
}
